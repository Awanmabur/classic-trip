async function scannerRequest(path, payload) {
  const response = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload || {}),
  });
  const data = await response.json().catch(() => ({ ok: false, message: 'Scanner response was not valid JSON' }));
  return { ...data, httpStatus: response.status, httpOk: response.ok };
}

async function lookupTicketValue(value) {
  return scannerRequest('/api/scanner/lookup', { qrCodeValue: value, bookingRef: value });
}

async function validateTicketValue(value, note) {
  return scannerRequest('/api/scanner/validate', { qrCodeValue: value, bookingRef: value, note });
}

async function markNoShowTicketValue(value, reason) {
  return scannerRequest('/api/scanner/no-show', { bookingRef: value, reason });
}
