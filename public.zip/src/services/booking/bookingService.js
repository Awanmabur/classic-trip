const store = require('../data/demoStore');
const { mongoose } = require('../../config/db');

function mongoReady() {
  return mongoose.connection.readyState === 1;
}

async function persistBooking(booking, payload, transactionStartIndex) {
  if (!mongoReady()) return;

  const Booking = require('../../models/Booking');
  const Seat = require('../../models/Seat');
  const TripSchedule = require('../../models/TripSchedule');
  const Room = require('../../models/Room');
  const WalletTransaction = require('../../models/WalletTransaction');
  const Wallet = require('../../models/Wallet');
  const Commission = require('../../models/Commission');

  await Booking.updateOne(
    { bookingRef: booking.bookingRef },
    { $set: booking },
    { upsert: true, runValidators: true }
  );

  const selectedInventory = booking.passengers?.[0]?.seatOrRoom;
  if (booking.serviceType === 'bus' && booking.scheduleId && selectedInventory) {
    await Seat.updateOne(
      { scheduleId: booking.scheduleId, seatNumber: selectedInventory },
      { $set: { status: 'taken', lockedUntil: null, lockId: null } }
    );
    await TripSchedule.updateOne({ id: booking.scheduleId }, { $inc: { availableSeats: -1 } });
  }

  if (booking.serviceType === 'hotel' && payload.roomId) {
    await Room.updateOne({ id: payload.roomId }, { $inc: { inventory: -1 } });
  }

  const newTransactions = store.state.walletTransactions.slice(transactionStartIndex);
  if (newTransactions.length) await WalletTransaction.insertMany(newTransactions, { ordered: false });

  const affectedWalletKeys = new Set(newTransactions.map((txn) => `${txn.ownerType}:${txn.ownerId}`));
  const affectedWallets = store.state.wallets.filter((wallet) => affectedWalletKeys.has(`${wallet.ownerType}:${wallet.ownerId}`));
  if (affectedWallets.length) {
    await Wallet.bulkWrite(affectedWallets.map((wallet) => ({
      updateOne: {
        filter: { ownerType: wallet.ownerType, ownerId: wallet.ownerId },
        update: { $set: wallet },
        upsert: true,
      },
    })));
  }

  const commissions = store.state.commissions.filter((commission) => commission.bookingId === booking.id);
  if (commissions.length) {
    await Commission.bulkWrite(commissions.map((commission) => ({
      updateOne: {
        filter: { id: commission.id },
        update: { $set: commission },
        upsert: true,
      },
    })));
  }
}

async function createGuestBooking(payload, req) {
  const transactionStartIndex = store.state.walletTransactions.length;
  const booking = store.createBooking(payload, req);
  await persistBooking(booking, payload, transactionStartIndex);
  const notificationService = require('../notification/notificationService');
  await notificationService.bookingConfirmed(booking);
  return booking;
}

async function persistCheckIn(booking) {
  if (!mongoReady() || !booking) return;
  const Booking = require('../../models/Booking');
  await Booking.updateOne(
    { bookingRef: booking.bookingRef },
    {
      $set: {
        bookingStatus: booking.bookingStatus,
        checkInStatus: booking.checkInStatus,
        checkedInAt: booking.checkedInAt,
        checkedInBy: booking.checkedInBy,
        checkedInByUserId: booking.checkedInByUserId,
        checkInNote: booking.checkInNote,
        noShowAt: booking.noShowAt,
        noShowBy: booking.noShowBy,
        noShowReason: booking.noShowReason,
      },
    }
  );
}

async function persistAudit(entry) {
  if (!mongoReady() || !entry) return;
  const AuditLog = require('../../models/AuditLog');
  await AuditLog.updateOne({ id: entry.id }, { $set: entry }, { upsert: true, runValidators: true });
}

async function persistFinancialRelease(booking, commissions = []) {
  if (!mongoReady() || !booking) return;
  const Wallet = require('../../models/Wallet');
  const WalletTransaction = require('../../models/WalletTransaction');
  const Commission = require('../../models/Commission');
  const Booking = require('../../models/Booking');
  const ownerKeys = new Set([
    `company:${booking.companyId}`,
    booking.promoterAttribution?.promoterId ? `promoter:${booking.promoterAttribution.promoterId}` : '',
  ].filter(Boolean));
  const wallets = store.state.wallets.filter((wallet) => ownerKeys.has(`${wallet.ownerType}:${wallet.ownerId}`));
  if (wallets.length) {
    await Wallet.bulkWrite(wallets.map((wallet) => ({
      updateOne: {
        filter: { ownerType: wallet.ownerType, ownerId: wallet.ownerId },
        update: { $set: wallet },
        upsert: true,
      },
    })));
  }
  const txns = store.state.walletTransactions.filter((txn) => txn.referenceType === 'booking' && txn.referenceId === booking.id);
  if (txns.length) {
    await WalletTransaction.bulkWrite(txns.map((txn) => ({
      updateOne: {
        filter: { id: txn.id },
        update: { $set: txn },
        upsert: true,
      },
    })));
  }
  if (commissions.length) {
    await Commission.bulkWrite(commissions.map((commission) => ({
      updateOne: {
        filter: { id: commission.id },
        update: { $set: commission },
        upsert: true,
      },
    })));
  }
  await Booking.updateOne({ bookingRef: booking.bookingRef }, { $set: { earningsReleasedAt: booking.earningsReleasedAt } });
}

async function validateTicket(value, employeeId = 'employee-system', note = '') {
  const releaseService = require('../commission/releaseService');
  const auditStart = store.state.auditLogs.length;
  const result = store.validateTicket(value, employeeId, note);
  if (result.booking) result.listing = store.findListing(result.booking.listingId);
  if (result.booking) result.payment = store.state.payments.find((payment) => payment.bookingRef === result.booking.bookingRef || payment.bookingId === result.booking.id) || null;
  if (result.ok) {
    const released = releaseService.releaseCompletedBooking(result.booking.bookingRef) || [];
    result.releasedCommissions = released;
    await persistCheckIn(result.booking);
    await persistFinancialRelease(result.booking, released);
    await persistAudit(store.state.auditLogs[auditStart]);
  }
  return result;
}

function checkInBlockReason(booking) {
  if (!booking) return 'Ticket not found';
  if (booking.paymentStatus !== 'successful') return 'Ticket payment is not confirmed';
  if (['cancelled', 'refunded', 'voided'].includes(booking.bookingStatus)) return `Ticket is ${booking.bookingStatus}`;
  if (booking.bookingStatus === 'checked_in' || booking.checkInStatus === 'checked_in' || booking.bookingStatus === 'completed') return 'Ticket was already validated';
  if (booking.bookingStatus === 'no_show' || booking.checkInStatus === 'no_show') return 'Ticket is marked no-show';
  return '';
}

function userCanAccessBooking(user = {}, booking = {}) {
  const role = user.role;
  if (['super_admin', 'admin'].includes(role)) return true;
  if (['company_admin', 'partner', 'company_employee'].includes(role)) return Boolean(user.companyId && booking.companyId === user.companyId);
  return false;
}

function lookupPayment(booking = {}, value = '') {
  const key = String(value || '').toLowerCase().trim();
  return store.state.payments.find((payment) => (
    payment.bookingRef === booking.bookingRef
    || payment.bookingId === booking.id
    || String(payment.id || '').toLowerCase() === key
    || String(payment.providerReference || '').toLowerCase() === key
  )) || null;
}

async function lookupTicket(value, user = {}) {
  const booking = store.findBookingByAny ? store.findBookingByAny(value) : store.findBooking(value);
  if (!booking) return { ok: false, result: 'not_found', message: 'Ticket not found' };
  if (!userCanAccessBooking(user, booking)) {
    return { ok: false, result: 'forbidden', message: 'Ticket is outside your company scope' };
  }
  const listing = store.findListing(booking.listingId);
  const company = store.findCompany(booking.companyId);
  const payment = lookupPayment(booking, value);
  const disabledReason = checkInBlockReason(booking);
  return {
    ok: true,
    result: 'found',
    booking,
    listing,
    company,
    payment,
    canCheckIn: !disabledReason,
    disabledReason,
    message: disabledReason || 'Ticket found and ready for check-in',
  };
}

async function markNoShow(value, user = {}, note = 'Marked no-show from scanner') {
  const lookup = await lookupTicket(value, user);
  if (!lookup.ok) return lookup;
  const booking = lookup.booking;
  if (booking.bookingStatus === 'checked_in' || booking.checkInStatus === 'checked_in') {
    return { ...lookup, ok: false, result: 'already_checked_in', message: 'Checked-in tickets cannot be marked no-show' };
  }
  if (['cancelled', 'refunded', 'voided'].includes(booking.bookingStatus)) {
    return { ...lookup, ok: false, result: 'not_valid_for_no_show', message: `Ticket is ${booking.bookingStatus}` };
  }
  booking.bookingStatus = 'no_show';
  booking.checkInStatus = 'no_show';
  booking.noShowAt = new Date().toISOString();
  booking.noShowBy = user.id || 'employee-system';
  booking.noShowReason = String(note || 'Marked no-show from scanner').trim();
  booking.checkInNote = booking.noShowReason;
  const audit = {
    id: `audit-${store.state.auditLogs.length + 1}`,
    actorId: user.id || 'employee-system',
    actorRole: user.role || 'company_employee',
    action: 'ticket.no_show',
    target: booking.bookingRef,
    entityType: 'booking',
    entityId: booking.id,
    metadata: { bookingRef: booking.bookingRef, companyId: booking.companyId, note: booking.noShowReason },
    createdAt: new Date().toISOString(),
  };
  store.state.auditLogs.push(audit);
  await persistCheckIn(booking);
  await persistAudit(audit);
  return { ...lookup, ok: true, result: 'no_show', booking, message: 'Ticket marked no-show' };
}

function lookupBooking(bookingRef, contact = '') {
  const booking = store.findBooking(bookingRef);
  if (!booking) return null;
  if (!contact) return booking;
  const key = String(contact).toLowerCase();
  const email = String(booking.guestSnapshot?.email || '').toLowerCase();
  const phone = String(booking.guestSnapshot?.phone || '').toLowerCase();
  return email.includes(key) || phone.includes(key) ? booking : null;
}

function cancelBooking(bookingRef, reason = 'Customer requested cancellation') {
  const booking = store.findBooking(bookingRef);
  if (!booking) return null;
  booking.bookingStatus = 'cancelled';
  booking.cancelReason = reason;
  booking.cancelledAt = new Date().toISOString();
  return booking;
}

module.exports = { createGuestBooking, validateTicket, lookupTicket, markNoShow, lookupBooking, cancelBooking };
