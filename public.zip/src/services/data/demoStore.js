const { buildSeedData } = require('../../seeds/seedAll');
const generateBookingRef = require('../../utils/generateBookingRef');
const calculateCommission = require('../../utils/calculateCommission');
const { addMinutes } = require('../../utils/dates');
const { ENABLED_BOOKING_TYPES } = require('../../config/constants');
const toSlug = require('../../utils/slugify');

const state = buildSeedData();
const DATABASE_MODELS = {
  users: 'User',
  companies: 'Company',
  categories: 'ServiceCategory',
  listings: 'Listing',
  routes: 'Route',
  vehicles: 'Vehicle',
  schedules: 'TripSchedule',
  seats: 'Seat',
  rooms: 'Room',
  companyEmployees: 'CompanyEmployee',
  bookings: 'Booking',
  payments: 'Payment',
  wallets: 'Wallet',
  walletTransactions: 'WalletTransaction',
  promoterLinks: 'PromoterLink',
  referralClicks: 'ReferralClick',
  commissions: 'Commission',
  blogs: 'BlogPost',
  supportTickets: 'SupportTicket',
  refundRequests: 'RefundRequest',
  promotionCampaigns: 'PromotionCampaign',
  reviews: 'Review',
  auditLogs: 'AuditLog',
  notifications: 'Notification',
};
const FALLBACK_MEDIA = {
  bus: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=70',
  hotel: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=70',
  flight: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1200&q=70',
  train: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?auto=format&fit=crop&w=1200&q=70',
  default: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1400&q=70',
};
const SERVICE_LABELS = {
  bus: 'Bus',
  hotel: 'Hotel',
  flight: 'Flight',
  train: 'Train',
  ferry: 'Ferry',
  tour: 'Tour',
  car_rental: 'Car rental',
  airport_transfer: 'Airport transfer',
  event: 'Event',
  cargo: 'Cargo',
  visa: 'Visa support',
  insurance: 'Travel insurance',
  package: 'Travel package',
};
const TYPE_ORDER = ['bus', 'hotel', 'flight', 'train'];
const ROUTED_SERVICE_TYPES = ['bus', 'flight', 'train', 'ferry', 'tour', 'airport_transfer', 'package', 'cargo'];
const CITY_CODES = {
  kampala: 'ug',
  entebbe: 'ug',
  jinja: 'ug',
  gulu: 'ug',
  mukono: 'ug',
  mbarara: 'ug',
  masaka: 'ug',
  uganda: 'ug',
  nairobi: 'ke',
  mombasa: 'ke',
  kisumu: 'ke',
  kenya: 'ke',
  kigali: 'rw',
  rwanda: 'rw',
  arusha: 'tz',
  zanzibar: 'tz',
  morogoro: 'tz',
  'dar es salaam': 'tz',
  tanzania: 'tz',
  bujumbura: 'bi',
  burundi: 'bi',
  juba: 'ss',
  'south sudan': 'ss',
  'addis ababa': 'et',
  ethiopia: 'et',
  djibouti: 'dj',
  mogadishu: 'so',
  somalia: 'so',
  goma: 'drc',
  'dr congo': 'drc',
  congo: 'drc',
};

function addonCatalogFor(serviceType) {
  const options = serviceType === 'hotel'
    ? [
      { name: 'Breakfast package', price: 18000 },
      { name: 'Airport pickup', price: 45000 },
      { name: 'Late checkout', price: 25000 },
    ]
    : serviceType === 'flight'
      ? [
        { name: 'Extra baggage', price: 55000 },
        { name: 'Priority boarding', price: 25000 },
        { name: 'Travel insurance', price: 18000 },
      ]
      : [
        { name: 'Extra luggage', price: 12000 },
        { name: 'Priority boarding', price: 8000 },
        { name: 'SMS and WhatsApp ticket', price: 2500 },
      ];
  return options.map((option) => ({ ...option, id: option.id || toSlug(option.name) }));
}

function requestedAddonIds(payload = {}) {
  const raw = payload.addons || payload.addonIds || payload.addon || [];
  return (Array.isArray(raw) ? raw : [raw])
    .flatMap((value) => String(value || '').split(','))
    .map((value) => toSlug(value))
    .filter(Boolean);
}

function selectedAddonsFor(serviceType, payload = {}) {
  const ids = new Set(requestedAddonIds(payload));
  if (!ids.size) return [];
  return addonCatalogFor(serviceType).filter((addon) => ids.has(addon.id));
}

function releaseExpiredSeatLocks(now = new Date()) {
  state.seats.forEach((seat) => {
    if (seat.status === 'locked' && seat.lockedUntil && new Date(seat.lockedUntil) <= now) {
      seat.status = 'available';
      seat.lockedUntil = null;
      seat.lockId = null;
    }
  });
}

function stripMongoFields(row) {
  const clean = { ...row };
  if (!clean.id && row._id) clean.id = String(row._id);
  if (clean.companyId && typeof clean.companyId !== 'string') clean.companyId = String(clean.companyId);
  if (clean.ownerId && typeof clean.ownerId !== 'string') clean.ownerId = String(clean.ownerId);
  delete clean._id;
  delete clean.__v;
  return clean;
}

function recordKey(stateKey, row) {
  if (stateKey === 'categories') return normalize(row.key || row.id || row.label);
  if (stateKey === 'companies') return normalize(row.slug || row.id || row.name);
  if (stateKey === 'listings') return normalize(row.slug || row.id || row.title);
  if (stateKey === 'bookings') return normalize(row.bookingRef || row.id);
  if (stateKey === 'promoterLinks') return normalize(row.code || row.id);
  if (stateKey === 'wallets') return normalize(row.id || `${row.ownerType}-${row.ownerId}-${row.currency}`);
  return normalize(row.id || row.slug || row.key || row.code || row.name || row.title);
}

function mergeHydratedRecords(stateKey, incomingRows) {
  const currentRows = Array.isArray(state[stateKey]) ? state[stateKey] : [];
  const rowsByKey = new Map();
  currentRows.forEach((row) => rowsByKey.set(recordKey(stateKey, row), row));
  incomingRows.forEach((row) => {
    const key = recordKey(stateKey, row);
    rowsByKey.set(key, { ...(rowsByKey.get(key) || {}), ...row });
  });
  return Array.from(rowsByKey.values());
}

function normalizeMedia(media, fallbackUrl, alt) {
  if (!media) return { url: fallbackUrl, publicId: 'classic-trip/fallback', alt };
  if (typeof media === 'string') return { url: media, publicId: media, alt };
  return {
    ...media,
    url: media.url || media.secureUrl || fallbackUrl,
    publicId: media.publicId || media.public_id || media.url || 'classic-trip/fallback',
    alt: media.alt || alt,
  };
}

function normalizeMediaList(row, serviceType) {
  const fallbackUrl = FALLBACK_MEDIA[serviceType] || FALLBACK_MEDIA.default;
  const rawMedia = Array.isArray(row.media) && row.media.length
    ? row.media
    : Array.isArray(row.images) && row.images.length
      ? row.images
      : [row.image || row.img].filter(Boolean);
  const media = rawMedia.map((item) => normalizeMedia(item, fallbackUrl, row.title || row.name || 'Classic Trip listing'));
  return media.length ? media : [normalizeMedia(null, fallbackUrl, row.title || row.name || 'Classic Trip listing')];
}

function seatNumbers(totalSeats) {
  const seats = [];
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  for (let index = 0; index < totalSeats; index += 1) {
    const row = letters[Math.floor(index / 4)] || `R${Math.floor(index / 4) + 1}`;
    seats.push(`${row}${(index % 4) + 1}`);
  }
  return seats;
}

function ensureBookableInventory() {
  if (!Array.isArray(state.vehicles)) state.vehicles = [];
  state.listings.forEach((listing) => {
    if (!listing.bookable) return;
    if (listing.serviceType === 'bus' && !state.schedules.some((schedule) => schedule.listingId === listing.id)) {
      const routeId = `auto-route-${toSlug(listing.id)}`;
      const vehicleId = `auto-vehicle-${toSlug(listing.id)}`;
      const scheduleId = `auto-schedule-${toSlug(listing.id)}`;
      const totalSeats = Math.max(Number(listing.availability || listing.availableUnits || 28), 12);
      const takenSeats = Array.isArray(listing.taken) ? listing.taken : [];
      if (!state.routes.some((route) => route.listingId === listing.id)) {
        state.routes.push({
          id: routeId,
          listingId: listing.id,
          companyId: listing.companyId,
          origin: listing.from,
          destination: listing.to,
          corridor: listing.corridor || `${toSlug(listing.from)}-${toSlug(listing.to)}`,
          status: 'active',
        });
      }
      if (!state.vehicles.some((vehicle) => vehicle.companyId === listing.companyId && vehicle.listingId === listing.id && vehicle.status !== 'archived')) {
        state.vehicles.push({
          id: vehicleId,
          companyId: listing.companyId,
          listingId: listing.id,
          serviceType: listing.serviceType,
          name: `${listing.companyName || listing.partner || 'Partner'} ${listing.type || 'Coach'}`,
          plateOrCode: vehicleId.replace('auto-vehicle-', 'CT-').slice(0, 16).toUpperCase(),
          layoutName: listing.layout || '2x2',
          rows: Math.ceil(totalSeats / 4),
          cols: 4,
          totalSeats,
          seats: seatNumbers(totalSeats).map((seatNumber, index) => ({
            id: seatNumber,
            seatNumber,
            row: Math.floor(index / 4) + 1,
            col: (index % 4) + 1,
            label: seatNumber,
            isAisle: false,
            isDisabled: false,
          })),
          amenities: ['Ticket scanner'],
          media: listing.media,
          status: 'active',
        });
      }
      const assignedVehicle = state.vehicles.find((vehicle) => vehicle.companyId === listing.companyId && vehicle.listingId === listing.id && vehicle.status !== 'archived')
        || state.vehicles.find((vehicle) => vehicle.id === vehicleId);
      state.schedules.push({
        id: scheduleId,
        routeId,
        listingId: listing.id,
        companyId: listing.companyId,
        vehicleId: assignedVehicle?.id || vehicleId,
        vehicleName: assignedVehicle?.name || '',
        departAt: addMinutes(new Date(), 1440).toISOString(),
        arriveAt: addMinutes(new Date(), 1560).toISOString(),
        basePrice: listing.priceFrom,
        currency: listing.currency,
        totalSeats,
        availableSeats: Math.max(0, totalSeats - takenSeats.length),
        status: 'active',
      });
      seatNumbers(totalSeats).forEach((seatNumber, index) => {
        state.seats.push({
          id: `auto-seat-${toSlug(listing.id)}-${seatNumber}`,
          scheduleId,
          seatNumber,
          seatClass: index < 4 ? 'VIP' : 'Standard',
          priceDelta: index < 4 ? 12000 : 0,
          status: takenSeats.includes(seatNumber) ? 'taken' : 'available',
          lockedUntil: null,
        });
      });
    }
    if (listing.serviceType === 'hotel' && !state.rooms.some((room) => room.listingId === listing.id)) {
      state.rooms.push({
        id: `auto-room-${toSlug(listing.id)}`,
        listingId: listing.id,
        companyId: listing.companyId,
        roomType: 'Standard Room',
        capacity: 2,
        nightlyPrice: listing.priceFrom,
        inventory: Math.max(Number(listing.availability || listing.availableUnits || 6), 1),
        amenities: ['Wi-Fi', 'Receipt', 'Support'],
        media: listing.media,
        status: 'active',
      });
    }
  });
}

function normalizeHydratedState() {
  state.companies = state.companies.map((company) => {
    const slug = company.slug || toSlug(company.name || company.id || 'partner');
    return {
      ...company,
      id: company.id || slug,
      slug,
      companyType: company.companyType || company.type || 'partner',
      country: company.country || 'Uganda',
      city: company.city || 'Kampala',
      description: company.description || 'Verified Classic Trip partner.',
      logo: normalizeMedia(company.logo || company.logoUrl, `https://ui-avatars.com/api/?name=${encodeURIComponent(company.name || 'Classic Trip')}&background=4f8cff&color=fff&bold=true`, company.name || 'Classic Trip partner'),
      coverImage: normalizeMedia(company.coverImage || company.coverUrl, FALLBACK_MEDIA.default, company.name || 'Classic Trip partner'),
      verificationStatus: company.verificationStatus || (company.isVerified ? 'verified' : 'pending'),
      supportContacts: company.supportContacts || { phone: '+256 700 000 000', email: 'support@classictrip.example', whatsapp: '+256 700 000 999' },
      ratingAverage: Number(company.ratingAverage || company.rating || 4.5),
      reviewCount: Number(company.reviewCount || 0),
      settings: company.settings || { instantConfirmation: true, canPublish: true },
    };
  });

  state.listings = state.listings.map((listing) => {
    const serviceType = listing.serviceType || listing.group || 'bus';
    const company = state.companies.find((item) => normalize(item.id) === normalize(listing.companyId) || normalize(item.slug) === normalize(listing.companySlug));
    const title = listing.title || `${listing.origin || listing.from || listing.city || 'Classic'} to ${listing.destination || listing.to || 'Trip'} ${SERVICE_LABELS[serviceType] || 'Service'}`;
    const slug = listing.slug || toSlug(`${title}-${company?.name || listing.companyName || 'classic-trip'}`);
    const media = normalizeMediaList(listing, serviceType);
    return {
      ...listing,
      id: listing.id || slug,
      serviceType,
      group: listing.group || serviceType,
      type: listing.type || SERVICE_LABELS[serviceType] || serviceType,
      title,
      slug,
      sub: listing.sub || listing.description || listing.policy || `${company?.name || listing.companyName || 'Classic Trip'} service`,
      companyId: listing.companyId || company?.id || '',
      companySlug: listing.companySlug || company?.slug || 'classic-trip',
      companyName: listing.companyName || company?.name || listing.partner || 'Classic Trip Partner',
      partner: listing.partner || listing.companyName || company?.name || 'Classic Trip Partner',
      from: listing.from || listing.origin || listing.city || '',
      to: listing.to || listing.destination || listing.city || '',
      time: listing.time || listing.timeLabel || 'On schedule',
      duration: listing.duration || listing.durationLabel || 'Scheduled service',
      price: listing.price || listing.priceFrom || 0,
      priceFrom: Number(listing.priceFrom || listing.price || 0),
      currency: listing.currency || 'UGX',
      media,
      img: listing.img || media[0]?.url,
      amenities: Array.isArray(listing.amenities) ? listing.amenities : [],
      checkInTime: listing.checkInTime || '',
      checkOutTime: listing.checkOutTime || '',
      serviceNotes: listing.serviceNotes || '',
      contactPhone: listing.contactPhone || '',
      pickupInstructions: listing.pickupInstructions || '',
      dropoffInstructions: listing.dropoffInstructions || '',
      ratingAverage: Number(listing.ratingAverage || listing.rating || 4.5),
      rating: String(listing.rating || listing.ratingAverage || '4.5'),
      reviewCount: Number(listing.reviewCount || 0),
      bookable: typeof listing.bookable === 'boolean' ? listing.bookable : ENABLED_BOOKING_TYPES.includes(serviceType),
      releaseStatus: listing.releaseStatus || (ENABLED_BOOKING_TYPES.includes(serviceType) ? 'live' : 'teaser'),
      status: listing.status || 'active',
      policy: listing.policy || (ENABLED_BOOKING_TYPES.includes(serviceType) ? 'Instant - refundable rules apply' : 'Integration preview'),
      layout: listing.layout || (serviceType === 'hotel' ? 'hotel-rooms' : 'bus-2-2'),
      taken: Array.isArray(listing.taken) ? listing.taken : [],
      availability: Number(listing.availability || listing.availableUnits || 0),
      cancellationRules: listing.cancellationRules || 'Free cancellation before operator cutoff. Refund rules vary by partner.',
      baggageRules: listing.baggageRules || (serviceType === 'bus' ? 'One main bag + one cabin bag included.' : ''),
    };
  });

  state.vehicles = (Array.isArray(state.vehicles) ? state.vehicles : []).map((vehicle) => {
    const listing = state.listings.find((item) => item.id === vehicle.listingId);
    const company = state.companies.find((item) => item.id === vehicle.companyId) || state.companies.find((item) => item.id === listing?.companyId);
    const totalSeats = Number(vehicle.totalSeats || vehicle.capacity || 0) || Math.max(12, Number(listing?.availability || 48));
    return {
      ...vehicle,
      id: vehicle.id || toSlug(`${vehicle.name || 'vehicle'}-${vehicle.plateOrCode || totalSeats}`),
      companyId: vehicle.companyId || company?.id || listing?.companyId || '',
      listingId: vehicle.listingId || listing?.id || '',
      serviceType: vehicle.serviceType || listing?.serviceType || vehicle.type || 'bus',
      name: vehicle.name || `${company?.name || 'Partner'} vehicle`,
      plateOrCode: vehicle.plateOrCode || vehicle.code || '',
      layoutName: vehicle.layoutName || vehicle.layout || listing?.layout || '2x2',
      rows: Number(vehicle.rows || Math.ceil(totalSeats / 4)),
      cols: Number(vehicle.cols || 4),
      totalSeats,
      seats: Array.isArray(vehicle.seats) ? vehicle.seats : seatNumbers(totalSeats).map((seatNumber, index) => ({
        id: seatNumber,
        seatNumber,
        row: Math.floor(index / 4) + 1,
        col: (index % 4) + 1,
        label: seatNumber,
        isAisle: false,
        isDisabled: false,
      })),
      amenities: Array.isArray(vehicle.amenities) ? vehicle.amenities : [],
      media: Array.isArray(vehicle.media) ? vehicle.media : [],
      status: vehicle.status || 'active',
    };
  });

  state.schedules = state.schedules.map((schedule) => {
    const vehicle = state.vehicles.find((item) => item.id === schedule.vehicleId)
      || state.vehicles.find((item) => item.companyId === schedule.companyId && item.listingId === schedule.listingId && item.status !== 'archived');
    return {
      ...schedule,
      vehicleId: schedule.vehicleId || vehicle?.id || '',
      vehicleName: schedule.vehicleName || vehicle?.name || '',
      totalSeats: Number(schedule.totalSeats || vehicle?.totalSeats || 0),
      availableSeats: Number(schedule.availableSeats || 0),
      currency: schedule.currency || 'UGX',
      status: schedule.status || 'active',
    };
  });

  state.categories = state.categories.map((category) => ({
    ...category,
    key: category.key || toSlug(category.label || category.name || 'service'),
    label: category.label || category.name || SERVICE_LABELS[category.key] || 'Service',
    icon: category.icon || 'fa-ticket',
    bookable: typeof category.bookable === 'boolean' ? category.bookable : ENABLED_BOOKING_TYPES.includes(category.key),
    release: category.release || (ENABLED_BOOKING_TYPES.includes(category.key) ? 'v1' : 'architecture-ready'),
  }));

  ensureBookableInventory();
}

async function hydrateFromDatabase({ mongoose, logger } = {}) {
  if (!mongoose || mongoose.connection.readyState !== 1) {
    return { source: 'memory', loadedCollections: 0, loadedRecords: 0 };
  }

  const nextState = {};
  let loadedCollections = 0;
  let loadedRecords = 0;

  for (const [stateKey, modelName] of Object.entries(DATABASE_MODELS)) {
    try {
      require(`../../models/${modelName}`);
      const Model = mongoose.model(modelName);
      const rows = await Model.find({}).lean();
      if (rows.length) {
        nextState[stateKey] = rows.map(stripMongoFields);
        loadedCollections += 1;
        loadedRecords += rows.length;
      }
    } catch (error) {
      logger?.warn?.('Database hydration skipped collection', { modelName, stateKey, error: error.message });
    }
  }

  if (!loadedRecords) {
    logger?.info?.('Database hydration found no records; using in-memory seed data');
    return { source: 'memory', loadedCollections: 0, loadedRecords: 0 };
  }

  Object.entries(nextState).forEach(([stateKey, rows]) => {
    state[stateKey] = mergeHydratedRecords(stateKey, rows);
  });
  normalizeHydratedState();
  logger?.info?.('Database hydration completed', { loadedCollections, loadedRecords });
  return { source: 'database', loadedCollections, loadedRecords };
}

function normalize(value) {
  return String(value || '').toLowerCase().trim();
}

function cleanNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function asDate(value) {
  const date = value ? new Date(value) : null;
  return date && !Number.isNaN(date.getTime()) ? date : null;
}

function placeCode(value) {
  const raw = normalize(value);
  return CITY_CODES[raw] || '';
}

function listingCorridorCode(listing = {}) {
  const fromCode = placeCode(listing.from || listing.city || listing.country);
  const toCode = placeCode(listing.to || listing.city || listing.country);
  if (!fromCode && !toCode) return listing.corridor || 'regional';
  if (fromCode && toCode && fromCode === toCode) return `${fromCode}-local`;
  if (fromCode && toCode) return [fromCode, toCode].sort().join('-');
  return `${fromCode || toCode}-local`;
}

function unique(values = []) {
  return [...new Set(values.filter(Boolean))];
}

function routeLabelForListing(listing = {}) {
  if (listing.from && listing.to) return `${listing.from} to ${listing.to}`;
  if (listing.city && listing.country) return `${listing.city}, ${listing.country}`;
  return listing.city || listing.country || 'Live listing';
}

function scheduleSeatStats(schedule) {
  const seats = seatsForSchedule(schedule.id);
  const total = seats.length || cleanNumber(schedule.totalSeats);
  const booked = seats.filter((seat) => seat.status === 'taken').length;
  const held = seats.filter((seat) => seat.status === 'locked').length;
  const blocked = seats.filter((seat) => seat.status === 'blocked').length;
  const available = seats.length ? seats.filter((seat) => seat.status === 'available').length : cleanNumber(schedule.availableSeats);
  return { total, booked, held, blocked, available };
}

function listingAvailabilitySnapshot(listing = {}) {
  if (listing.serviceType === 'bus' || listing.serviceType === 'train' || listing.serviceType === 'flight') {
    const schedules = schedulesForListing(listing.id).filter((schedule) => schedule.status !== 'archived' && schedule.status !== 'cancelled');
    const totals = schedules.reduce((acc, schedule) => {
      const stats = scheduleSeatStats(schedule);
      acc.total += stats.total;
      acc.booked += stats.booked;
      acc.held += stats.held;
      acc.blocked += stats.blocked;
      acc.available += stats.available;
      return acc;
    }, { total: 0, booked: 0, held: 0, blocked: 0, available: 0 });
    const nextSchedule = schedules
      .map((schedule) => ({ schedule, departAt: asDate(schedule.departAt) }))
      .filter((item) => item.departAt)
      .sort((a, b) => a.departAt - b.departAt)[0]?.schedule || schedules[0] || null;
    return {
      ...totals,
      remaining: totals.available,
      unitsLabel: totals.total ? `${totals.available}/${totals.total} seats open` : 'Schedule pending',
      nextDepartAt: nextSchedule?.departAt || '',
      scheduleId: nextSchedule?.id || '',
      inventoryType: 'seats',
    };
  }

  if (listing.serviceType === 'hotel') {
    const rooms = roomsForListing(listing.id).filter((room) => room.status !== 'archived');
    const available = rooms.filter((room) => room.status === 'active').reduce((total, room) => total + cleanNumber(room.inventory), 0);
    const capacity = rooms.reduce((total, room) => total + (cleanNumber(room.inventory) * cleanNumber(room.capacity, 1)), 0);
    return {
      total: capacity || available,
      booked: 0,
      held: 0,
      blocked: rooms.filter((room) => room.status !== 'active').reduce((total, room) => total + cleanNumber(room.inventory), 0),
      available,
      remaining: available,
      unitsLabel: rooms.length ? `${available} rooms across ${rooms.length} room types` : 'Room inventory pending',
      nextDepartAt: '',
      roomTypes: rooms.length,
      inventoryType: 'rooms',
    };
  }

  const available = cleanNumber(listing.availability || listing.availableUnits || 0);
  return {
    total: available,
    booked: 0,
    held: 0,
    blocked: 0,
    available,
    remaining: available,
    unitsLabel: available ? `${available} slots open` : 'Provider integration pending',
    nextDepartAt: '',
    inventoryType: 'slots',
  };
}

function listingSearchText(listing = {}) {
  return [
    listing.title,
    listing.sub,
    listing.description,
    listing.partner,
    listing.companyName,
    listing.from,
    listing.to,
    listing.city,
    listing.country,
    listing.corridor,
    listing.type,
    listing.serviceType,
    listing.policy,
    listing.baggageRules,
    listing.cancellationRules,
  ].map(normalize).join(' ');
}

function listingCatalogItem(listing = {}) {
  const availability = listingAvailabilitySnapshot(listing);
  const nextDate = asDate(availability.nextDepartAt);
  const serviceType = listing.serviceType || listing.group || 'bus';
  const price = cleanNumber(listing.priceFrom || listing.price);
  const corridor = listingCorridorCode(listing);
  const bookable = Boolean(listing.bookable && listing.status === 'active' && availability.remaining > 0);
  return {
    ...frontendListing(listing),
    serviceType,
    group: ['bus', 'hotel', 'flight', 'train'].includes(serviceType) ? serviceType : 'more',
    catalogType: serviceType,
    typeLabel: SERVICE_LABELS[serviceType] || listing.type || serviceType,
    routeLabel: routeLabelForListing(listing),
    corridor,
    searchText: listingSearchText(listing),
    price,
    priceFrom: price,
    basePrice: price,
    remainingInventory: availability.remaining,
    availability: availability.remaining,
    availableUnits: availability.remaining,
    totalUnits: availability.total,
    bookedUnits: availability.booked,
    heldUnits: availability.held,
    blockedUnits: availability.blocked,
    unitsLabel: availability.unitsLabel,
    inventoryType: availability.inventoryType,
    nextDepartAt: availability.nextDepartAt,
    scheduleId: availability.scheduleId || '',
    nextDepartLabel: nextDate ? nextDate.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : listing.time || 'Flexible schedule',
    bookable,
    bookingUrl: bookable ? `/listings/${serviceType}/${listing.slug}` : '',
    bookableReason: bookable ? 'Instant checkout' : availability.remaining <= 0 ? 'Sold out or pending inventory' : 'Provider preview',
  };
}

function buildListingCatalog({ includeTeasers = true } = {}) {
  return state.listings
    .filter((listing) => listing.status === 'active' && (includeTeasers || listing.bookable))
    .map(listingCatalogItem);
}

function moneyMetric(items = []) {
  const priced = items.filter((item) => cleanNumber(item.priceFrom || item.price) > 0);
  if (!priced.length) return null;
  const currencies = unique(priced.map((item) => String(item.currency || 'UGX').toUpperCase()));
  if (currencies.length !== 1) return null;
  const prices = priced.map((item) => cleanNumber(item.priceFrom || item.price));
  return {
    currency: currencies[0],
    average: Math.round(prices.reduce((total, price) => total + price, 0) / prices.length),
    lowest: Math.min(...prices),
    highest: Math.max(...prices),
  };
}

function catalogTypeStats(listings = buildListingCatalog()) {
  return TYPE_ORDER.map((type) => {
    const items = listings.filter((listing) => listing.serviceType === type);
    const nextDeparture = items
      .map((listing) => asDate(listing.nextDepartAt))
      .filter(Boolean)
      .sort((a, b) => a - b)[0] || null;
    return {
      type,
      label: SERVICE_LABELS[type] || type,
      count: items.length,
      partners: unique(items.map((listing) => listing.partner || listing.companyName)).length,
      remainingSeats: items.reduce((total, listing) => total + cleanNumber(listing.remainingInventory), 0),
      nextDeparture: nextDeparture ? nextDeparture.toISOString() : '',
      price: moneyMetric(items),
    };
  });
}

function catalogRouteHighlights(listings = buildListingCatalog()) {
  const groups = new Map();
  listings.forEach((listing) => {
    const key = listing.corridor || 'regional';
    const current = groups.get(key) || {
      key,
      corridor: key,
      type: listing.serviceType || 'bus',
      label: routeLabelForListing(listing),
      count: 0,
      remainingSeats: 0,
      minPrice: null,
      currency: listing.currency || 'UGX',
      nextDeparture: '',
    };
    const nextDate = asDate(listing.nextDepartAt);
    const currentDate = asDate(current.nextDeparture);
    current.count += 1;
    current.remainingSeats += cleanNumber(listing.remainingInventory);
    current.minPrice = current.minPrice === null ? cleanNumber(listing.priceFrom) : Math.min(current.minPrice, cleanNumber(listing.priceFrom));
    if (nextDate && (!currentDate || nextDate < currentDate)) current.nextDeparture = nextDate.toISOString();
    groups.set(key, current);
  });
  return Array.from(groups.values())
    .sort((a, b) => b.count - a.count || b.remainingSeats - a.remainingSeats)
    .slice(0, 12);
}

function catalogStats(listings = buildListingCatalog()) {
  const countries = unique(listings.map((listing) => listing.country)).filter(Boolean);
  const departuresNext24h = listings.filter((listing) => {
    const departAt = asDate(listing.nextDepartAt);
    if (!departAt) return false;
    const diff = departAt.getTime() - Date.now();
    return diff >= 0 && diff <= 24 * 60 * 60 * 1000;
  }).length;
  return {
    liveListings: listings.length,
    availableNow: listings.reduce((total, listing) => total + cleanNumber(listing.remainingInventory), 0),
    countries: countries.length,
    types: unique(listings.map((listing) => listing.serviceType)).length,
    partners: unique(listings.map((listing) => listing.partner || listing.companyName)).length,
    departuresNext24h,
  };
}

function catalogGuideCards(listings = buildListingCatalog()) {
  return listings
    .slice()
    .sort((a, b) => recommendedScore(b) - recommendedScore(a))
    .slice(0, 4)
    .map((listing) => ({
      id: `guide-${listing.id}`,
      listingId: listing.id,
      title: `${listing.routeLabel}: what to know before you book`,
      tag: listing.serviceType === 'hotel' ? 'Stay guide' : listing.serviceType === 'flight' ? 'Flight tips' : listing.serviceType === 'train' ? 'Rail guide' : 'Route guide',
      image: listing.img || listing.media?.[0]?.url,
      excerpt: listing.sub || listing.policy || `${listing.unitsLabel} from ${listing.partner || listing.companyName}.`,
      location: listing.routeLabel,
      partner: listing.partner || listing.companyName,
      price: { amount: listing.priceFrom || 0, currency: listing.currency || 'UGX' },
      url: listing.url,
    }));
}

function marketplaceInfo(listings = buildListingCatalog()) {
  const stats = catalogStats(listings);
  const typeStats = catalogTypeStats(listings);
  const routeHighlights = catalogRouteHighlights(listings);
  return {
    generatedAt: new Date().toISOString(),
    stats,
    hero: {
      badges: [
        { icon: 'fa-solid fa-shield-halved', label: 'Secure checkout' },
        { icon: 'fa-solid fa-clock', label: `${stats.departuresNext24h} departures in the next 24h` },
        { icon: 'fa-solid fa-users', label: `${stats.partners} partner operations live` },
        { icon: 'fa-solid fa-headset', label: 'Booking support ready' },
      ],
      stats: [
        { value: String(stats.liveListings), label: 'Live listings' },
        { value: String(stats.availableNow), label: 'Seats / rooms open' },
        { value: String(stats.countries), label: 'Countries covered' },
        { value: String(stats.types), label: 'Active categories' },
      ],
    },
    typeStats,
    routeHighlights,
    guides: catalogGuideCards(listings),
    featured: TYPE_ORDER.reduce((acc, type) => {
      acc[type] = listings.filter((listing) => listing.serviceType === type).slice(0, 12);
      return acc;
    }, {}),
  };
}

function homeBootstrap() {
  const listings = buildListingCatalog();
  const marketplace = marketplaceInfo(listings);
  return {
    generatedAt: new Date().toISOString(),
    listings,
    categories: state.categories,
    companies: state.companies.map(publicCompany),
    routes: state.routes.map(publicRoute),
    bookings: state.bookings.slice(0, 8).map(frontendBooking),
    promoterLinks: state.promoterLinks.slice(0, 12).map(publicPromoterLink),
    campaigns: state.promotionCampaigns.map(publicCampaign),
    serviceStats: serviceStats(),
    corridorStats: corridorStats(),
    marketplace,
    heroStats: {
      liveRoutes: marketplace.routeHighlights.length || state.routes.length,
      verifiedPartners: marketplace.stats.partners,
      bookableInventory: listings.filter((listing) => listing.bookable).length,
      totalServices: marketplace.stats.liveListings,
      availableNow: marketplace.stats.availableNow,
      departuresNext24h: marketplace.stats.departuresNext24h,
    },
  };
}

function frontendListing(listing) {
  return {
    ...listing,
    img: listing.img || listing.media?.[0]?.url,
    rating: String(listing.rating || listing.ratingAverage || '4.5'),
    price: listing.price || listing.priceFrom,
    partner: listing.partner || listing.companyName,
    group: listing.group,
    type: listing.type,
    url: `/listings/${listing.serviceType}/${listing.slug}`,
    bookingUrl: listing.bookable ? `/listings/${listing.serviceType}/${listing.slug}` : '',
    companyUrl: `/companies/${listing.companySlug}`,
  };
}

function publicCompany(company) {
  const listings = state.listings.filter((item) => item.companyId === company.id);
  const campaigns = state.promotionCampaigns.filter((campaign) => campaign.companyId === company.id);
  return {
    ...company,
    listingsCount: listings.length,
    activeListingsCount: listings.filter((item) => item.status === 'active').length,
    bookableListingsCount: listings.filter((item) => item.bookable).length,
    sponsoredListingsCount: listings.filter((item) => item.isSponsored).length,
    campaignCount: campaigns.length,
  };
}

function publicRoute(route) {
  const listing = findListing(route.listingId);
  const schedules = listing ? schedulesForListing(listing.id) : [];
  const nextSchedule = schedules.find((schedule) => schedule.status === 'active') || schedules[0];
  return {
    ...route,
    listing,
    scheduleCount: schedules.length,
    availableSeats: schedules.reduce((total, schedule) => total + (Number(schedule.availableSeats) || 0), 0),
    nextDepartAt: nextSchedule?.departAt || null,
    bookingUrl: listing?.bookable ? `/listings/${listing.serviceType}/${listing.slug}` : '',
    listingUrl: listing ? `/listings/${listing.serviceType}/${listing.slug}` : '',
  };
}

function frontendBooking(booking) {
  const listing = findListing(booking.listingId);
  const passenger = booking.passengers?.[0] || {};
  return {
    code: booking.bookingRef,
    title: listing?.title || booking.serviceType,
    type: listing?.type || booking.serviceType,
    selected: passenger.seatOrRoom || 'Selected inventory',
    total: `${booking.pricing.currency} ${Math.round(booking.pricing.total).toLocaleString()}`,
    customer: booking.guestSnapshot?.fullName || 'Guest customer',
    date: booking.createdAt ? new Date(booking.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : 'Recent',
    channel: 'Backend ticket',
    status: booking.bookingStatus,
    ticketUrl: `/tickets/${booking.bookingRef}`,
    lookupUrl: `/tickets?bookingRef=${encodeURIComponent(booking.bookingRef)}`,
  };
}

function publicPromoterLink(link) {
  const listing = findListing(link.listingId);
  return {
    ...link,
    listing,
    shareUrl: link.url,
    conversionRate: link.clicks ? Math.round((link.conversions / link.clicks) * 1000) / 10 : 0,
  };
}

function publicCampaign(campaign) {
  return {
    ...campaign,
    listing: findListing(campaign.listingId),
    company: findCompany(campaign.companyId),
  };
}

function listingPreview(listing, availability = null, company = null) {
  const safeAvailability = availability || getAvailability(listing.id) || {};
  const partner = company || findCompany(listing.companyId || listing.companySlug);
  const currency = listing.currency || 'UGX';
  const subtotal = Number(listing.priceFrom || 0);
  const serviceFee = Math.round(subtotal * 0.045 + 3500);
  const schedules = safeAvailability.schedules || schedulesForListing(listing.id);
  const rooms = safeAvailability.rooms || roomsForListing(listing.id);
  const seats = safeAvailability.seats || [];
  const previewSeats = seats.slice(0, 32);
  const previewRooms = rooms.slice(0, 12);
  const firstSeat = (previewSeats.find((seat) => seat.status === 'available') || previewSeats[0] || {}).seatNumber || '';
  const firstRoom = (previewRooms.find((room) => room.inventory > 0) || previewRooms[0] || {}).id || '';
  const selectedPreview = listing.serviceType === 'hotel' ? (previewRooms[0]?.roomType || 'Room pending') : (firstSeat || 'Slot S1');
  const serviceIcon = {
    hotel: 'fa-hotel',
    bus: 'fa-bus',
    flight: 'fa-plane',
    train: 'fa-train',
    ferry: 'fa-ship',
    car_rental: 'fa-car',
    tour: 'fa-map-location-dot',
  }[listing.serviceType] || 'fa-ticket';
  const addons = addonCatalogFor(listing.serviceType);

  return {
    currency,
    subtotal,
    serviceFee,
    totalEstimate: subtotal + serviceFee,
    serviceIcon,
    previewSeats,
    previewRooms,
    firstSeat,
    firstRoom,
    selectedPreview,
    addons,
    partnerName: listing.partner || partner?.name || 'Classic Trip partner',
    supportPhone: partner?.supportPhone || partner?.phone || '+256 700 000 000',
    scheduleLabel: schedules[0]?.departureTime || listing.time || 'Flexible schedule',
    ticketAccess: 'Email, SMS, WhatsApp',
    policy: listing.bookable ? 'Instant checkout' : 'Provider teaser',
    paymentMethods: ['Mobile Money', 'Card', 'Wallet', 'Pay at office'],
  };
}

function moneyValue(amount, currency = 'UGX') {
  return `${currency} ${Math.round(Number(amount) || 0).toLocaleString()}`;
}

function dateValue(value) {
  if (!value) return 'Recent';
  return new Date(value).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function bookingTitle(booking) {
  const listing = findListing(booking.listingId);
  return listing ? listing.title : booking.serviceType;
}

function bookingCompany(booking) {
  const company = findCompany(booking.companyId);
  return company ? company.name : 'Classic Trip partner';
}

function bookingCustomer(booking) {
  return booking.guestSnapshot?.fullName || booking.passengers?.[0]?.fullName || 'Guest customer';
}

function bookingTotal(booking) {
  return moneyValue(booking.pricing?.total, booking.pricing?.currency || 'UGX');
}

function firstValue(...values) {
  return values.find((value) => value !== undefined && value !== null && value !== '') || '';
}

function timestampValue(value) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toISOString();
}

function lastRowMeta(row) {
  if (!Array.isArray(row)) return null;
  const last = row[row.length - 1];
  return last && typeof last === 'object' && !Array.isArray(last) ? last : null;
}

function rowWithoutMeta(row) {
  const meta = lastRowMeta(row);
  return meta ? row.slice(0, -1) : row;
}

function groupFields(source = {}, fields = []) {
  const output = {};
  fields.forEach(([label, value]) => {
    output[label] = firstValue(value);
  });
  return output;
}

function findPayment(identifier) {
  const key = normalize(identifier);
  return state.payments.find((payment) => (
    normalize(payment.id) === key
    || normalize(payment.bookingId) === key
    || normalize(payment.bookingRef) === key
    || normalize(payment.providerReference) === key
  ));
}

function findWallet(identifier) {
  const key = normalize(identifier);
  return state.wallets.find((wallet) => normalize(wallet.id) === key || normalize(`${wallet.ownerType}:${wallet.ownerId}`) === key || normalize(wallet.ownerId) === key);
}

function findWalletTxn(identifier) {
  const key = normalize(identifier);
  return state.walletTransactions.find((txn) => normalize(txn.id) === key || normalize(txn.referenceId) === key);
}

function findRoute(identifier) {
  const key = normalize(identifier);
  return state.routes.find((route) => normalize(route.id) === key || normalize(`${route.origin} to ${route.destination}`) === key || normalize(route.corridor) === key);
}

function findSchedule(identifier) {
  const key = normalize(identifier);
  return state.schedules.find((schedule) => normalize(schedule.id) === key);
}

function findVehicle(identifier) {
  const key = normalize(identifier);
  return state.vehicles.find((vehicle) => normalize(vehicle.id) === key || normalize(vehicle.name) === key || normalize(vehicle.plateOrCode) === key);
}

function findRoom(identifier) {
  const key = normalize(identifier);
  return state.rooms.find((room) => normalize(room.id) === key || normalize(room.roomType) === key);
}

function findSupportTicket(identifier) {
  const key = normalize(identifier);
  return state.supportTickets.find((ticket) => normalize(ticket.id) === key || normalize(ticket.subject) === key);
}

function findRefund(identifier) {
  const key = normalize(identifier);
  return state.refundRequests.find((refund) => normalize(refund.id) === key || normalize(refund.bookingRef) === key);
}

function findCampaign(identifier) {
  const key = normalize(identifier);
  return state.promotionCampaigns.find((campaign) => normalize(campaign.id) === key || normalize(campaign.name) === key || normalize(campaign.title) === key);
}

function findReview(identifier) {
  const key = normalize(identifier);
  return state.reviews.find((review) => normalize(review.id) === key || normalize(review.bookingId) === key);
}

function findUser(identifier) {
  const key = normalize(identifier);
  return state.users.find((user) => (
    normalize(user.id) === key
    || normalize(user.email) === key
    || normalize(user.phone) === key
    || normalize(user.fullName) === key
  ));
}

function findCompanyEmployee(identifier) {
  const key = normalize(identifier);
  return (state.companyEmployees || []).find((employee) => (
    normalize(employee.id) === key
    || normalize(employee.userId) === key
    || normalize(findUser(employee.userId)?.fullName) === key
    || normalize(findUser(employee.userId)?.email) === key
  ));
}

function findHandover(identifier) {
  const key = normalize(identifier);
  return (state.shiftHandovers || []).find((handover) => normalize(handover.id) === key || normalize(handover.shift) === key);
}

function findReferralLink(identifier) {
  const key = normalize(identifier);
  return state.promoterLinks.find((link) => normalize(link.id) === key || normalize(link.code) === key);
}

function findNotification(identifier) {
  const key = normalize(identifier);
  return (state.notifications || []).find((notice) => normalize(notice.id) === key || normalize(notice.title) === key || normalize(notice.subject) === key);
}

function findBookingByAny(identifier) {
  const key = normalize(identifier);
  if (!key) return null;
  const direct = state.bookings.find((booking) => (
    normalize(booking.id) === key
    || normalize(booking.bookingRef) === key
    || normalize(booking.guestLookupCode) === key
    || normalize(booking.qrCodeValue) === key
    || normalize(booking.paymentRef) === key
    || normalize(booking.guestSnapshot?.email) === key
    || normalize(booking.guestSnapshot?.phone) === key
    || (booking.passengers || []).some((passenger) => normalize(passenger.seatOrRoom) === key || normalize(passenger.seatId) === key)
  ));
  if (direct) return direct;
  const payment = findPayment(identifier);
  if (payment) return findBooking(payment.bookingRef || payment.bookingId);
  return null;
}

function bookingPayment(booking = {}) {
  return findPayment(booking.bookingRef || booking.id) || {
    id: booking.paymentRef || `payment-${booking.bookingRef || booking.id || 'pending'}`,
    bookingId: booking.id,
    bookingRef: booking.bookingRef,
    provider: booking.paymentProvider || 'Classic Trip Payments',
    providerReference: booking.paymentRef || booking.bookingRef,
    amount: booking.pricing?.total,
    currency: booking.pricing?.currency || 'UGX',
    status: booking.paymentStatus,
    paidAt: booking.paymentStatus === 'successful' ? booking.createdAt : '',
    methodNote: booking.paymentMethodNote || '',
    rawPayload: { source: booking.source || 'booking_store' },
  };
}

function bookingCommission(booking = {}) {
  return state.commissions.find((commission) => commission.bookingId === booking.id || commission.bookingRef === booking.bookingRef) || null;
}

function bookingAudit(booking = {}) {
  return state.auditLogs
    .filter((log) => normalize(`${log.target} ${log.metadata?.bookingRef || ''} ${log.meta?.bookingRef || ''}`).includes(normalize(booking.bookingRef || booking.id)))
    .slice(0, 5);
}

function companyTotals(companyId) {
  const bookings = state.bookings.filter((booking) => booking.companyId === companyId);
  const listings = listingsForCompany(companyId);
  const wallet = findWallet(`company:${companyId}`) || state.wallets.find((item) => item.ownerType === 'company' && item.ownerId === companyId) || {};
  const grossRevenue = bookings.reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0);
  const ownerEarnings = bookings.reduce((total, booking) => total + Number(booking.pricing?.split?.companyAmount || 0), 0);
  return { bookings, listings, wallet, grossRevenue, ownerEarnings };
}

function dashboardDetails(title, groups = {}) {
  return { title, groups };
}

function bookingDetails(booking = {}, row = []) {
  const listing = findListing(booking.listingId) || {};
  const company = findCompany(booking.companyId) || {};
  const schedule = findSchedule(booking.scheduleId) || {};
  const vehicle = findVehicle(schedule.vehicleId) || findVehicle(listing.vehicleId) || {};
  const payment = bookingPayment(booking);
  const commission = bookingCommission(booking) || {};
  const promoter = findUser(booking.promoterAttribution?.promoterId) || {};
  const split = booking.pricing?.split || {};
  const passenger = (booking.passengers || [])[0] || {};
  return dashboardDetails(`Booking ${booking.bookingRef || row[0] || ''}`, {
    'Main info': groupFields(booking, [
      ['Booking ID', booking.id],
      ['Booking reference', booking.bookingRef],
      ['Guest lookup code', booking.guestLookupCode || booking.bookingRef],
      ['Source', booking.source || 'online_checkout'],
      ['Status', booking.bookingStatus],
      ['Payment status', booking.paymentStatus],
      ['Service type', booking.serviceType],
      ['Quantity', booking.quantity || (booking.passengers || []).length || 1],
    ]),
    'Customer / guest': groupFields(booking.guestSnapshot || {}, [
      ['Name', booking.guestSnapshot?.fullName || passenger.fullName],
      ['Email', booking.guestSnapshot?.email],
      ['Phone', booking.guestSnapshot?.phone],
      ['User account ID', booking.customerUserId || 'Guest booking'],
      ['Guest type', booking.customerUserId ? 'Registered customer' : 'Guest checkout'],
      ['Passenger seat / room', passenger.seatOrRoom || passenger.seatId],
    ]),
    'Company / owner': groupFields(company, [
      ['Company ID', company.id || booking.companyId],
      ['Company name', company.name],
      ['Tenant slug', company.slug],
      ['Business type', company.companyType || company.type],
      ['Country', company.country],
      ['Support email', company.supportContacts?.email],
      ['Support phone', company.supportContacts?.phone],
    ]),
    'Service / trip / listing': groupFields(listing, [
      ['Catalog/listing ID', listing.id || booking.listingId],
      ['Service name', listing.title],
      ['Service type', listing.serviceType || booking.serviceType],
      ['From', listing.from || listing.city],
      ['To', listing.to],
      ['Address', listing.address || listing.city],
      ['Vehicle name', vehicle.name || schedule.vehicleName],
      ['Vehicle code', vehicle.plateOrCode],
      ['Travel date', timestampValue(schedule.departAt || booking.travelDate || booking.createdAt)],
      ['Trip/schedule ID', schedule.id || booking.scheduleId],
    ]),
    'Booking / payment': groupFields(payment, [
      ['Payment ID', payment.id],
      ['Payment provider', payment.provider],
      ['Payment reference', payment.providerReference || booking.paymentRef],
      ['Payment method note', payment.methodNote || payment.rawPayload?.source],
      ['Amount', moneyValue(payment.amount || booking.pricing?.total, payment.currency || booking.pricing?.currency)],
      ['Gross amount', moneyValue(booking.pricing?.total, booking.pricing?.currency)],
      ['Wallet used', booking.walletUsed || booking.pricing?.walletUsed || 0],
      ['Currency', payment.currency || booking.pricing?.currency],
      ['Paid at', timestampValue(payment.paidAt)],
    ]),
    'Finance / split': groupFields(split, [
      ['Referral code', booking.promoterAttribution?.code],
      ['Promoter name', promoter.fullName],
      ['Promoter email', promoter.email],
      ['Referral percent', firstValue(commission.promoterPercent, split.promoterPercent, booking.promoterAttribution ? '3%' : '0%')],
      ['Promoter amount', moneyValue(firstValue(commission.promoterAmount, split.promoterAmount, 0), booking.pricing?.currency)],
      ['Platform amount', moneyValue(firstValue(commission.platformAmount, split.platformFee, 0), booking.pricing?.currency)],
      ['Owner amount', moneyValue(firstValue(commission.companyAmount, split.companyAmount, 0), booking.pricing?.currency)],
      ['Settlement status', firstValue(commission.status, booking.settlementStatus, booking.earningsReleasedAt ? 'released' : 'pending')],
    ]),
    'Check-in': groupFields(booking, [
      ['Check-in status', booking.checkInStatus || (booking.checkedInAt ? 'checked_in' : booking.bookingStatus === 'no_show' ? 'no_show' : 'pending')],
      ['Checked-in time', timestampValue(booking.checkedInAt)],
      ['Checked-in by', booking.checkedInByUserId || booking.checkedInBy],
      ['Check-in note', booking.checkInNote],
      ['No-show time', timestampValue(booking.noShowAt)],
      ['No-show reason', booking.noShowReason],
    ]),
    'Notes / history': groupFields(booking, [
      ['Customer notes', booking.customerNotes || booking.note || ''],
      ['Cancellation reason', booking.cancellationReason || booking.cancelReason],
      ['Cancelled at', timestampValue(booking.cancelledAt)],
      ['Completed at', timestampValue(booking.completedAt || booking.earningsReleasedAt)],
      ['Recent audit count', bookingAudit(booking).length],
    ]),
    'Timestamps': groupFields(booking, [
      ['Created at', timestampValue(booking.createdAt)],
      ['Updated at', timestampValue(booking.updatedAt)],
      ['Locked until', timestampValue(booking.lockedUntil)],
    ]),
  });
}

function companyDetails(company = {}, row = []) {
  const totals = companyTotals(company.id || row[0]);
  const admins = state.users.filter((user) => user.companyId === company.id || (user.role === 'company_admin' && normalize(user.companyName) === normalize(company.name)));
  return dashboardDetails(company.name || row[0] || 'Company', {
    'Company': groupFields(company, [
      ['Company ID', company.id],
      ['Company name', company.name],
      ['Tenant ID', company.tenantId || company.id],
      ['Tenant slug', company.slug],
      ['Business type', company.companyType || company.type],
      ['Country', company.country],
      ['City', company.city],
      ['Status', company.verificationStatus],
      ['Currency', company.settings?.defaultCurrency || company.currency || 'UGX'],
      ['Payout account', company.payoutAccount || company.settings?.payoutAccount],
      ['Onboarding source', company.onboardingSource || 'platform'],
    ]),
    'Admin / contacts': groupFields(company, [
      ['Admin name', admins[0]?.fullName || company.contactName],
      ['Admin email', admins[0]?.email || company.supportContacts?.email],
      ['Phone', admins[0]?.phone || company.supportContacts?.phone],
      ['Support email', company.supportContacts?.email],
      ['Support phone', company.supportContacts?.phone],
      ['Support message', company.settings?.supportMessage || company.description],
    ]),
    'Performance': groupFields(totals, [
      ['Total listings', totals.listings.length],
      ['Active listings', totals.listings.filter((listing) => listing.status === 'active').length],
      ['Total bookings', totals.bookings.length],
      ['Confirmed bookings', totals.bookings.filter((booking) => booking.bookingStatus === 'confirmed' || booking.bookingStatus === 'checked_in').length],
      ['Revenue', moneyValue(totals.grossRevenue, totals.wallet.currency || company.settings?.defaultCurrency || 'UGX')],
      ['Owner earnings', moneyValue(totals.ownerEarnings, totals.wallet.currency || company.settings?.defaultCurrency || 'UGX')],
      ['Pending payout', moneyValue(totals.wallet.pendingBalance || 0, totals.wallet.currency || 'UGX')],
    ]),
    'Timestamps': groupFields(company, [
      ['Invited by', company.invitedBy],
      ['Invited at', timestampValue(company.invitedAt)],
      ['Onboarded at', timestampValue(company.onboardedAt)],
      ['Created at', timestampValue(company.createdAt)],
      ['Updated at', timestampValue(company.updatedAt)],
    ]),
  });
}

function listingDetails(listing = {}, row = []) {
  const company = findCompany(listing.companyId) || {};
  const routes = routesForListing(listing.id);
  const schedules = schedulesForListing(listing.id);
  const rooms = roomsForListing(listing.id);
  const seats = schedules.flatMap((schedule) => seatsForSchedule(schedule.id));
  const bookings = state.bookings.filter((booking) => booking.listingId === listing.id);
  return dashboardDetails(listing.title || row[0] || 'Listing', {
    'Listing': groupFields(listing, [
      ['Catalog/listing ID', listing.id],
      ['Tenant slug', company.slug || listing.companySlug],
      ['Owner/company', company.name || listing.partner],
      ['Service name/title', listing.title],
      ['Type', listing.type || listing.serviceType],
      ['From', listing.from || listing.city],
      ['To', listing.to],
      ['Address', listing.address || listing.city],
      ['Base price', moneyValue(listing.priceFrom, listing.currency)],
      ['Currency', listing.currency],
      ['Status', listing.status],
      ['Release status', listing.releaseStatus],
      ['Bookable', listing.bookable ? 'Yes' : 'No'],
    ]),
    'Inventory': groupFields(listing, [
      ['Routes', routes.length],
      ['Upcoming schedules', schedules.length],
      ['Room types', rooms.length],
      ['Total seats', seats.length || schedules.reduce((total, schedule) => total + Number(schedule.totalSeats || 0), 0)],
      ['Booked seats', seats.filter((seat) => seat.status === 'taken').length],
      ['Held seats', seats.filter((seat) => seat.status === 'locked').length],
      ['Remaining seats', schedules.reduce((total, schedule) => total + Number(schedule.availableSeats || 0), 0)],
      ['Room stock', rooms.reduce((total, room) => total + Number(room.inventory || 0), 0)],
      ['Bookings count', bookings.length],
      ['Revenue', moneyValue(bookings.reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0), listing.currency)],
    ]),
    'Operations': groupFields(listing, [
      ['Route details', routes.map((route) => `${route.origin} to ${route.destination}`).join(', ')],
      ['Vehicle details', schedules.map((schedule) => schedule.vehicleName || findVehicle(schedule.vehicleId)?.name).filter(Boolean).join(', ')],
      ['Next departure', timestampValue(schedules[0]?.departAt)],
      ['Next arrival', timestampValue(schedules[0]?.arriveAt)],
      ['Policy', listing.policy],
      ['Cancellation rules', listing.cancellationRules],
    ]),
    'Timestamps': groupFields(listing, [
      ['Created at', timestampValue(listing.createdAt)],
      ['Updated at', timestampValue(listing.updatedAt)],
    ]),
  });
}

function routeDetails(route = {}, row = []) {
  const listing = findListing(route.listingId) || {};
  return dashboardDetails(`${route.origin || row[0]} to ${route.destination || ''}`, {
    'Route': groupFields(route, [
      ['Route identifier', route.id],
      ['Listing ID', route.listingId],
      ['Listing title', listing.title],
      ['Company ID', route.companyId || listing.companyId],
      ['Origin', route.origin],
      ['Destination', route.destination],
      ['Corridor', route.corridor],
      ['Boarding points', (route.boardingPoints || []).join(', ')],
      ['Dropoff points', (route.dropoffPoints || []).join(', ')],
      ['Status', route.status],
    ]),
    'Related': groupFields(route, [
      ['Schedules', schedulesForListing(route.listingId).length],
      ['Vehicles', state.vehicles.filter((vehicle) => vehicle.listingId === route.listingId).length],
      ['Bookings', state.bookings.filter((booking) => booking.listingId === route.listingId).length],
    ]),
    'Timestamps': groupFields(route, [
      ['Created at', timestampValue(route.createdAt)],
      ['Updated at', timestampValue(route.updatedAt)],
    ]),
  });
}

function scheduleDetails(schedule = {}, row = []) {
  const listing = findListing(schedule.listingId) || {};
  const route = findRoute(schedule.routeId) || {};
  const vehicle = findVehicle(schedule.vehicleId) || {};
  const seats = seatsForSchedule(schedule.id);
  const sold = seats.filter((seat) => seat.status === 'taken').length;
  const held = seats.filter((seat) => seat.status === 'locked').length;
  return dashboardDetails(schedule.id || row[0] || 'Schedule', {
    'Schedule': groupFields(schedule, [
      ['Trip ID', schedule.id],
      ['Route', `${route.origin || listing.from || ''} to ${route.destination || listing.to || ''}`],
      ['Listing', listing.title],
      ['Vehicle', vehicle.name || schedule.vehicleName],
      ['Vehicle ID', schedule.vehicleId],
      ['Departure', timestampValue(schedule.departAt)],
      ['Arrival', timestampValue(schedule.arriveAt)],
      ['Price', moneyValue(schedule.basePrice, schedule.currency)],
      ['Currency', schedule.currency],
      ['Status', schedule.status],
    ]),
    'Availability': groupFields(schedule, [
      ['Total seats', seats.length || schedule.totalSeats],
      ['Booked seats', sold],
      ['Held seats', held],
      ['Blocked seats', seats.filter((seat) => seat.status === 'blocked').length],
      ['Remaining seats', schedule.availableSeats],
      ['Occupancy', `${Math.round((sold / Math.max(1, seats.length || Number(schedule.totalSeats || 1))) * 100)}%`],
    ]),
    'Timestamps': groupFields(schedule, [
      ['Created at', timestampValue(schedule.createdAt)],
      ['Updated at', timestampValue(schedule.updatedAt)],
    ]),
  });
}

function vehicleDetails(vehicle = {}, row = []) {
  const listing = findListing(vehicle.listingId) || {};
  return dashboardDetails(vehicle.name || row[0] || 'Vehicle', {
    'Vehicle': groupFields(vehicle, [
      ['Vehicle ID', vehicle.id],
      ['Company ID', vehicle.companyId],
      ['Listing ID', vehicle.listingId],
      ['Service', listing.title],
      ['Name', vehicle.name],
      ['Plate/code', vehicle.plateOrCode],
      ['Layout', vehicle.layoutName],
      ['Rows', vehicle.rows],
      ['Columns', vehicle.cols],
      ['Total seats', vehicle.totalSeats],
      ['Amenities', (vehicle.amenities || []).join(', ')],
      ['Status', vehicle.status],
    ]),
    'Timestamps': groupFields(vehicle, [
      ['Created at', timestampValue(vehicle.createdAt)],
      ['Updated at', timestampValue(vehicle.updatedAt)],
    ]),
  });
}

function roomDetails(room = {}, row = []) {
  const listing = findListing(room.listingId) || {};
  return dashboardDetails(room.roomType || row[0] || 'Room', {
    'Room / inventory': groupFields(room, [
      ['Room ID', room.id],
      ['Listing ID', room.listingId],
      ['Company ID', room.companyId],
      ['Listing', listing.title],
      ['Room type', room.roomType],
      ['Capacity', room.capacity],
      ['Nightly price', moneyValue(room.nightlyPrice, listing.currency || 'UGX')],
      ['Inventory remaining', room.inventory],
      ['Amenities', (room.amenities || []).join(', ')],
      ['Status', room.status],
    ]),
    'Timestamps': groupFields(room, [
      ['Created at', timestampValue(room.createdAt)],
      ['Updated at', timestampValue(room.updatedAt)],
    ]),
  });
}

function paymentDetails(payment = {}, row = []) {
  const booking = findBookingByAny(payment.bookingRef || payment.bookingId || row[1] || row[0]) || {};
  const resolved = payment.id ? payment : bookingPayment(booking);
  return dashboardDetails(`Payment ${resolved.id || row[0] || ''}`, {
    'Payment': groupFields(resolved, [
      ['Payment ID', resolved.id || row[0]],
      ['Booking ID', resolved.bookingId || booking.id],
      ['Booking reference', resolved.bookingRef || booking.bookingRef || row[1]],
      ['Provider', resolved.provider || row[3]],
      ['Provider reference', resolved.providerReference],
      ['Amount', moneyValue(resolved.amount || booking.pricing?.total, resolved.currency || booking.pricing?.currency)],
      ['Currency', resolved.currency || booking.pricing?.currency],
      ['Status', resolved.status || booking.paymentStatus || row[row.length - 1]],
      ['Paid at', timestampValue(resolved.paidAt)],
      ['Failure reason', resolved.failureReason],
      ['Checkout URL', resolved.checkoutUrl],
      ['Method note', resolved.methodNote || resolved.rawPayload?.source],
    ]),
    'Customer / company': groupFields(booking, [
      ['Customer', bookingCustomer(booking)],
      ['Customer email', booking.guestSnapshot?.email],
      ['Customer phone', booking.guestSnapshot?.phone],
      ['Company', bookingCompany(booking)],
      ['Company ID', booking.companyId],
    ]),
    'Split': groupFields(booking.pricing?.split || {}, [
      ['Platform percent', firstValue(booking.pricing?.split?.platformPercent, '7%')],
      ['Platform amount', moneyValue(booking.pricing?.split?.platformFee || 0, booking.pricing?.currency)],
      ['Promoter percent', booking.promoterAttribution ? '3%' : '0%'],
      ['Promoter amount', moneyValue(booking.pricing?.split?.promoterAmount || 0, booking.pricing?.currency)],
      ['Owner amount', moneyValue(booking.pricing?.split?.companyAmount || 0, booking.pricing?.currency)],
      ['Settlement status', booking.earningsReleasedAt ? 'released' : 'pending'],
    ]),
    'Metadata': groupFields(resolved, [
      ['Idempotency key', resolved.idempotencyKey],
      ['Raw payload', resolved.rawPayload ? JSON.stringify(resolved.rawPayload) : ''],
      ['Created at', timestampValue(resolved.createdAt || booking.createdAt)],
      ['Updated at', timestampValue(resolved.updatedAt)],
    ]),
  });
}

function supportDetails(ticket = {}, row = []) {
  const booking = findBookingByAny(ticket.bookingRef || ticket.referenceId || row[1]) || {};
  return dashboardDetails(ticket.subject || row[0] || 'Support case', {
    'Support case': groupFields(ticket, [
      ['Support case ID', ticket.id || row[0]],
      ['Owner type', ticket.ownerType || row[1]],
      ['Owner/user', ticket.ownerId],
      ['Company ID', ticket.companyId],
      ['Subject/category', ticket.subject || row[2]],
      ['Message', ticket.message],
      ['Priority', ticket.priority || row[3]],
      ['Status', ticket.status || row[4]],
      ['Assigned admin', ticket.assignedTo],
      ['Audience', ticket.audience],
      ['Resolution notes', ticket.resolutionNotes || ticket.lastResponse],
    ]),
    'Related booking / payment': groupFields(booking, [
      ['Booking reference', booking.bookingRef],
      ['Payment reference', bookingPayment(booking).providerReference],
      ['Customer', bookingCustomer(booking)],
      ['Customer email', booking.guestSnapshot?.email],
      ['Customer phone', booking.guestSnapshot?.phone],
      ['Company', bookingCompany(booking)],
    ]),
    'Timestamps': groupFields(ticket, [
      ['Created at', timestampValue(ticket.createdAt)],
      ['Updated at', timestampValue(ticket.updatedAt)],
      ['Responded at', timestampValue(ticket.respondedAt)],
    ]),
  });
}

function refundDetails(refund = {}, row = []) {
  const booking = findBookingByAny(refund.bookingRef || row[1]) || {};
  return dashboardDetails(`Refund ${refund.id || row[0] || ''}`, {
    'Refund': groupFields(refund, [
      ['Refund ID', refund.id || row[0]],
      ['Booking reference', refund.bookingRef || row[1]],
      ['Customer', bookingCustomer(booking) || row[2]],
      ['Company', bookingCompany(booking)],
      ['Amount', moneyValue(refund.amount || booking.pricing?.total, refund.currency || booking.pricing?.currency)],
      ['Currency', refund.currency || booking.pricing?.currency],
      ['Payment status', booking.paymentStatus],
      ['Refund reason', refund.reason || row[3]],
      ['Refund status', refund.status || row[5]],
      ['Requested by', refund.requesterId],
      ['Reviewed by', refund.approvedBy || refund.reviewedBy],
    ]),
    'Timestamps': groupFields(refund, [
      ['Requested at', timestampValue(refund.createdAt)],
      ['Reviewed at', timestampValue(refund.approvedAt || refund.reviewedAt)],
      ['Updated at', timestampValue(refund.updatedAt)],
    ]),
  });
}

function userDetails(user = {}, row = []) {
  const userBookings = state.bookings.filter((booking) => booking.customerUserId === user.id || booking.guestSnapshot?.email === user.email || booking.promoterAttribution?.promoterId === user.id);
  const wallet = state.wallets.find((item) => item.ownerId === user.id) || {};
  return dashboardDetails(user.fullName || row[0] || 'User', {
    'User': groupFields(user, [
      ['User ID', user.id],
      ['Name', user.fullName || row[0]],
      ['Email', user.email || row[1]],
      ['Phone', user.phone],
      ['Role', user.role],
      ['Status', user.status || row[5]],
      ['Company ID', user.companyId],
      ['Referral code', user.referralCode],
      ['Created at', timestampValue(user.createdAt)],
      ['Updated at', timestampValue(user.updatedAt)],
      ['Last activity', timestampValue(user.lastLoginAt)],
    ]),
    'Activity': groupFields(user, [
      ['Total bookings', userBookings.length],
      ['Confirmed bookings', userBookings.filter((booking) => ['confirmed', 'checked_in', 'completed'].includes(booking.bookingStatus)).length],
      ['Cancelled/refunded bookings', userBookings.filter((booking) => ['cancelled', 'refunded'].includes(booking.bookingStatus)).length],
      ['Total spend/revenue', moneyValue(userBookings.reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0), wallet.currency || 'UGX')],
      ['Wallet balance', moneyValue(wallet.availableBalance || 0, wallet.currency || 'UGX')],
      ['Pending balance', moneyValue(wallet.pendingBalance || 0, wallet.currency || 'UGX')],
    ]),
  });
}

function campaignDetails(campaign = {}, row = []) {
  const listing = findListing(campaign.listingId) || {};
  const company = findCompany(campaign.companyId || listing.companyId) || {};
  return dashboardDetails(campaign.name || campaign.title || row[0] || 'Campaign', {
    'Campaign': groupFields(campaign, [
      ['Promotion ID', campaign.id],
      ['Owner/company', company.name],
      ['Promoter', campaign.promoterId ? findUser(campaign.promoterId)?.fullName : ''],
      ['Campaign title', campaign.name || campaign.title || row[0]],
      ['Type', campaign.placement || campaign.type || row[2]],
      ['Target listing', listing.title || campaign.listingId],
      ['Start date', timestampValue(campaign.startsAt || campaign.startAt)],
      ['End date', timestampValue(campaign.endsAt || campaign.endAt)],
      ['Budget', moneyValue(campaign.budget, campaign.currency || listing.currency || 'UGX')],
      ['Spend', moneyValue(campaign.spend || 0, campaign.currency || listing.currency || 'UGX')],
      ['Status', campaign.status || row[row.length - 1]],
      ['Clicks/views', `${campaign.clicks || row[4] || 0} clicks / ${campaign.views || 0} views`],
      ['Conversions', campaign.bookings || campaign.conversions || row[5]],
    ]),
    'Timestamps': groupFields(campaign, [
      ['Created at', timestampValue(campaign.createdAt)],
      ['Updated at', timestampValue(campaign.updatedAt)],
    ]),
  });
}

function walletTxnDetails(txn = {}, row = []) {
  const wallet = findWallet(`${txn.ownerType}:${txn.ownerId}`) || {};
  return dashboardDetails(txn.id || row[0] || 'Wallet transaction', {
    'Wallet / transaction': groupFields(txn, [
      ['Txn ID', txn.id || row[0]],
      ['Owner type', txn.ownerType],
      ['Owner ID', txn.ownerId || row[2]],
      ['Wallet ID', wallet.id],
      ['Type', txn.transactionType || row[1]],
      ['Direction', txn.direction],
      ['Amount', moneyValue(txn.amount || row[4], txn.currency || row[2] || 'UGX')],
      ['Currency', txn.currency || wallet.currency],
      ['Status', txn.status || row[5]],
      ['Reference type', txn.referenceType],
      ['Reference ID', txn.referenceId],
      ['Reviewed by', txn.reviewedBy || txn.approvedBy],
    ]),
    'Timestamps': groupFields(txn, [
      ['Created at', timestampValue(txn.createdAt)],
      ['Updated at', timestampValue(txn.updatedAt)],
      ['Reviewed at', timestampValue(txn.reviewedAt || txn.approvedAt)],
    ]),
  });
}

function reviewDetails(review = {}, row = []) {
  const booking = state.bookings.find((item) => item.id === review.bookingId || item.bookingRef === row[0]) || {};
  const listing = findListing(review.listingId || booking.listingId) || {};
  return dashboardDetails(`Review ${review.id || row[0] || ''}`, {
    'Review': groupFields(review, [
      ['Review ID', review.id],
      ['Customer', bookingCustomer(booking) || review.customerUserId || row[0]],
      ['Booking/trip', booking.bookingRef || row[0]],
      ['Listing', listing.title || row[1]],
      ['Rating', review.rating || row[2]],
      ['Comment', review.comment || row[3]],
      ['Status', review.status || row[5]],
      ['Company reply', review.companyReply?.message],
      ['Replied by', review.companyReply?.repliedBy],
    ]),
    'Timestamps': groupFields(review, [
      ['Created at', timestampValue(review.createdAt)],
      ['Updated at', timestampValue(review.updatedAt)],
      ['Replied at', timestampValue(review.companyReply?.repliedAt)],
    ]),
  });
}

function employeeDetails(employee = {}, row = []) {
  const user = findUser(employee.userId) || findUser(row[0]) || {};
  const company = findCompany(employee.companyId || user.companyId) || {};
  return dashboardDetails(user.fullName || row[0] || 'Employee', {
    'Staff': groupFields(employee, [
      ['Staff ID', employee.id],
      ['User ID', user.id || employee.userId],
      ['Name', user.fullName || row[0]],
      ['Email', user.email],
      ['Phone', user.phone],
      ['Role', user.role],
      ['Status', employee.status || user.status || row[5]],
      ['Job title', employee.roleTitle || row[1]],
      ['Branch', employee.branch || row[2]],
      ['Permissions label', (employee.permissions || []).join(', ') || row[3]],
      ['Company', company.name],
      ['Invited by', employee.invitedBy],
    ]),
    'Timestamps': groupFields(employee, [
      ['Invited at', timestampValue(employee.invitedAt)],
      ['Onboarded at', timestampValue(employee.onboardedAt)],
      ['Created at', timestampValue(employee.createdAt)],
      ['Updated at', timestampValue(employee.updatedAt)],
      ['Last activity', timestampValue(user.lastLoginAt)],
    ]),
  });
}

function handoverDetails(handover = {}, row = []) {
  const user = findUser(handover.employeeId) || {};
  const company = findCompany(handover.companyId) || {};
  return dashboardDetails(handover.shift || row[0] || 'Shift handover', {
    'Shift handover': groupFields(handover, [
      ['Handover ID', handover.id],
      ['Employee', user.fullName || handover.employeeId || row[1]],
      ['Company', company.name],
      ['Shift date', timestampValue(handover.shiftDate || handover.createdAt)],
      ['Shift', handover.shift || row[0]],
      ['Next staff', handover.nextStaff || row[1]],
      ['Notes', handover.note || row[2]],
      ['Cash collected', moneyValue(handover.cashCollected || 0, company.settings?.defaultCurrency || 'UGX')],
      ['Bookings handled', handover.bookingsHandled],
      ['Check-ins handled', handover.checkInsHandled],
      ['Issues', handover.issues],
      ['Status', handover.status || row[3]],
    ]),
    'Timestamps': groupFields(handover, [
      ['Created at', timestampValue(handover.createdAt)],
      ['Updated at', timestampValue(handover.updatedAt)],
    ]),
  });
}

function auditDetails(log = {}, row = []) {
  return dashboardDetails(log.action || row[2] || 'Audit event', {
    'Audit event': groupFields(log, [
      ['Audit ID', log.id],
      ['Actor user ID', log.actorId || row[1]],
      ['Actor role', log.actorRole],
      ['Action', log.action || row[2]],
      ['Entity type', log.entityType || log.targetType || row[3]],
      ['Entity ID', log.entityId || log.target || row[3]],
      ['Metadata', log.metadata ? JSON.stringify(log.metadata) : log.meta ? JSON.stringify(log.meta) : row[4]],
      ['IP / user agent', [log.ip, log.userAgent].filter(Boolean).join(' / ')],
      ['Status', log.status || row[5]],
      ['Created at', timestampValue(log.createdAt) || row[0]],
    ]),
  });
}

function referralLinkDetails(link = {}, row = []) {
  const listing = findListing(link.listingId) || {};
  const promoter = findUser(link.promoterId) || {};
  return dashboardDetails(link.code || row[0] || 'Referral link', {
    'Referral link': groupFields(link, [
      ['Referral link ID', link.id],
      ['Referral code', link.code || row[0]],
      ['Promoter', promoter.fullName],
      ['Promoter email', promoter.email],
      ['Listing', listing.title || row[1]],
      ['Service type', listing.serviceType || row[2]],
      ['Marketplace referral URL', `/listings/${listing.slug || listing.id}?ref=${link.code || row[0]}`],
      ['Clicks', link.clicks || row[3]],
      ['Conversions', link.conversions || row[4]],
      ['Status', link.status || row[5]],
    ]),
    'Timestamps': groupFields(link, [
      ['Created at', timestampValue(link.createdAt)],
      ['Updated at', timestampValue(link.updatedAt)],
    ]),
  });
}

function notificationDetails(notice = {}, row = []) {
  return dashboardDetails(notice.title || notice.subject || row[0] || 'Notification', {
    'Notification': groupFields(notice, [
      ['Notification ID', notice.id || row[0]],
      ['Title', notice.title || notice.subject || row[0]],
      ['Channel', notice.channel || row[1]],
      ['Audience', notice.audience || notice.recipient?.name || row[2]],
      ['Body', notice.message || notice.body || row[2]],
      ['Created by', notice.createdBy],
      ['Delivery status', notice.status || row[row.length - 1]],
      ['Reference type', notice.referenceType],
      ['Reference ID', notice.referenceId],
      ['Created at', timestampValue(notice.createdAt) || row[3]],
      ['Updated at', timestampValue(notice.updatedAt)],
    ]),
  });
}

function detailsForEntity(entity, identifier, row = []) {
  const key = identifier || row[0];
  if (['booking', 'checkin', 'customer-booking'].includes(entity)) return bookingDetails(findBookingByAny(key) || {}, row);
  if (entity === 'customer') return bookingDetails(findBookingByAny(key) || findBookingByAny(row[1]) || {}, row);
  if (entity === 'partner' || entity === 'company') return companyDetails(findCompany(key) || findCompany(row[0]) || {}, row);
  if (entity === 'listing') return listingDetails(findListing(key) || findListing(row[0]) || {}, row);
  if (entity === 'route') return routeDetails(findRoute(key) || findRoute(row[0]) || {}, row);
  if (entity === 'schedule') return scheduleDetails(findSchedule(key) || {}, row);
  if (entity === 'vehicle') return vehicleDetails(findVehicle(key) || findVehicle(row[0]) || {}, row);
  if (entity === 'room') return roomDetails(findRoom(key) || findRoom(row[0]) || {}, row);
  if (entity === 'payment') return paymentDetails(findPayment(key) || findPayment(row[1]) || {}, row);
  if (entity === 'payout' || entity === 'withdrawal' || entity === 'wallet' || entity === 'wallet_txn') return walletTxnDetails(findWalletTxn(key) || {}, row);
  if (entity === 'support') return supportDetails(findSupportTicket(key) || {}, row);
  if (entity === 'refund') return refundDetails(findRefund(key) || findRefund(row[1]) || {}, row);
  if (entity === 'promotion' || entity === 'campaign') return campaignDetails(findCampaign(key) || findCampaign(row[0]) || {}, row);
  if (entity === 'review') return reviewDetails(findReview(key) || findReview(row[0]) || {}, row);
  if (entity === 'employee' || entity === 'staff' || entity === 'admin' || entity === 'promoter' || entity === 'user') return userDetails(findUser(key) || findUser(row[0]) || {}, row);
  if (entity === 'company_employee') return employeeDetails(findCompanyEmployee(key) || {}, row);
  if (entity === 'handover') return handoverDetails(findHandover(key) || {}, row);
  if (entity === 'audit' || entity === 'fraud') return auditDetails(state.auditLogs.find((log) => normalize(log.id) === normalize(key) || normalize(log.action) === normalize(row[2])) || {}, row);
  if (entity === 'referral_link') return referralLinkDetails(findReferralLink(key) || {}, row);
  if (entity === 'notification') return notificationDetails(findNotification(key) || {}, row);
  return dashboardDetails(row[0] || key || 'Record', { 'Table row': Object.fromEntries(row.map((cell, index) => [`Column ${index + 1}`, cell])) });
}

function attachRowDetails(row, spec = {}) {
  if (!Array.isArray(row)) return row;
  const cells = rowWithoutMeta(row);
  const existing = lastRowMeta(row) || {};
  const entity = existing.entity || spec.entity;
  if (!entity) return row;
  const id = existing.id || cells[spec.idIndex ?? 0] || cells[0];
  const label = existing.label || cells[spec.labelIndex ?? 0] || id;
  const status = existing.status || cells[spec.statusIndex ?? cells.length - 1] || '';
  const meta = {
    entity,
    id,
    label,
    status,
    ...existing,
  };
  if (!meta.details) meta.details = detailsForEntity(entity, meta.id, cells);
  return [...cells, meta];
}

function enrichDashboardRows(role, data = {}) {
  const shared = [
    { key: 'recentBookings', entity: 'booking', idIndex: 0, labelIndex: 1, statusIndex: 4 },
    { key: 'bookings', entity: 'booking', idIndex: 0, labelIndex: 1, statusIndex: 5 },
    { key: 'payments', entity: 'payment', idIndex: 0, labelIndex: 1, statusIndex: 6 },
    { key: 'support', entity: 'support', idIndex: 0, labelIndex: 2, statusIndex: 4 },
    { key: 'refunds', entity: 'refund', idIndex: 0, labelIndex: 1, statusIndex: 5 },
    { key: 'reviews', entity: 'review', idIndex: 0, labelIndex: 1, statusIndex: 5 },
    { key: 'notifications', entity: 'notification', idIndex: 0, labelIndex: 0, statusIndex: 5 },
  ];
  const roleSpecs = {
    admin: [
      { key: 'partners', entity: 'partner', idIndex: 0, labelIndex: 0, statusIndex: 4 },
      { key: 'listings', entity: 'listing', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'promoters', entity: 'promoter', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'customers', entity: 'user', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'ads', entity: 'promotion', idIndex: 0, labelIndex: 0, statusIndex: 6 },
      { key: 'routeInventory', entity: 'route', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'stayInventory', entity: 'listing', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'reviewInventory', entity: 'listing', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'audit', entity: 'audit', idIndex: 2, labelIndex: 2, statusIndex: 5 },
      { key: 'financeAudit', entity: 'audit', idIndex: 2, labelIndex: 2, statusIndex: 5 },
      { key: 'securityAudit', entity: 'audit', idIndex: 1, labelIndex: 1, statusIndex: 5 },
      { key: 'admins', entity: 'admin', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'kyc', entity: 'partner', idIndex: 0, labelIndex: 0, statusIndex: 5 },
    ],
    company: [
      { key: 'listings', entity: 'listing', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'routes', entity: 'route', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'vehicles', entity: 'vehicle', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'schedules', entity: 'schedule', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'checkins', entity: 'checkin', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'inventory', entity: 'schedule', idIndex: 0, labelIndex: 1, statusIndex: 6 },
      { key: 'payouts', entity: 'payout', idIndex: 0, labelIndex: 1, statusIndex: 6 },
      { key: 'promotions', entity: 'promotion', idIndex: 0, labelIndex: 0, statusIndex: 6 },
      { key: 'staff', entity: 'company_employee', idIndex: 0, labelIndex: 0, statusIndex: 5 },
    ],
    employee: [
      { key: 'tasks', entity: 'support', idIndex: 0, labelIndex: 2, statusIndex: 4 },
      { key: 'checkins', entity: 'checkin', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'schedules', entity: 'schedule', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'inventory', entity: 'schedule', idIndex: 0, labelIndex: 1, statusIndex: 6 },
      { key: 'customers', entity: 'customer', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'handovers', entity: 'handover', idIndex: 0, labelIndex: 0, statusIndex: 3 },
    ],
    customer: [
      { key: 'saved', entity: 'listing', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'receipts', entity: 'payment', idIndex: 1, labelIndex: 0, statusIndex: 5 },
      { key: 'wallet', entity: 'wallet', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'security', entity: 'audit', idIndex: 0, labelIndex: 0, statusIndex: 3 },
    ],
    promoter: [
      { key: 'links', entity: 'referral_link', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'share', entity: 'listing', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'commissions', entity: 'booking', idIndex: 1, labelIndex: 1, statusIndex: 5 },
      { key: 'withdrawals', entity: 'withdrawal', idIndex: 0, labelIndex: 1, statusIndex: 5 },
      { key: 'campaigns', entity: 'promotion', idIndex: 0, labelIndex: 0, statusIndex: 6 },
      { key: 'payouts', entity: 'wallet', idIndex: 0, labelIndex: 0, statusIndex: 5 },
      { key: 'fraud', entity: 'fraud', idIndex: 0, labelIndex: 0, statusIndex: 4 },
    ],
  };
  [...shared, ...(roleSpecs[role] || [])].forEach((spec) => {
    if (Array.isArray(data[spec.key])) data[spec.key] = data[spec.key].map((row) => attachRowDetails(row, spec));
  });
  return data;
}

function dashboardData(role = 'admin', context = {}) {
  const companyId = context.companyId || 'company-01';
  const promoterId = context.promoterId || 'user-promoter-001';
  const customerId = context.customerId || 'user-customer-001';
  const bookings = state.bookings.slice();
  const companyBookings = bookings.filter((booking) => booking.companyId === companyId);
  const customerUser = state.users.find((user) => user.id === customerId) || {};
  const customerBookings = bookings.filter((booking) => (
    booking.customerUserId === customerId
    || normalize(booking.guestSnapshot?.email) === normalize(customerUser.email)
    || normalize(booking.guestSnapshot?.phone) === normalize(customerUser.phone)
    || booking.guestSnapshot?.email === 'customer@classictrip.test'
  ));
  const promoterLinks = state.promoterLinks.filter((link) => link.promoterId === promoterId);
  const promoterBookings = bookings.filter((booking) => booking.promoterAttribution?.promoterId === promoterId);
  const companyListings = state.listings.filter((listing) => listing.companyId === companyId);

  if (role === 'admin') return enrichDashboardRows(role, adminDashboardData(bookings));
  if (role === 'company') return enrichDashboardRows(role, companyDashboardData(companyId, companyListings, companyBookings));
  if (role === 'employee') return enrichDashboardRows(role, employeeDashboardData(companyId, companyBookings, context));
  if (role === 'customer') return enrichDashboardRows(role, customerDashboardData(customerBookings));
  if (role === 'promoter') return enrichDashboardRows(role, promoterDashboardData(promoterLinks, promoterBookings));
  return {};
}

function adminDashboardData(bookings) {
  const listingRows = state.listings.slice(0, 18).map((listing) => [
    listing.title,
    listing.type,
    listing.partner,
    listing.serviceType === 'hotel' ? `${roomsForListing(listing.id).reduce((total, room) => total + room.inventory, 0)} rooms` : listing.serviceType === 'bus' ? `${schedulesForListing(listing.id).reduce((total, schedule) => total + schedule.availableSeats, 0)} seats` : 'Provider inventory',
    listing.corridor || listing.country,
    listing.isSponsored ? 'Sponsored' : listing.bookable ? 'Available' : 'Teaser',
    moneyValue(listing.priceFrom, listing.currency),
  ]);
  const companyRows = state.companies.slice(0, 18).map((company) => {
    const listings = listingsForCompany(company.id);
    const revenue = bookings.filter((booking) => booking.companyId === company.id).reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0);
    return [
      company.name,
      company.companyType,
      company.country,
      String(listings.length),
      company.verificationStatus,
      moneyValue(revenue),
      { entity: 'partner', id: company.id, slug: company.slug, label: company.name, status: company.verificationStatus },
    ];
  });
  const bookingRows = bookings.slice(0, 18).map((booking) => [
    booking.bookingRef,
    bookingTitle(booking),
    bookingCustomer(booking),
    dateValue(booking.createdAt),
    booking.lockedUntil ? '10 min hold' : 'None',
    booking.bookingStatus,
    bookingTotal(booking),
  ]);
  return {
    recentBookings: bookings.slice(0, 8).map((booking) => [booking.bookingRef, booking.serviceType, bookingCustomer(booking), bookingCompany(booking), booking.paymentStatus, bookingTotal(booking)]),
    bookings: bookingRows,
    partners: companyRows,
    listings: listingRows,
    payments: bookings.slice(0, 12).map((booking, index) => [
      `TX-${78000 + index}`,
      booking.bookingRef,
      bookingTotal(booking),
      moneyValue(booking.pricing?.split?.companyAmount || 0, booking.pricing?.currency),
      moneyValue(booking.pricing?.split?.platformFee || 0, booking.pricing?.currency),
      moneyValue(booking.pricing?.split?.promoterAmount || 0, booking.pricing?.currency),
      booking.paymentStatus,
    ]),
    promoters: state.users.filter((user) => user.role === 'promoter').map((user) => {
      const links = state.promoterLinks.filter((link) => link.promoterId === user.id);
      const commission = bookings.filter((booking) => booking.promoterAttribution?.promoterId === user.id).reduce((total, booking) => total + Number(booking.pricing?.split?.promoterAmount || 0), 0);
      return [user.fullName, String(links.reduce((total, link) => total + link.clicks, 0)), String(links.reduce((total, link) => total + link.conversions, 0)), moneyValue(commission), moneyValue(state.wallets.find((wallet) => wallet.ownerId === user.id)?.availableBalance || 0), user.status || 'active'];
    }),
    customers: state.users.filter((user) => user.role === 'customer').map((user) => [user.fullName, user.email || user.phone, String(bookings.filter((booking) => booking.customerUserId === user.id).length), moneyValue(bookings.filter((booking) => booking.customerUserId === user.id).reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0)), 'Recent', user.status || 'active']),
    support: state.supportTickets.map((ticket) => [ticket.id, ticket.ownerType, ticket.subject, ticket.priority, ticket.status, 'Recent']),
    ads: state.promotionCampaigns.map((campaign) => [campaign.name, findCompany(campaign.companyId)?.name || 'Partner', campaign.placement, moneyValue(campaign.budget), String(campaign.clicks), String(campaign.bookings), campaign.status]),
    routeInventory: state.routes.slice(0, 12).map((route) => {
      const schedules = schedulesForListing(route.listingId);
      const listing = findListing(route.listingId);
      return [`${route.origin} to ${route.destination}`, listing?.title || 'Route', listing?.partner || 'Partner', `${schedules.reduce((total, schedule) => total + schedule.availableSeats, 0)} seats`, `${schedules.length} schedules`, route.status, moneyValue(listing?.priceFrom || 0)];
    }),
    stayInventory: state.rooms.slice(0, 12).map((room) => {
      const listing = findListing(room.listingId);
      return [listing?.title || 'Hotel', room.roomType, listing?.partner || 'Partner', `${room.inventory} rooms`, listing?.city || 'City', room.status, moneyValue(room.nightlyPrice)];
    }),
    reviewInventory: state.listings.filter((listing) => listing.releaseStatus !== 'live').slice(0, 8).map((listing) => [listing.title, listing.partner, 'Provider integration pending', 'Medium', 'Recent', 'Needs review']),
    audit: state.auditLogs.map((log) => [dateValue(log.createdAt), log.actorId, log.action, log.target, 'Backend store', 'Success']),
    financeAudit: bookings.slice(0, 5).map((booking) => [dateValue(booking.createdAt), 'System', 'Revenue split', bookingTotal(booking), 'Low', 'Success']),
    securityAudit: [['Today', 'Dashboard data rendered', 'Backend store', 'Server session', 'Low', 'Success']],
    kyc: state.companies.slice(0, 10).map((company) => [
      company.name,
      Array.isArray(company.documents) && company.documents.length ? `${company.documents.length} documents` : 'Business profile',
      company.country,
      company.walletId || 'Wallet pending',
      company.verificationStatus === 'verified' ? 'Low' : 'Medium',
      company.verificationStatus,
      { entity: 'partner', id: company.id, slug: company.slug, label: company.name, status: company.verificationStatus },
    ]),
    refunds: state.refundRequests.map((refund) => [refund.id, refund.bookingRef, 'Customer', refund.reason, moneyValue(refund.amount), refund.status]),
    notifications: state.supportTickets.map((ticket) => [ticket.subject, 'Email', ticket.ownerType, '1', 'Pending', ticket.status]),
  };
}

function companyDashboardData(companyId, listings, bookings) {
  const company = findCompany(companyId) || {};
  const companyRoutes = state.routes.filter((route) => route.companyId === companyId);
  const vehicles = (state.vehicles || []).filter((vehicle) => vehicle.companyId === companyId);
  const schedules = state.schedules.filter((schedule) => schedule.companyId === companyId);
  const rooms = state.rooms.filter((room) => room.companyId === companyId);
  const reviews = state.reviews.filter((review) => review.companyId === companyId);
  const companyEmployees = Array.isArray(state.companyEmployees) ? state.companyEmployees.filter((employee) => employee.companyId === companyId) : [];
  const supportTickets = state.supportTickets.filter((ticket) => ticket.companyId === companyId || (ticket.ownerType === 'company' && (!ticket.ownerId || ticket.ownerId === companyId)));
  const grossRevenue = bookings.reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0);
  const companyEarnings = bookings.reduce((total, booking) => total + Number(booking.pricing?.split?.companyAmount || 0), 0);
  const seats = schedules.flatMap((schedule) => seatsForSchedule(schedule.id));
  const bookedSeats = seats.filter((seat) => seat.status === 'taken').length;
  const heldSeats = seats.filter((seat) => seat.status === 'locked').length;
  const blockedSeats = seats.filter((seat) => seat.status === 'blocked').length;
  const fillRate = seats.length ? Math.round((bookedSeats / seats.length) * 100) : 0;
  const activeListings = listings.filter((listing) => listing.status === 'active');
  const activeSchedules = schedules.filter((schedule) => schedule.status === 'active');
  const checkedInBookings = bookings.filter((booking) => booking.bookingStatus === 'checked_in');
  const scheduleLabel = (schedule) => {
    const departAt = schedule.departAt ? new Date(schedule.departAt) : null;
    const time = departAt && !Number.isNaN(departAt.getTime()) ? departAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }) : '';
    return `${dateValue(schedule.departAt)}${time ? ` ${time}` : ''}`;
  };
  const listingOption = (listing) => ({
    id: listing.id,
    value: listing.id,
    label: listing.title,
    serviceType: listing.serviceType,
    status: listing.status,
  });
  const routeOption = (route) => {
    const listing = findListing(route.listingId);
    return {
      id: route.id,
      value: route.id,
      label: `${route.origin} to ${route.destination}${listing ? ` - ${listing.title}` : ''}`,
      listingId: route.listingId,
      status: route.status,
    };
  };
  const scheduleOption = (schedule) => ({
    id: schedule.id,
    value: schedule.id,
    label: `${scheduleLabel(schedule)} - ${bookingTitle({ listingId: schedule.listingId })}`,
    routeId: schedule.routeId,
    listingId: schedule.listingId,
    status: schedule.status,
  });
  const roomOption = (room) => ({
    id: room.id,
    value: room.id,
    label: `${room.roomType} - ${bookingTitle({ listingId: room.listingId })}`,
    listingId: room.listingId,
    status: room.status,
  });
  const vehicleOption = (vehicle) => ({
    id: vehicle.id,
    value: vehicle.id,
    label: `${vehicle.name}${vehicle.plateOrCode ? ` - ${vehicle.plateOrCode}` : ''} (${vehicle.totalSeats || 0} seats)`,
    serviceType: vehicle.serviceType,
    listingId: vehicle.listingId,
    status: vehicle.status,
  });
  const seatInventoryRows = schedules.map((schedule) => {
    const scheduleSeats = seatsForSchedule(schedule.id);
    const totalSeats = scheduleSeats.length || Number(schedule.totalSeats || 0);
    const sold = scheduleSeats.filter((seat) => seat.status === 'taken').length;
    const held = scheduleSeats.filter((seat) => seat.status === 'locked').length;
    const blocked = scheduleSeats.filter((seat) => seat.status === 'blocked').length;
    return [
      `Seat map ${schedule.id}`,
      bookingTitle({ listingId: schedule.listingId }),
      String(totalSeats),
      String(sold),
      String(held),
      String(blocked),
      schedule.status,
      { entity: 'schedule', id: schedule.id, label: `Seat map ${schedule.id}`, status: schedule.status },
    ];
  });
  const roomInventoryRows = rooms.map((room) => {
    const roomBookings = bookings.filter((booking) => booking.listingId === room.listingId && booking.passengers?.some((passenger) => passenger.seatOrRoom === room.roomType)).length;
    return [
      room.roomType,
      bookingTitle({ listingId: room.listingId }),
      String(room.inventory + roomBookings),
      String(roomBookings),
      '0',
      room.status === 'active' ? '0' : String(room.inventory),
      room.status,
      { entity: 'room', id: room.id, label: room.roomType, status: room.status },
    ];
  });
  return {
    company: {
      id: company.id || companyId,
      name: company.name || 'Company partner',
      slug: company.slug || companyId,
      type: company.companyType || company.type || 'partner',
      city: company.city || '',
      country: company.country || '',
      verificationStatus: company.verificationStatus || 'pending',
      supportEmail: company.supportContacts?.email || '',
      supportPhone: company.supportContacts?.phone || '',
      supportWhatsapp: company.supportContacts?.whatsapp || '',
      payoutAccount: company.payoutAccount || company.settings?.payoutAccount || '',
      defaultCurrency: company.settings?.defaultCurrency || 'UGX',
      supportMessage: company.settings?.supportMessage || '',
      ratingAverage: Number(company.ratingAverage || 0),
      reviewCount: Number(company.reviewCount || reviews.length),
    },
    stats: {
      earnings: moneyValue(companyEarnings),
      grossRevenue: moneyValue(grossRevenue),
      confirmedBookings: bookings.length.toLocaleString(),
      activeListings: activeListings.length.toLocaleString(),
      seatsOnHold: heldSeats.toLocaleString(),
      upcomingTrips: activeSchedules.length.toLocaleString(),
      openSupportCases: supportTickets.filter((ticket) => !['closed', 'resolved'].includes(normalize(ticket.status))).length.toLocaleString(),
      fillRate: `${fillRate}%`,
      rating: `${Number(company.ratingAverage || 0).toFixed(1)}/5`,
      routeCount: companyRoutes.length.toLocaleString(),
      vehicleCount: vehicles.filter((vehicle) => vehicle.status !== 'archived').length.toLocaleString(),
      roomTypes: rooms.length.toLocaleString(),
      blockedSeats: blockedSeats.toLocaleString(),
      checkedIn: checkedInBookings.length.toLocaleString(),
    },
    options: {
      listings: listings.map(listingOption),
      busListings: listings.filter((listing) => listing.serviceType === 'bus').map(listingOption),
      hotelListings: listings.filter((listing) => listing.serviceType === 'hotel').map(listingOption),
      transportListings: listings.filter((listing) => ROUTED_SERVICE_TYPES.includes(listing.serviceType)).map(listingOption),
      routes: companyRoutes.filter((route) => route.status !== 'archived').map(routeOption),
      vehicles: vehicles.filter((vehicle) => vehicle.status !== 'archived').map(vehicleOption),
      schedules: schedules.filter((schedule) => schedule.status !== 'archived').map(scheduleOption),
      rooms: rooms.filter((room) => room.status !== 'archived').map(roomOption),
    },
    recentBookings: bookings.slice(0, 8).map((booking) => [booking.bookingRef, bookingTitle(booking), bookingCustomer(booking), booking.passengers?.[0]?.seatOrRoom || 'Selected', booking.bookingStatus, bookingTotal(booking)]),
    listings: listings.map((listing) => [
      listing.title,
      listing.type,
      listing.serviceType === 'hotel' ? [listing.city, listing.country].filter(Boolean).join(', ') : `${listing.from} to ${listing.to}`,
      listing.serviceType === 'hotel' ? `${roomsForListing(listing.id).length} room types` : `${schedulesForListing(listing.id).length} schedules`,
      moneyValue(listing.priceFrom),
      listing.status,
      { entity: 'listing', id: listing.id, label: listing.title, status: listing.status },
    ]),
    routes: companyRoutes.map((route) => [
      `${route.origin} to ${route.destination}`,
      bookingTitle({ listingId: route.listingId }),
      `${route.boardingPoints?.length || 0} boarding`,
      `${route.dropoffPoints?.length || 0} dropoffs`,
      route.corridor || '',
      route.status,
      { entity: 'route', id: route.id, label: `${route.origin} to ${route.destination}`, status: route.status },
    ]),
    schedules: schedules.slice(0, 24).map((schedule) => {
      const totalSeats = Number(schedule.totalSeats || 0);
      const sold = Math.max(0, totalSeats - Number(schedule.availableSeats || 0) - seatsForSchedule(schedule.id).filter((seat) => ['locked', 'blocked'].includes(seat.status)).length);
      const vehicle = vehicles.find((item) => item.id === schedule.vehicleId);
      return [
        schedule.id,
        bookingTitle({ listingId: schedule.listingId }),
        scheduleLabel(schedule),
        vehicle?.name || schedule.vehicleName || 'Vehicle pending',
        `${sold}/${totalSeats}`,
        schedule.status,
        { entity: 'schedule', id: schedule.id, label: schedule.id, status: schedule.status },
      ];
    }),
    vehicles: vehicles.map((vehicle) => [
      vehicle.name,
      SERVICE_LABELS[vehicle.serviceType] || vehicle.serviceType || 'Vehicle',
      vehicle.plateOrCode || '-',
      `${vehicle.totalSeats || 0} seats`,
      vehicle.layoutName || 'Layout pending',
      vehicle.status,
      { entity: 'vehicle', id: vehicle.id, label: vehicle.name, status: vehicle.status },
    ]),
    bookings: bookings.map((booking) => [booking.bookingRef, bookingTitle(booking), bookingCustomer(booking), booking.passengers?.[0]?.seatOrRoom || 'Selected', dateValue(booking.createdAt), booking.bookingStatus, bookingTotal(booking)]),
    checkins: bookings.slice(0, 24).map((booking) => [
      booking.bookingRef,
      bookingCustomer(booking),
      bookingTitle(booking),
      booking.passengers?.[0]?.seatOrRoom || 'Selected',
      booking.checkedInAt ? dateValue(booking.checkedInAt) : 'Pending',
      booking.bookingStatus === 'checked_in' ? 'Checked in' : booking.bookingStatus,
      { entity: 'checkin', id: booking.bookingRef, label: booking.bookingRef, status: booking.bookingStatus },
    ]),
    inventory: [...seatInventoryRows, ...roomInventoryRows],
    payouts: [
      ...state.walletTransactions.filter((txn) => txn.ownerType === 'company' && txn.ownerId === companyId).map((txn) => [
        txn.id,
        txn.transactionType || txn.referenceType || 'Wallet transaction',
        moneyValue(txn.amount, txn.currency),
        txn.direction === 'debit' ? moneyValue(txn.amount, txn.currency) : '-',
        '-',
        '-',
        txn.status,
        { entity: 'payout', id: txn.id, label: txn.id, status: txn.status },
      ]),
      ...bookings.slice(0, 10).map((booking, index) => [`TX-${9000 + index}`, booking.bookingRef, bookingTotal(booking), moneyValue(booking.pricing?.split?.companyAmount || 0), moneyValue(booking.pricing?.split?.platformFee || 0), moneyValue(booking.pricing?.split?.promoterAmount || 0), booking.paymentStatus]),
    ],
    promotions: state.promotionCampaigns.filter((campaign) => campaign.companyId === companyId).map((campaign) => [campaign.name, findListing(campaign.listingId)?.title || 'Listing', campaign.placement, moneyValue(campaign.budget), String(campaign.clicks), String(campaign.bookings), campaign.status, { entity: 'promotion', id: campaign.id, label: campaign.name, status: campaign.status }]),
    reviews: reviews.map((review) => {
      const booking = state.bookings.find((item) => item.id === review.bookingId);
      return [
        bookingCustomer(booking || {}) || review.customerUserId || 'Customer',
        bookingTitle({ listingId: review.listingId }),
        String(review.rating || '-'),
        review.comment || '',
        review.companyReply?.message ? `Replied: ${review.companyReply.message}` : dateValue(review.createdAt),
        review.status,
        { entity: 'review', id: review.id, label: booking?.bookingRef || review.id, status: review.status },
      ];
    }),
    staff: companyEmployees.map((employee) => {
      const user = state.users.find((item) => item.id === employee.userId) || {};
      return [user.fullName || user.email || employee.userId, employee.roleTitle || 'Staff', employee.branch || 'Main branch', (employee.permissions || []).join(', '), user.lastLoginAt ? dateValue(user.lastLoginAt) : 'Invited', employee.status || user.status || 'active', { entity: 'employee', id: employee.id, label: user.fullName || user.email || employee.userId, status: employee.status || user.status || 'active' }];
    }),
    support: supportTickets.map((ticket) => [
      ticket.id,
      ticket.audience || ticket.ownerType,
      ticket.subject,
      ticket.priority,
      ticket.status,
      ticket.updatedAt ? dateValue(ticket.updatedAt) : dateValue(ticket.createdAt),
      { entity: 'support', id: ticket.id, label: ticket.id, status: ticket.status },
    ]),
  };
}

function employeeDashboardData(companyId, bookings, context = {}) {
  const employeeId = context.employeeId || 'user-employee-001';
  const company = findCompany(companyId) || {};
  const employeeUser = state.users.find((user) => user.id === employeeId) || state.users.find((user) => user.companyId === companyId && user.role === 'company_employee') || {};
  const employeeProfile = (Array.isArray(state.companyEmployees) ? state.companyEmployees : []).find((employee) => employee.companyId === companyId && employee.userId === employeeUser.id) || {};
  const listings = state.listings.filter((listing) => listing.companyId === companyId);
  const schedules = state.schedules.filter((schedule) => schedule.companyId === companyId).slice(0, 20);
  const rooms = state.rooms.filter((room) => room.companyId === companyId);
  const supportTickets = state.supportTickets.filter((ticket) => ticket.companyId === companyId || (ticket.ownerType === 'company' && (!ticket.ownerId || ticket.ownerId === companyId)));
  const companyDashboard = companyDashboardData(companyId, listings, bookings);
  const rows = bookings.slice(0, 18).map((booking) => [
    booking.bookingRef,
    bookingTitle(booking),
    bookingCustomer(booking),
    booking.passengers?.[0]?.seatOrRoom || 'Selected',
    dateValue(booking.createdAt),
    booking.bookingStatus,
    bookingTotal(booking),
    { entity: 'booking', id: booking.bookingRef, label: booking.bookingRef, status: booking.bookingStatus },
  ]);
  const paymentRows = [
    ...state.payments.filter((payment) => {
      const booking = findBooking(payment.bookingRef || payment.bookingId);
      return booking?.companyId === companyId;
    }).map((payment) => {
      const booking = findBooking(payment.bookingRef || payment.bookingId) || {};
      return [
        payment.id,
        payment.bookingRef,
        bookingCustomer(booking),
        payment.provider || 'Desk',
        moneyValue(payment.amount, payment.currency),
        payment.status,
        { entity: 'payment', id: payment.id, label: payment.id, status: payment.status },
      ];
    }),
    ...bookings.slice(0, 8).map((booking, index) => [
      `PAY-${8000 + index}`,
      booking.bookingRef,
      bookingCustomer(booking),
      'Classic Trip Payments',
      bookingTotal(booking),
      booking.paymentStatus,
      { entity: 'payment', id: booking.bookingRef, label: booking.bookingRef, status: booking.paymentStatus },
    ]),
  ];
  const handovers = (Array.isArray(state.shiftHandovers) ? state.shiftHandovers : [])
    .filter((handover) => handover.companyId === companyId)
    .slice(0, 12);
  const checkedInCount = bookings.filter((booking) => booking.bookingStatus === 'checked_in').length;
  const manualBookings = bookings.filter((booking) => booking.source === 'employee_manual').length;
  const deskSales = bookings.reduce((total, booking) => total + Number(booking.pricing?.total || 0), 0);
  return {
    company: {
      id: company.id || companyId,
      name: company.name || 'Company partner',
      slug: company.slug || companyId,
    },
    profile: {
      id: employeeUser.id || employeeId,
      fullName: employeeUser.fullName || 'Company employee',
      email: employeeUser.email || '',
      phone: employeeUser.phone || '',
      roleTitle: employeeProfile.roleTitle || 'Ticket Checker',
      branch: employeeProfile.branch || company.city || 'Main branch',
      shift: employeeProfile.shift || 'Morning shift',
      notes: employeeProfile.notes || 'Can create bookings, check in passengers, view payments, and create support tasks.',
      permissions: employeeProfile.permissions || ['check_in', 'view_bookings'],
    },
    stats: {
      checkedIn: checkedInCount.toLocaleString(),
      manualBookings: manualBookings.toLocaleString(),
      openTasks: supportTickets.filter((ticket) => !['closed', 'resolved', 'completed'].includes(normalize(ticket.status))).length.toLocaleString(),
      deskSales: moneyValue(deskSales),
      shiftEnds: employeeProfile.shiftEnds || '6:00 PM',
    },
    options: {
      listings: listings.filter((listing) => listing.bookable && listing.status === 'active').map((listing) => ({ id: listing.id, value: listing.id, label: listing.title, serviceType: listing.serviceType })),
      schedules: schedules.filter((schedule) => schedule.status !== 'archived').map((schedule) => ({ id: schedule.id, value: schedule.id, label: `${schedule.id} - ${bookingTitle({ listingId: schedule.listingId })}`, listingId: schedule.listingId, status: schedule.status })),
      rooms: rooms.filter((room) => room.status !== 'archived').map((room) => ({ id: room.id, value: room.id, label: `${room.roomType} - ${bookingTitle({ listingId: room.listingId })}`, listingId: room.listingId, status: room.status })),
    },
    tasks: supportTickets.map((ticket) => [
      ticket.id,
      ticket.audience || ticket.ownerType,
      ticket.subject,
      ticket.priority,
      ticket.status,
      ticket.updatedAt ? dateValue(ticket.updatedAt) : dateValue(ticket.createdAt),
      { entity: 'support', id: ticket.id, label: ticket.id, status: ticket.status },
    ]),
    checkins: bookings.slice(0, 18).map((booking) => [
      booking.bookingRef,
      bookingCustomer(booking),
      bookingTitle(booking),
      booking.passengers?.[0]?.seatOrRoom || 'Selected',
      booking.checkedInAt ? dateValue(booking.checkedInAt) : 'Pending',
      booking.bookingStatus === 'checked_in' ? 'Checked in' : 'Not checked',
      { entity: 'checkin', id: booking.bookingRef, label: booking.bookingRef, status: booking.bookingStatus },
    ]),
    bookings: rows,
    schedules: schedules.map((schedule) => [
      schedule.id,
      bookingTitle({ listingId: schedule.listingId }),
      dateValue(schedule.departAt),
      schedule.vehicleName || 'Assigned inventory',
      `${schedule.availableSeats}/${schedule.totalSeats}`,
      schedule.status,
      { entity: 'schedule', id: schedule.id, label: schedule.id, status: schedule.status },
    ]),
    inventory: companyDashboard.inventory,
    customers: bookings.slice(0, 12).map((booking) => [
      bookingCustomer(booking),
      booking.guestSnapshot?.phone || booking.guestSnapshot?.email || 'Contact',
      '1',
      bookingTitle(booking),
      bookingTotal(booking),
      booking.bookingStatus,
      { entity: 'customer', id: booking.bookingRef, label: bookingCustomer(booking), status: booking.bookingStatus },
    ]),
    payments: paymentRows,
    refunds: state.refundRequests
      .filter((refund) => !refund.companyId || refund.companyId === companyId || bookings.some((booking) => booking.bookingRef === refund.bookingRef))
      .map((refund) => [
        refund.id,
        refund.bookingRef,
        'Customer',
        refund.reason,
        moneyValue(refund.amount),
        refund.status,
        { entity: 'refund', id: refund.id, label: refund.id, status: refund.status },
      ]),
    support: supportTickets.map((ticket) => [
      ticket.id,
      ticket.audience || ticket.ownerType,
      ticket.subject,
      ticket.priority,
      ticket.status,
      ticket.updatedAt ? dateValue(ticket.updatedAt) : dateValue(ticket.createdAt),
      { entity: 'support', id: ticket.id, label: ticket.id, status: ticket.status },
    ]),
    handovers: handovers.length ? handovers.map((handover) => [
      handover.shift,
      handover.nextStaff || handover.employeeId,
      handover.note,
      handover.status,
      { entity: 'handover', id: handover.id, label: handover.shift, status: handover.status },
    ]) : [['Current shift', employeeUser.fullName || 'Team', 'Backend bookings and support queues are loaded from store.', 'Open', { entity: 'handover', id: 'handover-current', status: 'open' }]],
  };
}

function customerDashboardData(bookings) {
  const savedListings = state.listings.filter((listing) => listing.isFeatured).slice(0, 8);
  const walletRows = state.wallets
    .filter((wallet) => wallet.ownerType === 'customer')
    .map((wallet) => [wallet.id, 'Wallet balance', wallet.currency, 'Recent', moneyValue(wallet.availableBalance, wallet.currency), 'Active']);
  const reviewRows = bookings.slice(0, 6).map((booking) => {
    const review = state.reviews.find((item) => item.bookingId === booking.id);
    const canReview = ['checked_in', 'completed'].includes(booking.bookingStatus);
    return [
      booking.bookingRef,
      bookingTitle(booking),
      bookingCompany(booking),
      review ? String(review.rating) : '-',
      review ? review.comment : canReview ? 'Ready for review' : 'Not reviewed yet',
      review ? (review.status === 'published' ? 'Submitted' : review.status) : 'Pending',
    ];
  });
  return {
    bookings: bookings.map((booking) => [booking.bookingRef, bookingTitle(booking), bookingCompany(booking), dateValue(booking.createdAt), bookingCustomer(booking), booking.bookingStatus, bookingTotal(booking)]),
    saved: savedListings.map((listing) => [listing.title, listing.type, listing.partner, `${listing.from} to ${listing.to}`, moneyValue(listing.priceFrom), listing.bookable ? 'Available' : 'Teaser']),
    receipts: bookings.map((booking, index) => [`RCT-${9000 + index}`, booking.bookingRef, 'Classic Trip Payments', dateValue(booking.createdAt), bookingTotal(booking), booking.paymentStatus]),
    refunds: state.refundRequests.map((refund) => [refund.id, refund.bookingRef, refund.reason, moneyValue(refund.amount), refund.status, 'Recent']),
    support: state.supportTickets.filter((ticket) => ticket.ownerType === 'customer').map((ticket) => [ticket.id, ticket.subject, ticket.ownerType, ticket.priority, ticket.status, 'Recent']),
    reviews: reviewRows,
    wallet: walletRows.length ? walletRows : [['wallet-customer-live', 'Wallet balance', 'UGX', 'Current', moneyValue(0, 'UGX'), 'Active']],
    notifications: bookings.slice(0, 5).map((booking) => [`N-${booking.bookingRef}`, 'Booking', `${bookingTitle(booking)} is ${booking.bookingStatus}.`, dateValue(booking.createdAt), 'Unread']),
    security: [['Current session', 'Dashboard', 'Today', 'Current']],
  };
}

function promoterDashboardData(links, bookings) {
  const shareListings = state.listings.filter((listing) => listing.bookable || listing.isSponsored).slice(0, 10);
  const withdrawalRows = state.walletTransactions
    .filter((txn) => txn.ownerType === 'promoter')
    .map((txn) => [txn.id, txn.transactionType, txn.ownerId, dateValue(txn.createdAt), moneyValue(txn.amount, txn.currency), txn.status]);
  const promoterWalletRows = state.wallets
    .filter((wallet) => wallet.ownerType === 'promoter')
    .map((wallet) => [wallet.id, 'available_balance', wallet.ownerId, 'Current', moneyValue(wallet.availableBalance, wallet.currency), wallet.pendingBalance > 0 ? 'Pending payout' : 'Available']);
  return {
    links: links.map((link) => [link.code, findListing(link.listingId)?.title || 'Listing', findListing(link.listingId)?.type || 'Service', String(link.clicks), String(link.conversions), link.status]),
    share: shareListings.map((listing) => [listing.title, listing.type, listing.partner, `${listing.from} to ${listing.to}`, moneyValue(listing.priceFrom), listing.isSponsored ? 'Sponsored' : 'Available']),
    commissions: bookings.map((booking, index) => {
      const commission = state.commissions.find((item) => item.bookingId === booking.id && item.promoterId === booking.promoterAttribution?.promoterId);
      const status = commission?.status === 'released' ? 'Earned' : commission?.status === 'hold' ? 'Hold' : 'Pending';
      return [`COM-${700 + index}`, booking.bookingRef, bookingTotal(booking), '3%', moneyValue(booking.pricing?.split?.promoterAmount || 0, booking.pricing?.currency), status];
    }),
    withdrawals: withdrawalRows.length ? withdrawalRows : promoterWalletRows,
    bookings: bookings.map((booking) => [booking.bookingRef, bookingTitle(booking), bookingCustomer(booking), bookingTotal(booking), moneyValue(booking.pricing?.split?.promoterAmount || 0, booking.pricing?.currency), booking.paymentStatus]),
    campaigns: state.promotionCampaigns.map((campaign) => [campaign.name, campaign.placement, String(links.length), String(campaign.clicks), String(campaign.bookings), moneyValue(campaign.budget), campaign.status]),
    payouts: state.wallets.filter((wallet) => wallet.ownerType === 'promoter').map((wallet) => [wallet.id, 'Current', wallet.currency, moneyValue(wallet.availableBalance, wallet.currency), 'Wallet', wallet.pendingBalance > 0 ? 'Pending' : 'Paid']),
    fraud: [['Click quality', 'All links', 'Backend click tracking active', 'Low', 'Approved']],
    support: state.supportTickets.filter((ticket) => ticket.ownerType === 'promoter').map((ticket) => [ticket.id, ticket.subject, ticket.priority, ticket.status, 'Recent']),
  };
}

function serviceStats() {
  return state.categories.map((category) => {
    const listings = state.listings.filter((listing) => listing.serviceType === category.key);
    return {
      ...category,
      listingsCount: listings.length,
      activeListingsCount: listings.filter((listing) => listing.status === 'active').length,
      bookableListingsCount: listings.filter((listing) => listing.bookable).length,
      sponsoredListingsCount: listings.filter((listing) => listing.isSponsored).length,
    };
  });
}

function corridorStats() {
  return catalogRouteHighlights().map((item) => ({
    corridor: item.corridor,
    label: item.label,
    routes: item.count,
    seats: item.remainingSeats,
    minPrice: item.minPrice,
    currency: item.currency,
    nextDeparture: item.nextDeparture,
  }));
}

function searchListings(query = {}) {
  const q = normalize(query.q || query.search || '');
  const serviceType = normalize(query.serviceType || query.type || query.group || '');
  const route = normalize(query.route || '');
  const corridor = normalize(query.corridor || '');
  const city = normalize(query.city || '');
  const country = normalize(query.country || '');
  const origin = normalize(query.origin || query.from || '');
  const destination = normalize(query.destination || query.to || '');
  const partner = normalize(query.partner || '');
  const min = Number(query.min || query.priceMin || 0);
  const max = Number(query.max || query.priceMax || 0);
  const date = query.date ? new Date(query.date) : null;
  const verified = query.verified === 'true' || query.verified === true;
  const bookable = query.bookable === 'true' || query.bookable === true;
  const sponsored = query.sponsored === 'true' || query.sponsored === true;
  const availableOnly = query.available === 'true' || query.availableOnly === 'true' || query.availableOnly === true;
  const sort = normalize(query.sort || 'recommended');

  let results = buildListingCatalog();
  if (q) {
    results = results.filter((item) => item.searchText.includes(q));
  }
  if (serviceType && serviceType !== 'all') {
    results = results.filter((item) => normalize(item.serviceType) === serviceType || normalize(item.group) === serviceType || normalize(item.typeLabel) === serviceType.replace('_', ' '));
  }
  if (route) results = results.filter((item) => normalize(`${item.from} ${item.to} ${item.corridor} ${item.routeLabel}`).includes(route));
  if (corridor) results = results.filter((item) => normalize(item.corridor) === corridor);
  if (city) results = results.filter((item) => normalize(`${item.city} ${item.from} ${item.to}`).includes(city));
  if (country) results = results.filter((item) => normalize(item.country).includes(country));
  if (origin) results = results.filter((item) => normalize(item.from).includes(origin));
  if (destination) results = results.filter((item) => normalize(item.to).includes(destination));
  if (partner) results = results.filter((item) => normalize(`${item.partner} ${item.companyName}`).includes(partner));
  if (min) results = results.filter((item) => item.priceFrom >= min);
  if (max) results = results.filter((item) => item.priceFrom <= max);
  if (date && !Number.isNaN(date.getTime())) {
    const target = date.toISOString().slice(0, 10);
    results = results.filter((item) => !item.nextDepartAt || new Date(item.nextDepartAt).toISOString().slice(0, 10) === target);
  }
  if (verified) results = results.filter((item) => item.isVerified);
  if (bookable) results = results.filter((item) => item.bookable);
  if (sponsored) results = results.filter((item) => item.isSponsored);
  if (availableOnly) results = results.filter((item) => item.remainingInventory > 0);

  results = results.slice().sort((a, b) => {
    if (sort === 'cheapest') return a.priceFrom - b.priceFrom;
    if (sort === 'top-rated') return b.ratingAverage - a.ratingAverage;
    if (sort === 'most-booked') return b.reviewCount - a.reviewCount;
    if (sort === 'sponsored') return Number(b.isSponsored) - Number(a.isSponsored) || b.ratingAverage - a.ratingAverage;
    if (sort === 'soonest') return (asDate(a.nextDepartAt)?.getTime() || Number.MAX_SAFE_INTEGER) - (asDate(b.nextDepartAt)?.getTime() || Number.MAX_SAFE_INTEGER);
    if (sort === 'availability') return b.remainingInventory - a.remainingInventory;
    if (sort === 'fastest') return String(a.duration).localeCompare(String(b.duration));
    return recommendedScore(b) - recommendedScore(a);
  });
  return results;
}

function recommendedScore(item) {
  const sponsored = item.isSponsored ? 12 : 0;
  const verified = item.isVerified ? 8 : 0;
  const bookable = item.bookable ? 6 : 0;
  const rating = (item.ratingAverage || 0) * 10;
  const popularity = Math.min(item.reviewCount || 0, 500) / 20;
  const price = item.priceFrom ? Math.max(0, 20 - item.priceFrom / 50000) : 0;
  const availability = Math.min(cleanNumber(item.remainingInventory || item.availability), 60) / 6;
  const nextDepartAt = asDate(item.nextDepartAt);
  const soon = nextDepartAt ? Math.max(0, 8 - Math.max(0, nextDepartAt.getTime() - Date.now()) / (24 * 60 * 60 * 1000)) : 0;
  return sponsored + verified + bookable + rating + popularity + price + availability + soon;
}

function findListing(identifier, serviceType) {
  const id = normalize(identifier);
  const type = normalize(serviceType || '');
  return state.listings.find((item) => normalize(item.id) === id || normalize(item.slug) === id || normalize(item.title) === id && (!type || normalize(item.serviceType) === type));
}

function findCompany(slug) {
  const key = normalize(slug);
  return state.companies.find((company) => normalize(company.slug) === key || normalize(company.id) === key);
}

function listingsForCompany(companyId) {
  return state.listings.filter((item) => item.companyId === companyId);
}

function routesForListing(listingId) {
  return state.routes.filter((route) => route.listingId === listingId);
}

function schedulesForListing(listingId) {
  return state.schedules.filter((schedule) => schedule.listingId === listingId);
}

function roomsForListing(listingId) {
  return state.rooms.filter((room) => room.listingId === listingId);
}

function seatsForSchedule(scheduleId) {
  return state.seats.filter((seat) => seat.scheduleId === scheduleId);
}

function getAvailability(listingId) {
  const listing = findListing(listingId);
  if (!listing) return null;
  if (listing.serviceType === 'bus') {
    releaseExpiredSeatLocks();
    const schedules = schedulesForListing(listing.id);
    const firstSchedule = schedules[0];
    return { listing, schedules, seats: firstSchedule ? seatsForSchedule(firstSchedule.id) : [] };
  }
  if (listing.serviceType === 'hotel') {
    return { listing, rooms: roomsForListing(listing.id) };
  }
  return { listing, message: 'Provider integration planned; read-only listing for now.' };
}

function findUserByIdentity(identity) {
  const key = normalize(identity);
  return state.users.find((user) => normalize(user.email) === key || normalize(user.phone) === key);
}

function upsertUser(user) {
  const existing = findUserByIdentity(user.email || user.phone);
  if (existing) Object.assign(existing, user, { lastLoginAt: new Date().toISOString() });
  else state.users.push({ id: `user-${state.users.length + 1}`, status: 'active', isVerified: false, ...user, createdAt: new Date().toISOString() });
  return findUserByIdentity(user.email || user.phone);
}

function recordReferralClick(code, listingId, req) {
  if (!code) return null;
  const link = state.promoterLinks.find((item) => normalize(item.code) === normalize(code) || normalize(item.code.split('-').slice(0, -1).join('-')) === normalize(code));
  const click = {
    id: `ref-click-${state.referralClicks.length + 1}`,
    linkId: link?.id || null,
    promoterId: link?.promoterId || null,
    listingId: listingId || link?.listingId || null,
    code,
    ip: req?.ip || '',
    userAgent: req?.headers?.['user-agent'] || '',
    createdAt: new Date().toISOString(),
  };
  state.referralClicks.push(click);
  if (link) link.clicks += 1;
  return click;
}

function createBooking(payload = {}, req = null) {
  const listing = findListing(payload.listingId || payload.slug);
  if (!listing) {
    const error = new Error('Listing not found');
    error.status = 404;
    throw error;
  }
  const company = findCompany(listing.companyId || listing.companySlug);
  if (listing.status !== 'active' || listing.bookable === false) {
    const error = new Error('This listing is not currently open for booking');
    error.status = 409;
    throw error;
  }
  if (company && (company.verificationStatus !== 'verified' || company.settings?.canPublish === false)) {
    const error = new Error('Company must be verified before it can receive bookings');
    error.status = 403;
    throw error;
  }
  if (!ENABLED_BOOKING_TYPES.includes(listing.serviceType)) {
    const error = new Error('This service is visible on the marketplace but is not fully bookable until provider integration is enabled.');
    error.status = 409;
    throw error;
  }
  const refCode = payload.ref || req?.cookies?.ct_ref || req?.session?.referralCode || '';
  const promoterLink = refCode ? state.promoterLinks.find((link) => normalize(link.code) === normalize(refCode) || normalize(link.code.split('-').slice(0, -1).join('-')) === normalize(refCode)) : null;
  const isSelfReferral = promoterLink && req?.session?.user?.id === promoterLink.promoterId;
  const hasValidReferral = Boolean(promoterLink && !isSelfReferral);
  let scheduleId = payload.scheduleId || schedulesForListing(listing.id)[0]?.id || null;
  let selected = payload.selected || payload.seatNumber || payload.roomId || (listing.serviceType === 'bus' ? 'A1' : 'Room 201');
  let subtotal = Number(listing.priceFrom) || 0;

  if (listing.serviceType === 'bus') {
    const schedule = state.schedules.find((item) => item.id === scheduleId) || schedulesForListing(listing.id)[0];
    scheduleId = schedule?.id || null;
    const seats = schedule ? seatsForSchedule(schedule.id) : [];
    const requestedSeat = payload.selected || payload.seatNumber;
    const seat = requestedSeat ? seats.find((item) => item.seatNumber === requestedSeat) : seats.find((item) => item.status === 'available');
    if (seat?.status === 'locked' && seat.lockedUntil && new Date(seat.lockedUntil) <= new Date()) {
      seat.status = 'available';
      seat.lockedUntil = null;
      seat.lockId = null;
    }
    const lockedByAnotherCheckout = seat?.status === 'locked' && (!payload.holdId || seat.lockId !== payload.holdId);
    if (!schedule || !seat || seat.status === 'taken' || lockedByAnotherCheckout) {
      const error = new Error('Selected seat is no longer available');
      error.status = 409;
      throw error;
    }
    seat.status = 'taken';
    seat.lockedUntil = null;
    seat.lockId = null;
    schedule.availableSeats = Math.max(0, Number(schedule.availableSeats || 0) - 1);
    selected = seat.seatNumber;
    subtotal = Number(schedule.basePrice || listing.priceFrom || 0) + Number(seat.priceDelta || 0);
  }

  if (listing.serviceType === 'hotel') {
    const rooms = roomsForListing(listing.id);
    const room = payload.roomId ? rooms.find((item) => item.id === payload.roomId) : rooms.find((item) => item.status === 'active' && item.inventory > 0);
    if (!room || room.inventory <= 0) {
      const error = new Error('Selected room is no longer available');
      error.status = 409;
      throw error;
    }
    if (payload.holdId) {
      const roomReservationService = require('../booking/roomReservationService');
      const reservation = roomReservationService.consumeReservation(payload.holdId, room.id);
      if (!reservation) {
        const error = new Error('Room hold expired or does not match this room');
        error.status = 409;
        throw error;
      }
    }
    room.inventory -= 1;
    selected = room.roomType;
    subtotal = Number(room.nightlyPrice || listing.priceFrom || 0);
  }

  const selectedAddons = selectedAddonsFor(listing.serviceType, payload);
  const addonTotal = selectedAddons.reduce((total, addon) => total + Number(addon.price || 0), 0);
  const fees = Math.round(subtotal * 0.045 + 3500);
  const computedTotal = subtotal + fees + addonTotal;
  const clientTotal = Number(payload.total || 0);
  const total = clientTotal > computedTotal ? clientTotal : computedTotal;
  const split = calculateCommission(total, hasValidReferral);
  const bookingRef = generateBookingRef(listing.serviceType);
  const booking = {
    id: `booking-${state.bookings.length + 1}`,
    bookingRef,
    guestLookupCode: bookingRef,
    serviceType: listing.serviceType,
    guestSnapshot: {
      fullName: payload.fullName || payload.customerName || 'Guest Customer',
      email: payload.email || 'guest@example.com',
      phone: payload.phone || '+256700000000',
    },
    customerUserId: req?.session?.user?.id || null,
    companyId: listing.companyId,
    listingId: listing.id,
    scheduleId,
    passengers: [{ fullName: payload.passengerName || payload.fullName || 'Guest Customer', seatOrRoom: selected }],
    addons: selectedAddons,
    quantity: 1,
    pricing: { subtotal, fees, addonTotal, total, currency: listing.currency || 'UGX', split, addons: selectedAddons },
    promoterAttribution: hasValidReferral ? { promoterId: promoterLink.promoterId, linkId: promoterLink.id, code: promoterLink.code } : null,
    source: req?.session?.user ? 'registered_checkout' : 'guest_checkout',
    paymentStatus: 'successful',
    paymentProvider: 'Classic Trip Payments',
    paymentRef: bookingRef,
    paymentMethodNote: payload.paymentMethodNote || 'Instant checkout',
    walletUsed: Number(payload.walletUsed || 0),
    settlementStatus: 'pending',
    bookingStatus: 'confirmed',
    checkInStatus: 'pending',
    qrCodeValue: `CLASSIC-TRIP:${bookingRef}:${listing.id}:${Date.now()}`,
    lockedUntil: addMinutes(new Date(), 10).toISOString(),
    createdAt: new Date().toISOString(),
  };
  state.bookings.unshift(booking);
  const walletService = require('../wallet/walletService');
  const commissionService = require('../commission/commissionService');
  const fraudService = require('../fraud/fraudService');
  commissionService.createCommission(booking, hasValidReferral, split);
  booking.risk = fraudService.scoreBookingRisk(booking);
  walletService.creditAvailable('platform', 'platform', split.platformFee, {
    currency: booking.pricing.currency,
    transactionType: 'platform_fee',
    referenceType: 'booking',
    referenceId: booking.id,
  });
  walletService.creditPending('company', listing.companyId, split.companyAmount, {
    currency: booking.pricing.currency,
    transactionType: 'company_earning_pending',
    referenceType: 'booking',
    referenceId: booking.id,
  });
  if (hasValidReferral) {
    walletService.creditPending('promoter', promoterLink.promoterId, split.promoterAmount, {
      currency: booking.pricing.currency,
      transactionType: 'promoter_commission_pending',
      referenceType: 'booking',
      referenceId: booking.id,
    });
    promoterLink.conversions += 1;
  }
  const activeCampaign = state.promotionCampaigns.find((campaign) => campaign.listingId === listing.id && campaign.status === 'active');
  if (activeCampaign) activeCampaign.bookings = Number(activeCampaign.bookings || 0) + 1;
  return booking;
}

function findBooking(ref) {
  const key = normalize(ref);
  return state.bookings.find((booking) => normalize(booking.bookingRef) === key || normalize(booking.id) === key);
}

function scopedTicketSearch(qrCodeValue) {
  const key = normalize(qrCodeValue);
  const payment = findPayment(qrCodeValue);
  return state.bookings.find((item) => (
    normalize(item.qrCodeValue) === key
    || normalize(item.bookingRef) === key
    || normalize(item.id) === key
    || normalize(item.guestLookupCode) === key
    || normalize(item.paymentRef) === key
    || normalize(payment?.bookingRef) === normalize(item.bookingRef)
    || normalize(payment?.bookingId) === normalize(item.id)
    || normalize(item.guestSnapshot?.email) === key
    || normalize(item.guestSnapshot?.phone) === key
    || (item.passengers || []).some((passenger) => normalize(passenger.seatOrRoom) === key || normalize(passenger.seatId) === key)
  ));
}

function checkInBlockReason(booking) {
  if (!booking) return 'Ticket not found';
  if (booking.paymentStatus !== 'successful') return 'Ticket payment is not confirmed';
  if (['cancelled', 'refunded', 'voided'].includes(booking.bookingStatus)) return `Ticket is ${booking.bookingStatus}`;
  if (booking.bookingStatus === 'checked_in' || booking.checkInStatus === 'checked_in' || booking.bookingStatus === 'completed') return 'Ticket was already validated';
  if (booking.bookingStatus === 'no_show' || booking.checkInStatus === 'no_show') return 'Ticket is marked no-show';
  return '';
}

function validateTicket(qrCodeValue, employeeId = 'employee-system', note = '') {
  const booking = scopedTicketSearch(qrCodeValue);
  if (!booking) return { ok: false, result: 'not_found', message: 'Ticket not found' };
  const reason = checkInBlockReason(booking);
  if (reason) {
    const result = reason.includes('payment') ? 'payment_not_successful' : reason.includes('already') ? 'already_used' : 'not_valid_for_checkin';
    return { ok: false, result, booking, message: reason };
  }
  booking.bookingStatus = 'checked_in';
  booking.checkInStatus = 'checked_in';
  booking.checkedInAt = new Date().toISOString();
  booking.checkedInBy = employeeId;
  booking.checkedInByUserId = employeeId;
  booking.checkInNote = note || booking.checkInNote || '';
  state.auditLogs.push({
    id: `audit-${state.auditLogs.length + 1}`,
    actorId: employeeId,
    action: 'ticket.scanned',
    target: booking.bookingRef,
    entityType: 'booking',
    entityId: booking.id,
    metadata: { bookingRef: booking.bookingRef, companyId: booking.companyId },
    createdAt: new Date().toISOString(),
  });
  return { ok: true, result: 'validated', booking, message: 'Ticket validated and checked in' };
}

module.exports = {
  state,
  hydrateFromDatabase,
  homeBootstrap,
  frontendListing,
  publicCompany,
  publicRoute,
  frontendBooking,
  publicPromoterLink,
  publicCampaign,
  buildListingCatalog,
  marketplaceInfo,
  listingPreview,
  dashboardData,
  serviceStats,
  corridorStats,
  searchListings,
  findListing,
  findCompany,
  listingsForCompany,
  routesForListing,
  schedulesForListing,
  roomsForListing,
  seatsForSchedule,
  getAvailability,
  findUserByIdentity,
  upsertUser,
  recordReferralClick,
  createBooking,
  findBooking,
  findBookingByAny,
  validateTicket,
};
