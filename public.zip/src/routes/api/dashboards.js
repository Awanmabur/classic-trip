const express = require('express');
const controller = require('../../controllers/api/dashboardController');
const { requireAuth } = require('../../middlewares/auth');
const router = express.Router();

router.use(requireAuth);
router.get('/data', controller.data);
router.get('/:role/data', controller.data);
router.post('/actions/:action', controller.action);

module.exports = router;
