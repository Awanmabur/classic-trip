const express = require('express');
const scannerController = require('../../controllers/api/scannerController');
const router = express.Router();

function requireApiAuth(req, res, next) {
  if (req.session?.user) return next();
  return res.status(401).json({ ok: false, result: 'unauthenticated', message: 'Please sign in before using the scanner.' });
}

function requireScannerRole(req, res, next) {
  const role = req.session?.user?.role;
  if (['company_employee', 'company_admin', 'partner', 'admin', 'super_admin'].includes(role)) return next();
  return res.status(403).json({ ok: false, result: 'forbidden', message: 'You do not have permission to scan tickets.' });
}

router.use(requireApiAuth, requireScannerRole);
router.post('/lookup', scannerController.lookup);
router.post('/validate', scannerController.validate);
router.post('/no-show', scannerController.noShow);
module.exports = router;
