const { Schema, model } = require('./_helpers');

const paymentSchema = new Schema({
  id: { type: String, index: true },
  bookingId: { type: String, required: true, index: true },
  bookingRef: { type: String, index: true },
  provider: String,
  providerReference: { type: String, index: true },
  methodNote: String,
  amount: Number,
  currency: { type: String, default: 'UGX' },
  status: { type: String, default: 'pending', index: true },
  paidAt: Date,
  failureReason: String,
  checkoutUrl: String,
  customerId: { type: String, index: true },
  companyId: { type: String, index: true },
  metadata: Schema.Types.Mixed,
  idempotencyKey: { type: String, index: true },
  rawPayload: Schema.Types.Mixed,
}, { timestamps: true });

paymentSchema.index({ bookingRef: 1, providerReference: 1 });
module.exports = model('Payment', paymentSchema);
