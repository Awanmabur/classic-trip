const { Schema, model } = require('./_helpers');

const auditLogSchema = new Schema({
  id: { type: String, index: true },
  actorId: { type: String, index: true },
  actorRole: String,
  actorName: String,
  actorEmail: String,
  action: { type: String, index: true },
  target: String,
  entityType: { type: String, index: true },
  entityId: { type: String, index: true },
  before: Schema.Types.Mixed,
  after: Schema.Types.Mixed,
  metadata: Schema.Types.Mixed,
  userAgent: String,
  ip: String,
}, { timestamps: true });

auditLogSchema.index({ entityType: 1, entityId: 1, createdAt: -1 });
module.exports = model('AuditLog', auditLogSchema);
