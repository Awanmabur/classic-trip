const { Schema, model } = require('./_helpers');

const refundRequestSchema = new Schema({
  id: { type: String, index: true },
  bookingId: { type: String, index: true },
  bookingRef: { type: String, index: true },
  requesterId: { type: String, index: true },
  amount: Number,
  currency: { type: String, default: 'UGX' },
  reason: String,
  status: { type: String, default: 'pending', index: true },
  companyId: { type: String, index: true },
  paymentStatus: String,
  reviewedBy: String,
  reviewedAt: Date,
  rejectedBy: String,
  rejectedAt: Date,
  approvedBy: String,
  approvedAt: Date,
}, { timestamps: true });

refundRequestSchema.index({ companyId: 1, status: 1 });
module.exports = model('RefundRequest', refundRequestSchema);
