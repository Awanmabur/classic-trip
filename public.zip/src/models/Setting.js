const { Schema, model } = require('./_helpers');

const settingSchema = new Schema({
  key: { type: String, unique: true, index: true },
  value: Schema.Types.Mixed,
  group: String,
}, { timestamps: true });

module.exports = model('Setting', settingSchema);
