const { Schema, model } = require('./_helpers');

const shiftHandoverSchema = new Schema({
  id: { type: String, index: true },
  userId: { type: String, index: true },
  employeeId: { type: String, index: true },
  companyId: { type: String, index: true },
  tenantSlug: { type: String, index: true },
  shiftDate: { type: Date, index: true },
  shift: String,
  nextStaff: String,
  notes: String,
  note: String,
  cashCollected: { type: Number, default: 0 },
  bookingsHandled: { type: Number, default: 0 },
  checkInsHandled: { type: Number, default: 0 },
  paymentsRecorded: { type: Number, default: 0 },
  refundRequestsHandled: { type: Number, default: 0 },
  issues: String,
  status: { type: String, default: 'open', index: true },
}, { timestamps: true });

shiftHandoverSchema.index({ companyId: 1, shiftDate: -1 });
module.exports = model('ShiftHandover', shiftHandoverSchema);
