const { Schema, moneySchema, model } = require('./_helpers');

const bookingSchema = new Schema({
  id: { type: String, index: true },
  bookingRef: { type: String, unique: true, required: true, index: true },
  guestLookupCode: { type: String, index: true },
  serviceType: { type: String, required: true, index: true },
  guestSnapshot: Schema.Types.Mixed,
  customerUserId: { type: String, index: true },
  companyId: { type: String, index: true },
  listingId: { type: String, index: true },
  scheduleId: { type: String, index: true },
  passengers: [Schema.Types.Mixed],
  addons: [Schema.Types.Mixed],
  quantity: { type: Number, default: 1 },
  pricing: moneySchema,
  promoterAttribution: Schema.Types.Mixed,
  risk: Schema.Types.Mixed,
  source: { type: String, default: 'online_checkout', index: true },
  paymentStatus: { type: String, default: 'pending', index: true },
  paymentProvider: String,
  paymentRef: { type: String, index: true },
  paymentMethodNote: String,
  walletUsed: { type: Number, default: 0 },
  settlementStatus: { type: String, default: 'pending', index: true },
  bookingStatus: { type: String, default: 'draft', index: true },
  qrCodeValue: { type: String, index: true },
  lockedUntil: Date,
  checkInStatus: { type: String, default: 'pending', index: true },
  checkedInAt: Date,
  checkedInBy: String,
  checkedInByUserId: { type: String, index: true },
  checkInNote: String,
  noShowAt: Date,
  noShowBy: String,
  noShowReason: String,
  customerNotes: String,
  cancellationReason: String,
  cancelledAt: Date,
  completedAt: Date,
  earningsReleasedAt: Date,
}, { timestamps: true });

bookingSchema.index({ bookingRef: 1, 'guestSnapshot.phone': 1 });
bookingSchema.index({ guestLookupCode: 1, paymentRef: 1 });
bookingSchema.index({ companyId: 1, bookingStatus: 1, paymentStatus: 1 });
bookingSchema.index({ companyId: 1, checkInStatus: 1 });
module.exports = model('Booking', bookingSchema);
