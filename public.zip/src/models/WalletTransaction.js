const { Schema, model } = require('./_helpers');

const walletTransactionSchema = new Schema({
  id: { type: String, index: true },
  walletId: { type: String, index: true },
  ownerType: { type: String, index: true },
  ownerId: { type: String, index: true },
  transactionType: { type: String, index: true },
  direction: { type: String, enum: ['credit', 'debit'] },
  amount: Number,
  currency: { type: String, default: 'UGX' },
  status: { type: String, default: 'pending', index: true },
  referenceType: String,
  referenceId: String,
  payoutMethod: String,
  payoutAccount: String,
  note: String,
  requestedBy: String,
  reviewedBy: String,
  reviewedAt: Date,
  approvedBy: String,
  approvedAt: Date,
}, { timestamps: true });

walletTransactionSchema.index({ ownerType: 1, ownerId: 1, status: 1 });
module.exports = model('WalletTransaction', walletTransactionSchema);
