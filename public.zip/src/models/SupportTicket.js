const { Schema, model } = require('./_helpers');

const supportTicketSchema = new Schema({
  id: { type: String, index: true },
  ownerType: { type: String, index: true },
  ownerId: { type: String, index: true },
  companyId: { type: String, index: true },
  bookingRef: { type: String, index: true },
  paymentRef: { type: String, index: true },
  category: String,
  audience: String,
  subject: String,
  message: String,
  priority: { type: String, default: 'medium' },
  status: { type: String, default: 'open', index: true },
  assignedTo: String,
  createdBy: String,
  lastResponse: String,
  respondedBy: String,
  respondedAt: Date,
  resolutionNotes: String,
  resolvedBy: String,
  resolvedAt: Date,
}, { timestamps: true });

supportTicketSchema.index({ companyId: 1, status: 1 });
supportTicketSchema.index({ ownerType: 1, ownerId: 1, status: 1 });
module.exports = model('SupportTicket', supportTicketSchema);
