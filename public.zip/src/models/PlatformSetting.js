const { Schema, model } = require('./_helpers');

const platformSettingSchema = new Schema({
  key: { type: String, unique: true, index: true, default: 'default' },
  platformName: { type: String, default: 'Classic Trip' },
  defaultCurrency: { type: String, default: 'UGX', index: true },
  platformFeePercent: { type: Number, default: 7 },
  promoterCommissionPercent: { type: Number, default: 3 },
  supportEmail: String,
  maintenanceMode: { type: Boolean, default: false, index: true },
  termsUrl: String,
  privacyUrl: String,
  updatedBy: String,
}, { timestamps: true });

module.exports = model('PlatformSetting', platformSettingSchema);
