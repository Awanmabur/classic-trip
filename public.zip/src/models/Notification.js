const { Schema, model } = require('./_helpers');

const notificationSchema = new Schema({
  id: { type: String, index: true },
  userId: { type: String, index: true },
  channel: String,
  title: String,
  message: String,
  recipient: Schema.Types.Mixed,
  referenceType: String,
  referenceId: String,
  meta: Schema.Types.Mixed,
  status: { type: String, default: 'queued', index: true },
  sentAt: Date,
}, { timestamps: true });

module.exports = model('Notification', notificationSchema);
