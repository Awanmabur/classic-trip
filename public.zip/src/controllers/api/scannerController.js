const bookingService = require('../../services/booking/bookingService');

function scanValue(req) {
  return req.body.qrCodeValue || req.body.bookingRef || req.body.lookup || req.body.value || req.body.query || '';
}

function actor(req) {
  return req.session?.user || {};
}

async function lookup(req, res, next) {
  try {
    const result = await bookingService.lookupTicket(scanValue(req), actor(req));
    res.status(result.ok ? 200 : result.result === 'forbidden' ? 403 : 404).json(result);
  } catch (error) {
    next(error);
  }
}

async function validate(req, res, next) {
  try {
    const user = actor(req);
    const value = scanValue(req);
    const scoped = await bookingService.lookupTicket(value, user);
    if (!scoped.ok) {
      res.status(scoped.result === 'forbidden' ? 403 : 404).json(scoped);
      return;
    }
    const result = await bookingService.validateTicket(value, user.id || 'employee-api', req.body.note || req.body.checkInNote || '');
    res.status(result.ok ? 200 : 409).json(result);
  } catch (error) {
    next(error);
  }
}

async function noShow(req, res, next) {
  try {
    const result = await bookingService.markNoShow(scanValue(req), actor(req), req.body.note || req.body.reason || '');
    res.status(result.ok ? 200 : result.result === 'forbidden' ? 403 : 409).json(result);
  } catch (error) {
    next(error);
  }
}

module.exports = { lookup, validate, noShow };
