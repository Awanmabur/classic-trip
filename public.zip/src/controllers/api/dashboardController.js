const store = require('../../services/data/demoStore');
const actionService = require('../../services/dashboard/actionService');

function roleFor(req) {
  const userRole = req.session?.user?.role || req.query.role || 'customer';
  if (['super_admin', 'admin'].includes(userRole)) return 'admin';
  if (['company_admin', 'partner'].includes(userRole)) return 'company';
  if (userRole === 'company_employee') return 'employee';
  if (userRole === 'promoter') return 'promoter';
  return 'customer';
}

function contextFor(req) {
  return {
    companyId: req.session?.user?.companyId || req.query.companyId,
    customerId: req.session?.user?.id || req.query.customerId,
    promoterId: req.session?.user?.id || req.query.promoterId,
    employeeId: req.session?.user?.id || req.query.employeeId,
  };
}

function data(req, res) {
  const role = roleFor(req);
  res.json({ ok: true, role, generatedAt: new Date().toISOString(), data: store.dashboardData(role, contextFor(req)) });
}

async function action(req, res, next) {
  try {
    const user = req.session?.user || {};
    const role = user.role || '';
    const isPlatformAdmin = ['super_admin', 'admin'].includes(role);
    const companyId = user.companyId || (isPlatformAdmin ? req.body.companyId : '');
    const actorId = user.id || 'dashboard-api';
    const type = String(req.params.action || req.body.action || '').toLowerCase();
    const companyAdminActions = ['company-settings', 'company-payout', 'company-notice', 'manual-booking'];
    const employeeActions = ['employee-payment', 'employee-refund', 'handover'];
    const canCompanyAdmin = isPlatformAdmin || ['company_admin', 'partner'].includes(role);
    const canEmployee = canCompanyAdmin || role === 'company_employee';
    if (companyAdminActions.includes(type) && (!canCompanyAdmin || !companyId)) {
      const error = new Error('You do not have permission to perform this company action');
      error.status = 403;
      throw error;
    }
    if (employeeActions.includes(type) && (!canEmployee || !companyId)) {
      const error = new Error('You do not have permission to perform this employee action');
      error.status = 403;
      throw error;
    }
    let result;
    if (type === 'company-settings') result = await actionService.updateCompanySettings(companyId, req.body, actorId);
    else if (type === 'company-payout') result = await actionService.requestCompanyPayout(companyId, req.body, actorId);
    else if (type === 'company-notice') result = await actionService.createCompanyNotice(companyId, req.body, actorId);
    else if (type === 'manual-booking') result = await actionService.createManualBooking(companyId, req.body, actorId);
    else if (type === 'employee-payment') result = await actionService.recordEmployeePayment(companyId, req.body, actorId);
    else if (type === 'employee-refund') result = await actionService.requestEmployeeRefund(companyId, req.body, actorId);
    else if (type === 'handover') result = await actionService.createHandover(companyId, req.body, actorId);
    else {
      const error = new Error('Unsupported dashboard action');
      error.status = 404;
      throw error;
    }
    res.json({ ok: true, action: type, result });
  } catch (error) {
    next(error);
  }
}

module.exports = { data, action };
