const bookingService = require('../../services/booking/bookingService');

async function checkIn(req, res, next) {
  try {
    const user = req.session?.user || {};
    const scoped = await bookingService.lookupTicket(req.params.bookingRef, user);
    if (!scoped.ok) {
      const error = new Error(scoped.message || 'Booking not found for this company');
      error.status = scoped.result === 'forbidden' ? 403 : 404;
      throw error;
    }
    await bookingService.validateTicket(req.params.bookingRef, user.id || 'employee-form', req.body.note || '');
    res.redirect('/employee/dashboard');
  } catch (error) {
    next(error);
  }
}

module.exports = { checkIn };
