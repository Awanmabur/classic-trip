const bookingService = require('../../services/booking/bookingService');

async function validate(req, res, next) {
  try {
    const user = req.session?.user || {};
    const value = req.body.qrCodeValue || req.body.bookingRef;
    const scoped = await bookingService.lookupTicket(value, user);
    if (!scoped.ok) {
      res.status(scoped.result === 'forbidden' ? 403 : 404).json(scoped);
      return;
    }
    const result = await bookingService.validateTicket(value, user.id || 'employee-demo', req.body.note || '');
    res.status(result.ok ? 200 : 409).json(result);
  } catch (error) {
    next(error);
  }
}

module.exports = { validate };
