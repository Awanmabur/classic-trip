const bookingService = require('../../services/booking/bookingService');

async function checkIn(req, res, next) {
  try {
    const bookingRef = req.params.bookingRef || req.body.bookingRef || req.body.qrCodeValue;
    const user = req.session?.user || {};
    const scoped = await bookingService.lookupTicket(bookingRef, user);
    if (!scoped.ok) {
      const error = new Error(scoped.message || 'Booking not found for this company');
      error.status = scoped.result === 'forbidden' ? 403 : 404;
      throw error;
    }
    await bookingService.validateTicket(bookingRef, user.id || 'company-admin', req.body.note || '');
    res.redirect('/company/checkins');
  } catch (error) {
    next(error);
  }
}

module.exports = { checkIn };
