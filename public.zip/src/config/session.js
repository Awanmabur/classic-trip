const session = require('express-session');
const MongoStore = require('connect-mongo');
const { env } = require('./env');

module.exports = function sessionConfig() {
  const config = {
    name: 'ct.sid',
    secret: env.sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: env.isProduction,
      sameSite: env.isProduction ? 'lax' : 'lax',
      maxAge: 1000 * 60 * 60 * 24 * 7,
    },
  };
  if (env.mongoUri && env.nodeEnv !== 'test') {
    config.store = MongoStore.create({ mongoUrl: env.mongoUri, collectionName: 'express_sessions' });
  }
  return session(config);
};
