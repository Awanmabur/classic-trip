# Main Page Bus Visibility Fix

**Project:** Classic Trip  
**Date:** 22 July 2026  
**Scope:** Public homepage, search, services, routes, company profile, direct listing page, departure publication, and legacy-data recovery.

## Reported failure

A bus service and live departure could exist in the company dashboard while no bus card appeared on the public main page.

## Root causes

1. **Listing and departure publication were disconnected.** Publishing a dated departure did not publish its parent bus listing, so the catalog could continue filtering the listing as a draft.
2. **Legacy relationship shapes were too narrow.** Public queries expected custom `id` and direct `listingId` values. Older MongoDB records could use `_id`, `bus_company`, `coach`, `transport`, or a departure linked through its route or vehicle.
3. **Client-only homepage rendering hid server data problems.** The Featured Buses section had no server-rendered fallback and could remain empty when old JavaScript was cached or the client renderer did not find the expected group.
4. **Public surfaces did not share one publication rule.** Home, search, routes, company profile, promoter surfaces, and direct listing pages could disagree about whether a bus was public.

## Implemented correction

- Added one canonical public-listing visibility service.
- Normalized bus aliases such as `bus`, `coach`, `bus_company`, `bus_service`, and legacy `transport` records.
- Added safe MongoDB `_id` and custom `id` comparison.
- Resolves legacy departures through an owned route or vehicle only when no conflicting listing/company ownership is present.
- Keeps archived, deleted, rejected, suspended, blocked, and removed listings private.
- Keeps explicitly draft listings private unless a valid connected departure is already public.
- Publishing a valid departure now runs listing readiness and publishes the parent bus listing automatically when ready.
- Publication synchronization result and failures are stored on the departure.
- Added server-rendered Featured Bus cards and a visible empty state.
- Version-busted `home.js` to prevent the previous cached renderer from replacing corrected cards.
- Applied the same visibility and relationship handling to Home, Search, Services, Routes, Company Profile, Promoters, and direct public listing pages.
- Added a safe existing-data repair command that updates legacy MongoDB documents in place and does not upsert duplicate listings.

## Existing database recovery

Back up MongoDB before running a repair.

For one company:

```bash
npm run repair:public-buses -- --company=<company-id>
```

For every company:

```bash
npm run repair:public-buses -- --all
```

The repair output reports each listing as published, still draft, incomplete, archived, or failed. A listing that is not ready will include the exact missing requirements, such as image, public phone, operator licence, policies, route, compliant vehicle, fare, or published departure.

## Verification

- Main-page bus visibility: **18/18 passed**
- Public bus visibility and vehicle templates: **9/9 passed**
- Live departure seat maps: **47/47 passed**
- Smart bus forms: **30/30 passed**
- Bus form contracts: **45/45 passed**
- Multipart CSRF: **42/42 passed**
- Browser CSRF synchronization: **4/4 passed**
- Bus architecture blueprint: **81/81 passed**
- Architecture/security validation: **passed**
- Route security audit: **passed**
- Entity relationship audit: **passed**
- Dashboard tenant-scope validation: **passed**
- Dashboard static route smoke test: **passed**
- JavaScript parsing: **489/489 passed**
- EJS delimiter validation: **123/123 passed**

## Runtime limitation

The full dependency-loaded Jest/runtime suite was not run in the artifact environment because the supplied archive did not contain `node_modules`, and `npm run check` could not load `mongoose`. All dependency-free project, syntax, relationship, security, CSRF, bus-form, seat-map, and architecture checks listed above passed.
