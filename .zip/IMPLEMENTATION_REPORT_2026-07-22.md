# Classic Trip Canonical Bus Rebuild — Implementation Report

**Date:** July 22, 2026  
**Scope completed:** Bus vertical, end to end.  
**UI rule:** Existing visual design retained; fields and information architecture were corrected inside the current components.  
**Next stage:** Hotel vertical, after this bus baseline is accepted.

## Result

The former mixed bus implementation has been replaced behind the current UI with a canonical bus domain. Existing shared platform entities were reused rather than copied. The bus chain is now:

```text
Company / terminals
 -> bus listing
 -> vehicle -> seat-map template -> immutable seat-map version
 -> route -> ordered stops -> route segments
 -> fare product -> segment fares
 -> dated departure -> frozen snapshots -> seat-segment inventory
 -> inventory hold
 -> booking -> booking item -> reservation
 -> passenger -> seat assignment -> ticket
 -> verified payment
 -> manifest -> check-in/no-show -> completion
 -> cancellation/refund -> settlement/audit/reporting
```

## Main corrections

- Separated reusable bus setup from dated departures and transactional inventory.
- Replaced typed route dependencies with selected company-owned branches/stops.
- Added ordered route segments and partial-route seat availability.
- Made versioned seat maps authoritative; retained embedded vehicle seats only as a UI projection.
- Replaced trusted listing/departure prices with fare products and route-stop fares.
- Added vehicle permit, inspection and insurance records and publication checks.
- Allowed unassigned draft departures but required an active verified driver for publication.
- Added overlapping vehicle/departure protection.
- Added normalized booking items, reservations, assignments and tickets.
- Corrected round-trip discovery to use actual reverse routes and independent holds.
- Added passenger identity, nationality, emergency contact and luggage fields to checkout.
- Made hold tokens hashed, constant-time compared and absent from URLs.
- Prevented browser payment redirects from confirming payment.
- Connected verified webhooks to canonical confirm/fail/refund transitions.
- Changed manifests and scanner operations to canonical ticket/reservation data.
- Corrected partial check-in for multiple passengers and return legs.
- Added idempotent bus setup with compensating rollback and replay-media cleanup.
- Added a canonical legacy-data migration and a bus-specific static release gate.
- Rebuilt fresh development/test seed data so new installations use canonical bus entities instead of legacy embedded seats and prices.
- Updated the primary public route smoke path to exercise protected holds, opaque session checkout drafts, normalized reservations/tickets, and canonical QR scanning.

## Canonical entities added

- `SeatMapTemplate`
- `SeatMapVersion`
- `RouteSegment`
- `FareProduct`
- `BusSegmentFare`
- `BusSeatSegmentInventory`
- `BookingItem`
- `BusReservation`
- `BusSeatAssignment`
- `BusTicket`

Existing `Company`, `CompanyBranch`, `CompanyEmployee`, `Listing`, `Route`, `RouteStop`, `Vehicle`, `TripSchedule`, `Seat`, `Booking`, `Passenger`, `InventoryHold`, `Payment`, finance, support, notification and audit records remain shared.

## Verification performed in this environment

Passed:

- JavaScript syntax check across `src`, `scripts` and `tests`.
- Canonical bus static verifier: **81 checks passed, 0 failed**, including canonical fresh-seed relationship checks.
- Architecture/security static gate.
- Route-security audit.
- Entity/relationship UI audit.
- Dashboard-scope audit.
- Dashboard-route smoke static audit.
- Acceptance matrix manifest: **21 required criteria mapped to intended test evidence**; those Jest tests were not executed in this offline environment.
- Uploaded archive cleanup scan found no temporary backup/log/generated junk files requiring removal.

Not executed here:

- Jest runtime/integration suite.
- Application boot against MongoDB.
- Current npm advisory audit.

The execution environment did not have `node_modules`, and package-registry access was unavailable, so `npm ci` could not complete. Those checks remain mandatory in connected CI and are not represented as passed in this report.

## Deployment sequence

1. Back up MongoDB and object storage.
2. Install exactly from `package-lock.json` using `npm ci`.
3. Run all static and bus gates.
4. Start a MongoDB replica set and run the Jest suite.
5. Run the canonical transport migration in dry-run mode.
6. Resolve every reported missing price, invalid compliance document or unresolved booking.
7. Apply the migration.
8. Run post-migration verification and booking/payment concurrency tests.
9. Run current dependency audit, DAST and penetration testing.
10. Deploy to staging and complete real payment-provider sandbox certification.

Detailed architecture and workflow documentation is in `docs/BUS_END_TO_END_IMPLEMENTATION.md`.


## Super Admin MFA and partner registration follow-up

- MFA enforcement now defaults to `PLATFORM_MFA_ENABLED=false`; Super Admin login, admin middleware, setup routes and challenge routes no longer force MFA while disabled.
- Activation later requires `PLATFORM_MFA_ENABLED=true`, a strong `MFA_ENCRYPTION_KEY`, application restart and normal administrator setup/challenge.
- The false partner `account_exists` response was traced to blanket handling of MongoDB duplicate-key errors during downstream company provisioning.
- New users and companies are created with insert-only repository operations, preventing stale ID counters from overwriting existing records through upsert.
- Duplicate-key fields are classified accurately; only a real `User.email` or `User.phone` identity conflict becomes `account_exists`.
- Company ID/slug collisions retry safely and organization conflicts remain organization conflicts.
- Legacy user/company counters can be aligned with `npm run migrate:seed-id-counters`.
- Auth hotfix release gate: **16/16 passed**.

## Runtime partner-registration wallet repair

A real Atlas runtime log exposed a MongoDB conflicting update path in `financeRepository.atomicWalletDelta()`. First wallet creation used `availableBalance` and `pendingBalance` in both `$setOnInsert` and `$inc`, with Mongoose defaults able to reintroduce the overlap. The operation now initializes balances only through `$inc`, disables insert defaults, retries compound wallet-identity races, and replaces stale wallet IDs with UUID fallbacks. `MONGO_DB_NAME` and `npm run admin:sync-contact` were added for the database/seeded-admin contact issues shown in the same log. See `REGISTRATION_WALLET_HOTFIX_2026-07-22.md`.
