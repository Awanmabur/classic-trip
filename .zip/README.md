## July 22 multipart CSRF upload hotfix

Bus listing creation and every other file-upload route now validate CSRF at the correct stage. Multipart forms first pass a same-origin preflight, Multer parses the hidden `_csrf` field and file, and route-level CSRF verification runs before company-service validation or controllers. CSRF remains mandatory and query-string tokens remain prohibited. See `CSRF_MULTIPART_UPLOAD_HOTFIX_2026-07-22.md`.


## July 22 registration wallet runtime hotfix

Partner registration now provisions the initial company/promoter wallet without targeting `availableBalance` or `pendingBalance` through both `$setOnInsert` and `$inc`. Mongoose defaults are disabled for the atomic upsert, concurrent wallet creation is retried safely, and stale wallet IDs receive collision-resistant fallbacks.

The application also supports `MONGO_DB_NAME` and warns when Atlas falls back to the database named `test`. The supplied runtime log showed a real phone collision with `user-admin-001`; use a different partner phone or update `SUPER_ADMIN_PHONE` and run `npm run admin:sync-contact`. See `REGISTRATION_WALLET_HOTFIX_2026-07-22.md`.
# Classic Trip Platform

Classic Trip is a production-oriented modular monolith for a multi-tenant travel marketplace. It uses Node.js, Express, MongoDB/Mongoose, EJS, and repository-backed domain services for public booking, transport, hotels, payments, finance, support, promoters, customers, company operations, employee/driver work, and platform administration.

## Implemented architecture

### Runtime data boundary

- MongoDB is the only production system of record.
- Runtime services fail closed when MongoDB is unavailable; production never falls back to mutable in-memory data.
- `src/repositories/memoryDatabase.js` is an isolated seeded adapter used only when `NODE_ENV=test`.
- Domain repositories validate Mongoose schemas and support session-aware transactions.
- Production transactions require a MongoDB replica set or mongos and `MONGO_TRANSACTIONS=true`.
- Startup read-model hydration and the former `persistentStore.js` compatibility database have been removed.

### Canonical domains

- **Identity and tenancy:** users, companies, memberships, roles, permissions, invitations, verification, sessions, and audit records.
- **Canonical bus:** public bus listings, ordered route stops/segments, versioned seat maps, fare products/segment fares, dated departures, seat-segment inventory, holds, normalized reservations/tickets, round trips, manifests, check-in/no-show, cancellation and refund transitions.
- **Hotel boundary retained for the next stage:** the existing hotel UI and records remain isolated and operationally unchanged, but they are not represented as part of this bus-stage completion. The hotel domain must be reviewed and rebuilt next using the same shared identity, provider, booking, payment, finance, support, notification, and audit boundaries.
- **Commerce:** carts, browser-bound guest cart access, booking groups, child bookings, passengers, ticket legs, inventory holds/items, payment intents, payments, receipts, and webhooks.
- **Finance:** wallets, immutable wallet transactions, commissions, settlements, payout requests/batches, refunds, reconciliation, finance risk, and statements.
- **Support and notifications:** support tickets, correspondence, booking timelines, delivery attempts, notification templates, outbox events, retries, and dead-letter handling.
- **Promoters:** referral links/clicks, attribution sessions, campaign conversions, offline cash sales, fraud signals, commissions, and payouts.

### Role and permission model

| Role | Dashboard | Authority boundary |
|---|---|---|
| Super Admin | `/admin` | Full platform administration |
| Admin | `/operations/dashboard` | Permission-based platform operations without Super Admin namespace access |
| Support Admin | `/support/dashboard` | Support, customer cases, refund requests, correspondence, and support reports |
| Finance Admin | `/finance/dashboard` | Payments, settlements, payouts, refunds, reconciliation, and finance reports |
| Operations Admin | `/operations/dashboard` | Listings, bookings, routes, schedules, inventory, and operational reports |
| Content Admin | `/content/dashboard` | Listings content, promotions, reviews, notices, and content reports |
| Company Admin | `/company/dashboard` | Exact company-scoped inventory, employees, bookings, payments, support, and reports |
| Company Employee | `/employee/dashboard` | Active-membership and action-level permission scoped workflows |
| Driver | `/driver/dashboard` | Assigned trips, manifests, trip status, check-in assistance, and incidents |
| Customer | `/account` | Own profile, bookings, passengers, tickets, saved listings, and support |
| Promoter | `/promoter/dashboard` | Own referral, campaigns, offline sales, fraud review context, commission, and payout data |

Dashboard menus and backend action guards use the same canonical access-control registry. Hidden UI controls never substitute for server authorization.

## Security controls

- Active-account, verification, membership, tenant, role, and action-level permission checks.
- Cryptographic guest-cart access tokens stored as hashes; a cart reference is never an authorization credential.
- Exact normalized ticket-contact or private access-code verification; no partial contact matching.
- CSRF protection for browser mutations; tokens are not accepted through query strings.
- Signed and idempotent payment webhooks using the original raw body.
- Per-request CSP nonces, `script-src-attr 'none'`, HTTPS redirects, secure production cookies, Helmet headers, and host-header-safe redirects.
- Centralized production and public-write rate limiting with a MongoDB-backed distributed counter.
- File extension, MIME, size, and real file-signature validation.
- Password-reset session invalidation through authentication-version checks.
- Tenant ownership checks on every company, employee, driver, customer, promoter, and specialized-admin action.
- Transactional outbox with deduplication, locking, retry/backoff, and dead-letter state.
- Auditable finance, inventory, booking, support, verification, and administrative changes.

## Booking and inventory guarantees

- Multi-company carts create a `BookingGroup` plus independent child bookings per company/service.
- Authoritative prices, fees, discounts, currency, commission, and settlement splits are calculated server-side.
- Bus seat holds use `InventoryHold` plus one unique `InventoryHoldItem` for every selected seat/route segment.
- Partial unique indexes and transactional rechecks prevent overlapping active claims on the same seat segment.
- Inventory claims, hold consumption, bookings, payment records, checkout attempts, and outbox events share transaction boundaries.
- Duplicate payment webhooks and settlement retries are idempotent.
- Paid-but-unconfirmed inventory enters reconciliation/compensation handling rather than being reported as completed.
- Canonical lifecycle values use underscore forms such as `checked_in`, `checked_out`, and `no_show`.

## Operations and entity clarity

- Company dashboards include a service-specific **Setup & Workflow Guide** in dependency order.
- Every other role includes **How This Dashboard Works**, explaining its records, permissions, upstream dependencies, generated outputs, and escalation path.
- Existing branches, listings, routes, vehicles, drivers, schedules, seats, properties, room types, room units, bookings, payments, customers, promoters, and companies are selected from tenant-filtered options rather than typed as IDs.
- Staff assignment includes selected branch, listing, schedule, service, and permission scopes; cross-company and mismatched dependencies fail server-side.
- Bus setup follows `Company -> Terminal -> Listing -> Vehicle/SeatMapVersion -> Route/Stops/Segments -> FareProduct/SegmentFare -> Dated Departure/Segment Inventory -> Hold -> BookingItem/Reservation/Assignment/Ticket -> Manifest/Check-in -> Settlement`.
- Hotel setup follows `Company -> Branch -> Listing -> Property -> Room Type -> Room Unit -> Room-night Inventory -> Booking/Stay -> Daily Work -> Settlement`.
- The full plain-language guide is at `docs/OPERATIONS_AND_ENTITY_GUIDE.md`. The canonical bus implementation is documented at `docs/BUS_END_TO_END_IMPLEMENTATION.md`.

## Dashboard and frontend architecture

- Every role has a separate dashboard entry view under `src/views/dashboards/<role>/index.ejs`.
- Shared dashboard composition is split into 58 focused sections under `src/views/dashboards/shared/sections/`.
- The main workspace is approximately 40 KB; CSS and behavior live in static assets.
- Specialized support, finance, operations, and content actions use their own URL namespaces and redirect back to their own dashboards.
- Role projections remove unrelated datasets before serialization to the browser.
- Public marketplace, search, listing, company, promoter, booking, ticket, support, and payment pages use repository-backed services.

## Local setup

```bash
cp .env.example .env
npm ci
npm run check
npm test
npm run dev
```

Local development requires MongoDB. Optional reference seeding is explicit:

```bash
npm run seed:local
npm run seed:counts
```

`AUTO_SEED_MONGO=true` is development-only and is rejected by production validation.

## Authentication and role onboarding

The July 22, 2026 auth correction keeps the existing UI and implements one canonical onboarding lifecycle:

- Customers self-register and use customer features.
- Company owners/partners self-register into an active but verification-restricted company workspace.
- Promoters self-register into a restricted profile/referral workspace until verification.
- Staff are invitation-only; drivers use a separate administrator-approved invitation, compliance, phone-verification, and safety workflow.
- Platform administrators are invitation-only. Authenticator MFA is implemented but temporarily not enforced while `PLATFORM_MFA_ENABLED=false`; set it to `true` later to require setup and a fresh MFA challenge on administrator dashboards and APIs.
- Partner, promoter, and driver activation requires verified email and phone plus the role-specific compliance checklist. Changing those contacts invalidates stale approval.
- Driver identity is based on the dedicated account role and the complete canonical permission set, never a text job title.
- Partner owners can add or replace their login email/phone in the existing company profile UI and complete fresh verification.
- Invitation, email-verification, password-reset, and phone-code secrets are delivered transiently and redacted from durable notification history.

See `docs/AUTH_ROLE_ONBOARDING_IMPLEMENTATION.md` and `AUTH_ONBOARDING_REPORT_2026-07-22.md`.

Run the auth gates:

```bash
npm run check:auth-onboarding
npm run check:auth-hotfix
```


### Temporary Super Admin MFA setting

The delivered default is:

```env
PLATFORM_MFA_ENABLED=false
```

This lets an active Super Admin sign in directly. To activate authenticator MFA later, configure a strong `MFA_ENCRYPTION_KEY`, change the flag to `true`, restart the application, and sign in to complete setup.

### Partner registration identity rules

- Email matching is exact after trim/lowercase; Gmail dots and `+alias` text are no longer removed by the form validator.
- Phone formatting is normalized so `+256...`, `00256...`, and digits-only international forms can be compared consistently.
- Email and phone conflicts are checked separately and returned inside the existing signup UI.
- MongoDB duplicate keys are classified by their actual field. A company slug, organization ID, or stale counter collision is never relabeled as an existing user email.
- New user and company creation is insert-only, so a stale numeric counter cannot overwrite an existing account or organization through an upsert.
- User/company identifier collisions retry safely and fall back to collision-resistant UUID identifiers; `npm run migrate:seed-id-counters` can also align legacy counters before deployment.
- One verified login identity still belongs to one account. A phone or email already used by the Super Admin cannot be reused for a separate partner account.
- The server log records the matched field, role, user ID, and actual MongoDB database name without logging the submitted email or phone.
- Signup buttons are disabled after a valid submit to prevent accidental rapid double submissions.

## Production requirements

- A MongoDB replica set or Atlas/mongos deployment.
- `MONGO_TRANSACTIONS=true`.
- Public HTTPS `APP_URL` and `SITE_URL`.
- Strong session, webhook, and Super Admin credentials.
- Production Cloudinary, SMTP, WhatsApp, push, and Pesapal credentials.
- `DEMO_MODE=false`, `ALLOW_DEMO_LOGIN=false`, `ALLOW_MOCK_PAYMENTS=false`.
- `AUTO_SEED_MONGO=false` and `SEED_READ_MODEL=false`.

Run the release gates:

```bash
npm run verify
npm audit --audit-level=low
npm run launch:check
```

`npm run launch:check` intentionally fails until real production credentials and URLs are supplied.

## Existing-data migrations

Dry-run each migration first, back up MongoDB, then apply in this order:

```bash
npm run migrate:inventory-holds
npm run migrate:legacy-rooms
npm run migrate:canonical-statuses
npm run migrate:canonical-transport
npm run migrate:auth-onboarding
npm run migrate:seed-id-counters

npm run migrate:inventory-holds -- --apply
npm run migrate:legacy-rooms:apply
npm run migrate:canonical-statuses:apply
npm run migrate:canonical-transport:apply
npm run migrate:auth-onboarding:apply
```

After a successful backup, dry run, apply and reconciliation, canonical transport can remove retired embedded route fields:

```bash
npm run migrate:canonical-transport:archive
```

The legacy-room script can archive retired source records after validation:

```bash
npm run migrate:legacy-rooms:archive
```

## Verification status

On July 22, 2026, the bus and auth/onboarding rebuilds were verified with the dependency-free gates available in the execution environment:

- JavaScript syntax across `src`, `public`, `scripts`, and `tests`: **470 files checked, 0 failed**.
- `npm run check:auth-onboarding`: **130 checks passed, 0 failed**.
- `npm run check:auth-pure`: **11 behavior checks passed, 0 failed**.
- `npm run verify:bus`: **81 checks passed, 0 failed**, including fresh-seed entity and relationship invariants.
- Architecture/security gate: passed.
- Route-security gate: passed.
- Entity/relationship UI gate: passed.
- Dashboard scope and static route smoke gates: passed.
- Package and package-lock root metadata: consistent.
- No temporary backup/log/generated junk files are intended for the release archive.

The Jest suite, application boot against MongoDB, live email/SMS/OAuth integration, and a current npm advisory audit were not run in this environment because locked dependencies could not be installed without package-registry access. Run `npm ci`, the auth migration dry-run/apply, `npm run verify`, `npm audit --omit=dev`, provider sandbox tests, concurrency tests, and `npm run launch:check` in connected CI/staging before production deployment.

No security review can truthfully guarantee that a system has no possible future vulnerability. This codebase uses defense in depth, fail-closed verification and MFA boundaries, tenant isolation, hashed one-time secrets, immutable snapshots, transactions/idempotency, signed payment confirmation, compliance publication gates, audit events, and automated static release gates.

## Live departure seat-map recovery (2026-07-22)

The Seat Maps page now distinguishes reusable vehicle templates from dated live departure inventory. A template preview appears immediately; creating a schedule with that vehicle generates the live seat map automatically. Existing safe legacy schedules can be repaired with `npm run repair:bus-seat-maps -- --company=<company-id>` or `--all`. See `LIVE_DEPARTURE_SEAT_MAPS_RECOVERY_2026-07-22.md`. Focused verification: live maps 47/47, public bus/template projection 9/9, JavaScript 486/486, EJS delimiter balance 123/123, and executable EJS blocks 83/83.

## Public bus visibility recovery

Published bus departures now synchronize their parent listing with the public catalog. For records created before this behavior existed, back up MongoDB and run:

```bash
npm run repair:public-buses -- --company=<company-id>
# or, for all companies:
npm run repair:public-buses -- --all
```

Verify the public homepage contract with:

```bash
npm run check:main-page-buses
```
