# Classic Trip: Public Bus Visibility and Vehicle Seat Templates Fix

Date: 22 July 2026

## Root causes

### Vehicle seat templates were not showing

The Seat Maps page read `dashboardData.vehicles` as if it contained vehicle objects. That field is intentionally formatted as dashboard table rows, so properties such as `vehicle.id`, `vehicle.name`, and `vehicle.seats` were unavailable to the template-card renderer.

### Published buses were missing from the public homepage

Bus listings are stored internally with `serviceType: bus` and `group: transport`. The public homepage rendered only listings whose display group was exactly `bus`. The catalog preserved the internal `transport` group, so otherwise valid active buses were excluded from the Bus section.

## Implementation

- Added a dedicated vehicle-seat-template projection that joins:
  - vehicle identity and capacity;
  - active `SeatMapTemplate`;
  - current or latest published `SeatMapVersion`;
  - actual seat labels, classes, positions, and statuses.
- Updated the Seat Maps view to render `dashboardData.vehicleSeatTemplates` rather than tabular vehicle rows.
- Seat chips now display real labels such as `A1`, `A2`, or `S1`, rather than generated preview indexes.
- Added public catalog grouping that maps:
  - bus to `bus`;
  - hotel to `hotel`;
  - flight to `flight`;
  - train to `train`;
  - other services to `more`.
- Preserved the internal domain group separately as `internalGroup`.
- Applied one public-listing boundary consistently across Home, Search, Services, Routes, company profiles, promoter surfaces, and direct listing pages.
- Draft or archived listings are not public. Active/published bus listings now appear without a data migration.
- Added `npm run check:public-bus-visibility` and included it in the project verification chain.

## Verification

- Public visibility and seat-template regression checks: 8/8 passed
- Smart bus form checks: 30/30 passed
- Bus form contracts: 45/45 passed
- Bus blueprint checks: 81/81 passed
- Multipart CSRF checks: 42/42 passed
- Browser CSRF checks: 4/4 passed
- JavaScript parse checks: 429/429 passed
- Route security audit: passed
- Entity relationship audit: passed
- Dashboard scope, hotel operations, bus hardening, housekeeping, and settlement validation: passed

The dependency-loaded model/Jest suite was not run because the clean archive does not contain `node_modules` and dependency installation did not complete in the execution environment.
