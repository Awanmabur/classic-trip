# Classic Trip Partner Registration Wallet Hotfix

## Observed runtime failure

The application connected successfully to MongoDB, then partner registration failed while creating the company's initial wallet:

```text
Updating the path 'availableBalance' would create a conflict at 'availableBalance'
```

The newly created user was then removed by the registration compensation workflow, which is why no incomplete partner account remained.

## Root cause

`atomicWalletDelta()` used the same balance paths in both MongoDB operators during an upsert:

- `$setOnInsert.availableBalance` and `$inc.availableBalance`
- `$setOnInsert.pendingBalance` and `$inc.pendingBalance`

Mongoose could also add the schema defaults to `$setOnInsert`. MongoDB rejects an update that targets the same path through both operators.

## Corrected behavior

- Balance fields are initialized only through `$inc`; MongoDB creates missing numeric fields automatically.
- `setDefaultsOnInsert` is explicitly disabled for this operation.
- Wallet creation retries safely when concurrent requests race on the unique owner/currency index.
- Stale wallet identifier collisions receive a collision-resistant UUID and retry.
- Company registration keeps its compensation behavior: a genuinely incomplete account is removed rather than left half-provisioned.
- The partner registration integration test now asserts that a zero-balance company wallet exists.

## Database shown by the supplied log

The application is connected to database:

```text
test
```

Set one of these so the application and MongoDB viewer use the same intended database:

```env
MONGO_DB_NAME=classic-trip
```

or include the database name in the URI:

```env
MONGO_URI=mongodb+srv://.../classic-trip?retryWrites=true&w=majority
```

The application now warns whenever MongoDB falls back to the database name `test`.

## Phone collision shown by the supplied log

The first request used a phone already owned by:

```text
user-admin-001
role: super_admin
```

That is a real collision. One phone remains one login identity. Either use a different partner phone or change the Super Admin phone in `.env` and run:

```bash
npm run admin:sync-contact
```

The command updates only the existing Super Admin contact and refuses to take an email or phone already owned by another account.

## Verification performed in the artifact environment

- Auth hotfix checks: 19/19 passed.
- Auth/onboarding checks: 130/130 passed.
- Auth pure behavior checks: 11/11 passed.
- Bus blueprint checks: 81/81 passed.
- JavaScript syntax: 463 files checked, 0 failures.
- Architecture/security gate: passed.
- Route security gate: passed.
- Entity relationship UI gate: passed.
- Dashboard scope/static smoke gates: passed.
- Acceptance evidence mappings: 21/21 present.
- Package and lockfile dependency metadata: consistent.

The Jest/MongoDB runtime suite could not be executed in the artifact container because dependencies are not installed there. Run the commands below in the connected local project:

```bash
npm ci
npm run migrate:seed-id-counters
npm test -- --runInBand tests/integration/authRoleOnboarding.test.js
npm run verify
```
