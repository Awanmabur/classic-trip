# Live Departure Seat Maps Recovery

Date: 2026-07-22

## Problem confirmed

The Vehicle Seat Templates area and the Live Departure Seat Maps area represent different records:

- A vehicle seat template is a reusable layout attached to a physical bus.
- A live departure seat map is dated operational inventory attached to a trip schedule.

The previous implementation could leave the live section completely empty when a real database schedule used an older relationship shape, omitted `companyId` on a child row, had no persisted `Seat` rows, or stored only a seat-map version/snapshot. The page also gave no visual feedback when a valid template existed but no dated departure had been created.

## End-to-end correction

### Dashboard data loading

- Resolves company-owned routes, vehicles and schedules through the secure listing ownership chain.
- Loads seat-map versions/templates referenced by schedules or vehicles even when legacy child rows omitted `companyId`.
- Never adopts a row carrying another company’s explicit `companyId`.

### Live seat-map projection

A departure now renders from the first available authoritative source:

1. Persisted live `Seat` inventory.
2. Departure seat-inventory snapshot.
3. Immutable departure seat-map snapshot.
4. Published vehicle seat-map version.
5. Vehicle template.
6. Capacity preview as a final read-only fallback.

Exact custom labels are preserved. Statuses are normalized to available, booked, held and blocked without fabricating reservations.

### Template-only state

When a vehicle template exists but there is no dated departure:

- The actual layout is shown immediately as a clearly labelled template preview.
- Live counts remain zero rather than pretending the template is operational inventory.
- The page links directly to Schedules & Fares to create the dated departure.
- Seat-status actions and live inventory tables remain unavailable until a schedule exists.

### New departure integrity

New departures now freeze the complete seat layout—including labels, row/column positions, class, deck, price delta and enabled state—inside the immutable schedule snapshot. Inventory generation remains server-authoritative.

### Existing-record recovery

The repair service:

- Validates ownership through company → bus listing → route/vehicle/version.
- Rebuilds inventory only when both seat and segment inventory are absent.
- Refuses to overwrite partial inventory, reservations, assignments, tickets or active holds.
- Restores canonical bus service/inventory metadata for safe legacy schedules.

Automatic safe recovery runs when the company opens Seat Maps or Schedules. A maintenance command is also included:

```bash
npm run repair:bus-seat-maps -- --company=<company-id>
npm run repair:bus-seat-maps -- --all
```

Optional limit:

```bash
npm run repair:bus-seat-maps -- --all --limit=500
```

## Verification completed

- Live departure seat-map checks: 47/47 passed.
- Smart bus form checks: 30/30 passed.
- Bus form contracts: 45/45 passed.
- Public bus visibility/template checks: 9/9 passed.
- Multipart CSRF: 42/42 passed.
- Browser CSRF synchronization: 4/4 passed.
- Bus architecture blueprint: 81/81 passed.
- Route security audit: passed.
- Entity relationship UI audit: passed.
- JavaScript parse checks: 486/486 passed.
- EJS delimiter balance: 123/123 passed; executable-block syntax: 83/83 passed.

The dependency-loaded Jest/EJS runtime suite could not be run in this environment because locked dependency installation did not complete in the artifact environment. No partial dependency directory is included in the delivered archive.
