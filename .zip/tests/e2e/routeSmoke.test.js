'use strict';

const request = require('supertest');
const app = require('../../src/app');
const store = require('../../src/repositories/memoryDatabase');

async function prepareOneWayBusCheckout(agent, listing, schedule, seatNumbers) {
  const holdResponse = await agent
    .post(`/api/v1/bus/departures/${schedule.id}/holds`)
    .send({
      originStopId: schedule.originStopId,
      destinationStopId: schedule.destinationStopId,
      selectedSeats: seatNumbers,
    })
    .expect(201);
  const hold = holdResponse.body.hold;
  const draftResponse = await agent
    .post(`/book/bus/${listing.slug}/prepare`)
    .send({
      holdId: hold.id,
      holdToken: hold.accessToken,
      scheduleId: schedule.id,
      originStopId: schedule.originStopId,
      destinationStopId: schedule.destinationStopId,
      selectedSeats: seatNumbers,
      passengerCount: seatNumbers.length,
    })
    .expect(201);
  return { hold, draft: draftResponse.body };
}

test('public search to secure bus hold, checkout, payment, ticket, and scan path works', async () => {
  const listing = store.state.listings.find((item) => item.bookable && item.serviceType === 'bus' && item.status === 'active');
  const company = store.findCompany(listing.companyId);
  const schedule = store.schedulesForListing(listing.id).find((item) => item.status === 'published');
  const seat = store.seatsForSchedule(schedule.id).find((item) => item.status === 'available');
  const email = `route-smoke-${Date.now()}@example.com`;
  const traveler = request.agent(app);

  await traveler.get('/').expect(200);
  await traveler.get('/search?serviceType=bus&bookable=true').expect(200);
  await traveler.get(`/companies/${company.slug}`).expect(200);
  await traveler.get(`/listings/${listing.serviceType}/${listing.slug}`).expect(200);

  const { hold, draft } = await prepareOneWayBusCheckout(traveler, listing, schedule, [seat.seatNumber]);
  expect(draft.redirectUrl).toMatch(new RegExp(`^/book/bus/${listing.slug}\\?draft=`));
  expect(draft.redirectUrl).not.toContain(hold.accessToken);
  await traveler.get(draft.redirectUrl).expect(200);

  const bookingResponse = await traveler
    .post('/bookings/guest')
    .type('form')
    .send({
      listingId: listing.id,
      bookingDraftId: draft.id,
      holdId: hold.id,
      fullName: 'Route Smoke Guest',
      email,
      phone: '+256700444555',
      identityTypes: 'Passport',
      identityNumbers: 'P-SMOKE-001',
      nationalities: 'Ugandan',
      emergencyContactNames: 'Smoke Contact',
      emergencyContactPhones: '+256700444556',
      luggageCounts: '1',
      provider: 'mock',
      paymentMethod: 'Mobile Money',
      paymentReference: '+256700444555',
    })
    .expect(302);

  expect(bookingResponse.headers.location).toMatch(/^\/booking\/success\/CT-/);
  const bookingRef = bookingResponse.headers.location.split('/').pop();
  const booking = store.findBooking(bookingRef);
  expect(store.state.bookingItems.some((item) => item.bookingId === booking.id)).toBe(true);
  expect(store.state.busReservations.some((item) => item.bookingId === booking.id)).toBe(true);
  expect(store.state.busTickets.some((item) => item.bookingId === booking.id && item.status === 'valid')).toBe(true);

  await traveler.get(`/tickets/${bookingRef}?accessCode=${encodeURIComponent(booking.guestLookupCode)}`).expect(200);
  const scannerAgent = request.agent(app);
  await scannerAgent.post('/login').type('form').send({ identity: 'employee@classictrip.test', password: 'Password123' }).expect(302);
  const ticketLeg = booking.ticketLegs[0];
  await scannerAgent.post('/api/scanner/validate').send({ qrCodeValue: ticketLeg.qrToken }).expect(200);
  await scannerAgent.post('/api/scanner/validate').send({ qrCodeValue: ticketLeg.qrToken }).expect(409);
});
