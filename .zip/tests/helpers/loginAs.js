const request = require('supertest');
const authService = require('../../src/services/auth/authService');
const mfaService = require('../../src/services/auth/mfaService');
const { env } = require('../../src/config/env');

// Test-only in-memory MFA secrets. Production code never exposes or stores
// plaintext authenticator secrets after setup.
const mfaSecrets = new Map();

async function prepareAdminMfa(identity) {
  const user = await authService.findUserByIdentity(identity);
  if (!env.platformMfaEnabled || !user || !mfaService.isPlatformAdmin(user.role)) return null;

  if (!mfaService.isConfigured(user)) {
    const setup = await mfaService.beginSetup(user.id);
    const code = mfaService.totp(setup.secret);
    await mfaService.confirmSetup(user.id, code);
    mfaSecrets.set(user.id, setup.secret);
  }

  const secret = mfaSecrets.get(user.id);
  if (!secret) {
    throw new Error(`The test MFA secret is unavailable for ${identity}. Reset the test store before using loginAs().`);
  }
  return { userId: user.id, code: mfaService.totp(secret) };
}

async function loginAs(app, identity, password = 'Password123') {
  const mfa = await prepareAdminMfa(identity);
  const agent = request.agent(app);
  await agent.post('/login').type('form').send({ identity, password }).expect(302);
  if (mfa) {
    await agent.post('/auth/mfa/challenge').type('form').send({ code: mfa.code }).expect(302);
  }
  return agent;
}

module.exports = { loginAs };
