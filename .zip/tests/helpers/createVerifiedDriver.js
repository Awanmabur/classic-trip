'use strict';

const store = require('../../src/repositories/memoryDatabase');
const onboardingRepository = require('../../src/repositories/domain/onboardingRepository');
const invitationService = require('../../src/services/onboarding/invitationService');
const phoneVerificationService = require('../../src/services/auth/phoneVerificationService');
const verificationService = require('../../src/services/onboarding/verificationService');

async function createVerifiedDriver(companyId, payload = {}) {
  const company = await onboardingRepository.companies.findOne({ id: companyId });
  if (!company || company.status !== 'active' || company.verificationStatus !== 'verified') {
    throw new Error('createVerifiedDriver requires an active, verified company');
  }
  const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const email = payload.email || `driver-${stamp}@classictrip.test`;
  const phone = payload.phone || `+2567${String(Date.now()).slice(-8)}`;
  const licenseNumber = payload.licenseNumber || `DL-${stamp}`;
  const invitation = await invitationService.createInvitation({
    type: 'driver', companyId: company.id, companyName: company.name,
    fullName: payload.fullName || 'Verified Test Driver', email, phone,
    roleTitle: 'Driver',
    permissions: ['manifest.view', 'checkin.assist', 'trip.status.update', 'incident.create'],
    branchId: payload.branchId || '', listingIds: payload.listingIds || [], scheduleIds: payload.scheduleIds || [],
    vehicleId: payload.vehicleId || '', scheduleId: payload.scheduleId || '',
    licenseNumber, licenseClass: payload.licenseClass || 'D',
  }, payload.actorId || company.ownerId || 'super-admin-test', 'admin');

  const accepted = await invitationService.acceptInvitation(invitation.token, {
    fullName: payload.fullName || 'Verified Test Driver', phone,
    password: payload.password || 'Password123', confirmPassword: payload.password || 'Password123',
    agreementAccepted: 'on', documentType: 'driver_license', documentReference: licenseNumber,
    identityReference: payload.identityReference || `NIN-${stamp}`,
    licenseNumber, licenseClass: payload.licenseClass || 'D',
  });
  const employee = store.state.companyEmployees.find((row) => row.userId === accepted.user.id && row.companyId === company.id);
  if (!employee) throw new Error('Driver membership was not created');

  const challenge = await phoneVerificationService.requestCode(accepted.user.id, { force: true });
  if (!challenge.testCode) throw new Error('Driver test helper requires NODE_ENV=test');
  await phoneVerificationService.verifyCode(accepted.user.id, challenge.testCode);

  const review = await verificationService.getReview('driver', employee.id);
  for (const item of review.checklist) {
    await verificationService.reviewChecklistItem('driver', employee.id, item.key, 'approved', payload.actorId || 'super-admin-test', { note: 'Approved by secure driver test helper' });
  }
  await verificationService.activateTarget('driver', employee.id, payload.actorId || 'super-admin-test');
  return {
    invitation,
    user: store.state.users.find((row) => row.id === accepted.user.id),
    employee: store.state.companyEmployees.find((row) => row.id === employee.id),
  };
}

module.exports = createVerifiedDriver;
