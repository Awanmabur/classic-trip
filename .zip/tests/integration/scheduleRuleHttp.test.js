const request = require('supertest');
const app = require('../../src/app');
const store = require('../../src/repositories/memoryDatabase');

async function login(email) {
  const agent = request.agent(app);
  await agent.post('/login').type('form').send({ identity: email, password: 'Password123' }).expect(302);
  return agent;
}

function tomorrowDateOnly() {
  // Local time, not UTC - see the identical helper in scheduleRuleMaterializer.test.js for why.
  const date = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

test('POST /company/schedule-rules creates a rule, and pause/resume/cancel routes update its status', async () => {
  const agent = await login('company@classictrip.test');
  const route = store.state.routes.find((item) => item.companyId === 'company-01');
  const vehicle = store.state.vehicles.find((item) => item.companyId === 'company-01' && item.status !== 'archived');
  expect(route).toBeTruthy();
  expect(vehicle).toBeTruthy();

  await agent.post('/company/schedule-rules').type('form').send({
    routeId: route.id,
    vehicleId: vehicle.id,
    departureTime: '07:00',
    startDate: tomorrowDateOnly(),
    basePrice: '35000',
  }).expect(302);

  const rule = store.state.scheduleRules.find((item) => item.companyId === 'company-01' && item.routeId === route.id && item.departureTime === '07:00');
  expect(rule).toBeTruthy();
  expect(rule.status).toBe('active');

  await agent.post(`/company/schedule-rules/${rule.id}/pause`).type('form').send({}).expect(302);
  expect(store.state.scheduleRules.find((item) => item.id === rule.id).status).toBe('paused');

  await agent.post(`/company/schedule-rules/${rule.id}/resume`).type('form').send({}).expect(302);
  expect(store.state.scheduleRules.find((item) => item.id === rule.id).status).toBe('active');

  await agent.post(`/company/schedule-rules/${rule.id}/cancel`).type('form').send({}).expect(302);
  expect(store.state.scheduleRules.find((item) => item.id === rule.id).status).toBe('cancelled');
});
