const request = require('supertest');
const app = require('../../src/app');
const store = require('../../src/repositories/memoryDatabase');
const authService = require('../../src/services/auth/authService');
const billingService = require('../../src/services/billing/billingService');
const companyRepository = require('../../src/repositories/domain/companyOperationsRepository');

function unique(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

describe('role-aware public signup and onboarding', () => {
  test('partner signup creates an active restricted owner and a separate pending company', async () => {
    const stamp = unique('partner');
    const email = `${stamp}@classictrip.test`;
    const response = await request.agent(app)
      .post('/register')
      .type('form')
      .send({
        role: 'partner',
        fullName: 'New Bus Partner',
        email,
        phone: `+256${String(Date.now()).slice(-9)}`,
        password: 'Password123',
        confirmPassword: 'Password123',
        company: `Secure Bus Company ${stamp}`,
        companyType: 'bus',
        country: 'Uganda',
        city: 'Kampala',
        operatingCurrency: 'UGX',
        termsAccepted: 'on',
      })
      .expect(302);

    expect(response.headers.location).toBe('/company/profile?onboarding=1');
    const user = store.state.users.find((row) => row.email === email);
    expect(user).toBeTruthy();
    expect(user.role).toBe('company_admin');
    expect(user.status).toBe('active');
    expect(user.verificationStatus).toBe('pending');
    expect(user.onboardingStatus).toBe('company_verification');

    const company = store.state.companies.find((row) => row.id === user.companyId);
    expect(company).toBeTruthy();
    expect(company.ownerId).toBe(user.id);
    expect(company.status).toBe('pending');
    expect(company.verificationStatus).toBe('pending');
    expect(company.settings.canPublish).toBe(false);
    const wallet = store.state.wallets.find((row) => row.ownerType === 'company' && row.ownerId === company.id && row.currency === 'UGX');
    expect(wallet).toBeTruthy();
    expect(wallet.availableBalance).toBe(0);
    expect(wallet.pendingBalance).toBe(0);
    expect(store.state.verificationReviews.some((row) => row.targetType === 'company' && row.targetId === company.id)).toBe(true);
  });

  test('promoter signup can enter onboarding but cannot withdraw or sell offline before approval', async () => {
    const stamp = unique('promoter');
    const email = `${stamp}@classictrip.test`;
    const agent = request.agent(app);
    const response = await agent
      .post('/register')
      .type('form')
      .send({
        role: 'promoter',
        fullName: 'New Promoter',
        email,
        phone: `+257${String(Date.now()).slice(-9)}`,
        password: 'Password123',
        confirmPassword: 'Password123',
        termsAccepted: 'on',
      })
      .expect(302);

    expect(response.headers.location).toBe('/promoter/profile?onboarding=1');
    const promoter = store.state.users.find((row) => row.email === email);
    expect(promoter.status).toBe('active');
    expect(promoter.verificationStatus).toBe('pending');
    expect(store.state.verificationReviews.some((row) => row.targetType === 'promoter' && row.targetId === promoter.id)).toBe(true);

    const withdrawal = await agent
      .post('/promoter/withdrawals')
      .type('form')
      .send({ amount: '1000', payoutMethod: 'mobile_money', payoutAccount: '+256700000001' })
      .expect(302);
    expect(withdrawal.headers.location).toBe('/promoter/profile#verification');

    const offline = await agent
      .post('/promoter/offline-sales')
      .type('form')
      .send({ listingId: 'bus-001', scheduleId: 'schedule-0001', customerName: 'Blocked Sale' })
      .expect(302);
    expect(offline.headers.location).toBe('/promoter/profile#verification');
  });

  test('partner duplicate conflict returns to the existing UI and reports the exact contact field', async () => {
    const stamp = unique('partner-conflict');
    const existingEmail = `${stamp}@classictrip.test`;
    await authService.registerUser({
      role: 'customer', fullName: 'Existing Customer', email: existingEmail,
      phone: `+256${String(Date.now()).slice(-9)}`, password: 'Password123',
    });

    const response = await request.agent(app)
      .post('/register')
      .type('form')
      .send({
        role: 'partner', fullName: 'Duplicate Partner', email: existingEmail,
        phone: `+254${String(Date.now() + 11).slice(-9)}`, password: 'Password123', confirmPassword: 'Password123',
        company: `Conflict Coach ${stamp}`, companyType: 'bus', country: 'Kenya', city: 'Nairobi',
        operatingCurrency: 'KES', termsAccepted: 'on',
      })
      .expect(302);

    expect(response.headers.location).toBe('/login?error=account_exists#partner');
    expect(store.state.companies.some((row) => row.name === `Conflict Coach ${stamp}`)).toBe(false);
  });

  test('partner company duplicate keys are never mislabeled as an existing user account', async () => {
    const stamp = unique('company-key-conflict');
    const email = `${stamp}@classictrip.test`;
    const insertSpy = jest.spyOn(companyRepository.companies, 'insert').mockRejectedValueOnce(Object.assign(
      new Error('duplicate organization registration key'),
      { code: 11000, keyPattern: { registrationNumber: 1 }, keyValue: { registrationNumber: 'REG-001' } }
    ));

    await expect(authService.registerUser({
      role: 'partner', fullName: 'Conflicting Organization', email,
      phone: `+254${String(Date.now() + 21).slice(-9)}`, password: 'Password123',
      company: `Conflict Organization ${stamp}`, companyType: 'bus', country: 'Kenya', city: 'Nairobi', operatingCurrency: 'KES',
    })).rejects.toMatchObject({ status: 409, code: 'company_registration_conflict' });

    insertSpy.mockRestore();
    expect(store.state.users.some((row) => row.email === email)).toBe(false);
  });

  test('email plus aliases remain distinct exact login identities', async () => {
    const stamp = unique('email-alias');
    const base = `${stamp}@example.com`;
    const alias = `${stamp}+partner@example.com`;
    await authService.registerUser({ role: 'customer', fullName: 'Base Account', email: base, phone: `+256${String(Date.now()).slice(-9)}`, password: 'Password123' });
    const partner = await authService.registerUser({
      role: 'partner', fullName: 'Alias Partner', email: alias, phone: `+254${String(Date.now() + 31).slice(-9)}`,
      password: 'Password123', company: `Alias Coach ${stamp}`, companyType: 'bus', country: 'Kenya', city: 'Nairobi', operatingCurrency: 'KES',
    });
    expect(partner.email).toBe(alias);
    expect(partner.role).toBe('company_admin');
  });

  test('employee and driver public signup is rejected because privileged roles require invitations', async () => {
    const stamp = unique('employee');
    const email = `${stamp}@classictrip.test`;
    await expect(authService.registerUser({
      role: 'employee',
      fullName: 'Uninvited Employee',
      email,
      phone: `+258${String(Date.now()).slice(-9)}`,
      password: 'Password123',
      company: 'Existing Company',
    })).rejects.toMatchObject({ code: 'invitation_required', status: 403 });
    expect(store.state.users.some((row) => row.email === email)).toBe(false);
  });

  test('pricing partner onboarding uses the canonical secure account and blocks anonymous reuse', async () => {
    const stamp = unique('pricing-partner');
    const email = `${stamp}@classictrip.test`;
    const phone = `+255${String(Date.now()).slice(-9)}`;
    const payload = {
      planId: 'growth', contactName: 'Pricing Partner Owner', email, phone,
      password: 'Password123', confirmPassword: 'Password123', termsAccepted: 'on',
      name: `Pricing Coach ${stamp}`, legalName: `Pricing Coach ${stamp} Limited`,
      companyType: 'bus', country: 'Tanzania', city: 'Arusha', operatingCurrency: 'TZS',
    };

    const result = await billingService.createOnboardingOrder(payload, { ip: '127.0.0.1', session: {} });
    expect(result.user.role).toBe('company_admin');
    expect(result.user.status).toBe('active');
    expect(result.user.verificationStatus).toBe('pending');
    expect(result.user.onboardingStatus).toBe('plan_payment');
    expect(result.order.companyId).toBe(result.company.id);
    expect(result.order.createdBy).toBe(result.user.id);
    expect(store.state.users.find((row) => row.id === result.user.id)?.passwordHash).toBeTruthy();

    await expect(billingService.createOnboardingOrder(payload, { ip: '127.0.0.1', session: {} }))
      .rejects.toMatchObject({ status: 409, code: 'account_exists' });

    const continued = await billingService.createOnboardingOrder(
      { ...payload, planId: 'scale', password: '', confirmPassword: '' },
      { ip: '127.0.0.1', session: { user: { id: result.user.id, role: 'company_admin', companyId: result.company.id } } }
    );
    expect(continued.user.id).toBe(result.user.id);
    expect(continued.company.id).toBe(result.company.id);
    expect(continued.order.planId).toBe('scale');
  });

  test('partner and promoter verification forms are mounted', async () => {
    const partnerEmail = `${unique('verify-partner')}@classictrip.test`;
    const partner = request.agent(app);
    await partner.post('/register').type('form').send({
      role: 'partner', fullName: 'Verification Owner', email: partnerEmail,
      phone: `+259${String(Date.now()).slice(-9)}`, password: 'Password123', confirmPassword: 'Password123',
      company: `Verification Coach ${Date.now()}`, companyType: 'bus', country: 'Uganda', city: 'Kampala',
      operatingCurrency: 'UGX', termsAccepted: 'on',
    }).expect(302);
    await partner.post('/company/verification').type('form').send({
      payoutMethod: 'mobile_money', payoutProvider: 'MTN MoMo', accountName: 'Verification Coach',
      accountNumber: '+256700000001', currency: 'UGX', licenseReference: 'BUS-LIC-001',
      supportEmail: 'support-verification@classictrip.test', supportPhone: '+256700000002',
      agreementSummary: 'Partner agreement accepted', agreementAccepted: 'on',
    }).expect(302).expect('Location', '/company/profile#verification');

    const promoterEmail = `${unique('verify-promoter')}@classictrip.test`;
    const promoter = request.agent(app);
    await promoter.post('/register').type('form').send({
      role: 'promoter', fullName: 'Verification Promoter', email: promoterEmail,
      phone: `+250${String(Date.now()).slice(-9)}`, password: 'Password123', confirmPassword: 'Password123', termsAccepted: 'on',
    }).expect(302);
    await promoter.post('/promoter/verification').type('form').send({
      documentType: 'national_id', documentReference: 'NIN-001', payoutMethod: 'Mobile Money',
      payoutProvider: 'Airtel', payoutAccount: '+250700000001', termsAccepted: 'on', trainingAcknowledged: 'on',
    }).expect(302).expect('Location', '/promoter/profile#verification');
  });
});
