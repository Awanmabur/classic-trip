'use strict';

const { buildSeedData, seedModelNames, collectionMapFromSeedData } = require('../../src/seeds/seedAll');

describe('canonical bus seed', () => {
  const data = buildSeedData();
  const busListings = data.listings.filter((row) => row.serviceType === 'bus');
  const busBookings = data.bookings.filter((row) => row.serviceType === 'bus');

  test('fresh seed includes every canonical bus collection', () => {
    const required = [
      'RouteSegment', 'SeatMapTemplate', 'SeatMapVersion', 'FareProduct', 'BusSegmentFare',
      'BusSeatSegmentInventory', 'BookingItem', 'BusReservation', 'BusSeatAssignment',
      'BusTicket', 'InventoryHoldItem', 'OutboxEvent',
    ];
    expect(required.every((name) => seedModelNames.includes(name))).toBe(true);
    const map = collectionMapFromSeedData(data);
    required.forEach((name) => expect(Array.isArray(map[name])).toBe(true));
  });

  test('every bus listing is backed by route, vehicle, seat map, fare, and published departures', () => {
    busListings.forEach((listing) => {
      const route = data.routes.find((row) => row.listingId === listing.id);
      expect(route).toBeTruthy();
      const stops = data.routeStops.filter((row) => row.routeId === route.id).sort((a, b) => a.stopOrder - b.stopOrder);
      const segments = data.routeSegments.filter((row) => row.routeId === route.id);
      expect(stops.length).toBeGreaterThanOrEqual(2);
      expect(segments).toHaveLength(stops.length - 1);
      expect(data.fareProducts.some((row) => row.id === route.activeFareProductId && row.status === 'active')).toBe(true);
      expect(data.busSegmentFares.some((row) => row.routeId === route.id && row.status === 'active')).toBe(true);
      const vehicle = data.vehicles.find((row) => row.listingId === listing.id);
      expect(vehicle).toBeTruthy();
      expect(data.seatMapVersions.some((row) => row.id === vehicle.activeSeatMapVersionId && row.status === 'published')).toBe(true);
      expect(data.schedules.some((row) => row.routeId === route.id && row.status === 'published')).toBe(true);
    });
  });

  test('every published departure has exact segment inventory and compliance snapshots', () => {
    data.schedules.filter((row) => row.status === 'published').forEach((schedule) => {
      const version = data.seatMapVersions.find((row) => row.id === schedule.seatMapVersionId);
      const segmentCount = data.routeSegments.filter((row) => row.routeId === schedule.routeId).length;
      expect(data.busSeatSegmentInventories.filter((row) => row.scheduleId === schedule.id)).toHaveLength(version.totalSeats * segmentCount);
      expect(schedule.routeSnapshot).toBeTruthy();
      expect(schedule.seatMapSnapshot).toBeTruthy();
      expect(schedule.fareSnapshot).toBeTruthy();
      expect(data.companyEmployees.some((row) => row.id === schedule.driverEmployeeId && row.safetyStatus === 'cleared')).toBe(true);
      expect(data.vehicles.some((row) => row.id === schedule.vehicleId && row.operatorPermitRef && row.inspectionRef && row.insuranceRef)).toBe(true);
    });
  });

  test('sample bus bookings are normalized and consume the correct segment inventory', () => {
    busBookings.forEach((booking) => {
      const item = data.bookingItems.find((row) => row.bookingId === booking.id);
      const reservation = data.busReservations.find((row) => row.bookingId === booking.id);
      const assignment = data.busSeatAssignments.find((row) => row.bookingId === booking.id);
      const ticket = data.busTickets.find((row) => row.bookingId === booking.id);
      expect(item).toBeTruthy();
      expect(reservation).toBeTruthy();
      expect(assignment).toBeTruthy();
      expect(ticket).toBeTruthy();
      expect(data.inventoryHolds.some((row) => row.bookingId === booking.id && row.status === 'consumed')).toBe(true);
      expect(data.inventoryHoldItems.filter((row) => row.bookingId === booking.id).every((row) => row.status === 'consumed')).toBe(true);
      expect(data.busSeatSegmentInventories.filter((row) => row.bookingId === booking.id)).toHaveLength(reservation.segmentIds.length);
    });
  });
});
