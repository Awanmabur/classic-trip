const request = require('supertest');
const app = require('../../src/app');
const store = require('../../src/repositories/memoryDatabase');
const mongoDashboardService = require('../../src/services/dashboard/mongoDashboardService');
const { normalizeReferralCode, normalizeListingId } = require('../../src/middlewares/referral');
const { detectedMimeType, assertFileSignature } = require('../../src/services/media/uploadService');
const { assertActionAllowed } = require('../../src/controllers/api/dashboardController');
const accountStateService = require('../../src/services/auth/accountStateService');

describe('Phase 3 security and role-isolation architecture', () => {
  test('public HTML uses a nonce CSP and contains no executable event attributes', async () => {
    const response = await request(app).get('/').expect(200);
    const csp = response.headers['content-security-policy'] || '';
    expect(csp).toContain("script-src-attr 'none'");
    expect(csp).toMatch(/script-src[^;]*'nonce-[A-Za-z0-9+/=]+'/);
    expect(csp).not.toMatch(/script-src[^;]*'unsafe-inline'/);
    expect(response.text).not.toMatch(/\son[a-z]+\s*=/i);
  });

  test('referral and listing identifiers are normalized and reject unsafe values', () => {
    expect(normalizeReferralCode('  summer_2026-ug ')).toBe('SUMMER_2026-UG');
    expect(normalizeReferralCode('<script>alert(1)</script>')).toBe('');
    expect(normalizeReferralCode('a'.repeat(81))).toBe('');
    expect(normalizeListingId('listing-01')).toBe('listing-01');
    expect(normalizeListingId('../listing-01')).toBe('');
  });

  test('upload authorization validates content signatures, not only extensions and MIME claims', () => {
    const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00]);
    const pdf = Buffer.from('%PDF-1.7\n');
    expect(detectedMimeType(png)).toBe('image/png');
    expect(detectedMimeType(pdf)).toBe('application/pdf');
    expect(() => assertFileSignature({ mimetype: 'image/png', buffer: png })).not.toThrow();
    expect(() => assertFileSignature({ mimetype: 'image/png', buffer: Buffer.from('<html>') })).toThrow(/does not match/i);
    expect(() => assertFileSignature({ mimetype: 'image/jpeg', buffer: png })).toThrow(/does not match/i);
  });

  test('specialized admin dashboards do not receive unrelated finance or customer datasets', async () => {
    const support = await mongoDashboardService.roleDashboard('support');
    const finance = await mongoDashboardService.roleDashboard('finance');
    const content = await mongoDashboardService.roleDashboard('content');
    const operations = await mongoDashboardService.roleDashboard('operations');

    expect(support.support).toBeDefined();
    expect(support.payments).toBeUndefined();
    expect(support.ledger).toBeUndefined();
    expect(finance.payments).toBeDefined();
    expect(finance.customers).toBeUndefined();
    expect(content.listings).toBeDefined();
    expect(content.support).toBeUndefined();
    expect(operations.schedules).toBeDefined();
    expect(operations.financeStatements).toBeUndefined();
  });

  test('generic dashboard actions enforce employee permissions server-side', async () => {
    const employee = store.state.users.find((user) => user.email === 'employee@classictrip.test');
    await expect(assertActionAllowed(employee, 'createManualBooking')).rejects.toMatchObject({ status: 403, code: 'permission_denied' });
    await expect(assertActionAllowed(employee, 'updateEmployeeInventory')).rejects.toMatchObject({ status: 403, code: 'permission_denied' });
    await expect(assertActionAllowed({ ...employee, role: 'company_admin' }, 'updateCompanySettings')).resolves.toBe(true);
  });

  test('password auth-version changes invalidate earlier authenticated sessions', async () => {
    const user = store.state.users.find((row) => row.email === 'amina@classictrip.test');
    const previous = user.authVersion;
    try {
      user.authVersion = 4;
      const stale = { session: { user: { id: user.id, email: user.email, authVersion: 3 } } };
      const current = { session: { user: { id: user.id, email: user.email, authVersion: 4 } } };
      await expect(accountStateService.refreshSessionUser(stale)).resolves.toBeNull();
      await expect(accountStateService.refreshSessionUser(current)).resolves.toMatchObject({ id: user.id, authVersion: 4 });
    } finally {
      if (previous === undefined) delete user.authVersion;
      else user.authVersion = previous;
    }
  });
});
