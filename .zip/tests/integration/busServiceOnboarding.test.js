const store = require('../../src/repositories/memoryDatabase');
const companyService = require('../../src/services/company/companyService');
const busServiceOnboarding = require('../../src/services/company/busServiceOnboarding');

function suffix() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

async function verifiedCompany(name = 'Wizard Partner', operatingCurrency = 'UGX') {
  const company = await companyService.createCompany({
    name: `${name} ${suffix()}`,
    companyType: 'transport',
    country: 'Uganda',
    city: 'Kampala',
    email: 'ops@example.com',
    operatingCurrency,
  });
  await companyService.setVerificationStatus(company.slug, 'verified', 'admin-e2e');
  company.testOriginBranch = await companyService.createBranch(company.id, { name: `Kampala Terminal ${suffix()}`, branchType: 'terminal', city: 'Kampala', status: 'active' });
  company.testDestinationBranch = await companyService.createBranch(company.id, { name: `Mbarara Terminal ${suffix()}`, branchType: 'terminal', city: 'Mbarara', status: 'active' });
  return company;
}

function fullPayload(company, overrides = {}) {
  return {
    listing: {
      title: `Wizard route ${suffix()}`,
      status: 'draft',
      ...overrides.listing,
    },
    vehicle: {
      name: `Wizard Coach ${suffix()}`,
      plateOrCode: `WZ-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
      layoutName: '2x2',
      rows: 3,
      columns: 4,
      totalSeats: 12,
      ...overrides.vehicle,
    },
    route: {
      originBranchId: company.testOriginBranch.id,
      destinationBranchId: company.testDestinationBranch.id,
      ...overrides.route,
    },
    fare: {
      name: 'Standard fare',
      fareClass: 'standard',
      currency: company.operatingCurrency,
      amount: 45000,
      bookingFee: 1000,
      baggageAllowanceKg: 20,
      status: 'active',
      ...overrides.fare,
    },
    schedule: {
      departAt: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(),
      status: 'draft',
      ...overrides.schedule,
    },
  };
}

test('createBusService creates one canonical listing, vehicle/seat-map, route/segments, fare, and dated departure', async () => {
  const company = await verifiedCompany('Wizard Happy Path', 'KES');
  const payload = fullPayload(company);

  const result = await busServiceOnboarding.createBusService(company.id, payload, { actorId: 'wizard-test' });

  expect(result.listing.companyId).toBe(company.id);
  expect(result.listing.currency).toBe('KES');
  expect(result.vehicle.listingId).toBe(result.listing.id);
  expect(result.route.listingId).toBe(result.listing.id);
  expect(result.fare.routeId).toBe(result.route.id);
  expect(result.schedule.routeId).toBe(result.route.id);
  expect(result.schedule.vehicleId).toBe(result.vehicle.id);
  expect(result.schedule.fareProductId).toBe(result.fare.id);
  expect(result.schedule.seatMapVersionId).toBeTruthy();
  expect(result.schedule.currency).toBe('KES');
  expect(result.seats.length).toBe(result.schedule.totalSeats);
  expect(store.state.routeSegments.filter((item) => item.routeId === result.route.id)).toHaveLength(1);
  expect(store.state.busSeatSegmentInventories.filter((item) => item.scheduleId === result.schedule.id)).toHaveLength(12);
  expect(store.findListing(result.listing.id).status).not.toBe('archived');
});

test('createBusService rolls back already-created records when a later step fails', async () => {
  const company = await verifiedCompany('Wizard Rollback Path');
  const payload = fullPayload(company, { listing: { status: 'active' }, schedule: { status: 'published' } });

  await expect(busServiceOnboarding.createBusService(company.id, payload, { actorId: 'wizard-test' }))
    .rejects.toThrow('Assign an active verified driver before publishing the departure');

  const listings = store.state.listings.filter((item) => item.companyId === company.id);
  const vehicles = store.state.vehicles.filter((item) => item.companyId === company.id);
  expect(listings.length).toBeGreaterThan(0);
  expect(listings.every((item) => item.status === 'archived' && item.bookable === false)).toBe(true);
  expect(vehicles.length).toBeGreaterThan(0);
  expect(vehicles.every((item) => item.status === 'archived')).toBe(true);
  const routes = store.state.routes.filter((item) => item.companyId === company.id);
  expect(routes.length).toBeGreaterThan(0);
  expect(routes.every((item) => item.status === 'archived')).toBe(true);
  expect(store.state.fareProducts.filter((item) => item.companyId === company.id).every((item) => item.status === 'archived')).toBe(true);
  expect(store.state.schedules.some((item) => item.companyId === company.id)).toBe(false);
});

test('createBusService replays the cached result instead of duplicating on a repeated idempotency key', async () => {
  const company = await verifiedCompany('Wizard Idempotent Path');
  const payload = fullPayload(company);
  const idempotencyKey = `wizard-idem-${suffix()}`;

  const first = await busServiceOnboarding.createBusService(company.id, payload, { actorId: 'wizard-test', idempotencyKey });
  const second = await busServiceOnboarding.createBusService(company.id, payload, { actorId: 'wizard-test', idempotencyKey });

  expect(second.listing.id).toBe(first.listing.id);
  expect(second.replayed).toBe(true);
  expect(store.state.listings.filter((item) => item.companyId === company.id).length).toBe(1);
});
