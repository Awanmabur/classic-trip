const request = require('supertest');
const bcrypt = require('bcryptjs');
const app = require('../../src/app');
const store = require('../../src/repositories/memoryDatabase');
const identityRepository = require('../../src/repositories/domain/identityRepository');
const invitationService = require('../../src/services/onboarding/invitationService');
const mfaService = require('../../src/services/auth/mfaService');
const { env } = require('../../src/config/env');
const phoneVerificationService = require('../../src/services/auth/phoneVerificationService');
const verificationService = require('../../src/services/onboarding/verificationService');
const onboardingRepository = require('../../src/repositories/domain/onboardingRepository');
const authService = require('../../src/services/auth/authService');
const companyService = require('../../src/services/company/companyService');

function unique(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

describe('authentication and privileged-role security boundaries', () => {
  test('pending partner can finish onboarding but cannot run live bus operations', async () => {
    const stamp = unique('restricted-partner');
    const agent = request.agent(app);
    const email = `${stamp}@classictrip.test`;

    await agent.post('/register').type('form').send({
      role: 'partner', fullName: 'Restricted Partner', email,
      phone: `+256${String(Date.now()).slice(-9)}`, password: 'Password123', confirmPassword: 'Password123',
      company: `Restricted Bus ${stamp}`, companyType: 'bus', country: 'Uganda', city: 'Kampala',
      operatingCurrency: 'UGX', termsAccepted: 'on',
    }).expect(302).expect('Location', '/company/profile?onboarding=1');

    await agent.get('/company/profile').expect(200);
    await agent.post('/company/scanner/validate').type('form').send({ bookingRef: 'NOT-A-BOOKING' })
      .expect(302).expect('Location', '/company/profile#verification');
    await agent.post('/company/payments').type('form').send({ bookingRef: 'NOT-A-BOOKING', amount: '1000' })
      .expect(302).expect('Location', '/company/profile#verification');
  });

  test('staff invitation token is transient and accepted membership is company-scoped', async () => {
    const stamp = unique('staff-invite');
    const company = {
      id: `company-${stamp}`, ownerId: `owner-${stamp}`, name: `Verified Company ${stamp}`,
      companyType: 'bus', status: 'active', verificationStatus: 'verified',
      settings: { canPublish: true }, createdAt: new Date().toISOString(),
    };
    await identityRepository.companies.save(company, { id: company.id });

    const invite = await invitationService.createInvitation({
      type: 'staff', companyId: company.id, email: `${stamp}@classictrip.test`,
      fullName: 'Invited Staff', roleTitle: 'Check-in agent', permissions: 'booking.view,checkin.scan',
    }, company.ownerId, 'company_staff');

    expect(invite.token).toBeTruthy();
    const stored = store.state.invitations.find((row) => row.id === invite.id);
    expect(stored.token).toBeUndefined();
    expect(stored.tokenHash).toBeTruthy();

    const accepted = await invitationService.acceptInvitation(invite.token, {
      fullName: 'Invited Staff', password: 'Password123', confirmPassword: 'Password123', agreementAccepted: 'on',
    });
    expect(accepted.user.role).toBe('company_employee');
    expect(accepted.user.companyId).toBe(company.id);
    expect(store.state.companyEmployees.some((row) => row.userId === accepted.user.id && row.companyId === company.id && row.status === 'active')).toBe(true);
  });

  test('driver invitation requires OTP and verification before assignment or operational access', async () => {
    const stamp = unique('driver-invite');
    const company = {
      id: `company-${stamp}`, ownerId: `owner-${stamp}`, name: `Verified Fleet ${stamp}`,
      companyType: 'bus', status: 'active', verificationStatus: 'verified',
      settings: { canPublish: true }, createdAt: new Date().toISOString(),
    };
    const vehicle = { id: `vehicle-${stamp}`, companyId: company.id, status: 'active', registrationNumber: `BUS-${stamp}` };
    const schedule = { id: `schedule-${stamp}`, companyId: company.id, vehicleId: vehicle.id, status: 'active' };
    await onboardingRepository.companies.save(company, { id: company.id });
    await onboardingRepository.vehicles.save(vehicle, { id: vehicle.id });
    await onboardingRepository.schedules.save(schedule, { id: schedule.id });

    const invite = await invitationService.createInvitation({
      type: 'driver', companyId: company.id, email: `${stamp}@classictrip.test`,
      phone: `+256${String(Date.now()).slice(-9)}`, fullName: 'Verified Driver',
      roleTitle: 'Driver', licenseNumber: 'DL-001', licenseClass: 'D',
      vehicleId: vehicle.id, scheduleId: schedule.id,
    }, company.ownerId, 'admin');

    const accepted = await invitationService.acceptInvitation(invite.token, {
      fullName: 'Verified Driver', phone: invite.phone, password: 'Password123',
      confirmPassword: 'Password123', agreementAccepted: 'on',
      documentType: 'driver_license', documentReference: 'DL-001',
      identityReference: 'NIN-DRIVER-001', licenseNumber: 'DL-001', licenseClass: 'D',
    });
    expect(accepted.user.status).toBe('active');
    expect(accepted.user.verificationStatus).toBe('pending');
    const employee = store.state.companyEmployees.find((row) => row.userId === accepted.user.id);
    expect(employee.status).toBe('pending_verification');
    expect(store.state.driverAssignments.some((row) => row.employeeId === employee.id && row.status === 'active')).toBe(false);

    const challenge = await phoneVerificationService.requestCode(accepted.user.id, { force: true });
    expect(challenge.testCode).toMatch(/^\d{6}$/);
    await phoneVerificationService.verifyCode(accepted.user.id, challenge.testCode);

    const review = await verificationService.getReview('driver', employee.id);
    for (const item of review.checklist) {
      await verificationService.reviewChecklistItem('driver', employee.id, item.key, 'approved', 'super-admin-test', { note: 'Verified in integration test' });
    }
    await verificationService.activateTarget('driver', employee.id, 'super-admin-test');

    const activatedUser = store.state.users.find((row) => row.id === accepted.user.id);
    const activatedEmployee = store.state.companyEmployees.find((row) => row.id === employee.id);
    const assignment = store.state.driverAssignments.find((row) => row.employeeId === employee.id && row.scheduleId === schedule.id);
    expect(activatedUser.verificationStatus).toBe('verified');
    expect(activatedUser.onboardingStatus).toBe('complete');
    expect(activatedEmployee.status).toBe('active');
    expect(assignment).toMatchObject({ status: 'active', vehicleId: vehicle.id, companyId: company.id });
  });

  test('passwords beyond the bcrypt UTF-8 byte limit are rejected before account creation', async () => {
    const email = `${unique('long-password')}@classictrip.test`;
    await expect(authService.registerUser({
      role: 'customer', fullName: 'Long Password User', email, phone: `+256${String(Date.now()).slice(-9)}`,
      password: `A1${'é'.repeat(36)}`,
    })).rejects.toMatchObject({ status: 422, code: 'invalid_password_policy' });
    expect(store.state.users.some((row) => row.email === email)).toBe(false);
  });

  test('company staff invitation cannot be converted into driver access by title or permissions', async () => {
    const stamp = unique('staff-driver-escalation');
    const company = {
      id: `company-${stamp}`, ownerId: `owner-${stamp}`, name: `Verified Company ${stamp}`,
      companyType: 'bus', status: 'active', verificationStatus: 'verified', settings: { canPublish: true },
      createdAt: new Date().toISOString(),
    };
    await onboardingRepository.companies.save(company, { id: company.id });
    await expect(companyService.inviteEmployee(company.id, {
      fullName: 'Fake Driver', email: `${stamp}@classictrip.test`, roleTitle: 'Driver',
      permissions: ['manifest.view', 'trip.status.update'],
    })).rejects.toMatchObject({ status: 409 });
  });

  test('generic membership editing cannot activate a driver awaiting verification', async () => {
    const stamp = unique('driver-state-machine');
    const company = {
      id: `company-${stamp}`, ownerId: `owner-${stamp}`, name: `Verified Fleet ${stamp}`,
      companyType: 'bus', status: 'active', verificationStatus: 'verified', settings: { canPublish: true },
      createdAt: new Date().toISOString(),
    };
    const user = {
      id: `user-${stamp}`, companyId: company.id, role: 'driver', fullName: 'Pending Driver',
      email: `${stamp}@classictrip.test`, phone: '+256700000099', status: 'active',
      passwordHash: await bcrypt.hash('Password123', 12), verificationStatus: 'pending', onboardingStatus: 'driver_verification',
      createdAt: new Date().toISOString(),
    };
    const employee = {
      id: `employee-${stamp}`, companyId: company.id, userId: user.id, roleTitle: 'Driver',
      permissions: ['manifest.view', 'checkin.assist', 'trip.status.update', 'incident.create'],
      status: 'pending_verification', acceptedAt: new Date().toISOString(), createdAt: new Date().toISOString(),
    };
    await onboardingRepository.companies.save(company, { id: company.id });
    await onboardingRepository.users.save(user, { id: user.id });
    await onboardingRepository.employees.save(employee, { id: employee.id });
    await expect(companyService.updateEmployeeRole(company.id, employee.id, { status: 'active' }, company.ownerId))
      .rejects.toThrow(/verification workflow/i);
  });

  test('driver assignment requires verified driver identity, safety clearance, and every canonical permission', async () => {
    const stamp = unique('driver-assignment-boundary');
    const company = {
      id: `company-${stamp}`, ownerId: `owner-${stamp}`, name: `Verified Fleet ${stamp}`,
      companyType: 'bus', status: 'active', verificationStatus: 'verified', settings: { canPublish: true }, createdAt: new Date().toISOString(),
    };
    const user = {
      id: `driver-${stamp}`, companyId: company.id, role: 'company_employee', fullName: 'Impersonated Driver',
      email: `${stamp}@classictrip.test`, phone: '+256700000055', status: 'active', verificationStatus: 'verified',
      passwordHash: await bcrypt.hash('Password123', 12), createdAt: new Date().toISOString(),
    };
    const employee = {
      id: `employee-${stamp}`, companyId: company.id, userId: user.id, roleTitle: 'Driver', status: 'active', safetyStatus: 'cleared',
      permissions: ['manifest.view', 'checkin.assist', 'trip.status.update'], acceptedAt: new Date().toISOString(), createdAt: new Date().toISOString(),
    };
    const vehicle = { id: `vehicle-${stamp}`, companyId: company.id, listingId: '', status: 'active', createdAt: new Date().toISOString() };
    await onboardingRepository.companies.save(company, { id: company.id });
    await onboardingRepository.users.save(user, { id: user.id });
    await onboardingRepository.employees.save(employee, { id: employee.id });
    await onboardingRepository.vehicles.save(vehicle, { id: vehicle.id });
    await expect(companyService.assignDriver(company.id, employee.id, { vehicleId: vehicle.id }, company.ownerId))
      .rejects.toThrow(/fully verified driver account/i);

    user.role = 'driver';
    await onboardingRepository.users.save(user, { id: user.id });
    await expect(companyService.assignDriver(company.id, employee.id, { vehicleId: vehicle.id }, company.ownerId))
      .rejects.toThrow(/required operational permissions/i);
  });

  test('partner owner can add or replace login contacts only through reverification', async () => {
    const stamp = unique('partner-owner-contact');
    const owner = {
      id: `owner-${stamp}`, companyId: `company-${stamp}`, role: 'company_admin', fullName: 'Partner Owner',
      email: `${stamp}@classictrip.test`, phone: '+256700000066', status: 'active', verificationStatus: 'verified',
      emailVerifiedAt: new Date().toISOString(), phoneVerifiedAt: new Date().toISOString(), passwordHash: await bcrypt.hash('Password123', 12), createdAt: new Date().toISOString(),
    };
    const company = {
      id: owner.companyId, ownerId: owner.id, name: `Owner Contact Company ${stamp}`, companyType: 'bus', status: 'active',
      verificationStatus: 'verified', settings: { canPublish: true }, createdAt: new Date().toISOString(),
    };
    await onboardingRepository.users.save(owner, { id: owner.id });
    await onboardingRepository.companies.save(company, { id: company.id });
    await require('../../src/services/dashboard/actionService').updateCompanySettings(company.id, {
      name: company.name, ownerEmail: owner.email, ownerPhone: '+256700000067', supportEmail: owner.email, supportPhone: '+256700000067',
    }, owner.id);
    const changedOwner = store.state.users.find((row) => row.id === owner.id);
    const changedCompany = store.state.companies.find((row) => row.id === company.id);
    expect(changedOwner.phoneVerifiedAt).toBeFalsy();
    expect(changedOwner.verificationStatus).toBe('pending');
    expect(changedCompany.verificationStatus).toBe('pending');
    expect(changedCompany.settings.canPublish).toBe(false);
  });

  test('regulated contact changes reset approval and suspend driver assignments', async () => {
    const stamp = unique('contact-reset');
    const company = {
      id: `company-${stamp}`, ownerId: `owner-${stamp}`, name: `Verified Fleet ${stamp}`,
      companyType: 'bus', status: 'active', verificationStatus: 'verified', settings: { canPublish: true }, createdAt: new Date().toISOString(),
    };
    const user = {
      id: `driver-${stamp}`, companyId: company.id, role: 'driver', fullName: 'Contact Driver',
      email: `${stamp}@classictrip.test`, phone: '+256700000088', status: 'active', verificationStatus: 'verified',
      emailVerifiedAt: new Date().toISOString(), phoneVerifiedAt: new Date().toISOString(), passwordHash: await bcrypt.hash('Password123', 12),
      createdAt: new Date().toISOString(),
    };
    const employee = {
      id: `employee-${stamp}`, companyId: company.id, userId: user.id, roleTitle: 'Driver', status: 'active', safetyStatus: 'cleared',
      permissions: ['manifest.view', 'checkin.assist', 'trip.status.update', 'incident.create'], acceptedAt: new Date().toISOString(), createdAt: new Date().toISOString(),
    };
    const assignment = { id: `assignment-${stamp}`, companyId: company.id, employeeId: employee.id, driverUserId: user.id, status: 'active', createdAt: new Date().toISOString() };
    await onboardingRepository.companies.save(company, { id: company.id });
    await onboardingRepository.users.save(user, { id: user.id });
    await onboardingRepository.employees.save(employee, { id: employee.id });
    await onboardingRepository.driverAssignments.save(assignment, { id: assignment.id });
    user.phone = '+256700000077';
    await onboardingRepository.users.save(user, { id: user.id });
    await verificationService.invalidateContactVerificationForUser(user.id, { phoneChanged: true }, user.id);
    expect(store.state.users.find((row) => row.id === user.id).verificationStatus).toBe('pending');
    expect(store.state.companyEmployees.find((row) => row.id === employee.id).status).toBe('pending_verification');
    expect(store.state.driverAssignments.find((row) => row.id === assignment.id).status).toBe('suspended');
  });

  test('administrator MFA enforcement can be disabled now and re-enabled later', async () => {
    const stamp = unique('mfa-admin');
    const password = 'Password123';
    const admin = {
      id: `admin-${stamp}`, role: 'super_admin', fullName: 'MFA Administrator',
      email: `${stamp}@classictrip.test`, phone: '', status: 'active', isVerified: true,
      verificationStatus: 'verified', twoFactorEnabled: false, onboardingStatus: 'mfa_setup_required',
      passwordHash: await bcrypt.hash(password, 12), authProviders: { local: { enabled: true } },
      createdAt: new Date().toISOString(),
    };
    await identityRepository.users.save(admin, { id: admin.id });

    const previous = env.platformMfaEnabled;
    try {
      env.platformMfaEnabled = false;
      const disabledSession = request.agent(app);
      await disabledSession.post('/login').type('form').send({ identity: admin.email, password }).expect(302).expect('Location', '/admin');
      await disabledSession.get('/admin/dashboard').expect(200);

      env.platformMfaEnabled = true;
      const firstSession = request.agent(app);
      await firstSession.post('/login').type('form').send({ identity: admin.email, password }).expect(302).expect('Location', '/auth/mfa/setup');
      await firstSession.get('/admin/dashboard').expect(302).expect('Location', '/auth/mfa/setup');

      const setup = await mfaService.beginSetup(admin.id);
      const code = mfaService.totp(setup.secret);
      await mfaService.confirmSetup(admin.id, code);

      const secondSession = request.agent(app);
      await secondSession.post('/login').type('form').send({ identity: admin.email, password }).expect(302).expect('Location', '/auth/mfa/challenge');
      await secondSession.post('/auth/mfa/challenge').type('form').send({ code: mfaService.totp(setup.secret) }).expect(302);
      await secondSession.get('/admin/dashboard').expect(200);
    } finally {
      env.platformMfaEnabled = previous;
    }
  });
});
