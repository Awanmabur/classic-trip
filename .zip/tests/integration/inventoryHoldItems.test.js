const store = require('../../src/repositories/memoryDatabase');
const seatLockService = require('../../src/services/booking/seatLockService');
const roomReservationService = require('../../src/services/booking/roomReservationService');
const inventoryHoldService = require('../../src/services/booking/inventoryHoldService');

describe('canonical inventory hold items', () => {
  const suffix = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  const scheduleId = `hold-test-schedule-${suffix}`;
  const companyId = `hold-test-company-${suffix}`;
  const listingId = `hold-test-listing-${suffix}`;
  const roomTypeId = `hold-test-room-type-${suffix}`;
  const roomUnitIds = [`hold-test-unit-a-${suffix}`, `hold-test-unit-b-${suffix}`];
  const checkIn = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  const checkOut = new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10);

  beforeAll(() => {
    store.state.seats.push(
      { id: `seat-a-${suffix}`, scheduleId, seatNumber: 'A1', status: 'available' },
      { id: `seat-b-${suffix}`, scheduleId, seatNumber: 'A2', status: 'available' }
    );
    store.state.roomTypes.push({ id: roomTypeId, companyId, listingId, name: 'Twin', basePrice: 120000, status: 'active' });
    roomUnitIds.forEach((id, index) => store.state.roomUnits.push({ id, companyId, listingId, roomTypeId, unitNumber: `T${index + 1}`, status: 'available' }));
  });

  afterAll(() => {
    store.state.seats = store.state.seats.filter((seat) => seat.scheduleId !== scheduleId);
    store.state.roomTypes = store.state.roomTypes.filter((room) => room.id !== roomTypeId);
    store.state.roomUnits = store.state.roomUnits.filter((room) => !roomUnitIds.includes(room.id));
    store.state.roomNightInventories = store.state.roomNightInventories.filter((row) => !roomUnitIds.includes(row.roomUnitId));
    store.state.inventoryHolds = store.state.inventoryHolds.filter((hold) => hold.scheduleId !== scheduleId && hold.roomTypeId !== roomTypeId);
    store.state.inventoryHoldItems = store.state.inventoryHoldItems.filter((item) => item.scheduleId !== scheduleId && item.roomTypeId !== roomTypeId);
    roomReservationService.reservations.splice(0, roomReservationService.reservations.length);
  });

  test('a grouped seat lock creates one parent and one item per seat', async () => {
    const grouped = await seatLockService.lockSeatsPersistent(scheduleId, ['A1', 'A2'], 10, { listingId, companyId });
    const parents = store.state.inventoryHolds.filter((hold) => hold.id === grouped.id);
    const children = store.state.inventoryHoldItems.filter((item) => item.holdId === grouped.id);
    expect(parents).toHaveLength(1);
    expect(parents[0]).toMatchObject({ type: 'seats', itemCount: 2, status: 'active' });
    expect(children).toHaveLength(2);
    expect(children.map((item) => item.resourceKey).sort()).toEqual([
      inventoryHoldService.seatResourceKey(scheduleId, 'A1'),
      inventoryHoldService.seatResourceKey(scheduleId, 'A2'),
    ].sort());
    expect(store.state.inventoryHolds.filter((hold) => grouped.holds.some((item) => item.id === hold.id))).toHaveLength(0);
    await expect(seatLockService.lockSeatPersistent(scheduleId, 'A1', 10)).rejects.toMatchObject({ status: 409 });
    await inventoryHoldService.consumeHold(grouped.id, { id: 'booking-group-test', groupRef: 'ORDER-TEST' });
    expect(store.state.inventoryHolds.find((hold) => hold.id === grouped.id).status).toBe('consumed');
    expect(store.state.inventoryHoldItems.filter((item) => item.holdId === grouped.id).every((item) => item.status === 'consumed')).toBe(true);
  });

  test('room holds allocate separate units for the same night', async () => {
    const context = { listingId, companyId, roomTypeId, checkIn, checkOut };
    const first = await roomReservationService.reserveRoomPersistent(roomTypeId, { fullName: 'Guest One' }, 10, context);
    const second = await roomReservationService.reserveRoomPersistent(roomTypeId, { fullName: 'Guest Two' }, 10, context);
    expect(first.roomUnitId).not.toBe(second.roomUnitId);
    expect(await roomReservationService.roomActiveHoldCount(roomTypeId)).toBe(2);
    await expect(roomReservationService.reserveRoomPersistent(roomTypeId, { fullName: 'Guest Three' }, 10, context)).rejects.toMatchObject({ status: 409 });
    const items = store.state.inventoryHoldItems.filter((item) => item.roomTypeId === roomTypeId && item.status === 'active');
    expect(items).toHaveLength(2);
    expect(new Set(items.map((item) => item.resourceKey)).size).toBe(2);
    expect(items.every((item) => item.resourceType === 'room_unit_night')).toBe(true);
  });
});
