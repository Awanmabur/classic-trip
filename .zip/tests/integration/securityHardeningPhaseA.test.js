const request = require('supertest');
const app = require('../../src/app');
const store = require('../../src/repositories/memoryDatabase');
const { resolvePromoterId } = require('../../src/utils/promoterScope');
const { resolveCustomerId } = require('../../src/utils/customerScope');

function suffix() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

async function login(email) {
  const agent = request.agent(app);
  await agent.post('/login').type('form').send({ identity: email, password: 'Password123' }).expect(302);
  return agent;
}

describe('Phase A2 - cross-tenant support ticket IDOR', () => {
  test('a company cannot update a support ticket that belongs to no company (promoter/customer/public-lead ticket)', async () => {
    const ticket = {
      id: `support-idor-${suffix()}`,
      ownerType: 'promoter',
      ownerId: 'user-promoter-001',
      subject: 'Promoter-only ticket',
      status: 'open',
      priority: 'medium',
      createdAt: new Date().toISOString(),
    };
    store.state.supportTickets.push(ticket);

    const company = await login('company@classictrip.test');
    await company.post(`/company/support/${ticket.id}`).type('form').send({ status: 'resolved', message: 'Should not be allowed' });

    const unchanged = store.state.supportTickets.find((item) => item.id === ticket.id);
    expect(unchanged.status).toBe('open');
    expect(unchanged.lastResponse).toBeUndefined();
  });

  test('a company can still update its own support ticket', async () => {
    const ticket = {
      id: `support-owned-${suffix()}`,
      companyId: 'company-01',
      subject: 'Company-owned ticket',
      status: 'open',
      priority: 'medium',
      createdAt: new Date().toISOString(),
    };
    store.state.supportTickets.push(ticket);

    const company = await login('company@classictrip.test');
    await company.post(`/company/support/${ticket.id}`).type('form').send({ status: 'resolved', message: 'Handled' }).expect(302);

    const updated = store.state.supportTickets.find((item) => item.id === ticket.id);
    expect(updated.status).toBe('resolved');
    expect(updated.lastResponse).toBe('Handled');
  });
});

describe('Phase A1 - customerUserId spoofing', () => {
  test('POST /bookings/guest ignores a client-supplied customerUserId', async () => {
    const listing = store.state.listings.find((item) => item.bookable && item.serviceType === 'bus');
    const victim = store.state.users.find((user) => user.role === 'customer');
    expect(victim).toBeTruthy();

    const res = await request(app)
      .post('/bookings/guest')
      .type('form')
      .send({
        listingId: listing.id,
        fullName: 'Spoofer Guest',
        email: `spoofer-${suffix()}@example.com`,
        phone: '+256700900100',
        customerUserId: victim.id,
        userId: victim.id,
      });
    expect([302, 303]).toContain(res.status);

    const booking = store.state.bookings.find((item) => item.guestSnapshot?.email?.startsWith('spoofer-') || item.buyerSnapshot?.email?.startsWith('spoofer-'));
    expect(booking).toBeTruthy();
    expect(booking.customerUserId).not.toBe(victim.id);
  });

  test('POST /api/bookings ignores a client-supplied customerUserId', async () => {
    const listing = store.state.listings.find((item) => item.bookable && item.serviceType === 'bus');
    const victim = store.state.users.find((user) => user.role === 'customer');

    const res = await request(app)
      .post('/api/bookings')
      .send({
        listingId: listing.id,
        fullName: 'API Spoofer Guest',
        email: `api-spoofer-${suffix()}@example.com`,
        phone: '+256700900101',
        customerUserId: victim.id,
      })
      .expect(201);
    expect(res.body.booking.customerUserId).not.toBe(victim.id);
  });

  test('POST /cart ignores a client-supplied customerUserId', async () => {
    const victim = store.state.users.find((user) => user.role === 'customer');

    const res = await request(app)
      .post('/api/bookings/cart')
      .send({ customerUserId: victim.id })
      .expect(201);
    const cart = store.state.carts.find((item) => item.cartRef === res.body.cart.cartRef);
    expect(cart).toBeTruthy();
    expect(cart.userId).not.toBe(victim.id);
  });
});

describe('Phase A3 - promoter/customer identity resolution never falls back to another account', () => {
  test('resolvePromoterId throws instead of defaulting when the session has no id', () => {
    expect(() => resolvePromoterId({ session: {} })).toThrow();
    expect(() => resolvePromoterId({ session: { user: { role: 'promoter' } } })).toThrow();
    expect(() => resolvePromoterId({ session: { user: { id: 'user-customer-001', role: 'customer' } } })).toThrow();
  });

  test('resolvePromoterId returns the real session id for a promoter or super_admin', () => {
    expect(resolvePromoterId({ session: { user: { id: 'user-promoter-001', role: 'promoter' } } })).toBe('user-promoter-001');
    expect(resolvePromoterId({ session: { user: { id: 'admin-1', role: 'super_admin' } } })).toBe('admin-1');
  });

  test('resolveCustomerId throws instead of defaulting when the session has no id', () => {
    expect(() => resolveCustomerId({ session: {} })).toThrow();
    expect(() => resolveCustomerId({ session: { user: { role: 'customer' } } })).toThrow();
    expect(() => resolveCustomerId({ session: { user: { id: 'user-promoter-001', role: 'promoter' } } })).toThrow();
  });

  test('a customer dashboard request for an id with no matching user does not crash and does not leak another customer\'s bookings', () => {
    const bogusId = `nonexistent-customer-${suffix()}`;
    const data = store.dashboardData('customer', { customerId: bogusId });
    expect(data).toBeTruthy();
    const bookingRows = data.bookings || data.upcomingTrips || [];
    expect(Array.isArray(bookingRows) ? bookingRows.length : 0).toBe(0);
  });
});

describe('Phase A4 - sanitization gaps', () => {
  test('markNoShow strips HTML tags from the note before storing it', async () => {
    const listing = store.state.listings.find((item) => item.bookable && item.serviceType === 'bus');
    const booking = await store.createBooking({
      listingId: listing.id,
      fullName: 'No Show Guest',
      email: `noshow-${suffix()}@example.com`,
      phone: '+256700900200',
    });

    const result = await store.markNoShow(booking.bookingRef, 'employee-test', booking.companyId, '<script>alert(1)</script>Late arrival');
    expect(result.ok).toBe(true);
    expect(result.booking.checkInNote).toBe('alert(1)Late arrival');
    expect(result.booking.checkInNote).not.toContain('<script>');
  });

  test('markSponsored strips HTML tags from campaign name and placement', async () => {
    const company = await login('company@classictrip.test');
    const listing = store.state.listings.find((item) => item.companyId === 'company-01' && item.bookable);
    const promotionService = require('../../src/services/promotion/promotionService');
    const result = await promotionService.markSponsored(listing.id, 'company-01', {
      name: '<b>Weekend</b> Boost',
      placement: '<i>route_boost</i>',
    });
    expect(result.campaign.name).toBe('Weekend Boost');
    expect(result.campaign.placement).toBe('route_boost');
  });
});
