const request = require('supertest');
const app = require('../../src/app');

describe('Phase B - account-level login lockout', () => {
  test('locks out an identity after repeated failed attempts, independent of the correct password eventually being sent', async () => {
    const identity = `lockout-tester-${Date.now()}@classictrip.test`;
    await request(app).post('/register').type('form').send({
      fullName: 'Lockout Tester',
      email: identity,
      phone: '+256700900300',
      password: 'Password123',
      confirmPassword: 'Password123',
      role: 'customer',
    }).expect(302);

    for (let i = 0; i < 5; i += 1) {
      // eslint-disable-next-line no-await-in-loop
      await request(app).post('/login').type('form').send({ identity, password: 'wrong-password' }).expect(302);
    }

    const res = await request(app).post('/login').type('form').send({ identity, password: 'Password123' });
    expect(res.status).toBe(302);
    expect(res.headers.location).toContain('error=locked');
  });

  test('a fresh identity with no prior failures can still log in normally', async () => {
    const res = await request(app).post('/login').type('form').send({ identity: 'company@classictrip.test', password: 'Password123' });
    expect(res.status).toBe(302);
    expect(res.headers.location).not.toContain('error=locked');
  });
});
