'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const failures = [];
const checks = [];

function read(relative) {
  return fs.readFileSync(path.join(root, relative), 'utf8');
}
function pass(label) { checks.push({ label, ok: true }); }
function fail(label, detail) { checks.push({ label, ok: false, detail }); failures.push(`${label}: ${detail}`); }
function requireFile(relative) {
  if (fs.existsSync(path.join(root, relative))) pass(`file ${relative}`);
  else fail(`file ${relative}`, 'missing');
}
function contains(relative, needle, label = `${relative} contains ${needle}`) {
  const source = read(relative);
  if (source.includes(needle)) pass(label);
  else fail(label, `missing ${JSON.stringify(needle)}`);
}
function notContains(relative, needle, label = `${relative} excludes ${needle}`) {
  const source = read(relative);
  if (!source.includes(needle)) pass(label);
  else fail(label, `found prohibited ${JSON.stringify(needle)}`);
}
function blockBetween(relative, start, end) {
  const source = read(relative);
  const from = source.indexOf(start);
  const to = source.indexOf(end, from + start.length);
  if (from < 0 || to < 0) throw new Error(`Could not isolate block in ${relative}`);
  return source.slice(from, to);
}
function assertBlock(relative, start, end, required = [], prohibited = []) {
  let block;
  try { block = blockBetween(relative, start, end); }
  catch (error) { fail(`${relative} block`, error.message); return; }
  for (const value of required) {
    if (block.includes(value)) pass(`${relative} bus UI includes ${value}`);
    else fail(`${relative} bus UI includes ${value}`, 'missing');
  }
  for (const value of prohibited) {
    if (!block.includes(value)) pass(`${relative} bus UI excludes ${value}`);
    else fail(`${relative} bus UI excludes ${value}`, 'legacy duplicate field remains');
  }
}
function walk(dir, extension) {
  const result = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) result.push(...walk(full, extension));
    else if (!extension || full.endsWith(extension)) result.push(full);
  }
  return result;
}
function checkJavascriptSyntax() {
  for (const file of [...walk(path.join(root, 'src'), '.js'), ...walk(path.join(root, 'scripts'), '.js'), ...walk(path.join(root, 'tests'), '.js')]) {
    try { execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' }); }
    catch (error) { fail(`syntax ${path.relative(root, file)}`, String(error.stderr || error.message)); }
  }
  if (!failures.some((item) => item.startsWith('syntax '))) pass('all JavaScript parses');
}

function checkCanonicalBusSeed() {
  let data;
  try { data = require(path.join(root, 'src/seeds/seedAll')).buildSeedData(); }
  catch (error) { fail('canonical fresh seed loads', error.message); return; }
  pass('canonical fresh seed loads');
  const busListings = (data.listings || []).filter((row) => row.serviceType === 'bus');
  const publishedSchedules = (data.schedules || []).filter((row) => row.status === 'published');
  const busBookings = (data.bookings || []).filter((row) => row.serviceType === 'bus');
  const predicates = [
    ['every bus listing has one canonical route', busListings.every((listing) => (data.routes || []).some((route) => route.listingId === listing.id && route.status === 'active'))],
    ['every route has ordered stops and segments', (data.routes || []).every((route) => (data.routeStops || []).filter((stop) => stop.routeId === route.id).length >= 2 && (data.routeSegments || []).filter((segment) => segment.routeId === route.id).length >= 1)],
    ['every vehicle has a published seat-map version', (data.vehicles || []).every((vehicle) => (data.seatMapVersions || []).some((version) => version.id === vehicle.activeSeatMapVersionId && version.status === 'published'))],
    ['every bus route has an active fare product and segment fares', (data.routes || []).every((route) => (data.fareProducts || []).some((product) => product.id === route.activeFareProductId && product.status === 'active') && (data.busSegmentFares || []).some((fare) => fare.routeId === route.id && fare.status === 'active'))],
    ['every published departure freezes route seat-map and fare configuration', publishedSchedules.every((schedule) => schedule.routeSnapshot && schedule.seatMapSnapshot && schedule.fareSnapshot && schedule.seatMapVersionId && schedule.fareProductId)],
    ['every published departure has a verified driver and compliance-ready vehicle', publishedSchedules.every((schedule) => schedule.driverEmployeeId && (data.companyEmployees || []).some((employee) => employee.id === schedule.driverEmployeeId && employee.status === 'active' && employee.safetyStatus === 'cleared') && (data.vehicles || []).some((vehicle) => vehicle.id === schedule.vehicleId && vehicle.operatorPermitRef && vehicle.inspectionRef && vehicle.insuranceRef))],
    ['every departure has segment-level inventory for every seat', publishedSchedules.every((schedule) => { const segments = (data.routeSegments || []).filter((segment) => segment.routeId === schedule.routeId).length; const version = (data.seatMapVersions || []).find((row) => row.id === schedule.seatMapVersionId); return (data.busSeatSegmentInventories || []).filter((row) => row.scheduleId === schedule.id).length === segments * Number(version?.totalSeats || 0); })],
    ['every seeded bus booking has independent item reservation assignment and ticket', busBookings.every((booking) => (data.bookingItems || []).some((item) => item.bookingId === booking.id) && (data.busReservations || []).some((reservation) => reservation.bookingId === booking.id) && (data.busSeatAssignments || []).some((assignment) => assignment.bookingId === booking.id) && (data.busTickets || []).some((ticket) => ticket.bookingId === booking.id))],
    ['seeded booked seats update canonical segment inventory and compatibility projection', busBookings.every((booking) => (data.busSeatSegmentInventories || []).some((row) => row.bookingId === booking.id && ['booked', 'checked_in'].includes(row.status)) && (data.seats || []).some((row) => row.bookingId === booking.id && ['booked', 'checked_in'].includes(row.status)))],
    ['fresh seed registers all canonical Mongo collections', ['RouteSegment','SeatMapTemplate','SeatMapVersion','FareProduct','BusSegmentFare','BusSeatSegmentInventory','BookingItem','BusReservation','BusSeatAssignment','BusTicket','InventoryHoldItem','OutboxEvent'].every((name) => (require(path.join(root, 'src/seeds/seedAll')).seedModelNames || []).includes(name))],
  ];
  for (const [label, ok] of predicates) ok ? pass(label) : fail(label, 'seed relationship invariant failed');
}

function checkEjsScripts(relative) {
  // Normalize EJS before parsing HTML tags because the `%>` in a nonce attribute also
  // contains `>` and would otherwise look like the end of the opening <script> tag.
  const template = read(relative)
    .replace(/<%-[\s\S]*?%>/g, 'null')
    .replace(/<%=[\s\S]*?%>/g, 'null')
    .replace(/<%[\s\S]*?%>/g, '');
  const scripts = [...template.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script>/gi)].map((match) => match[1]);
  scripts.forEach((source, index) => {
    if (!source.trim()) return;
    try { new vm.Script(source, { filename: `${relative}#script-${index + 1}` }); pass(`${relative} inline script ${index + 1}`); }
    catch (error) { fail(`${relative} inline script ${index + 1}`, error.message); }
  });
}

[
  'src/models/SeatMapTemplate.js',
  'src/models/SeatMapVersion.js',
  'src/models/RouteSegment.js',
  'src/models/FareProduct.js',
  'src/models/BusSegmentFare.js',
  'src/models/BusSeatSegmentInventory.js',
  'src/models/BookingItem.js',
  'src/models/BusReservation.js',
  'src/models/BusSeatAssignment.js',
  'src/models/BusTicket.js',
  'src/modules/bus/services/busSetupService.js',
  'src/modules/bus/services/busDepartureService.js',
  'src/modules/bus/services/busInventoryService.js',
  'src/modules/bus/services/busBookingService.js',
  'src/modules/bus/services/busBookingDraftService.js',
  'src/modules/bus/services/busOperationsService.js',
  'src/modules/bus/services/busSearchService.js',
  'src/modules/bus/routes/publicBusRoutes.js',
].forEach(requireFile);

contains('src/app.js', "app.use('/api/v1/bus', require('./modules/bus/routes/publicBusRoutes'))", 'canonical public bus API is mounted');
contains('src/modules/bus/services/busInventoryService.js', 'crypto.timingSafeEqual', 'hold tokens use constant-time comparison');
contains('src/modules/bus/routes/publicBusRoutes.js', "req.headers['x-hold-token']", 'hold token accepted through protected header');
notContains('src/modules/bus/routes/publicBusRoutes.js', 'req.query.holdToken', 'hold token is never read from URL query');
notContains('src/controllers/public/listingController.js', 'req.query.holdToken', 'legacy booking controller never reads outbound hold tokens from query strings');
notContains('src/controllers/public/listingController.js', 'req.query.returnHoldToken', 'legacy booking controller never reads return hold tokens from query strings');
notContains('src/views/pages/listing-details.ejs', "params.set('holdToken'", 'outbound hold token is never placed in checkout URL');
notContains('src/views/pages/listing-details.ejs', "params.set('returnHoldToken'", 'return hold token is never placed in checkout URL');
notContains('src/views/pages/booking-form.ejs', 'name="holdToken"', 'checkout HTML does not expose outbound hold token');
notContains('src/views/pages/booking-form.ejs', 'name="returnHoldToken"', 'checkout HTML does not expose return hold token');
contains('src/routes/web/public.js', "router.post('/book/:serviceType/:slug/prepare'", 'secure session-backed checkout preparation route is mounted');
contains('src/routes/web/public.js', 'busBookingDraftService.applyDraftToPayload', 'bus checkout restores trusted hold access from the server session');
contains('src/modules/bus/services/busBookingDraftService.js', 'crypto.randomUUID()', 'booking drafts use opaque session-bound identifiers');
contains('src/modules/bus/services/busBookingDraftService.js', "createCipheriv(TOKEN_CIPHER", 'session-backed hold access is encrypted with authenticated encryption');
contains('src/modules/bus/services/busBookingDraftService.js', 'decipher.setAuthTag', 'encrypted checkout hold access is integrity checked before use');
notContains('src/modules/bus/services/busBookingDraftService.js', 'holdToken: token', 'raw hold tokens are not stored in booking draft session records');
contains('src/controllers/public/listingController.js', "res.set('Cache-Control', 'no-store, max-age=0')", 'checkout page disables browser/proxy caching');
contains('src/controllers/public/listingController.js', "provider: 'pesapal'", 'browser payment return is limited to provider-verified Pesapal reconciliation');
contains('src/controllers/public/listingController.js', 'A browser redirect is not a trusted payment webhook', 'payment return trust boundary is explicit');
contains('src/services/payment/webhookService.js', 'assertAmountAndCurrency', 'payment amount and currency are checked server-side');
contains('src/services/payment/webhookService.js', 'busBookingService.confirmPayment', 'verified payment confirms canonical bus reservations');
contains('src/services/payment/webhookService.js', 'busBookingService.refundBooking', 'verified refund updates canonical bus reservations');
contains('src/modules/bus/services/busSearchService.js', 'findReturnsForDeparture', 'round-trip search uses reverse route discovery');
contains('src/services/operations/manifestService.js', 'busOperationsService.manifest', 'manifest uses canonical bus operation records');
contains('src/services/booking/bookingService.js', 'busOperationsService.validateTicket', 'scanner uses canonical ticket validation');
contains('src/services/company/busServiceOnboarding.js', 'replayed: true', 'bus setup idempotency explicitly reports replay');
contains('src/controllers/company/onboardingController.js', 'if (result.replayed)', 'replayed setup deletes newly uploaded orphan media');
contains('src/modules/bus/services/busDepartureService.js', 'operator_permit_missing_or_expired', 'departure publication checks operator permit');
contains('src/modules/bus/services/busDepartureService.js', 'inspection_missing_or_expired', 'departure publication checks inspection');
contains('src/modules/bus/services/busDepartureService.js', 'insurance_missing_or_expired', 'departure publication checks insurance');
contains('src/modules/bus/services/busDepartureService.js', 'vehicle_time_conflict', 'departure publication blocks vehicle conflicts');
contains('src/modules/bus/services/busBookingService.js', 'returnHoldToken', 'round-trip checkout carries an independent return hold token');
contains('src/modules/bus/repositories/busRepository.js', "bookingItems: new HybridCollection('bookingItems')", 'canonical booking items have an independent repository');

assertBlock(
  'public/js/dashboard-workspace.js',
  "if (isCompanyRole && key === 'bus service')",
  "if (isCompanyRole && key === 'room type')",
  [
    "listingImageFile",
    "listing[operatorLicenceRef]",
    "listing[baggageRules]",
    "listing[cancellationRules]",
    "vehicle[plateOrCode]",
    "vehicle[operatorPermitRef]",
    "vehicle[inspectionRef]",
    "vehicle[insuranceRef]",
    "route[originBranchId]",
    "route[destinationBranchId]",
    "fare[amount]",
    "fare[baggageAllowanceKg]",
    "schedule[driverId]",
  ],
  ["listing[priceFrom]", "schedule[basePrice]"]
);

checkCanonicalBusSeed();
checkEjsScripts('src/views/pages/listing-details.ejs');
checkEjsScripts('src/views/pages/booking-form.ejs');
checkJavascriptSyntax();

const summary = { passed: checks.filter((item) => item.ok).length, failed: failures.length, checks };
console.log(JSON.stringify(summary, null, 2));
if (failures.length) process.exitCode = 1;
