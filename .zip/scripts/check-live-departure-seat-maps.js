'use strict';

const fs = require('fs');
const path = require('path');
const { buildLiveDepartureSeatMaps, isBusDepartureSchedule } = require('../src/services/dashboard/liveDepartureSeatMapProjection');
const { buildCompanyTransportScope } = require('../src/services/dashboard/companyTransportScope');
const { createDashboardProjection } = require('../src/services/dashboard/dashboardProjectionEngine');
const memoryDatabase = require('../src/repositories/memoryDatabase');

let passed = 0;
function check(condition, message) {
  if (!condition) throw new Error(message);
  passed += 1;
}

const base = {
  listings: [{ id: 'listing-1', companyId: 'company-1', serviceType: 'bus', title: 'Kampala to Juba', from: 'Kampala', to: 'Juba' }],
  routes: [{ id: 'route-1', companyId: 'company-1', listingId: 'listing-1', routeName: 'Kampala to Juba' }],
  vehicles: [{ id: 'vehicle-1', companyId: 'company-1', listingId: 'listing-1', serviceType: 'bus', name: 'Coach 1', totalSeats: 4 }],
  seatMapVersions: [{ id: 'version-1', companyId: 'company-1', listingId: 'listing-1', vehicleId: 'vehicle-1', version: 1, status: 'published', totalSeats: 4, seats: [{ seatNumber: 'A1' }, { seatNumber: 'A2' }, { seatNumber: 'B1' }, { seatNumber: 'B2' }] }],
  bookings: [],
};

check(isBusDepartureSchedule({ id: 's', listingId: 'listing-1' }, {
  listingById: new Map(base.listings.map((row) => [row.id, row])),
  routeById: new Map(),
  vehicleById: new Map(),
}), 'Bus listing should classify its schedule as bus');

const persisted = buildLiveDepartureSeatMaps({
  ...base,
  schedules: [{ id: 'schedule-1', listingId: 'listing-1', routeId: 'route-1', vehicleId: 'vehicle-1', seatMapVersionId: 'version-1', status: 'published', departAt: '2026-07-30T08:00:00.000Z' }],
  seats: [{ id: 'seat-1', scheduleId: 'schedule-1', seatNumber: 'A1', status: 'available' }, { id: 'seat-2', scheduleId: 'schedule-1', seatNumber: 'A2', status: 'taken' }],
});
check(persisted.length === 1, 'Persisted departure should render one live seat map');
check(persisted[0].inventorySource === 'persisted_inventory', 'Persisted seats must remain authoritative');
check(persisted[0].totalSeats === 2, 'Persisted total must match live rows');
check(persisted[0].bookedSeats === 1, 'Taken seats must count as booked');

const legacy = buildLiveDepartureSeatMaps({
  ...base,
  schedules: [{ id: 'legacy-1', listingId: 'listing-1', routeId: 'route-1', vehicleId: 'vehicle-1', seatMapVersionId: 'version-1', status: 'draft', departAt: '2026-07-31T08:00:00.000Z', totalSeats: 4 }],
  seats: [],
});
check(legacy.length === 1, 'Legacy departure should not disappear');
check(legacy[0].inventorySource === 'published_seat_map_version', 'Published vehicle version should recover the visual map');
check(legacy[0].inventoryNeedsRepair === true, 'Recovered inventory must be marked for safe repair');
check(legacy[0].seats.map((seat) => seat.seatNumber).join(',') === 'A1,A2,B1,B2', 'Custom labels must remain exact');
check(legacy[0].availableSeats === 4, 'Recovered available count must be accurate');

const snapshot = buildLiveDepartureSeatMaps({
  ...base,
  schedules: [{ id: 'snapshot-1', listingId: 'listing-1', routeId: 'route-1', vehicleId: 'vehicle-1', status: 'active', seatInventorySnapshot: [{ seatNumber: '1', status: 'blocked' }, { seatNumber: '2', status: 'available' }] }],
  seatMapVersions: [],
  seats: [],
});
check(snapshot[0].inventorySource === 'schedule_inventory_snapshot', 'Schedule snapshot should recover missing rows');
check(snapshot[0].blockedSeats === 1, 'Recovered blocked count must be accurate');

const capacity = buildLiveDepartureSeatMaps({
  listings: base.listings,
  routes: base.routes,
  vehicles: [{ ...base.vehicles[0], seatTemplate: [], totalSeats: 3 }],
  seatMapVersions: [],
  schedules: [{ id: 'capacity-1', listingId: 'listing-1', routeId: 'route-1', vehicleId: 'vehicle-1', status: 'draft', totalSeats: 3, seatMapSnapshot: { totalSeats: 3 } }],
  seats: [],
  bookings: [],
});
check(capacity[0].inventorySource === 'capacity_fallback', 'Capacity fallback should prevent an empty page');
check(capacity[0].seats.length === 3, 'Capacity fallback should generate the expected preview count');


const alternateShapes = buildLiveDepartureSeatMaps({
  listings: [{ _id: 'listing-object-id', serviceType: 'bus', title: 'Legacy Bus' }],
  routes: [{ _id: 'route-object-id', listingId: 'listing-object-id', origin: 'A', destination: 'B' }],
  vehicles: [{ _id: 'vehicle-object-id', listingId: 'listing-object-id', serviceType: 'bus', name: 'Legacy Coach' }],
  seatMapVersions: [{ _id: 'version-object-id', vehicleId: 'vehicle-object-id', status: 'published', seatDefinitions: [{ label: 'L1' }, { label: 'L2' }] }],
  schedules: [{ _id: 'schedule-object-id', listingId: 'listing-object-id', routeId: 'route-object-id', vehicleId: 'vehicle-object-id', seatMapSnapshot: { versionId: 'version-object-id' }, status: 'active' }],
  seats: [{ id: 'legacy-live-seat', departureId: 'schedule-object-id', label: 'L1', status: 'held' }],
  bookings: [],
});
check(alternateShapes.length === 1, 'ObjectId-only legacy departure should render');
check(alternateShapes[0].scheduleId === 'schedule-object-id', 'ObjectId fallback must become the schedule id');
check(alternateShapes[0].inventorySource === 'persisted_inventory', 'Legacy departureId seat rows must be recognized');
check(alternateShapes[0].heldSeats === 1, 'Legacy held seat status must be counted');

const companyListings = [{ id: 'owned-listing', companyId: 'company-owned', serviceType: 'bus' }];
const scoped = buildCompanyTransportScope({
  routes: [
    { id: 'legacy-route', listingId: 'owned-listing' },
    { id: 'foreign-route', companyId: 'company-foreign', listingId: 'owned-listing' },
  ],
  vehicles: [{ id: 'legacy-vehicle', listingId: 'owned-listing', serviceType: 'bus' }],
  schedules: [
    { id: 'legacy-schedule', routeId: 'legacy-route', vehicleId: 'legacy-vehicle' },
    { id: 'foreign-schedule', companyId: 'company-foreign', routeId: 'legacy-route' },
  ],
  seatMapVersions: [{ id: 'legacy-version', vehicleId: 'legacy-vehicle', seats: [{ seatNumber: '1' }] }],
  seatMapTemplates: [], routeStops: [], routeSegments: [], fareProducts: [], busSegmentFares: [], seats: [],
}, 'company-owned', companyListings);
check(scoped.routes.some((row) => row.id === 'legacy-route'), 'Listing-linked legacy route must be company scoped');
check(scoped.vehicles.some((row) => row.id === 'legacy-vehicle'), 'Listing-linked legacy vehicle must be company scoped');
check(scoped.schedules.some((row) => row.id === 'legacy-schedule'), 'Route/vehicle-linked legacy departure must be company scoped');
check(!scoped.routes.some((row) => row.id === 'foreign-route'), 'Explicit foreign route ownership must never be inferred');
check(!scoped.schedules.some((row) => row.id === 'foreign-schedule'), 'Explicit foreign departure ownership must never be inferred');

const projectionState = {};
for (const entity of memoryDatabase.BASE_KEYS) projectionState[entity] = [];
projectionState.platformSettings = {};
projectionState.companies = [{ id: 'company-owned', name: 'Owned Bus Co', companyType: 'bus', serviceTypes: ['bus'], status: 'active', verificationStatus: 'verified' }];
projectionState.listings = [{ id: 'owned-listing', companyId: 'company-owned', serviceType: 'bus', title: 'Owned Bus', from: 'A', to: 'B', status: 'active' }];
projectionState.routes = [{ id: 'legacy-route', listingId: 'owned-listing', routeName: 'A to B', origin: 'A', destination: 'B', status: 'active' }];
projectionState.vehicles = [{ id: 'legacy-vehicle', listingId: 'owned-listing', serviceType: 'bus', name: 'Owned Coach', activeSeatMapVersionId: 'legacy-version', totalSeats: 2, status: 'active' }];
projectionState.seatMapVersions = [{ id: 'legacy-version', listingId: 'owned-listing', vehicleId: 'legacy-vehicle', version: 1, status: 'published', totalSeats: 2, seats: [{ seatNumber: 'A1' }, { seatNumber: 'A2' }] }];
projectionState.schedules = [{ id: 'legacy-schedule', routeId: 'legacy-route', vehicleId: 'legacy-vehicle', seatMapVersionId: 'legacy-version', departAt: '2026-08-01T08:00:00.000Z', status: 'active' }];
const projectedDashboard = createDashboardProjection(projectionState).dashboardData('company', { companyId: 'company-owned' });
check(projectedDashboard.seatMaps.length === 1, 'Company dashboard must retain a relationship-owned legacy departure');
check(projectedDashboard.seatMaps[0].seats.length === 2, 'Company dashboard must resolve the linked published seat-map version');
check(projectedDashboard.seatMapDiagnostics.inferredLegacyLinks.schedules === 1, 'Diagnostics must report inferred legacy departure links');

const root = path.resolve(__dirname, '..');
const engine = fs.readFileSync(path.join(root, 'src/services/dashboard/dashboardProjectionEngine.js'), 'utf8');
const snapshotService = fs.readFileSync(path.join(root, 'src/services/dashboard/dashboardSnapshotService.js'), 'utf8');
const controller = fs.readFileSync(path.join(root, 'src/controllers/company/dashboardController.js'), 'utf8');
const template = fs.readFileSync(path.join(root, 'src/views/dashboards/shared/sections/seat-maps.ejs'), 'utf8');
const browser = fs.readFileSync(path.join(root, 'public/js/dashboard-workspace.js'), 'utf8');
const departure = fs.readFileSync(path.join(root, 'src/modules/bus/services/busDepartureService.js'), 'utf8');
const scopeSource = fs.readFileSync(path.join(root, 'src/services/dashboard/companyTransportScope.js'), 'utf8');

check(engine.includes('buildLiveDepartureSeatMaps'), 'Dashboard must use the resilient live seat-map projection');
check(engine.includes('seatMapDiagnostics'), 'Dashboard must expose seat-map diagnostics');
check(snapshotService.includes('Compatibility recovery for older records'), 'Snapshot must recover listing-linked legacy rows');
check(snapshotService.includes('referencedVersionIds'), 'Snapshot must load referenced seat-map versions');
check(snapshotService.includes('vehicleIdsForSchedules'), 'Snapshot must recover route/vehicle-linked legacy departures');
check(scopeSource.includes('an explicit companyId always wins'), 'Ownership resolver must document explicit-owner security precedence');
check(engine.includes('buildCompanyTransportScope'), 'Dashboard must use the shared secure transport ownership scope');
check(controller.includes('repairCompanyDepartureInventories'), 'Seat-map page must run safe automatic repair');
check(departure.includes('inventory_in_use_or_partial'), 'Repair must refuse to overwrite partial or booked inventory');
check(departure.includes('listCompanySchedulesForRepair'), 'Automatic repair must include safely linked legacy departures');
check(departure.includes('resolveCompanyScheduleForRepair'), 'Automatic repair must canonicalize ownership before writing inventory');
check(template.includes('seat.displayLabel || seat.seatNumber'), 'Visual map must preserve custom labels');
check(template.includes('No departure exists yet.'), 'Empty state must explain the actual dependency');
check(browser.includes("'seatMaps', 'vehicleSeatTemplates'"), 'Browser bootstrap must always initialize seat-map collections');
check(browser.includes('m.totals?.total'), 'Browser table must support nested total snapshots');
check(template.includes('templatePreviewMaps'), 'Reusable vehicle templates must render an immediate visual preview when no departure exists');
check(template.includes('This is the reusable vehicle-template preview, not a live departure yet.'), 'Template preview must clearly explain the live-departure dependency');
check(template.includes('Turn template into live map'), 'Template-only state must link directly to dated schedule creation');
check(departure.includes('seats: seatMapVersion.seats.map'), 'New departures must preserve an immutable copy of exact seat labels');
check(departure.includes('resolveOwnedSeatMapVersion'), 'Legacy inventory repair must validate seat-map ownership through the vehicle/listing chain');
check(fs.existsSync(path.join(root, 'scripts/repair-bus-departure-seat-maps.js')), 'A safe production repair command must be included for existing departures');

console.log(`Live departure seat-map checks passed: ${passed}/${passed}`);
