// One-time migration: normalizes Company.companyType values that are raw UI display labels
// instead of the slug values every other company record and all app code use (e.g. the login
// form's business-type <select> correctly submits value="bus" for its "Bus company" option, but
// at least 2 legacy company records ended up with the literal label "Bus company" stored instead
// of "bus" - likely from a manual edit or an older, unvalidated entry path). Needed before
// Company.companyType can safely get a clean, closed enum. Safe to re-run - only touches
// documents still holding a known label instead of its slug.
require('dotenv').config();

const LABEL_TO_SLUG = {
  'Bus company': 'bus',
  'Hotel / apartments': 'hotel',
  Airline: 'flight',
  'Train operator': 'train',
  'Tour company': 'tour',
  'Car rental': 'car_rental',
};

async function main() {
  const { connectDb, mongoose } = require('../src/config/db');
  await connectDb();
  if (mongoose.connection.readyState !== 1) throw new Error('MongoDB did not connect');

  const Company = require('../src/models/Company');
  let updated = 0;
  for (const [label, slug] of Object.entries(LABEL_TO_SLUG)) {
    // eslint-disable-next-line no-await-in-loop
    const result = await Company.updateMany({ companyType: label }, { $set: { companyType: slug } });
    if (result.modifiedCount) console.log(`  companyType "${label}" -> "${slug}": ${result.modifiedCount} document(s)`);
    updated += result.modifiedCount;
  }
  console.log(`\nDone. Updated ${updated} companies.`);
  await mongoose.disconnect();
}

main().catch((error) => { console.error('MIGRATION FAILED:', error); process.exit(1); });
