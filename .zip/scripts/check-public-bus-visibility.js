'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { publicCatalogGroup } = require('../src/services/marketplace/catalogGrouping');
const { buildVehicleSeatTemplateProjections } = require('../src/services/dashboard/vehicleSeatTemplateProjection');

const checks = [];
function check(name, fn) {
  fn();
  checks.push(name);
}

check('bus transport domain group maps to public bus section', () => {
  assert.strictEqual(publicCatalogGroup('bus', 'transport'), 'bus');
});
check('hotel remains in hotel section', () => {
  assert.strictEqual(publicCatalogGroup('hotel', 'stays'), 'hotel');
});
check('secondary services map to more', () => {
  assert.strictEqual(publicCatalogGroup('ferry', 'transport'), 'more');
});
check('active seat-map version projects into a vehicle template card', () => {
  const rows = buildVehicleSeatTemplateProjections({
    vehicles: [{ id: 'vehicle-1', name: 'Coach 1', status: 'active', activeSeatMapTemplateId: 'template-1', activeSeatMapVersionId: 'version-2' }],
    templates: [{ id: 'template-1', vehicleId: 'vehicle-1', name: 'Coach 1 map', status: 'active' }],
    versions: [{ id: 'version-2', vehicleId: 'vehicle-1', version: 2, status: 'published', layoutName: '2x2', rows: 1, columns: 2, totalSeats: 2, seats: [{ seatNumber: 'A1', row: 1, column: 1 }, { seatNumber: 'A2', row: 1, column: 2 }] }],
  });
  assert.strictEqual(rows.length, 1);
  assert.strictEqual(rows[0].templateName, 'Coach 1 map');
  assert.strictEqual(rows[0].seatMapVersion, 2);
  assert.deepStrictEqual(rows[0].seats.map((seat) => seat.seatNumber), ['A1', 'A2']);
});
check('legacy ObjectId template and alternate seat arrays remain visible', () => {
  const rows = buildVehicleSeatTemplateProjections({
    vehicles: [{ _id: 'vehicle-object-id', name: 'Legacy Coach', status: 'active', activeSeatMapVersionId: 'version-object-id' }],
    templates: [],
    versions: [{ _id: 'version-object-id', vehicleId: 'vehicle-object-id', version: 3, status: 'published', seatDefinitions: [{ label: 'L1' }, { label: 'L2' }] }],
  });
  assert.strictEqual(rows[0].id, 'vehicle-object-id');
  assert.strictEqual(rows[0].seatMapVersion, 3);
  assert.deepStrictEqual(rows[0].seats.map((seat) => seat.seatNumber), ['L1', 'L2']);
});
check('dashboard view consumes vehicleSeatTemplates, not tabular vehicles', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/views/dashboards/shared/sections/seat-maps.ejs'), 'utf8');
  assert(source.includes('dashboardData?.vehicleSeatTemplates'));
  assert(!source.includes("const vehicleTemplates = (dashboardData?.vehicles || [])"));
});
check('dashboard projection returns vehicleSeatTemplates', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/services/dashboard/dashboardProjectionEngine.js'), 'utf8');
  assert(source.includes('buildVehicleSeatTemplateProjections'));
  assert(source.includes('vehicleSeatTemplates,'));
});
check('public catalog uses service-aware grouping', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/services/marketplace/catalogService.js'), 'utf8');
  assert(source.includes('group: publicCatalogGroup(serviceType, listing.group)'));
  assert(source.includes('isPublicListing(row, data)'));
});
check('direct public listing pages reject drafts', () => {
  const source = fs.readFileSync(path.join(__dirname, '../src/controllers/public/listingController.js'), 'utf8');
  assert(source.includes('!catalogService.isPublicListing(raw, data)'));
});

console.log(`Public bus visibility and seat templates: ${checks.length}/${checks.length} passed`);
