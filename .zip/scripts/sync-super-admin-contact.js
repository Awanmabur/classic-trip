const { connectDb, mongoose } = require('../src/config/db');
const { env } = require('../src/config/env');
const { cleanEmail, cleanPhone, phoneVariants } = require('../src/services/auth/identityContact');
const User = require('../src/models/User');

async function main() {
  await connectDb();
  if (mongoose.connection.readyState !== 1) throw new Error('MongoDB is not connected');

  const email = cleanEmail(env.superAdmin.email);
  const phone = cleanPhone(env.superAdmin.phone);
  if (!email && !phone) throw new Error('Set SUPER_ADMIN_EMAIL or SUPER_ADMIN_PHONE before running this command');

  const admin = await User.findOne({ $or: [{ id: 'user-admin-001' }, { role: 'super_admin' }] });
  if (!admin) throw new Error('No Super Admin account was found. Run the approved bootstrap/seed process first.');

  if (email) {
    const emailOwner = await User.findOne({ email, _id: { $ne: admin._id } }).lean();
    if (emailOwner) throw new Error(`SUPER_ADMIN_EMAIL already belongs to ${emailOwner.id || emailOwner._id}`);
  }
  if (phone) {
    const phoneOwner = await User.findOne({ phone: { $in: phoneVariants(phone) }, _id: { $ne: admin._id } }).lean();
    if (phoneOwner) throw new Error(`SUPER_ADMIN_PHONE already belongs to ${phoneOwner.id || phoneOwner._id}`);
  }

  if (email) admin.email = email;
  if (phone) admin.phone = phone;
  admin.updatedAt = new Date();
  await admin.save();

  console.log(JSON.stringify({
    ok: true,
    database: mongoose.connection.name,
    userId: admin.id,
    email: admin.email,
    phone: admin.phone,
  }, null, 2));
}

main()
  .catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  })
  .finally(async () => {
    if (mongoose.connection.readyState !== 0) await mongoose.disconnect();
  });
