'use strict';

require('dotenv').config();

function argument(name) {
  const prefix = `--${name}=`;
  const item = process.argv.find((value) => value.startsWith(prefix));
  return item ? item.slice(prefix.length).trim() : '';
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

function normalize(value) {
  return String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_');
}

async function main() {
  const { connectDb, mongoose } = require('../src/config/db');
  const repositories = require('../src/repositories');
  const busSetupService = require('../src/modules/bus/services/busSetupService');
  const { entityId, canonicalServiceType, hasPublishedDeparture } = require('../src/services/marketplace/catalogVisibility');

  await connectDb();
  if (mongoose.connection.readyState !== 1) throw new Error('MongoDB connection is required');

  const requestedCompanyId = argument('company');
  const repairAll = hasFlag('all');
  if (!requestedCompanyId && !repairAll) {
    throw new Error('Use --company=<company-id> for one company or --all for all bus companies');
  }

  const [allListings, schedules, vehicles] = await Promise.all([
    repositories.listings.list(requestedCompanyId ? { companyId: requestedCompanyId } : {}, { limit: 30000 }),
    repositories.schedules.list(requestedCompanyId ? { companyId: requestedCompanyId } : {}, { limit: 60000 }),
    repositories.vehicles.list(requestedCompanyId ? { companyId: requestedCompanyId } : {}, { limit: 30000 }),
  ]);
  const context = { schedules, vehicles };
  const listings = allListings.filter((listing) => canonicalServiceType(listing, context) === 'bus');
  const report = [];

  for (const listing of listings) {
    const originalId = entityId(listing);
    const companyId = String(listing.companyId || '').trim();
    if (!companyId) {
      report.push({ listingId: originalId, title: listing.title, changed: false, published: false, error: 'missing_company_id' });
      continue;
    }

    const normalizedFields = {};
    if (!listing.id && originalId) normalizedFields.id = originalId;
    if (normalize(listing.serviceType) !== 'bus') normalizedFields.serviceType = 'bus';
    if (normalize(listing.group) !== 'transport') normalizedFields.group = 'transport';
    if (listing.type !== 'Bus') normalizedFields.type = 'Bus';
    if (!listing.listingKind) normalizedFields.listingKind = 'operator_service';
    if (!listing.slug && originalId) normalizedFields.slug = originalId;
    let changed = Object.keys(normalizedFields).length > 0;
    if (changed) {
      normalizedFields.updatedAt = new Date().toISOString();
      // Repository reads normalize Mongo `_id` into `id`, but an older document may
      // not yet have a persisted `id` field. Update the original document in place
      // instead of using an upsert-by-id that could create a duplicate.
      const persistedById = await repositories.listings.findOne({ id: originalId });
      const result = await repositories.listings.updateOne(
        persistedById ? { id: originalId } : { _id: originalId },
        { $set: normalizedFields },
      );
      if (!result || Number(result.matchedCount || 0) !== 1) {
        throw new Error(`Could not normalize original bus listing ${originalId}`);
      }
      Object.assign(listing, normalizedFields);
    }

    if (['archived', 'deleted'].includes(normalize(listing.status))) {
      report.push({ listingId: listing.id, title: listing.title, changed, published: false, reason: 'archived' });
      continue;
    }

    const departurePublished = hasPublishedDeparture(listing, context);
    const publicationRequested = departurePublished
      || ['active', 'published', 'live'].includes(normalize(listing.status))
      || ['published', 'live'].includes(normalize(listing.releaseStatus))
      || Boolean(listing.publishedAt);

    if (!publicationRequested) {
      report.push({ listingId: listing.id, title: listing.title, changed, published: false, reason: 'still_draft' });
      continue;
    }

    try {
      const readiness = await busSetupService.listingReadiness(companyId, listing.id);
      if (!readiness.publicReady) {
        listing.publication = { readiness: 'incomplete', bookingReadiness: 'incomplete', lastCheckedAt: readiness.checkedAt, failures: readiness.failures, bookingFailures: readiness.bookingFailures, counts: readiness.counts };
        listing.updatedAt = new Date().toISOString();
        await repositories.listings.save(listing, { id: listing.id });
        report.push({ listingId: listing.id, title: listing.title, changed: true, published: false, reason: 'not_ready', failures: readiness.failures });
        continue;
      }
      const published = await busSetupService.publishBusListing(companyId, listing.id, 'public-bus-listing-repair');
      report.push({
        listingId: published.id,
        title: published.title,
        changed: true,
        published: true,
        bookable: Boolean(published.bookable),
        bookingFailures: readiness.bookingFailures,
        reason: departurePublished ? 'published_departure_found' : 'publication_state_repaired',
      });
    } catch (error) {
      report.push({ listingId: listing.id, title: listing.title, changed, published: false, error: error.message || String(error) });
    }
  }

  const totals = {
    scanned: report.length,
    changed: report.filter((row) => row.changed).length,
    published: report.filter((row) => row.published).length,
    incomplete: report.filter((row) => row.reason === 'not_ready').length,
    failed: report.filter((row) => row.error).length,
  };
  console.log(JSON.stringify({ ok: totals.failed === 0, totals, report }, null, 2));
  await mongoose.disconnect();
  if (totals.failed) process.exitCode = 1;
}

main().catch(async (error) => {
  console.error(`FAILED: ${error.message}`);
  try {
    const { mongoose } = require('../src/config/db');
    if (mongoose.connection.readyState !== 0) await mongoose.disconnect();
  } catch (_) { /* no-op */ }
  process.exitCode = 1;
});
