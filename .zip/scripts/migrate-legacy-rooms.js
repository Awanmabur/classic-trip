/* eslint-disable no-console */
const crypto = require('crypto');
const { connectDb, mongoose } = require('../src/config/db');
const RoomType = require('../src/models/RoomType');
const RoomUnit = require('../src/models/RoomUnit');
const InventoryHold = require('../src/models/InventoryHold');
const InventoryHoldItem = require('../src/models/InventoryHoldItem');
const inventoryHoldService = require('../src/services/booking/inventoryHoldService');

const APPLY = process.argv.includes('--apply');
const ARCHIVE = process.argv.includes('--archive-legacy');
function clean(value) { return String(value || '').trim(); }
function number(value, fallback = 0) { const parsed = Number(value); return Number.isFinite(parsed) ? parsed : fallback; }
function digest(value) { return crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, 20); }
function roomTypeId(room) { return `room-type-legacy-${digest(room.id || room._id)}`; }
function roomUnitId(room, index) { return `room-unit-legacy-${digest(`${room.id || room._id}:${index}`)}`; }
function itemId(holdId, key) { return `hold-item-${digest(`${holdId}:${key}`)}`; }
function dateOnly(value) { const parsed = new Date(value); return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString().slice(0, 10); }
function dateRange(startValue, endValue) {
  const start = dateOnly(startValue); const end = dateOnly(endValue);
  if (!start || !end || end <= start) return [];
  const rows = [];
  for (const cursor = new Date(`${start}T00:00:00Z`), limit = new Date(`${end}T00:00:00Z`); cursor < limit; cursor.setUTCDate(cursor.getUTCDate() + 1)) rows.push(cursor.toISOString().slice(0, 10));
  return rows;
}
function split(value) { return Array.isArray(value) ? value.map(clean).filter(Boolean) : clean(value).split(',').map(clean).filter(Boolean); }

async function migrateRoom(room, summary) {
  const oldId = clean(room.id || room._id);
  if (!oldId || !clean(room.companyId) || !clean(room.listingId)) { summary.skippedInvalid += 1; return null; }
  const type = {
    id: roomTypeId(room), companyId: clean(room.companyId), listingId: clean(room.listingId), propertyId: clean(room.propertyId),
    name: clean(room.roomType || room.name || room.title || `Legacy room ${oldId}`), capacity: Math.max(1, number(room.capacity, 1)),
    basePrice: Math.max(0, number(room.nightlyPrice ?? room.basePrice ?? room.price, 0)), amenities: split(room.amenities),
    policies: split(room.policies), status: clean(room.status).toLowerCase() === 'archived' ? 'archived' : 'active',
    createdBy: 'legacy-room-migration', updatedBy: 'legacy-room-migration',
  };
  const count = Math.max(1, Math.min(1000, Math.floor(number(room.inventory ?? room.quantity ?? room.available, 1))));
  const units = Array.from({ length: count }, (_, index) => ({
    id: roomUnitId(room, index + 1), companyId: type.companyId, listingId: type.listingId, propertyId: type.propertyId,
    roomTypeId: type.id, unitNumber: clean(room.unitNumber || room.number) ? `${clean(room.unitNumber || room.number)}-${index + 1}` : `LEGACY-${digest(oldId).slice(0, 6).toUpperCase()}-${index + 1}`,
    status: type.status === 'archived' ? 'archived' : 'available', housekeepingStatus: 'ready', createdBy: 'legacy-room-migration', updatedBy: 'legacy-room-migration',
  }));
  if (APPLY) {
    await RoomType.updateOne({ id: type.id }, { $set: type }, { upsert: true, runValidators: true });
    for (const unit of units) await RoomUnit.updateOne({ id: unit.id }, { $set: unit }, { upsert: true, runValidators: true });
  }
  summary.roomTypes += 1; summary.roomUnits += units.length;
  return { oldId, type, units };
}

async function migrateBookings(mapping, summary) {
  const bookings = mongoose.connection.collection('bookings');
  for (const [oldId, target] of mapping) {
    const cursor = bookings.find({ $or: [{ roomId: oldId }, { 'bookingItems.roomId': oldId }, { 'hotelStay.roomId': oldId }] });
    for await (const booking of cursor) {
      const items = Array.isArray(booking.bookingItems) ? booking.bookingItems.map((item) => clean(item.roomId) === oldId ? { ...item, roomTypeId: target.type.id, roomType: target.type.name, roomId: undefined } : item) : [];
      const set = { bookingItems: items, 'hotelStay.roomTypeIds': [target.type.id] };
      if (APPLY) await bookings.updateOne({ _id: booking._id }, { $set: set, $unset: { roomId: '', 'hotelStay.roomId': '' } });
      summary.bookings += 1;
    }
  }
}

async function migrateHolds(mapping, summary) {
  const holds = mongoose.connection.collection('inventoryholds');
  const rows = await holds.find({ holdType: 'room', roomId: { $exists: true, $nin: ['', null] } }).toArray();
  for (const hold of rows) {
    const target = mapping.get(clean(hold.roomId));
    const nights = dateRange(hold.startDate || hold.meta?.checkIn, hold.endDate || hold.meta?.checkOut);
    if (!target || !nights.length || !target.units.length) {
      if (APPLY) await holds.updateOne({ _id: hold._id }, { $set: { status: 'released', releasedAt: new Date(), releaseReason: 'legacy_room_hold_unmappable' }, $unset: { roomId: '' } });
      summary.releasedHolds += 1; continue;
    }
    const unit = target.units[Math.abs(number(hold.meta?.allocationSlot, 1) - 1) % target.units.length];
    const items = nights.map((nightDate) => {
      const resourceKey = inventoryHoldService.roomNightResourceKey(unit.id, nightDate);
      return { id: itemId(hold.id, resourceKey), holdId: hold.id, resourceType: 'room_unit_night', resourceKey, serviceType: 'hotel', companyId: hold.companyId || target.type.companyId, listingId: hold.listingId || target.type.listingId, roomTypeId: target.type.id, roomUnitId: unit.id, nightDate, selectedLabel: hold.selectedLabel || target.type.name, status: hold.status || 'active', expiresAt: hold.expiresAt || hold.lockedUntil || new Date(), metadata: { ...(hold.meta || {}), migratedFromLegacyRoom: clean(hold.roomId) } };
    });
    if (APPLY) {
      for (const item of items) await InventoryHoldItem.updateOne({ id: item.id }, { $setOnInsert: item }, { upsert: true, runValidators: true });
      await InventoryHold.updateOne({ id: hold.id }, { $set: { roomTypeId: target.type.id, roomUnitIds: [unit.id], startDate: nights[0], endDate: dateOnly(new Date(new Date(`${nights[nights.length - 1]}T00:00:00Z`).getTime() + 86400000)), itemIds: items.map((item) => item.id), itemCount: items.length }, $unset: { roomId: '' } });
    }
    summary.holds += 1;
  }
}

async function run() {
  await connectDb();
  const names = await mongoose.connection.db.listCollections({ name: 'rooms' }).toArray();
  if (!names.length) { console.log(JSON.stringify({ mode: APPLY ? 'apply' : 'dry-run', message: 'No legacy rooms collection exists' }, null, 2)); return; }
  const legacy = mongoose.connection.collection('rooms');
  const rows = await legacy.find({}).toArray();
  const summary = { mode: APPLY ? 'apply' : 'dry-run', legacyRooms: rows.length, roomTypes: 0, roomUnits: 0, bookings: 0, holds: 0, releasedHolds: 0, skippedInvalid: 0, archivedCollection: '' };
  const mapping = new Map();
  for (const room of rows) { const target = await migrateRoom(room, summary); if (target) mapping.set(target.oldId, target); }
  await migrateBookings(mapping, summary);
  await migrateHolds(mapping, summary);
  if (APPLY) { await RoomType.syncIndexes(); await RoomUnit.syncIndexes(); await InventoryHoldItem.syncIndexes(); }
  if (APPLY && ARCHIVE && rows.length) {
    const name = `rooms_legacy_${new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14)}`;
    await legacy.rename(name); summary.archivedCollection = name;
  }
  console.log(JSON.stringify(summary, null, 2));
  if (!APPLY) console.log('Dry run only. Re-run with --apply after reviewing counts; add --archive-legacy to rename the old collection after migration.');
}

run().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => mongoose.disconnect());
