require('dotenv').config();

async function main() {
  const { connectDb, mongoose } = require('../src/config/db');
  await connectDb();
  const Agreement = require('../src/models/Agreement');

  const bad = await Agreement.find({ status: 'signed' }, { id: 1, agreementType: 1 }).lean();
  console.log(`Found ${bad.length} agreement(s) with legacy status 'signed'.`);
  for (const row of bad) {
    console.log(`Fixing ${row.id}: signed -> approved`);
  }
  const result = await Agreement.updateMany({ status: 'signed' }, { $set: { status: 'approved' } });
  console.log('Modified:', result.modifiedCount);

  await mongoose.disconnect();
}

main().catch((error) => { console.error('FAILED:', error); process.exit(1); });
