require('dotenv').config();

async function main() {
  const { connectDb, mongoose } = require('../src/config/db');
  await connectDb();
  const Invitation = require('../src/models/Invitation');

  const bad = await Invitation.find({ status: 'pending' }).lean();
  console.log(`Found ${bad.length} invitation(s) with legacy status 'pending'.`);
  for (const row of bad) {
    console.log(`Fixing ${row.id} (${row.email}): pending -> sent`);
  }
  const result = await Invitation.updateMany({ status: 'pending' }, { $set: { status: 'sent' } });
  console.log('Modified:', result.modifiedCount);

  await mongoose.disconnect();
}

main().catch((error) => { console.error('FAILED:', error); process.exit(1); });
