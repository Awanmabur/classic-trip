/* eslint-disable no-console */
const crypto = require('crypto');
const { connectDb, mongoose } = require('../src/config/db');
const InventoryHold = require('../src/models/InventoryHold');
const InventoryHoldItem = require('../src/models/InventoryHoldItem');
const inventoryHoldService = require('../src/services/booking/inventoryHoldService');

function itemId(holdId, resourceKey) {
  return `hold-item-${crypto.createHash('sha256').update(`${holdId}:${resourceKey}`).digest('hex').slice(0, 24)}`;
}
function unique(values) { return [...new Set([].concat(values || []).map((value) => String(value || '').trim()).filter(Boolean))]; }
function dateOnly(value) {
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? '' : parsed.toISOString().slice(0, 10);
}
function dateRange(startValue, endValue) {
  const start = dateOnly(startValue);
  const end = dateOnly(endValue);
  if (!start || !end || end <= start) return [];
  const rows = [];
  for (const cursor = new Date(`${start}T00:00:00Z`), limit = new Date(`${end}T00:00:00Z`); cursor < limit; cursor.setUTCDate(cursor.getUTCDate() + 1)) rows.push(cursor.toISOString().slice(0, 10));
  return rows;
}
function common(hold) {
  return {
    holdId: hold.id, serviceType: hold.serviceType, companyId: hold.companyId || '', listingId: hold.listingId || '',
    status: hold.status || 'active', expiresAt: hold.expiresAt || hold.lockedUntil || hold.createdAt || new Date(),
    consumedAt: hold.consumedAt, consumedBy: hold.consumedBy || '', bookingId: hold.bookingId || '', bookingRef: hold.bookingRef || '',
    releasedAt: hold.releasedAt, releaseReason: hold.releaseReason || '', createdAt: hold.createdAt || new Date(), updatedAt: hold.updatedAt || new Date(),
  };
}
function seatItems(hold) {
  const seats = unique(hold.meta?.seatNumbers || hold.seatNumber);
  return seats.map((seatNumber) => {
    const resourceKey = inventoryHoldService.seatResourceKey(hold.scheduleId, seatNumber);
    return { ...common(hold), id: itemId(hold.id, resourceKey), resourceType: 'schedule_seat', resourceKey, scheduleId: hold.scheduleId, seatNumber, selectedLabel: seatNumber, metadata: hold.meta || {} };
  });
}
function roomItems(hold) {
  const unitIds = unique(hold.roomUnitIds || hold.meta?.roomUnitId);
  const nights = unique(hold.meta?.nightDates).map(dateOnly).filter(Boolean);
  const stayNights = nights.length ? nights : dateRange(hold.startDate || hold.meta?.checkIn, hold.endDate || hold.meta?.checkOut);
  if (!unitIds.length || !stayNights.length) return [];
  return unitIds.flatMap((roomUnitId) => stayNights.map((nightDate) => {
    const resourceKey = inventoryHoldService.roomNightResourceKey(roomUnitId, nightDate);
    return {
      ...common(hold), id: itemId(hold.id, resourceKey), resourceType: 'room_unit_night', resourceKey,
      roomTypeId: hold.roomTypeId || hold.meta?.roomTypeId || '', roomUnitId, nightDate,
      selectedLabel: hold.selectedLabel || '', metadata: { ...(hold.meta || {}), roomUnitId, nightDate },
    };
  }));
}

async function dropObsoleteIndexes() {
  for (const name of ['scheduleId_1_seatNumber_1_holdType_1_status_1', 'roomId_1_holdType_1_status_1']) {
    try { await InventoryHold.collection.dropIndex(name); console.log(`Dropped obsolete index: ${name}`); }
    catch (error) { if (error.codeName !== 'IndexNotFound' && error.code !== 27) throw error; }
  }
}

async function run() {
  await connectDb();
  await dropObsoleteIndexes();
  const holds = await InventoryHold.find({ itemCount: { $in: [0, null] } }).sort({ createdAt: 1 }).lean();
  const summary = { scanned: holds.length, migrated: 0, releasedUnmappable: 0, conflicts: 0 };
  for (const hold of holds) {
    const items = hold.holdType === 'seat' ? seatItems(hold) : roomItems(hold);
    if (!items.length) {
      await InventoryHold.updateOne({ id: hold.id, status: 'active' }, { $set: { status: 'released', releasedAt: new Date(), releaseReason: 'canonical_hold_items_unmappable' } });
      summary.releasedUnmappable += 1;
      continue;
    }
    try {
      await InventoryHoldItem.insertMany(items, { ordered: true });
      await InventoryHold.updateOne({ id: hold.id }, { $set: { itemIds: items.map((item) => item.id), itemCount: items.length } });
      summary.migrated += 1;
    } catch (error) {
      if (error.code !== 11000) throw error;
      await InventoryHold.updateOne({ id: hold.id }, { $set: { status: 'released', releasedAt: new Date(), releaseReason: 'migration_resource_conflict' } });
      summary.conflicts += 1;
    }
  }
  await InventoryHoldItem.syncIndexes();
  console.log(JSON.stringify(summary, null, 2));
}

run().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => mongoose.disconnect());
