'use strict';

require('dotenv').config();
const { connectDb, mongoose } = require('../src/config/db');

const apply = process.argv.includes('--apply');

const STATUS_REPLACEMENTS = Object.freeze({
  'checked-in': 'checked_in',
  'checked-out': 'checked_out',
  'no-show': 'no_show',
});

async function previewOrUpdate(collection, filter, update, label) {
  const count = await collection.countDocuments(filter);
  console.log(`${label}: ${count} record(s)${apply ? ' updated' : ' would be updated'}`);
  if (apply && count) await collection.updateMany(filter, update);
  return count;
}

async function run() {
  await connectDb();
  const db = mongoose.connection.db;
  const totals = {};

  for (const [legacy, canonical] of Object.entries(STATUS_REPLACEMENTS)) {
    totals[`bookings.bookingStatus.${legacy}`] = await previewOrUpdate(
      db.collection('bookings'),
      { bookingStatus: legacy },
      { $set: { bookingStatus: canonical, updatedAt: new Date() } },
      `bookings.bookingStatus ${legacy} -> ${canonical}`,
    );
    totals[`bookings.hotelStay.status.${legacy}`] = await previewOrUpdate(
      db.collection('bookings'),
      { 'hotelStay.status': legacy },
      { $set: { 'hotelStay.status': canonical, updatedAt: new Date() } },
      `bookings.hotelStay.status ${legacy} -> ${canonical}`,
    );
    totals[`campaignconversions.status.${legacy}`] = await previewOrUpdate(
      db.collection('campaignconversions'),
      { status: legacy },
      { $set: { status: canonical, updatedAt: new Date() } },
      `campaignconversions.status ${legacy} -> ${canonical}`,
    );
    totals[`roomnightinventories.status.${legacy}`] = await previewOrUpdate(
      db.collection('roomnightinventories'),
      { status: legacy },
      { $set: { status: canonical, updatedAt: new Date() } },
      `roomnightinventories.status ${legacy} -> ${canonical}`,
    );
    totals[`roomnightinventories.checkInStatus.${legacy}`] = await previewOrUpdate(
      db.collection('roomnightinventories'),
      { checkInStatus: legacy },
      { $set: { checkInStatus: canonical, updatedAt: new Date() } },
      `roomnightinventories.checkInStatus ${legacy} -> ${canonical}`,
    );
    totals[`seats.status.${legacy}`] = await previewOrUpdate(
      db.collection('seats'),
      { status: legacy },
      { $set: { status: canonical, updatedAt: new Date() } },
      `seats.status ${legacy} -> ${canonical}`,
    );
  }

  console.log(JSON.stringify({ mode: apply ? 'apply' : 'dry-run', totals }, null, 2));
}

run()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect().catch(() => {});
  });
