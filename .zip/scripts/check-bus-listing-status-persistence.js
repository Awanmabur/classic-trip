'use strict';

const assert = require('assert');
const path = require('path');
const fs = require('fs');

const repositoryPath = path.resolve(__dirname, '../src/modules/bus/repositories/busRepository.js');
const servicePath = path.resolve(__dirname, '../src/modules/bus/services/busSetupService.js');

function validListing(overrides = {}) {
  return {
    id: 'listing-1',
    companyId: 'company-1',
    serviceType: 'bus',
    group: 'transport',
    type: 'Bus',
    title: 'Kampala Express',
    slug: 'kampala-express',
    media: [{ url: '/bus.jpg' }],
    contactPhone: '+256700000000',
    operatorLicenceRef: 'OP-001',
    baggageRules: 'One checked bag.',
    cancellationRules: 'Refund before departure.',
    status: 'draft',
    releaseStatus: 'draft',
    bookable: false,
    ...overrides,
  };
}

let currentListing = validListing();
let schedules = [];
const writes = [];
const events = [];
const audits = [];
const future = new Date(Date.now() + 86400000 * 90).toISOString();

const mockRepository = {
  listingOrThrow: async () => currentListing,
  companyOrThrow: async () => ({ id: 'company-1', status: 'active', verificationStatus: 'verified' }),
  branches: { findOne: async () => null },
  listings: {
    findOne: async () => null,
    save: async (row) => {
      currentListing = JSON.parse(JSON.stringify(row));
      writes.push(JSON.parse(JSON.stringify(row)));
      return row;
    },
  },
  routes: { list: async () => [{ id: 'route-1', listingId: 'listing-1', status: 'active' }] },
  vehicles: { list: async () => [{ id: 'vehicle-1', listingId: 'listing-1', serviceType: 'bus', status: 'active', operatorPermitRef: 'PERMIT', inspectionRef: 'INSPECT', insuranceRef: 'INSURE', operatorPermitExpiresAt: future, inspectionExpiresAt: future, insuranceExpiresAt: future }] },
  fareProducts: { list: async () => [{ id: 'fare-1', listingId: 'listing-1', routeId: 'route-1', status: 'active' }] },
  schedules: { list: async () => schedules },
  withTransaction: async (work) => work(null),
  outbox: async (event) => { events.push(event); return event; },
  audit: async (event) => { audits.push(event); return event; },
};

require.cache[repositoryPath] = { id: repositoryPath, filename: repositoryPath, loaded: true, exports: mockRepository };
delete require.cache[servicePath];
const service = require(servicePath);

let passed = 0;
function check(name, test) {
  test();
  passed += 1;
  console.log(`PASS ${name}`);
}

(async () => {
  // Public listing activation must not require a departure.
  schedules = [];
  currentListing = validListing();
  const publicOnly = await service.updateBusListing('company-1', 'listing-1', { status: 'active' }, 'user-1');
  check('active status is persisted without a departure', () => assert.strictEqual(publicOnly.status, 'active'));
  check('public-only activation publishes release state', () => assert.strictEqual(publicOnly.releaseStatus, 'published'));
  check('public-only activation remains non-bookable', () => assert.strictEqual(publicOnly.bookable, false));
  check('public-only activation records public readiness', () => assert.strictEqual(publicOnly.publication.readiness, 'public'));
  check('public-only activation explains booking requirement', () => assert.match(publicOnly.publication.bookingFailures.join(' '), /future dated departure/i));
  check('public-only activation reaches repository write', () => assert.strictEqual(writes.at(-1).status, 'active'));
  check('public-only activation emits publication event', () => assert.strictEqual(events.length, 1));

  // A published departure upgrades the same public listing to bookable.
  schedules = [{ id: 'schedule-1', listingId: 'listing-1', routeId: 'route-1', vehicleId: 'vehicle-1', status: 'published', departAt: future }];
  const bookable = await service.updateBusListing('company-1', 'listing-1', { status: 'active' }, 'user-1');
  check('published departure makes listing bookable', () => assert.strictEqual(bookable.bookable, true));
  check('published departure records bookable readiness', () => assert.strictEqual(bookable.publication.readiness, 'bookable'));
  check('published departure clears booking failures', () => assert.deepStrictEqual(bookable.publication.bookingFailures, []));

  schedules = [{ id: 'past-schedule', listingId: 'listing-1', routeId: 'route-1', vehicleId: 'vehicle-1', status: 'published', departAt: new Date(Date.now() - 86400000).toISOString() }];
  const pastReadiness = await service.listingReadiness('company-1', 'listing-1');
  check('past departure does not keep bookings open', () => assert.strictEqual(pastReadiness.bookingReady, false));
  check('past departure leaves public profile readiness intact', () => assert.strictEqual(pastReadiness.publicReady, true));

  const paused = await service.updateBusListing('company-1', 'listing-1', { status: 'paused' }, 'user-1');
  check('paused status is persisted', () => assert.strictEqual(paused.status, 'paused'));
  check('paused release state is synchronized', () => assert.strictEqual(paused.releaseStatus, 'paused'));
  check('paused listing is not bookable', () => assert.strictEqual(paused.bookable, false));

  schedules = [{ id: 'legacy-schedule', routeId: 'route-1', vehicleId: 'vehicle-1', status: 'published', departAt: future }];
  const legacyReadiness = await service.listingReadiness('company-1', 'listing-1');
  check('legacy route-linked departure satisfies booking readiness securely', () => assert.strictEqual(legacyReadiness.bookingReady, true));
  check('legacy inferred departure is reported', () => assert.strictEqual(legacyReadiness.counts.inferredLegacyDepartures, 1));

  // Missing public-profile content still blocks visibility and stays atomic.
  currentListing = validListing({ media: [] });
  schedules = [];
  const beforeFailure = JSON.parse(JSON.stringify(currentListing));
  let activationError = null;
  try {
    await service.updateBusListing('company-1', 'listing-1', { status: 'active', title: 'Changed but invalid' }, 'user-1');
  } catch (error) {
    activationError = error;
  }
  check('incomplete public activation returns validation error', () => assert.strictEqual(activationError?.status, 422));
  check('incomplete public activation names missing image', () => assert.match(activationError?.message || '', /Upload at least one bus service image/i));
  check('missing departure is not a public activation error', () => assert.doesNotMatch(activationError?.message || '', /dated departure/i));
  check('failed public activation does not persist partial edits', () => assert.deepStrictEqual(currentListing, beforeFailure));
  check('status changes are audited', () => assert.ok(audits.some((row) => row.action === 'bus.listing.published') && audits.some((row) => row.action === 'bus.listing.updated')));

  const domain = require('../src/modules/bus/domain/busDomain');
  check('invalid bus status is rejected', () => assert.throws(() => domain.canonicalBusListingStatus('live-now'), /Invalid bus listing status/));
  check('draft state synchronizes all visibility fields', () => {
    const row = domain.applyBusListingPrivateStatus({ status: 'active', releaseStatus: 'published', bookable: true }, 'draft', { at: '2026-07-22T00:00:00.000Z' });
    assert.deepStrictEqual([row.status, row.releaseStatus, row.bookable], ['draft', 'draft', false]);
  });
  check('published public profile can remain non-bookable', () => {
    const row = domain.applyBusListingPublishedStatus({}, { publicReady: true, bookingReady: false, bookingFailures: ['Publish departure'] }, { at: '2026-07-22T00:00:00.000Z' });
    assert.deepStrictEqual([row.status, row.releaseStatus, row.bookable, row.publication.readiness], ['active', 'published', false, 'public']);
  });

  const setupSource = fs.readFileSync(servicePath, 'utf8');
  const controllerSource = fs.readFileSync(path.resolve(__dirname, '../src/controllers/company/listingController.js'), 'utf8');
  const dispatchSource = fs.readFileSync(path.resolve(__dirname, '../src/services/company/companyService.js'), 'utf8');
  const projectionSource = fs.readFileSync(path.resolve(__dirname, '../src/services/dashboard/dashboardProjectionEngine.js'), 'utf8');
  const workspaceSource = fs.readFileSync(path.resolve(__dirname, '../public/js/dashboard-workspace.js'), 'utf8');
  check('bus update explicitly reads submitted status', () => assert.match(setupSource, /hasOwnProperty\.call\(payload, 'status'\)/));
  check('activation uses candidate readiness before persistence', () => assert.match(setupSource, /listingReadiness\(companyId, listing\.id, listing\)/));
  check('public and booking readiness are separated', () => assert.match(setupSource, /const bookingFailures = \[\]/));
  check('dashboard explains public-only activation', () => assert.match(controllerSource, /Publish a future dated departure to enable Book now/));
  check('dashboard shows exact public activation failure', () => assert.match(controllerSource, /req\.flash\('error', error\.message\)/));
  check('legacy listing identifiers dispatch through bus service', () => assert.match(dispatchSource, /identities = \[\{ id: key \}, \{ slug: key \}\]/));
  check('dashboard edit actions support Mongo _id records', () => assert.match(projectionSource, /row\.id \?\? row\._id/));
  check('dashboard distinguishes public from bookable', () => assert.match(projectionSource, /Public · schedule pending/));
  check('listing editor explains visibility and booking separately', () => assert.match(workspaceSource, /Active publishes the bus service profile immediately/));
  check('non-bookable bus listing has a departure shortcut', () => assert.match(workspaceSource, /Create and publish a dated departure to enable bookings/));

  console.log(`Bus listing status persistence checks passed: ${passed}/${passed}`);
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
