const fs = require('fs');
const assert = require('assert');
const path = require('path');
const { cleanEmail, cleanPhone, phoneVariants, identityLookup } = require('../src/services/auth/identityContact');
const { duplicateKeyFields, isDuplicateKey } = require('../src/utils/mongoDuplicate');

let passed = 0;
function check(name, fn) {
  fn();
  passed += 1;
  console.log(`PASS ${name}`);
}
function source(file) { return fs.readFileSync(path.join(__dirname, '..', file), 'utf8'); }

check('email normalization preserves plus aliases', () => assert.equal(cleanEmail(' Simon+Partner@Example.COM '), 'simon+partner@example.com'));
check('international phone formatting is canonical', () => assert.equal(cleanPhone('00 256 700 123 456'), '+256700123456'));
check('local phone formatting remains stable', () => assert.equal(cleanPhone('0700 123 456'), '0700123456'));
check('phone variants match plus, 00, and digits forms', () => {
  const variants = phoneVariants('+256 700 123 456');
  assert(variants.includes('+256700123456'));
  assert(variants.includes('00256700123456'));
  assert(variants.includes('256700123456'));
});
check('login identity distinguishes email and phone', () => {
  assert.equal(identityLookup('A@B.COM').email, 'a@b.com');
  assert(identityLookup('+256700123456').phones.includes('+256700123456'));
});
check('MFA is controlled by an explicit environment flag', () => {
  const envSource = source('src/config/env.js');
  assert(/platformMfaEnabled:\s*booleanFlag\('PLATFORM_MFA_ENABLED', false\)/.test(envSource));
  assert(/if \(!env\.platformMfaEnabled\) return next\(\)/.test(source('src/middlewares/mfa.js')));
});
check('login and redirect skip MFA when disabled', () => {
  const controller = source('src/controllers/auth/authController.js');
  const auth = source('src/services/auth/authService.js');
  assert(/env\.platformMfaEnabled && mfaService\.isPlatformAdmin/.test(controller));
  assert(/env\.platformMfaEnabled && mfaService\.isPlatformAdmin/.test(auth));
});
check('registration checks email and phone separately', () => {
  const auth = source('src/services/auth/authService.js');
  assert(/findRegistrationConflict/.test(auth));
  assert(/conflictFields/.test(auth));
  assert(!/\$or: \[\.\.\.\(email/.test(auth));
});
check('web registration handles account conflicts without raw JSON', () => {
  const controller = source('src/controllers/auth/authController.js');
  assert(/account_exists/.test(controller));
  assert(/registration_conflict/.test(controller));
  assert(/#\$\{panel\}/.test(controller));
});
check('email validator does not collapse Gmail dots or plus aliases', () => {
  const validator = source('src/validators/authValidator.js');
  assert(!/normalizeEmail\(/.test(validator));
  assert(/customSanitizer/.test(validator));
});
check('signup buttons are disabled after valid submission', () => {
  const view = source('src/views/pages/auth/login.ejs');
  assert(/submitButton\.disabled = true/.test(view));
});


check('Mongo duplicate-key fields are classified instead of all becoming email conflicts', () => {
  const error = { code: 11000, keyPattern: { slug: 1 }, keyValue: { slug: 'coach' } };
  assert.deepEqual(duplicateKeyFields(error), ['slug']);
  assert(isDuplicateKey(error, 'slug'));
  assert(!isDuplicateKey(error, 'email'));
});
check('new user and company creation are insert-only', () => {
  const auth = source('src/services/auth/authService.js');
  const company = source('src/services/company/companyService.js');
  assert(/identityRepository\.users\.insert\(user\)/.test(auth));
  assert(/companyRepository\.companies\.insert\(company\)/.test(company));
});
check('partner provisioning duplicate keys are not mislabeled as email conflicts', () => {
  const auth = source('src/services/auth/authService.js');
  assert(/non-identity duplicate key/.test(auth));
  assert(/registration_conflict/.test(auth));
  assert(!/if \(error\?\.code === 11000\).*email address already belongs/s.test(auth));
});
check('stale user and company counters are retried safely', () => {
  const auth = source('src/services/auth/authService.js');
  const company = source('src/services/company/companyService.js');
  assert(/User identifier collision detected/.test(auth));
  assert(/fields\.includes\('id'\)/.test(auth));
  assert(/fields\.includes\('id'\) \|\| fields\.includes\('slug'\)/.test(company));
});
check('MFA setup and challenge endpoints are unavailable while disabled', () => {
  const controller = source('src/controllers/auth/authController.js');
  assert((controller.match(/if \(!env\.platformMfaEnabled\)/g) || []).length >= 4);
  assert(/Administrator MFA is temporarily disabled by platform configuration/.test(controller));
});


check('first wallet creation does not update the same balance path twice', () => {
  const finance = source('src/repositories/domain/financeRepository.js');
  const setOnInsertBlock = finance.match(/\$setOnInsert:\s*\{([\s\S]*?)\n\s*\},\n\s*\$inc:/)?.[1] || '';
  assert(!/availableBalance\s*:/.test(setOnInsertBlock));
  assert(!/pendingBalance\s*:/.test(setOnInsertBlock));
  assert(/\$inc:\s*increments/.test(finance));
  assert(/setDefaultsOnInsert:\s*false/.test(finance));
});
check('wallet provisioning recovers from compound-identity and stale-id races', () => {
  const finance = source('src/repositories/domain/financeRepository.js');
  assert(/walletIdentityRace/.test(finance));
  assert(/identifierCollision/.test(finance));
  assert(/crypto\.randomUUID\(\)/.test(finance));
  assert(/attempt <= 5/.test(finance));
});
check('MongoDB database name is explicit and default test database is warned about', () => {
  const envSource = source('src/config/env.js');
  const dbSource = source('src/config/db.js');
  const example = source('.env.example');
  assert(/mongoDbName:\s*configuredValue\('MONGO_DB_NAME'\)/.test(envSource));
  assert(/dbName:\s*env\.mongoDbName/.test(dbSource));
  assert(/default database name test/.test(dbSource));
  assert(/MONGO_DB_NAME=classic-trip/.test(example));
});

console.log(`Auth hotfix verification passed: ${passed}/${passed}`);
