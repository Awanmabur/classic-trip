'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {
  entityId,
  sameId,
  canonicalServiceType,
  isPublicListing,
  relatedSchedulesForListing,
} = require('../src/services/marketplace/catalogVisibility');

let passed = 0;
function check(name, work) {
  work();
  passed += 1;
  console.log(`PASS ${passed}: ${name}`);
}

const publishedSchedule = { _id: 'schedule-object-id', listingId: 'listing-object-id', serviceType: 'bus', status: 'published' };
const legacyBus = { _id: 'listing-object-id', companyId: 'company-1', group: 'transport', type: 'Bus', title: 'Kampala Coach', status: 'draft', releaseStatus: 'draft' };
const context = { schedules: [publishedSchedule], vehicles: [] };

check('Mongo _id is a stable public listing identifier', () => assert.strictEqual(entityId(legacyBus), 'listing-object-id'));
check('Object-id-shaped listing relationships compare safely', () => assert.strictEqual(sameId(publishedSchedule.listingId, legacyBus), true));
check('Legacy transport Bus listing canonicalizes to bus', () => assert.strictEqual(canonicalServiceType(legacyBus, context), 'bus'));
check('Published bus departure exposes its connected listing', () => assert.strictEqual(isPublicListing(legacyBus, context), true));
check('Archived listing remains private even with a published departure', () => assert.strictEqual(isPublicListing({ ...legacyBus, status: 'archived' }, context), false));
check('Operationally active listing remains private while release is explicitly draft', () => assert.strictEqual(isPublicListing({ ...legacyBus, status: 'active' }, { schedules: [] }), false));
check('Legacy active listing without release metadata is public', () => assert.strictEqual(isPublicListing({ ...legacyBus, status: 'active', releaseStatus: undefined }, { schedules: [] }), true));
check('Published public bus remains visible before its first departure', () => assert.strictEqual(isPublicListing({ ...legacyBus, status: 'active', releaseStatus: 'published', bookable: false }, { schedules: [] }), true));
check('bus_company alias canonicalizes to bus', () => assert.strictEqual(canonicalServiceType({ serviceType: 'bus_company' }), 'bus'));
check('legacy departure can resolve through its listing-owned route', () => {
  const listing = { id: 'listing-route-link', companyId: 'company-1', type: 'Bus', releaseStatus: 'draft' };
  const rows = relatedSchedulesForListing(listing, {
    routes: [{ id: 'route-1', listingId: listing.id, companyId: 'company-1' }],
    vehicles: [],
    schedules: [{ id: 'schedule-1', routeId: 'route-1', companyId: 'company-1', status: 'published' }],
  });
  assert.strictEqual(rows.length, 1);
  assert.strictEqual(isPublicListing(listing, { routes: [{ id: 'route-1', listingId: listing.id, companyId: 'company-1' }], vehicles: [], schedules: rows }), true);
});
check('explicit foreign listing ownership is never inferred from route or vehicle', () => {
  const listing = { id: 'listing-safe', companyId: 'company-1', type: 'Bus' };
  const rows = relatedSchedulesForListing(listing, {
    routes: [{ id: 'route-safe', listingId: listing.id, companyId: 'company-1' }],
    vehicles: [],
    schedules: [{ id: 'schedule-foreign', listingId: 'other-listing', routeId: 'route-safe', companyId: 'company-1', status: 'published' }],
  });
  assert.strictEqual(rows.length, 0);
});

const root = path.join(__dirname, '..');
const catalog = fs.readFileSync(path.join(root, 'src/services/marketplace/catalogService.js'), 'utf8');
const departure = fs.readFileSync(path.join(root, 'src/modules/bus/services/busDepartureService.js'), 'utf8');
const publicController = fs.readFileSync(path.join(root, 'src/controllers/public/listingController.js'), 'utf8');
const home = fs.readFileSync(path.join(root, 'src/views/pages/home.ejs'), 'utf8');
const homeJs = fs.readFileSync(path.join(root, 'public/js/home.js'), 'utf8');
const packageJson = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

check('homepage catalog passes complete snapshot to visibility rules', () => assert(catalog.includes('isPublicListing(row, data)')));
check('catalog snapshots vehicles for legacy bus inference', () => assert(catalog.includes('commerceRepository.vehicles.list')));
check('departure publication synchronizes listing publication', () => assert(departure.includes('synchronizeListingPublicationAfterDeparture')));
check('public listing details reuse compatibility-resolved departures', () => assert(publicController.includes('catalogService.relatedSchedulesForListing(raw, data)')));
check('homepage contains server-rendered bus fallback cards', () => assert(home.includes('initialBusListings')));
check('homepage JavaScript has an explicit empty-state fallback', () => assert(homeJs.includes('No published ${escapeHtml(cfg.label)} yet')));
check('homepage script URL is cache-versioned', () => assert(/home\.js\?v=\d+/.test(home)));
check('existing database repair command is registered', () => assert.strictEqual(packageJson.scripts['repair:public-buses'], 'node scripts/repair-public-bus-listings.js'));

console.log(`Main-page bus visibility checks passed: ${passed}/${passed}`);
