require('dotenv').config();

async function main() {
  const { connectDb, mongoose } = require('../src/config/db');
  await connectDb();
  const Listing = require('../src/models/Listing');

  const bad = await Listing.find({ serviceType: 'bus_company' }, { id: 1, title: 1, companyId: 1 }).lean();
  console.log(`Found ${bad.length} listing(s) with legacy serviceType 'bus_company'.`);
  for (const row of bad) {
    console.log(`Fixing ${row.id} (${row.title}, company ${row.companyId}): bus_company -> bus`);
  }
  const result = await Listing.updateMany(
    { serviceType: 'bus_company' },
    { $set: { serviceType: 'bus', group: 'bus', type: 'Bus' } },
  );
  console.log('Modified:', result.modifiedCount);

  await mongoose.disconnect();
}

main().catch((error) => { console.error('FAILED:', error); process.exit(1); });
