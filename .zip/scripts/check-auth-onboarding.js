'use strict';
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');
const checks = [];
function requireMatch(file, pattern, label) {
  const ok = pattern.test(read(file));
  checks.push({ label, ok });
  if (!ok) console.error(`FAIL: ${label} (${file})`);
}
function requireAbsent(file, pattern, label) {
  const ok = !pattern.test(read(file));
  checks.push({ label, ok });
  if (!ok) console.error(`FAIL: ${label} (${file})`);
}

for (const formId of ['loginForm', 'signupForm', 'partnerForm', 'supportForm', 'forgotForm']) {
  requireMatch('src/views/pages/auth/login.ejs', new RegExp(`id=["']${formId}["'][\\s\\S]{0,240}name=["']_csrf["']`), `${formId} includes CSRF token`);
}
requireMatch('src/services/auth/authService.js', /status:\s*'active'[\s\S]{0,160}onboardingStatus:\s*'company_verification'/, 'partner owners receive restricted active onboarding state');
requireMatch('src/services/auth/authService.js', /Employee and driver accounts must be created through a secure company invitation/, 'staff and drivers require invitation');
requireAbsent('src/services/auth/authService.js', /payload\.companyId\s*\|\|\s*payload\.companySlug/, 'public signup cannot select an existing company');
requireMatch('src/routes/web/company.js', /post\('\/company\/verification'/, 'company verification route is mounted');
requireMatch('src/routes/web/promoter.js', /post\('\/promoter\/verification'/, 'promoter verification route is mounted');
requireMatch('src/routes/web/promoter.js', /post\('\/promoter\/withdrawals',\s*requireVerifiedPromoter/, 'promoter withdrawals require approval');
requireMatch('src/routes/web/promoter.js', /post\('\/promoter\/offline-sales',\s*requireVerifiedPromoter/, 'promoter offline sales require approval');
requireMatch('src/routes/web/company.js', /post\('\/company\/payouts',\s*requireVerifiedCompany/, 'company payouts require approval');
requireMatch('src/services/dashboard/actionService.js', /Company verification must be approved before requesting payouts/, 'company payout service fails closed');
requireMatch('src/services/promoter/offlineSalesService.js', /const verified = normalize\(agent\.verificationStatus\) === 'verified'/, 'offline sales service requires business verification, not only email verification');
requireMatch('src/services/finance/settlementService.js', /Promoter verification must be approved before requesting payouts/, 'settlement service blocks unverified promoter payouts');
requireMatch('src/services/onboarding/verificationService.js', /submitPromoterChecklist/, 'promoter checklist service exists');
requireMatch('src/services/onboarding/verificationService.js', /targetType === 'promoter'/, 'admin verification supports promoters');
requireMatch('src/models/User.js', /onboardingStatus:/, 'user onboarding state is persisted');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Pending partner owners unlocked for restricted onboarding/, 'legacy pending partner migration exists');

requireMatch('src/views/pages/partner-onboarding.ejs', /id="partnerOnboardingForm"[\s\S]{0,220}name="_csrf"/, 'pricing partner onboarding includes CSRF token');
requireMatch('src/views/pages/partner-onboarding.ejs', /name="password"[\s\S]{0,300}name="confirmPassword"/, 'pricing partner onboarding creates secure credentials');
requireMatch('src/views/pages/partner-onboarding.ejs', /name="termsAccepted"/, 'pricing partner onboarding requires partner terms');
requireMatch('src/services/billing/billingService.js', /authService\.registerUser\(\{[\s\S]{0,180}role:\s*'company_admin'/, 'pricing onboarding reuses canonical partner registration');
requireMatch('src/services/billing/billingService.js', /An account with this email or phone already exists\. Sign in before continuing partner onboarding/, 'pricing onboarding prevents existing-account session takeover');
requireAbsent('src/services/billing/billingService.js', /upsertPendingAdmin/, 'duplicate passwordless pending-admin provisioning is removed');
requireMatch('src/controllers/public/billingController.js', /assertPartnerOrderAccess\(req, order\)/, 'partner checkout is restricted to the owning company account');

requireMatch('src/services/auth/authService.js', /rollbackNewAccount\(user, error\)/, 'failed public registration compensates partially provisioned accounts');
requireMatch('src/services/auth/authService.js', /delete clean\.mfa;/, 'session user sanitizer removes MFA secrets');
requireMatch('src/services/auth/authService.js', /mfaConfigured:\s*Boolean\(/, 'session user exposes only an MFA configured flag');
requireMatch('src/middlewares/mfa.js', /async function requirePlatformMfa/, 'platform MFA middleware exists');
requireMatch('src/middlewares/mfa.js', /verifiedSessionIsFresh/, 'administrator MFA session freshness is enforced');
requireMatch('src/routes/web/admin.js', /requireRole\('super_admin'\),\s*requirePlatformMfa/, 'Super Admin workspace requires MFA');
for (const rolePath of ['content', 'support', 'finance', 'operations']) {
  requireMatch('src/routes/web/admin.js', new RegExp(`router\\.use\\('/${rolePath}'[\\s\\S]{0,180}requirePlatformMfa`), `${rolePath} administrator workspace requires MFA`);
}
for (const apiFile of ['src/routes/api/dashboards.js', 'src/routes/api/notifications.js', 'src/routes/api/uploads.js', 'src/routes/api/scanner.js']) {
  requireMatch(apiFile, /requirePlatformMfa/, `${apiFile} applies administrator MFA`);
}
requireMatch('src/controllers/admin/actionController.js', /twoFactorEnabled:\s*false[\s\S]{0,180}onboardingStatus:\s*'mfa_setup_required'/, 'invited administrators cannot be marked MFA-enabled before setup');
requireMatch('src/seeds/admin.js', /twoFactorEnabled:\s*false[\s\S]{0,120}onboardingStatus:\s*'mfa_setup_required'/, 'seeded administrator must complete real MFA setup');
requireMatch('src/services/onboarding/invitationService.js', /tokenHash:\s*tokenHash\(rawToken\)/, 'invitations persist a token hash');
requireMatch('src/services/onboarding/invitationService.js', /delete stored\.token;/, 'plaintext invitation token is removed before persistence');
requireAbsent('src/services/onboarding/invitationService.js', /meta:\s*\{[^}]*token:\s*invitation\.token/, 'notification metadata does not duplicate invitation plaintext token');
requireMatch('src/services/onboarding/invitationService.js', /return \{ \.\.\.invitation, token: rawToken \};/, 'plaintext invitation token remains transient for immediate delivery');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Legacy plaintext invitation tokens/, 'legacy plaintext invitation tokens have a hashing migration');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Administrators without a real authenticator secret forced through MFA setup/, 'legacy fake administrator MFA state has a migration');
requireMatch('src/services/onboarding/verificationService.js', /owner\.onboardingStatus = 'complete'/, 'approved company-owner onboarding is completed');
requireMatch('src/services/onboarding/verificationService.js', /user\.onboardingStatus = 'complete'/, 'approved promoter and driver onboarding is completed');
requireMatch('src/services/onboarding/verificationService.js', /onboardingStep:\s*'correction_required'/, 'rejected companies keep a correction-only workspace');
requireMatch('src/routes/web/company.js', /post\('\/company\/scanner\/validate',\s*requireVerifiedCompany/, 'company scanning requires approved verification');
requireMatch('src/routes/web/company.js', /post\('\/company\/bookings\/:bookingRef\/check-in',\s*requireVerifiedCompany/, 'company check-in requires approved verification');
requireMatch('src/routes/web/employee.js', /post\('\/employee\/payments',\s*requireVerifiedCompany/, 'employee payment recording requires approved company verification');
requireMatch('src/routes/web/employee.js', /post\('\/driver\/trips\/:scheduleId\/status',\s*requireVerifiedCompany/, 'driver trip operations require approved company verification');
requireMatch('src/middlewares/companyAccess.js', /company_verification_required/, 'unverified operational access fails closed with a stable error code');
requireMatch('src/controllers/auth/authController.js', /verifiedSessionIsFresh\(req\)/, 'configured administrator cannot bypass login MFA through setup page');
requireMatch('src/views/pages/auth/mfa-challenge.ejs', /inputmode="text"/, 'MFA challenge accepts both TOTP and recovery codes');

requireMatch('src/routes/web/auth.js', /post\('\/account\/phone-verification\/verify'[\s\S]{0,100}phoneCodeRules/, 'phone verification route validates OTP input');
requireMatch('src/services/auth/phoneVerificationService.js', /crypto\.randomInt\(100000, 1000000\)/, 'phone verification uses cryptographically random six-digit codes');
requireMatch('src/services/auth/phoneVerificationService.js', /timingSafeEqual/, 'phone verification compares challenge hashes in constant time');
requireMatch('src/services/auth/phoneVerificationService.js', /MAX_ATTEMPTS\s*=\s*5/, 'phone verification limits failed attempts');
requireMatch('src/services/auth/phoneVerificationService.js', /RESEND_WAIT_MS\s*=\s*60\s*\*\s*1000/, 'phone verification throttles resend requests');
requireAbsent('src/services/auth/phoneVerificationService.js', /code:\s*code[,}]/, 'plaintext phone code is not persisted in the challenge');
requireMatch('src/services/onboarding/verificationService.js', /markPhoneVerifiedForUser/, 'verified phone updates the correct onboarding checklist');
requireMatch('src/services/onboarding/verificationService.js', /The driver company must remain active and verified before driver activation/, 'driver activation rechecks company operational state');
requireMatch('src/services/onboarding/invitationService.js', /prevalidatedCompany = await validatedInvitationCompany/, 'invitation acceptance revalidates company before credential creation');
requireMatch('src/services/dashboard/actionService.js', /Driver name, email, and phone are required for a signed driver invitation/, 'driver invitation request requires a deliverable email');
requireMatch('public/js/dashboard-workspace.js', /name:'email'[\s\S]{0,160}required:true[\s\S]{0,120}signed invitation/, 'driver request UI requires invitation email');
requireMatch('src/routes/web/company.js', /post\('\/company\/employees\/invite',\s*requireVerifiedCompany/, 'only verified companies can invite operational staff');
requireMatch('src/routes/web/company.js', /post\('\/company\/driver-requests',\s*requireVerifiedCompany/, 'only verified companies can request driver invitations');
requireAbsent('public/js/dashboard-workspace.js', /options:\[[^\]]*super_admin[^\]]*\]/, 'Super Admin is not exposed as an invitational dashboard role');
requireMatch('public/js/dashboard-workspace.js', /options:\[[^\]]*operations_admin[^\]]*\]/, 'Operations administrator is available as a delegated role');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Legacy passwordless staff and driver accounts blocked pending signed re-invitation/, 'legacy passwordless privileged accounts are safely migrated');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Assignments for unverified drivers disabled until activation/, 'legacy unverified driver assignments are disabled');
requireMatch('src/views/pages/auth/login.ejs', /name="password"[^>]*minlength="8"[^>]*pattern=/, 'public signup UI communicates backend password rules');

requireMatch('src/services/onboarding/verificationService.js', /const COMPANY_CHECKS[\s\S]{0,900}'email_verified'[\s\S]{0,900}'phone_verified'/, 'verification checklists require email and phone proof');
requireMatch('src/services/onboarding/verificationService.js', /markEmailVerifiedForUser/, 'verified email updates the correct onboarding checklist');
requireMatch('src/services/onboarding/verificationService.js', /Company owner email verification is required before activation/, 'company activation requires verified owner email');
requireMatch('src/services/onboarding/verificationService.js', /Company owner phone verification is required before activation/, 'company activation requires verified owner phone');
requireMatch('src/services/onboarding/verificationService.js', /Promoter email verification is required before activation/, 'promoter activation requires verified email');
requireMatch('src/services/onboarding/verificationService.js', /Promoter phone verification is required before activation/, 'promoter activation requires verified phone');
requireMatch('src/services/onboarding/verificationService.js', /Driver email verification is required before activation/, 'driver activation requires verified email');
requireMatch('src/services/onboarding/verificationService.js', /Driver phone verification is required before activation/, 'driver activation requires verified phone');
requireMatch('src/services/auth/authService.js', /markEmailVerifiedForUser\(user\.id, user\.id\)/, 'email confirmation updates onboarding verification state');
requireMatch('src/services/notification/notificationService.js', /persistedMessage = null[\s\S]{0,100}persistedMeta = null/, 'notification service separates delivery secrets from durable history');
requireMatch('src/services/onboarding/invitationService.js', /persistedMessage:[\s\S]{0,200}persistedMeta:/, 'invitation delivery token is redacted from durable notification history');
requireMatch('src/services/auth/phoneVerificationService.js', /persistedMessage:[\s\S]{0,200}codeStored:\s*false/, 'phone OTP is redacted from durable notification history');
requireMatch('src/services/auth/authService.js', /email verification link was sent[\s\S]{0,160}tokenStored:\s*false/, 'email verification token is redacted from durable notification history');
requireMatch('src/services/auth/authService.js', /password-reset link was sent[\s\S]{0,180}tokenStored:\s*false/, 'password-reset token is redacted from durable notification history');
requireMatch('src/services/onboarding/partnerPipelineService.js', /delete storedInvitation\.token;[\s\S]{0,500}updateOne\(\{ id: invitation\.id \}, \{ \$unset: \{ token: 1 \} \}\)/, 'partner agreement pipeline cannot re-persist invitation plaintext tokens');
requireMatch('src/controllers/admin/actionController.js', /let createdProvisionalUser = false;/, 'admin invitation tracks whether provisional account is newly created');
requireMatch('src/controllers/admin/actionController.js', /if \(createdProvisionalUser && provisionalUser/, 'failed admin invitation deletes only a newly created provisional account');



requireMatch('src/services/auth/passwordPolicy.js', /MAX_PASSWORD_BYTES\s*=\s*72/, 'password policy enforces the bcrypt UTF-8 byte limit');
requireMatch('src/services/auth/authService.js', /validatePassword\(payload\.password\)/, 'public registration uses the centralized password policy');
requireMatch('src/services/auth/authService.js', /validatedPassword = validatePassword\(password\)/, 'password reset uses the centralized password policy');
requireMatch('src/services/onboarding/invitationService.js', /validatePassword\(payload\.password\)/, 'invitation acceptance uses the centralized password policy');
requireMatch('src/views/pages/auth/login.ejs', /maxlength="72"[^>]*pattern="\(\?=\.\*\[A-Za-z\]\)\(\?=\.\*\[0-9\]\)\.\{8,72\}"/, 'public signup UI matches the safe password limit');
requireMatch('src/config/accessControl.js', /driver:\s*\['manifest\.view', 'checkin\.assist', 'trip\.status\.update', 'incident\.create'\]/, 'driver default permissions use canonical permission names');
requireAbsent('src/controllers/admin/actionController.js', /permissions:\s*\['driver_manifest', 'check_in', 'trip_status'\]/, 'admin driver invitations do not emit legacy permission labels');
requireMatch('src/services/company/companyService.js', /Drivers can be activated only by the driver verification workflow/, 'generic staff updates cannot activate drivers');
requireMatch('src/services/company/companyService.js', /Staff must accept the signed invitation and create credentials before activation/, 'generic staff updates cannot activate unaccepted or passwordless staff');
requireAbsent('src/services/company/companyService.js', /nextStatus === 'active'\) \{ user\.isVerified = true; user\.verificationStatus = 'verified'/, 'generic membership updates cannot self-approve verification');
requireMatch('src/services/onboarding/invitationService.js', /acceptedAt,\n\s*createdAt: acceptedAt/, 'accepted employee memberships persist invitation acceptance time');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Legacy employee permission labels/, 'legacy employee permissions have a canonical migration');
requireMatch('scripts/migrate-auth-onboarding-access.js', /Legacy active signed-invitation memberships marked accepted/, 'legacy active memberships receive acceptance timestamps');
requireMatch('src/services/onboarding/verificationService.js', /invalidateContactVerificationForUser/, 'verified contact changes have a centralized invalidation workflow');
requireMatch('src/services/onboarding/verificationService.js', /onboardingStep: 'contact_reverification'/, 'partner contact changes disable publishing and require reverification');
requireMatch('src/services/onboarding/verificationService.js', /Driver contact changed and must be reverified/, 'driver contact changes suspend operational assignments');
requireMatch('src/services/customer/customerService.js', /invalidateContactVerificationForUser\(user\.id, \{ emailChanged, phoneChanged \}/, 'customer and promoter-compatible profile changes reset stale contact proof');
requireMatch('src/controllers/promoter/profileController.js', /invalidateContactVerificationForUser\(user\.id, \{ emailChanged, phoneChanged \}/, 'promoter contact changes reset business verification');
requireMatch('src/services/dashboard/actionService.js', /invalidateContactVerificationForUser\(user\.id, \{ emailChanged, phoneChanged \}/, 'staff and driver contact changes reset operational verification');
requireMatch('src/services/onboarding/verificationService.js', /staff\.email_reverified/, 'ordinary staff can regain access only after verifying the replacement email');


requireMatch('src/services/company/companyService.js', /Drivers must use the approved driver request and verification workflow/, 'company staff invitations cannot masquerade as drivers');
requireMatch('src/services/onboarding/invitationService.js', /driver_verification_required/, 'invitation service rejects driver privilege through staff invitations');
requireMatch('src/services/transport/transportService.js', /role: 'driver', verificationStatus: 'verified'/, 'schedules select only fully verified driver identities');
requireMatch('src/services/transport/transportService.js', /Selected driver safety verification is not cleared/, 'schedule assignment requires driver safety clearance');
requireMatch('src/services/operations/manifestService.js', /account\.role === 'driver'[\s\S]{0,120}account\.verificationStatus === 'verified'/, 'manifest driver filters use verified identity roles');
requireAbsent('src/services/onboarding/verificationService.js', /const isDriver = \/driver\/i\.test\(employee\.roleTitle/, 'verification queue does not trust a text job title as driver identity');

requireMatch('src/config/accessControl.js', /const REQUIRED_DRIVER_PERMISSIONS = Object\.freeze\(\[[\s\S]{0,140}'incident\.create'/, 'one canonical required-driver permission set includes incident reporting');
requireMatch('src/services/onboarding/verificationService.js', /REQUIRED_DRIVER_PERMISSIONS\.every\(\(permission\) => grantedPermissions\.has\(permission\)\)/, 'driver checklist requires every canonical operational permission');
requireMatch('src/services/onboarding/verificationService.js', /driverAccount\.role !== 'driver'/, 'driver activation independently verifies the dedicated driver account role');
requireMatch('src/services/onboarding/verificationService.js', /Driver invitation must be accepted before activation/, 'driver activation requires accepted credentials');
requireMatch('src/services/company/companyService.js', /employee\.status !== 'active' \|\| employee\.safetyStatus !== 'cleared'/, 'driver assignment requires both active membership and safety clearance');
requireMatch('src/services/company/companyService.js', /user\.role !== 'driver' \|\| user\.status !== 'active' \|\| user\.verificationStatus !== 'verified'/, 'driver assignment rechecks verified driver identity at the service boundary');
requireMatch('src/services/dashboard/actionService.js', /ownerEmailChanged: emailChanged, ownerPhoneChanged: phoneChanged/, 'company owner contact changes are audited');
requireMatch('src/services/dashboard/actionService.js', /invalidateContactVerificationForUser\(owner\.id, \{ emailChanged, phoneChanged \}/, 'company owner contact changes require fresh verification');
requireMatch('public/js/dashboard-workspace.js', /name:'ownerEmail'[\s\S]{0,420}name:'ownerPhone'/, 'existing company profile UI can add or replace owner verification contacts');
requireMatch('src/views/dashboards/shared/sections/company-profile.ejs', /Add the owner phone number through <strong>Edit profile<\/strong>/, 'partner onboarding explains how to complete a missing owner phone');

const passed = checks.filter((check) => check.ok).length;
const failed = checks.length - passed;
console.log(`Auth/onboarding checks: ${passed}/${checks.length} passed`);
if (failed) process.exitCode = 1;
