const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function walk(dir, files = []) {
  for (const item of fs.readdirSync(dir)) {
    const p = path.join(dir, item);
    const st = fs.statSync(p);
    if (st.isDirectory()) walk(p, files);
    else if (p.endsWith('.js')) files.push(p);
  }
  return files;
}

let failed = false;
for (const file of walk(path.join(__dirname, '..', 'src'))) {
  const result = spawnSync(process.execPath, ['--check', file], { stdio: 'inherit' });
  if (result.status !== 0) failed = true;
}


// Syntax-only checks do not catch undefined constants or other module-load failures.
// Load every Mongoose model in a clean subprocess so production boot failures are caught.
const modelDir = path.join(__dirname, '..', 'src', 'models');
const modelFiles = fs.readdirSync(modelDir).filter((name) => name.endsWith('.js') && name !== '_helpers.js');
const loadScript = `for (const name of ${JSON.stringify(modelFiles)}) require(${JSON.stringify(modelDir)} + '/' + name);`;
const modelLoad = spawnSync(process.execPath, ['-e', loadScript], { stdio: 'inherit' });
if (modelLoad.status !== 0) failed = true;

process.exit(failed ? 1 : 0);
