'use strict';

require('dotenv').config();

function argument(name) {
  const prefix = `--${name}=`;
  const item = process.argv.find((value) => value.startsWith(prefix));
  return item ? item.slice(prefix.length).trim() : '';
}

function hasFlag(name) {
  return process.argv.includes(`--${name}`);
}

function busServiceType(value) {
  return ['bus', 'bus_company', 'coach'].includes(String(value || '').trim().toLowerCase().replace(/[-\s]+/g, '_'));
}

async function main() {
  const { connectDb, mongoose } = require('../src/config/db');
  const repositories = require('../src/repositories');
  const departureService = require('../src/modules/bus/services/busDepartureService');

  await connectDb();
  if (mongoose.connection.readyState !== 1) throw new Error('MongoDB connection is required');

  const requestedCompanyId = argument('company');
  const repairAll = hasFlag('all');
  const limit = Math.max(1, Math.min(Number(argument('limit') || 500), 500));
  if (!requestedCompanyId && !repairAll) {
    throw new Error('Use --company=<company-id> for one company or --all for every company with a bus listing');
  }

  let companyIds = requestedCompanyId ? [requestedCompanyId] : [];
  if (repairAll) {
    const listings = await repositories.listings.list({}, { limit: 20000 });
    companyIds = [...new Set(listings
      .filter((listing) => busServiceType(listing.serviceType || listing.type || listing.group))
      .map((listing) => String(listing.companyId || '').trim())
      .filter(Boolean))];
  }

  const report = [];
  for (const companyId of companyIds) {
    try {
      const result = await departureService.repairCompanyDepartureInventories(companyId, 'seat-map-repair-script', limit);
      report.push({ companyId, checked: result.checked, repaired: result.repaired, results: result.results });
    } catch (error) {
      report.push({ companyId, checked: 0, repaired: 0, error: error.message });
    }
  }

  const totals = report.reduce((summary, row) => ({
    companies: summary.companies + 1,
    checked: summary.checked + Number(row.checked || 0),
    repaired: summary.repaired + Number(row.repaired || 0),
    failedCompanies: summary.failedCompanies + (row.error ? 1 : 0),
  }), { companies: 0, checked: 0, repaired: 0, failedCompanies: 0 });

  console.log(JSON.stringify({ ok: totals.failedCompanies === 0, totals, report }, null, 2));
  await mongoose.disconnect();
  if (totals.failedCompanies) process.exitCode = 1;
}

main().catch(async (error) => {
  console.error(`FAILED: ${error.message}`);
  try {
    const { mongoose } = require('../src/config/db');
    if (mongoose.connection.readyState !== 0) await mongoose.disconnect();
  } catch (_) { /* no-op */ }
  process.exitCode = 1;
});
