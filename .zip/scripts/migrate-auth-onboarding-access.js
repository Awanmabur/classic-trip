'use strict';

require('dotenv').config();
const crypto = require('crypto');
const { connectDb, mongoose } = require('../src/config/db');

const apply = process.argv.includes('--apply');

async function updateMany(collection, filter, update, label) {
  const count = await collection.countDocuments(filter);
  console.log(`${label}: ${count} record(s)${apply ? ' updated' : ' would be updated'}`);
  if (apply && count) await collection.updateMany(filter, update);
  return count;
}

async function run() {
  await connectDb();
  const db = mongoose.connection.db;
  const users = db.collection('users');
  const companies = db.collection('companies');
  const invitations = db.collection('invitations');
  const employees = db.collection('companyemployees');
  const driverAssignments = db.collection('driverassignments');
  const now = new Date();

  const totals = {};
  totals.pendingPartnerAccounts = await updateMany(
    users,
    {
      role: 'company_admin',
      status: 'pending',
      verificationStatus: { $ne: 'verified' },
    },
    {
      $set: {
        status: 'active',
        verificationStatus: 'pending',
        onboardingStatus: 'company_verification',
        updatedAt: now,
      },
    },
    'Pending partner owners unlocked for restricted onboarding',
  );

  totals.pendingPromoterAccounts = await updateMany(
    users,
    {
      role: 'promoter',
      status: 'pending',
      verificationStatus: { $ne: 'verified' },
    },
    {
      $set: {
        status: 'active',
        verificationStatus: 'pending',
        onboardingStatus: 'promoter_verification',
        updatedAt: now,
      },
    },
    'Pending promoters unlocked for restricted onboarding',
  );

  totals.partnerOnboardingState = await updateMany(
    users,
    {
      role: 'company_admin',
      verificationStatus: { $ne: 'verified' },
      $or: [
        { onboardingStatus: { $exists: false } },
        { onboardingStatus: null },
        { onboardingStatus: '' },
      ],
    },
    { $set: { onboardingStatus: 'company_verification', updatedAt: now } },
    'Partner onboarding state normalized',
  );

  totals.promoterOnboardingState = await updateMany(
    users,
    {
      role: 'promoter',
      verificationStatus: { $ne: 'verified' },
      $or: [
        { onboardingStatus: { $exists: false } },
        { onboardingStatus: null },
        { onboardingStatus: '' },
      ],
    },
    { $set: { onboardingStatus: 'promoter_verification', updatedAt: now } },
    'Promoter onboarding state normalized',
  );

  totals.passwordlessPrivilegedAccounts = await updateMany(
    users,
    {
      role: { $in: ['company_employee', 'driver'] },
      $or: [{ passwordHash: { $exists: false } }, { passwordHash: null }, { passwordHash: '' }],
    },
    {
      $set: {
        status: 'blocked',
        verificationStatus: 'pending',
        onboardingStatus: 'signed_invitation_reissue_required',
        updatedAt: now,
      },
    },
    'Legacy passwordless staff and driver accounts blocked pending signed re-invitation',
  );

  const acceptedStaff = await employees.find({
    status: 'active',
    userId: { $exists: true, $nin: [null, ''] },
  }).project({ userId: 1 }).toArray();
  const acceptedStaffUserIds = acceptedStaff.map((row) => row.userId).filter(Boolean);
  totals.acceptedStaffAccounts = await updateMany(
    users,
    {
      id: { $in: acceptedStaffUserIds },
      role: 'company_employee',
      passwordHash: { $exists: true, $nin: [null, ''] },
      status: { $ne: 'blocked' },
    },
    {
      $set: {
        status: 'active',
        isVerified: true,
        verificationStatus: 'verified',
        onboardingStatus: 'complete',
        updatedAt: now,
      },
    },
    'Accepted signed-invitation staff accounts activated',
  );



  const permissionAliases = {
    driver_manifest: 'manifest.view',
    check_in: 'checkin.assist',
    trip_status: 'trip.status.update',
    report_incident: 'incident.create',
  };
  const legacyPermissionEmployees = await employees.find({
    permissions: { $in: Object.keys(permissionAliases) },
  }).project({ _id: 1, permissions: 1, roleTitle: 1, status: 1, invitedAt: 1, acceptedAt: 1 }).toArray();
  totals.canonicalEmployeePermissions = legacyPermissionEmployees.length;
  console.log(`Legacy employee permission labels: ${legacyPermissionEmployees.length} record(s)${apply ? ' normalized' : ' would be normalized'}`);
  if (apply && legacyPermissionEmployees.length) {
    const operations = legacyPermissionEmployees.map((employee) => {
      const normalizedPermissions = Array.from(new Set((employee.permissions || []).map((permission) => permissionAliases[permission] || permission)));
      const set = { permissions: normalizedPermissions, updatedAt: now };
      if (employee.status === 'active' && !employee.acceptedAt) set.acceptedAt = employee.invitedAt || now;
      return { updateOne: { filter: { _id: employee._id }, update: { $set: set } } };
    });
    await employees.bulkWrite(operations, { ordered: false });
  }

  totals.acceptedMembershipTimestamps = await updateMany(
    employees,
    {
      status: 'active',
      acceptedAt: { $exists: false },
      userId: { $exists: true, $nin: [null, ''] },
    },
    { $set: { acceptedAt: now, updatedAt: now } },
    'Legacy active signed-invitation memberships marked accepted',
  );

  const pendingDrivers = await employees.find({
    status: { $in: ['requested', 'invited', 'pending_verification'] },
    userId: { $exists: true, $nin: [null, ''] },
  }).project({ userId: 1 }).toArray();
  const pendingDriverUserIds = pendingDrivers.map((row) => row.userId).filter(Boolean);
  totals.pendingDriverAccounts = await updateMany(
    users,
    {
      id: { $in: pendingDriverUserIds },
      role: 'driver',
      passwordHash: { $exists: true, $nin: [null, ''] },
      status: { $ne: 'blocked' },
    },
    {
      $set: {
        status: 'active',
        isVerified: false,
        verificationStatus: 'pending',
        onboardingStatus: 'driver_verification',
        updatedAt: now,
      },
    },
    'Accepted driver accounts unlocked only for verification onboarding',
  );

  const unverifiedDriverUsers = await users.find({
    role: 'driver',
    verificationStatus: { $ne: 'verified' },
  }).project({ id: 1 }).toArray();
  const unverifiedDriverIds = unverifiedDriverUsers.map((row) => row.id).filter(Boolean);
  const unverifiedDriverEmployees = await employees.find({ userId: { $in: unverifiedDriverIds } }).project({ id: 1 }).toArray();
  const unverifiedEmployeeIds = unverifiedDriverEmployees.map((row) => row.id).filter(Boolean);
  totals.unverifiedDriverMemberships = await updateMany(
    employees,
    { id: { $in: unverifiedEmployeeIds }, status: 'active' },
    { $set: { status: 'pending_verification', safetyStatus: 'pending_review', updatedAt: now } },
    'Unverified driver memberships removed from operational access',
  );
  totals.unverifiedDriverAssignments = await updateMany(
    driverAssignments,
    { employeeId: { $in: unverifiedEmployeeIds }, status: 'active' },
    { $set: { status: 'pending_verification', safetyStatus: 'pending_review', updatedAt: now } },
    'Assignments for unverified drivers disabled until activation',
  );

  totals.phoneVerificationState = await updateMany(
    users,
    {
      role: { $in: ['company_admin', 'promoter', 'driver'] },
      phone: { $exists: true, $nin: [null, ''] },
      phoneVerifiedAt: { $exists: false },
      $or: [{ phoneVerificationStatus: { $exists: false } }, { phoneVerificationStatus: null }, { phoneVerificationStatus: '' }],
    },
    { $set: { phoneVerificationStatus: 'pending', updatedAt: now } },
    'Phone verification state initialized for regulated roles',
  );

  totals.unverifiedCompanyRestrictions = await updateMany(
    companies,
    { verificationStatus: { $ne: 'verified' }, status: { $nin: ['rejected', 'suspended', 'blocked'] } },
    {
      $set: {
        status: 'pending',
        'settings.canPublish': false,
        'settings.instantConfirmation': false,
        'settings.onboardingStep': 'verification',
        updatedAt: now,
      },
    },
    'Unverified companies restricted to draft onboarding',
  );

  totals.rejectedCompanyCorrections = await updateMany(
    companies,
    { $or: [{ status: 'rejected' }, { verificationStatus: 'rejected' }] },
    {
      $set: {
        'settings.canPublish': false,
        'settings.instantConfirmation': false,
        'settings.onboardingStep': 'correction_required',
        updatedAt: now,
      },
    },
    'Rejected companies retained in correction-only onboarding',
  );

  totals.completedCompanyOwners = await updateMany(
    users,
    { role: 'company_admin', status: 'active', verificationStatus: 'verified', onboardingStatus: { $ne: 'complete' } },
    { $set: { onboardingStatus: 'complete', updatedAt: now } },
    'Verified company-owner onboarding marked complete',
  );

  totals.completedPromoters = await updateMany(
    users,
    { role: 'promoter', status: 'active', verificationStatus: 'verified', onboardingStatus: { $ne: 'complete' } },
    { $set: { onboardingStatus: 'complete', updatedAt: now } },
    'Verified promoter onboarding marked complete',
  );

  const administratorRoles = ['super_admin', 'admin', 'finance_admin', 'support_admin', 'operations_admin', 'content_admin'];
  totals.adminMfaRepair = await updateMany(
    users,
    {
      role: { $in: administratorRoles },
      $or: [
        { 'mfa.secretEncrypted': { $exists: false } },
        { 'mfa.secretEncrypted': null },
        { 'mfa.secretEncrypted': '' },
      ],
    },
    {
      $set: {
        twoFactorEnabled: false,
        onboardingStatus: 'mfa_setup_required',
        updatedAt: now,
      },
    },
    'Administrators without a real authenticator secret forced through MFA setup',
  );

  const legacyTokenRows = await invitations.find({ token: { $exists: true, $nin: [null, ''] } }).toArray();
  totals.legacyInvitationTokens = legacyTokenRows.length;
  console.log(`Legacy plaintext invitation tokens: ${legacyTokenRows.length} record(s)${apply ? ' hashed and removed' : ' would be hashed and removed'}`);
  if (apply) {
    for (const invitation of legacyTokenRows) {
      const token = String(invitation.token || '');
      await invitations.updateOne(
        { _id: invitation._id },
        {
          $set: {
            tokenHash: crypto.createHash('sha256').update(token).digest('hex'),
            tokenPreview: token ? `${token.slice(0, 6)}...${token.slice(-4)}` : '',
            updatedAt: now,
          },
          $unset: { token: '' },
        },
      );
    }
  }

  console.log(JSON.stringify({ mode: apply ? 'apply' : 'dry-run', totals }, null, 2));
  if (!apply) console.log('Dry run only. Re-run with --apply after reviewing the counts.');
}

run()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect().catch(() => {});
  });
