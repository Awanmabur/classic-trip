'use strict';

require('dotenv').config();
const crypto = require('crypto');
const { connectDb, mongoose } = require('../src/config/db');
const {
  buildSeatDefinitions,
  seatMapChecksum,
  hashToken,
} = require('../src/modules/bus/domain/busDomain');

const Listing = require('../src/models/Listing');
const Route = require('../src/models/Route');
const RouteStop = require('../src/models/RouteStop');
const RouteSegment = require('../src/models/RouteSegment');
const Vehicle = require('../src/models/Vehicle');
const SeatMapTemplate = require('../src/models/SeatMapTemplate');
const SeatMapVersion = require('../src/models/SeatMapVersion');
const FareProduct = require('../src/models/FareProduct');
const BusSegmentFare = require('../src/models/BusSegmentFare');
const TripSchedule = require('../src/models/TripSchedule');
const Seat = require('../src/models/Seat');
const BusSeatSegmentInventory = require('../src/models/BusSeatSegmentInventory');
const Booking = require('../src/models/Booking');
const BookingItem = require('../src/models/BookingItem');
const BusReservation = require('../src/models/BusReservation');
const Passenger = require('../src/models/Passenger');
const BusSeatAssignment = require('../src/models/BusSeatAssignment');
const BusTicket = require('../src/models/BusTicket');
const InventoryHold = require('../src/models/InventoryHold');
const InventoryHoldItem = require('../src/models/InventoryHoldItem');

const apply = process.argv.includes('--apply');
const archiveLegacy = process.argv.includes('--archive-legacy');
const now = new Date();
const report = {
  mode: apply ? 'apply' : 'dry-run',
  archiveLegacy,
  routes: { inspected: 0, stops: 0, segments: 0 },
  vehicles: { inspected: 0, templates: 0, versions: 0 },
  fares: { inspected: 0, products: 0, segmentFares: 0, missingPrice: [] },
  departures: { inspected: 0, updated: 0, inventoryRows: 0, forcedDraft: [] },
  bookings: { inspected: 0, migrated: 0, items: 0, reservations: 0, assignments: 0, tickets: 0, unresolved: [] },
};

function deterministicId(prefix, ...parts) {
  const digest = crypto.createHash('sha256').update(parts.map((part) => String(part ?? '')).join('|')).digest('hex').slice(0, 20);
  return `${prefix}-${digest}`;
}
function clean(value, max = 1000) {
  return String(value ?? '').replace(/<[^>]*>/g, '').trim().replace(/\s+/g, ' ').slice(0, max);
}
function number(value, fallback = 0) {
  const resolved = Number(value);
  return Number.isFinite(resolved) ? resolved : fallback;
}
function unique(values = []) {
  return [...new Set(values.map((value) => clean(value, 180)).filter(Boolean))];
}
function asArray(value) {
  if (Array.isArray(value)) return value;
  return String(value || '').split(',').map((item) => item.trim()).filter(Boolean);
}
function dateValue(value) {
  const parsed = value ? new Date(value) : null;
  return parsed && !Number.isNaN(parsed.getTime()) ? parsed : null;
}
function dateValidAfter(reference, expiry) {
  const expiresAt = dateValue(expiry);
  const at = dateValue(reference) || now;
  return !!expiresAt && expiresAt.getTime() > at.getTime();
}
function status(value) {
  return clean(value, 80).toLowerCase().replace(/[\s-]+/g, '_');
}
function canonicalSeatStatus(value, lockStillValid = false) {
  const current = status(value);
  if (['taken', 'booked'].includes(current)) return 'booked';
  if (current === 'checked_in') return 'checked_in';
  if (current === 'no_show') return 'no_show';
  if (['locked', 'held', 'selected'].includes(current)) return lockStillValid ? 'held' : 'available';
  if (['blocked', 'maintenance', 'reserved'].includes(current)) return 'blocked';
  if (current === 'disabled') return 'disabled';
  return 'available';
}
async function upsert(Model, filter, document) {
  if (!apply) return;
  await Model.updateOne(filter, {
    $setOnInsert: { createdAt: document.createdAt || now },
    $set: { ...document, updatedAt: now },
  }, { upsert: true, runValidators: true });
}
async function update(Model, filter, patch) {
  if (!apply) return;
  await Model.updateOne(filter, { $set: { ...patch, updatedAt: now } }, { runValidators: true });
}

async function busListings() {
  return Listing.find({ serviceType: 'bus', status: { $ne: 'archived' } }).lean();
}

function legacyStopRows(route = {}) {
  const embedded = Array.isArray(route.stops) ? route.stops : [];
  if (embedded.length >= 2) return embedded.map((stop, index) => ({
    id: clean(stop.id, 180) || deterministicId('route-stop', route.id, index, stop.name || stop.label),
    branchId: clean(stop.branchId, 180),
    name: clean(stop.name || stop.stopName || stop.label, 180),
    stopType: status(stop.stopType || stop.type || (index === 0 ? 'origin' : index === embedded.length - 1 ? 'destination' : 'intermediate')),
    stopOrder: number(stop.stopOrder ?? stop.order, index),
    timeOffsetMinutes: number(stop.timeOffsetMinutes ?? stop.offsetMinutes, 0),
    pickupAllowed: stop.pickupAllowed !== false,
    dropoffAllowed: stop.dropoffAllowed !== false,
    publicInstructions: clean(stop.publicInstructions || stop.instructions, 2000),
    status: status(stop.status) === 'archived' ? 'archived' : 'active',
  })).filter((stop) => stop.name);
  const origin = clean(route.origin || route.from, 180);
  const destination = clean(route.destination || route.to, 180);
  if (!origin || !destination) return [];
  return [
    { id: clean(route.originStopId, 180) || deterministicId('route-stop', route.id, 'origin'), branchId: clean(route.originTerminalId, 180), name: origin, stopType: 'origin', stopOrder: 0, pickupAllowed: true, dropoffAllowed: false, status: 'active' },
    { id: clean(route.destinationStopId, 180) || deterministicId('route-stop', route.id, 'destination'), branchId: clean(route.destinationTerminalId, 180), name: destination, stopType: 'destination', stopOrder: 1, pickupAllowed: false, dropoffAllowed: true, status: 'active' },
  ];
}

async function migrateRoutes(listingMap) {
  const routes = await Route.find({ listingId: { $in: [...listingMap.keys()] }, status: { $ne: 'archived' } }).lean();
  for (const route of routes) {
    report.routes.inspected += 1;
    let stops = await RouteStop.find({ routeId: route.id, status: { $ne: 'archived' } }).sort({ stopOrder: 1 }).lean();
    if (stops.length < 2) stops = legacyStopRows(route);
    if (stops.length < 2) continue;
    stops = stops.map((stop, index) => ({
      ...stop,
      id: clean(stop.id, 180) || deterministicId('route-stop', route.id, index, stop.name),
      routeId: route.id,
      listingId: route.listingId,
      companyId: route.companyId,
      name: clean(stop.name, 180),
      stopType: ['origin', 'boarding', 'pickup', 'intermediate', 'dropoff', 'destination'].includes(status(stop.stopType)) ? status(stop.stopType) : (index === 0 ? 'origin' : index === stops.length - 1 ? 'destination' : 'intermediate'),
      stopOrder: number(stop.stopOrder, index),
      pickupAllowed: index === 0 ? true : stop.pickupAllowed !== false,
      dropoffAllowed: index === stops.length - 1 ? true : stop.dropoffAllowed !== false,
      status: 'active',
    })).sort((a, b) => a.stopOrder - b.stopOrder);
    for (const stop of stops) {
      report.routes.stops += 1;
      await upsert(RouteStop, { id: stop.id }, stop);
    }
    const segments = stops.slice(0, -1).map((fromStop, index) => {
      const toStop = stops[index + 1];
      return {
        id: deterministicId('route-segment', route.id, fromStop.id, toStop.id),
        companyId: route.companyId,
        listingId: route.listingId,
        routeId: route.id,
        fromStopId: fromStop.id,
        toStopId: toStop.id,
        fromOrder: number(fromStop.stopOrder, index),
        toOrder: number(toStop.stopOrder, index + 1),
        segmentOrder: index,
        distanceKm: Math.max(0, number(toStop.distanceFromPreviousKm, 0)),
        durationMinutes: Math.max(0, number(toStop.timeFromPreviousMinutes || toStop.timeOffsetMinutes, 0)),
        status: 'active',
      };
    });
    for (const segment of segments) {
      report.routes.segments += 1;
      await upsert(RouteSegment, { id: segment.id }, segment);
    }
    await update(Route, { id: route.id }, {
      originStopId: stops[0].id,
      destinationStopId: stops[stops.length - 1].id,
      stopCount: stops.length,
      segmentCount: segments.length,
      version: Math.max(1, number(route.version, 1)),
    });
    if (apply && archiveLegacy) await Route.updateOne({ id: route.id }, { $unset: { stops: '' } });
  }
}

function seatDefinitionsFor(vehicle = {}) {
  const legacy = Array.isArray(vehicle.seatTemplate) ? vehicle.seatTemplate.filter(Boolean) : [];
  const totalSeats = Math.max(1, number(vehicle.totalSeats, legacy.length || 32));
  const columns = Math.max(1, number(vehicle.cols || vehicle.columns, 4));
  const rows = Math.max(1, number(vehicle.rows, Math.ceil(totalSeats / columns)));
  if (!legacy.length) return buildSeatDefinitions({ totalSeats, rows, columns, layoutName: vehicle.layoutName || '2x2' });
  const seats = legacy.slice(0, totalSeats).map((seat, index) => {
    const seatNumber = clean(seat.seatNumber || seat.label || index + 1, 20).toUpperCase();
    const row = Math.max(1, number(seat.row, Math.floor(index / columns) + 1));
    const column = Math.max(1, number(seat.column || seat.col, (index % columns) + 1));
    const disabled = seat.isDisabled === true || ['disabled', 'blocked'].includes(status(seat.status || seat.seatType));
    const vip = status(seat.seatClass || seat.seatType) === 'vip';
    return {
      seatNumber,
      row,
      column,
      deck: clean(seat.deck || 'lower', 30),
      seatClass: disabled ? 'Standard' : vip ? 'VIP' : 'Standard',
      seatType: disabled ? 'aisle' : column === 1 || column === columns ? 'window' : 'aisle',
      priceDelta: Math.max(0, number(seat.priceDelta, 0)),
      accessible: seat.accessible === true,
      enabled: !disabled,
      blockedReason: disabled ? clean(seat.blockedReason || 'Migrated disabled seat', 300) : '',
    };
  });
  return { rows, columns, totalSeats: seats.length, seats };
}

async function migrateVehicles(listingMap) {
  const vehicles = await Vehicle.find({ $or: [{ serviceType: 'bus' }, { listingId: { $in: [...listingMap.keys()] } }], status: { $ne: 'archived' } }).lean();
  for (const vehicle of vehicles) {
    if (!listingMap.has(vehicle.listingId)) continue;
    report.vehicles.inspected += 1;
    const definitions = seatDefinitionsFor(vehicle);
    const templateId = clean(vehicle.activeSeatMapTemplateId, 180) || deterministicId('seat-map-template', vehicle.id);
    const versionId = clean(vehicle.activeSeatMapVersionId, 180) || deterministicId('seat-map-version', vehicle.id, 1);
    const template = {
      id: templateId,
      companyId: vehicle.companyId,
      listingId: vehicle.listingId,
      vehicleId: vehicle.id,
      name: `${clean(vehicle.name, 140) || 'Bus'} seat map`,
      layoutName: clean(vehicle.layoutName || '2x2', 40),
      rows: definitions.rows,
      columns: definitions.columns,
      totalSeats: definitions.totalSeats,
      activeVersionId: versionId,
      versionCounter: 1,
      status: 'active',
      createdBy: 'canonical-bus-migration',
    };
    const version = {
      id: versionId,
      templateId,
      companyId: vehicle.companyId,
      listingId: vehicle.listingId,
      vehicleId: vehicle.id,
      version: 1,
      layoutName: template.layoutName,
      ...definitions,
      checksum: seatMapChecksum({ layoutName: template.layoutName, ...definitions }),
      status: 'published',
      publishedAt: vehicle.createdAt || now,
      createdBy: 'canonical-bus-migration',
    };
    report.vehicles.templates += 1;
    report.vehicles.versions += 1;
    await upsert(SeatMapTemplate, { id: template.id }, template);
    await upsert(SeatMapVersion, { id: version.id }, version);
    await update(Vehicle, { id: vehicle.id }, {
      serviceType: 'bus',
      activeSeatMapTemplateId: template.id,
      activeSeatMapVersionId: version.id,
      rows: definitions.rows,
      cols: definitions.columns,
      totalSeats: definitions.totalSeats,
    });
  }
}

async function amountForRoute(route, listing) {
  const schedule = await TripSchedule.findOne({ routeId: route.id, basePrice: { $gt: 0 } }).sort({ departAt: 1 }).lean();
  return Math.max(0, number(schedule?.basePrice || listing?.priceFrom || listing?.price, 0));
}

async function migrateFares(listingMap) {
  const routes = await Route.find({ listingId: { $in: [...listingMap.keys()] }, status: { $ne: 'archived' } }).lean();
  for (const route of routes) {
    report.fares.inspected += 1;
    const listing = listingMap.get(route.listingId);
    const stops = await RouteStop.find({ routeId: route.id, status: 'active' }).sort({ stopOrder: 1 }).lean();
    if (stops.length < 2) continue;
    const amount = await amountForRoute(route, listing);
    const fareProductId = clean(route.activeFareProductId, 180) || deterministicId('fare-product', route.id, 'standard');
    const product = {
      id: fareProductId,
      companyId: route.companyId,
      listingId: route.listingId,
      routeId: route.id,
      name: 'Migrated standard fare',
      fareClass: 'standard',
      currency: clean(listing?.currency || 'UGX', 10).toUpperCase(),
      bookingFee: 0,
      refundable: false,
      changeable: false,
      baggageAllowanceKg: 0,
      status: amount > 0 ? 'active' : 'draft',
      createdBy: 'canonical-bus-migration',
    };
    report.fares.products += 1;
    await upsert(FareProduct, { id: product.id }, product);
    if (amount > 0) {
      const fare = {
        id: deterministicId('segment-fare', fareProductId, stops[0].id, stops[stops.length - 1].id),
        companyId: route.companyId,
        listingId: route.listingId,
        routeId: route.id,
        fareProductId,
        fromStopId: stops[0].id,
        toStopId: stops[stops.length - 1].id,
        fromOrder: number(stops[0].stopOrder, 0),
        toOrder: number(stops[stops.length - 1].stopOrder, stops.length - 1),
        amount,
        currency: product.currency,
        status: 'active',
      };
      report.fares.segmentFares += 1;
      await upsert(BusSegmentFare, { id: fare.id }, fare);
      await update(Route, { id: route.id }, { activeFareProductId: fareProductId });
    } else {
      report.fares.missingPrice.push({ routeId: route.id, listingId: route.listingId });
    }
  }
}

function publishSafe(schedule, vehicle, fareProduct) {
  const departAt = dateValue(schedule.departAt) || now;
  const driverAssigned = unique([...(schedule.driverIds || []), schedule.driverEmployeeId, schedule.driverUserId]).length > 0;
  return driverAssigned
    && fareProduct?.status === 'active'
    && clean(vehicle?.operatorPermitRef)
    && clean(vehicle?.inspectionRef)
    && clean(vehicle?.insuranceRef)
    && dateValidAfter(departAt, vehicle?.operatorPermitExpiresAt)
    && dateValidAfter(departAt, vehicle?.inspectionExpiresAt)
    && dateValidAfter(departAt, vehicle?.insuranceExpiresAt);
}

async function migrateDepartures(listingMap) {
  const schedules = await TripSchedule.find({ listingId: { $in: [...listingMap.keys()] }, status: { $ne: 'archived' } }).lean();
  for (const schedule of schedules) {
    report.departures.inspected += 1;
    const [route, vehicle] = await Promise.all([
      Route.findOne({ id: schedule.routeId, companyId: schedule.companyId }).lean(),
      Vehicle.findOne({ id: schedule.vehicleId, companyId: schedule.companyId }).lean(),
    ]);
    if (!route || !vehicle) continue;
    const [stops, segments, seatMapVersion] = await Promise.all([
      RouteStop.find({ routeId: route.id, status: 'active' }).sort({ stopOrder: 1 }).lean(),
      RouteSegment.find({ routeId: route.id, status: 'active' }).sort({ segmentOrder: 1 }).lean(),
      SeatMapVersion.findOne({ id: vehicle.activeSeatMapVersionId, status: 'published' }).lean(),
    ]);
    const fareProduct = await FareProduct.findOne({ id: route.activeFareProductId, status: { $in: ['active', 'draft'] } }).lean();
    const fullFare = fareProduct ? await BusSegmentFare.findOne({ fareProductId: fareProduct.id, fromStopId: stops[0]?.id, toStopId: stops[stops.length - 1]?.id, status: 'active' }).lean() : null;
    if (stops.length < 2 || segments.length !== stops.length - 1 || !seatMapVersion || !fareProduct) continue;
    const originalStatus = status(schedule.status);
    const requestedPublished = ['published', 'boarding', 'delayed', 'departed', 'arrived', 'completed'].includes(originalStatus);
    const safe = publishSafe(schedule, vehicle, fareProduct);
    const canonicalStatus = requestedPublished && safe ? originalStatus : 'draft';
    if (requestedPublished && !safe) report.departures.forcedDraft.push({ scheduleId: schedule.id, reason: 'Missing valid driver, fare, permit, inspection, or insurance' });
    const fareAmount = Math.max(0, number(fullFare?.amount || schedule.basePrice, 0));
    const patch = {
      originStopId: route.originStopId || stops[0].id,
      destinationStopId: route.destinationStopId || stops[stops.length - 1].id,
      routeVersion: Math.max(1, number(route.version, 1)),
      seatMapTemplateId: vehicle.activeSeatMapTemplateId,
      seatMapVersionId: seatMapVersion.id,
      fareProductId: fareProduct.id,
      routeSnapshot: { routeId: route.id, routeName: route.routeName, routeCode: route.routeCode, version: route.version || 1, timezone: route.timezone || 'Africa/Kampala', origin: stops[0], destination: stops[stops.length - 1], stops, segments },
      seatMapSnapshot: { versionId: seatMapVersion.id, templateId: seatMapVersion.templateId, version: seatMapVersion.version, checksum: seatMapVersion.checksum, layoutName: seatMapVersion.layoutName, rows: seatMapVersion.rows, columns: seatMapVersion.columns, totalSeats: seatMapVersion.totalSeats },
      fareSnapshot: { fareProductId: fareProduct.id, name: fareProduct.name, fareClass: fareProduct.fareClass, currency: fareProduct.currency, bookingFee: fareProduct.bookingFee || 0, refundable: !!fareProduct.refundable, changeable: !!fareProduct.changeable, baggageAllowanceKg: fareProduct.baggageAllowanceKg || 0, baseFare: fareAmount, source: fullFare ? 'migrated_full_route' : 'legacy_schedule' },
      basePrice: fareAmount,
      currency: fareProduct.currency,
      fareClass: fareProduct.fareClass,
      totalSeats: seatMapVersion.totalSeats,
      status: canonicalStatus,
      assignmentStatus: unique([...(schedule.driverIds || []), schedule.driverEmployeeId, schedule.driverUserId]).length ? 'assigned' : 'unassigned',
      inventoryReadyAt: now,
    };
    await update(TripSchedule, { id: schedule.id }, patch);
    report.departures.updated += 1;

    const legacySeats = await Seat.find({ scheduleId: schedule.id }).lean();
    const seatByNumber = new Map(legacySeats.map((seat) => [clean(seat.seatNumber, 20).toUpperCase(), seat]));
    let availableSeatCount = 0;
    for (const definition of seatMapVersion.seats || []) {
      const seatNumber = clean(definition.seatNumber, 20).toUpperCase();
      const old = seatByNumber.get(seatNumber);
      const lockedUntil = dateValue(old?.lockedUntil);
      const inventoryStatus = definition.enabled === false ? 'disabled' : canonicalSeatStatus(old?.status, !!lockedUntil && lockedUntil > now);
      if (inventoryStatus === 'available') availableSeatCount += 1;
      const compatibility = {
        id: clean(old?.id, 180) || deterministicId('seat', schedule.id, seatNumber),
        scheduleId: schedule.id,
        companyId: schedule.companyId,
        listingId: schedule.listingId,
        routeId: route.id,
        vehicleId: vehicle.id,
        seatMapVersionId: seatMapVersion.id,
        source: 'seat_map_projection',
        seatNumber,
        seatClass: definition.seatClass,
        seatType: definition.seatType,
        priceDelta: number(definition.priceDelta, 0),
        status: inventoryStatus === 'booked' ? 'taken' : inventoryStatus === 'held' ? 'locked' : inventoryStatus,
        blockedReason: definition.blockedReason || old?.blockedReason || '',
        lockedUntil: inventoryStatus === 'held' ? lockedUntil : null,
        lockId: inventoryStatus === 'held' ? clean(old?.lockId, 180) : '',
        bookingRef: inventoryStatus === 'booked' || inventoryStatus === 'checked_in' || inventoryStatus === 'no_show' ? clean(old?.bookingRef, 180) : '',
        bookingId: inventoryStatus === 'booked' || inventoryStatus === 'checked_in' || inventoryStatus === 'no_show' ? clean(old?.bookingId, 180) : '',
        passengerName: clean(old?.passengerName, 180),
        passengerPhone: clean(old?.passengerPhone, 80),
        passengerEmail: clean(old?.passengerEmail, 254).toLowerCase(),
      };
      await upsert(Seat, { scheduleId: schedule.id, seatNumber }, compatibility);
      for (const segment of segments) {
        const row = {
          id: deterministicId('bus-seat-segment', schedule.id, seatNumber, segment.id),
          companyId: schedule.companyId,
          listingId: schedule.listingId,
          routeId: route.id,
          scheduleId: schedule.id,
          vehicleId: vehicle.id,
          seatMapVersionId: seatMapVersion.id,
          seatNumber,
          seatClass: definition.seatClass,
          priceDelta: number(definition.priceDelta, 0),
          segmentId: segment.id,
          segmentOrder: segment.segmentOrder,
          fromStopId: segment.fromStopId,
          toStopId: segment.toStopId,
          status: inventoryStatus,
          holdId: inventoryStatus === 'held' ? clean(old?.lockId, 180) : '',
          lockedUntil: inventoryStatus === 'held' ? lockedUntil : null,
          bookingId: clean(old?.bookingId, 180),
          blockedReason: definition.blockedReason || old?.blockedReason || '',
        };
        report.departures.inventoryRows += 1;
        await upsert(BusSeatSegmentInventory, { id: row.id }, row);
      }
    }
    await update(TripSchedule, { id: schedule.id }, { availableSeats: availableSeatCount });
  }
}

function bookingRecordStatus(booking = {}) {
  const current = status(booking.bookingStatus);
  if (current === 'refunded' || status(booking.paymentStatus) === 'refunded') return 'refunded';
  if (['cancelled', 'failed'].includes(current) || status(booking.paymentStatus) === 'failed') return 'cancelled';
  if (current === 'completed') return 'completed';
  if (['in_progress', 'checked_in', 'boarding'].includes(current) || status(booking.checkInStatus) === 'checked_in') return 'in_progress';
  if (status(booking.paymentStatus) === 'successful' || current === 'confirmed') return 'confirmed';
  return dateValue(booking.lockedUntil)?.getTime() > now.getTime() ? 'awaiting_payment' : 'expired';
}
function reservationStatus(itemStatus) {
  if (itemStatus === 'in_progress') return 'boarding';
  return itemStatus;
}
function ticketStatus(itemStatus) {
  if (['confirmed', 'in_progress', 'completed'].includes(itemStatus)) return 'valid';
  if (itemStatus === 'refunded') return 'refunded';
  if (itemStatus === 'cancelled') return 'cancelled';
  if (itemStatus === 'expired') return 'voided';
  return 'pending_payment';
}
function checkInStatus(booking = {}, leg = {}) {
  const value = status(leg.checkInStatus || booking.checkInStatus);
  return ['boarding', 'checked_in', 'no_show', 'cancelled'].includes(value) ? value : 'not_checked';
}
function legCandidates(booking = {}) {
  const candidates = [];
  for (const leg of Array.isArray(booking.bookingLegs) ? booking.bookingLegs : []) if (leg?.scheduleId) candidates.push(leg);
  for (const leg of Array.isArray(booking.ticketLegs) ? booking.ticketLegs : []) if (leg?.scheduleId) candidates.push(leg);
  for (const item of Array.isArray(booking.bookingItems) ? booking.bookingItems : []) if (item?.scheduleId) candidates.push(item);
  if (booking.scheduleId) candidates.push({ scheduleId: booking.scheduleId, legType: 'outbound' });
  const map = new Map();
  for (const candidate of candidates) {
    const key = clean(candidate.scheduleId, 180);
    if (!key) continue;
    map.set(key, { ...(map.get(key) || {}), ...candidate, scheduleId: key });
  }
  return [...map.values()];
}
function seatsForLeg(booking = {}, leg = {}, passengers = []) {
  const values = [];
  for (const ticket of Array.isArray(booking.ticketLegs) ? booking.ticketLegs : []) if (!ticket.scheduleId || ticket.scheduleId === leg.scheduleId) values.push(ticket.seatNumber);
  for (const item of Array.isArray(booking.bookingItems) ? booking.bookingItems : []) if (!item.scheduleId || item.scheduleId === leg.scheduleId) values.push(item.seatNumber, ...(item.selectedSeats || []));
  values.push(leg.seatNumber, ...(asArray(leg.seatNumbers || leg.selectedSeats || [])));
  for (const passenger of passengers) if (!passenger.scheduleId || passenger.scheduleId === leg.scheduleId) values.push(passenger.seatNumber || passenger.seatOrRoom);
  return unique(values).map((value) => value.toUpperCase());
}

async function migrateBookings(listingMap) {
  const bookings = await Booking.find({ serviceType: 'bus', listingId: { $in: [...listingMap.keys()] } }).lean();
  for (const booking of bookings) {
    report.bookings.inspected += 1;
    if (await BookingItem.exists({ bookingId: booking.id, serviceType: 'bus' })) continue;
    const legs = legCandidates(booking);
    if (!legs.length) {
      report.bookings.unresolved.push({ bookingRef: booking.bookingRef, reason: 'No schedule/leg reference' });
      continue;
    }
    let passengers = await Passenger.find({ bookingRef: booking.bookingRef }).sort({ passengerIndex: 1 }).lean();
    if (!passengers.length) {
      passengers = (booking.passengers || []).map((passenger, index) => ({
        ...passenger,
        id: clean(passenger.id, 180) || deterministicId('passenger', booking.bookingRef, index),
        bookingId: booking.id,
        bookingRef: booking.bookingRef,
        companyId: booking.companyId,
        listingId: booking.listingId,
        passengerIndex: index,
        fullName: clean(passenger.fullName || passenger.name, 180),
        seatNumber: clean(passenger.seatNumber || passenger.seatOrRoom, 20).toUpperCase(),
      }));
      for (const passenger of passengers) await upsert(Passenger, { bookingRef: booking.bookingRef, passengerIndex: passenger.passengerIndex }, passenger);
    }
    const itemStatus = bookingRecordStatus(booking);
    const itemSummaries = [];
    const legSummaries = [];
    const ticketSummaries = [];
    let migratedLegs = 0;
    for (let legIndex = 0; legIndex < legs.length; legIndex += 1) {
      const leg = legs[legIndex];
      const schedule = await TripSchedule.findOne({ id: leg.scheduleId, companyId: booking.companyId }).lean();
      if (!schedule?.routeId || !schedule.seatMapVersionId || !schedule.fareProductId) {
        report.bookings.unresolved.push({ bookingRef: booking.bookingRef, scheduleId: leg.scheduleId, reason: 'Departure is not canonical' });
        continue;
      }
      const segments = await RouteSegment.find({ routeId: schedule.routeId, status: 'active' }).sort({ segmentOrder: 1 }).lean();
      const originStopId = clean(leg.originStopId || schedule.originStopId, 180);
      const destinationStopId = clean(leg.destinationStopId || schedule.destinationStopId, 180);
      const originSegment = segments.find((segment) => segment.fromStopId === originStopId) || segments[0];
      const destinationSegment = [...segments].reverse().find((segment) => segment.toStopId === destinationStopId) || segments[segments.length - 1];
      const selectedSegments = segments.filter((segment) => segment.segmentOrder >= originSegment?.segmentOrder && segment.segmentOrder <= destinationSegment?.segmentOrder);
      const seatNumbers = seatsForLeg(booking, leg, passengers);
      if (!selectedSegments.length || !seatNumbers.length) {
        report.bookings.unresolved.push({ bookingRef: booking.bookingRef, scheduleId: schedule.id, reason: 'Missing route segments or seats' });
        continue;
      }
      const legPassengers = passengers.slice(0, seatNumbers.length);
      if (legPassengers.length !== seatNumbers.length) {
        report.bookings.unresolved.push({ bookingRef: booking.bookingRef, scheduleId: schedule.id, reason: 'Passenger/seat count mismatch' });
        continue;
      }
      const bookingItemId = deterministicId('booking-item', booking.id, schedule.id);
      const reservationId = deterministicId('bus-reservation', booking.id, schedule.id);
      const holdId = deterministicId('inventory-hold', booking.id, schedule.id);
      const total = Math.max(0, number(booking.pricing?.total || booking.grossAmount, 0) / Math.max(1, legs.length));
      const currency = clean(booking.pricing?.currency || schedule.currency || 'UGX', 10).toUpperCase();
      const priceSnapshot = { ...(schedule.fareSnapshot || {}), migratedTotal: total, currency, source: 'legacy_booking_migration' };
      const holdStatus = ['confirmed', 'in_progress', 'completed'].includes(itemStatus) ? 'consumed' : itemStatus === 'awaiting_payment' ? 'active' : 'expired';
      const holdExpiry = itemStatus === 'awaiting_payment' ? dateValue(booking.lockedUntil) : dateValue(booking.createdAt) || now;
      const hold = {
        id: holdId,
        holdType: 'bus_segment_seat',
        serviceType: 'bus',
        listingId: booking.listingId,
        companyId: booking.companyId,
        scheduleId: schedule.id,
        routeId: schedule.routeId,
        seatNumbers,
        originStopId,
        destinationStopId,
        originOrder: originSegment?.fromOrder || 0,
        destinationOrder: destinationSegment?.toOrder || segments.length,
        segmentIds: selectedSegments.map((segment) => segment.id),
        itemCount: seatNumbers.length * selectedSegments.length,
        token: hashToken(deterministicId('migrated-hold-token', booking.bookingRef, schedule.id)),
        status: holdStatus,
        expiresAt: holdExpiry || now,
        lockedUntil: holdStatus === 'active' ? holdExpiry : null,
        consumedAt: holdStatus === 'consumed' ? dateValue(booking.updatedAt || booking.createdAt) || now : null,
        consumedBy: holdStatus === 'consumed' ? 'canonical-bus-migration' : '',
        bookingId: booking.id,
        bookingRef: booking.bookingRef,
        createdBy: 'canonical-bus-migration',
        source: 'legacy_booking_migration',
      };
      await upsert(InventoryHold, { id: hold.id }, hold);
      const item = {
        id: bookingItemId,
        bookingId: booking.id,
        bookingRef: booking.bookingRef,
        companyId: booking.companyId,
        listingId: booking.listingId,
        serviceType: 'bus',
        domainReservationId: reservationId,
        quantity: seatNumbers.length,
        pricing: { subtotal: total, fees: 0, addonTotal: 0, total, currency, addons: [] },
        priceSnapshot,
        policySnapshot: { migrated: true },
        status: itemStatus,
      };
      const reservation = {
        id: reservationId,
        bookingItemId,
        bookingId: booking.id,
        bookingRef: booking.bookingRef,
        companyId: booking.companyId,
        listingId: booking.listingId,
        routeId: schedule.routeId,
        scheduleId: schedule.id,
        vehicleId: schedule.vehicleId,
        seatMapVersionId: schedule.seatMapVersionId,
        fareProductId: schedule.fareProductId,
        originStopId,
        destinationStopId,
        originOrder: hold.originOrder,
        destinationOrder: hold.destinationOrder,
        segmentIds: hold.segmentIds,
        passengerCount: seatNumbers.length,
        holdId,
        priceSnapshot,
        routeSnapshot: schedule.routeSnapshot || {},
        status: reservationStatus(itemStatus),
        confirmedAt: ['confirmed', 'in_progress', 'completed'].includes(itemStatus) ? dateValue(booking.updatedAt || booking.createdAt) || now : null,
        cancelledAt: ['cancelled', 'refunded'].includes(itemStatus) ? dateValue(booking.cancelledAt || booking.updatedAt) || now : null,
        cancellationReason: clean(booking.cancelReason || booking.cancellationReason, 500),
      };
      await upsert(BookingItem, { id: item.id }, item);
      await upsert(BusReservation, { id: reservation.id }, reservation);
      report.bookings.items += 1;
      report.bookings.reservations += 1;
      const assignmentSummaries = [];
      for (let index = 0; index < seatNumbers.length; index += 1) {
        const passenger = legPassengers[index];
        const seatNumber = seatNumbers[index];
        const assignmentId = deterministicId('bus-seat-assignment', reservationId, passenger.id, seatNumber);
        const oldTicket = (booking.ticketLegs || []).find((ticket) => (!ticket.scheduleId || ticket.scheduleId === schedule.id) && clean(ticket.seatNumber, 20).toUpperCase() === seatNumber) || {};
        const busTicketId = clean(oldTicket.id, 180) || deterministicId('bus-ticket', reservationId, passenger.id, seatNumber);
        const oldQr = clean(oldTicket.qrToken || booking.qrCodeValue, 1000);
        const assignment = {
          id: assignmentId,
          reservationId,
          bookingItemId,
          bookingId: booking.id,
          bookingRef: booking.bookingRef,
          passengerId: passenger.id,
          companyId: booking.companyId,
          scheduleId: schedule.id,
          seatNumber,
          originStopId,
          destinationStopId,
          segmentIds: hold.segmentIds,
          status: itemStatus === 'refunded' ? 'refunded' : itemStatus === 'cancelled' || itemStatus === 'expired' ? 'cancelled' : checkInStatus(booking, oldTicket) === 'checked_in' ? 'checked_in' : checkInStatus(booking, oldTicket) === 'no_show' ? 'no_show' : itemStatus === 'awaiting_payment' ? 'held' : 'confirmed',
        };
        const ticket = {
          id: busTicketId,
          ticketNumber: clean(oldTicket.ticketNumber, 80) || `MIG-${crypto.createHash('sha1').update(`${booking.bookingRef}|${schedule.id}|${seatNumber}`).digest('hex').slice(0, 12).toUpperCase()}`,
          bookingId: booking.id,
          bookingRef: booking.bookingRef,
          bookingItemId,
          reservationId,
          seatAssignmentId: assignmentId,
          passengerId: passenger.id,
          companyId: booking.companyId,
          listingId: booking.listingId,
          routeId: schedule.routeId,
          scheduleId: schedule.id,
          seatNumber,
          originStopId,
          destinationStopId,
          ...(oldQr ? { qrTokenHash: clean(oldTicket.qrTokenHash, 200) || hashToken(`${oldQr}|${schedule.id}|${passenger.id}`), qrTokenPreview: `${oldQr.slice(0, 6)}…${oldQr.slice(-4)}` } : {}),
          status: ticketStatus(itemStatus),
          checkInStatus: checkInStatus(booking, oldTicket),
          issuedAt: ['confirmed', 'in_progress', 'completed'].includes(itemStatus) ? dateValue(oldTicket.issuedAt || booking.updatedAt || booking.createdAt) || now : null,
          checkedInAt: checkInStatus(booking, oldTicket) === 'checked_in' ? dateValue(oldTicket.checkedInAt || booking.checkedInAt) || now : null,
          checkedInBy: clean(oldTicket.checkedInBy || booking.checkedInBy, 180),
          noShowAt: checkInStatus(booking, oldTicket) === 'no_show' ? dateValue(oldTicket.noShowAt || booking.noShowAt) || now : null,
          cancelledAt: ['cancelled', 'refunded', 'expired'].includes(itemStatus) ? dateValue(booking.cancelledAt || booking.updatedAt) || now : null,
        };
        await upsert(BusSeatAssignment, { id: assignment.id }, assignment);
        await upsert(BusTicket, { id: ticket.id }, ticket);
        report.bookings.assignments += 1;
        report.bookings.tickets += 1;
        assignmentSummaries.push(assignment);
        ticketSummaries.push({ ...oldTicket, id: ticket.id, ticketNumber: ticket.ticketNumber, legType: leg.legType || (legIndex ? 'return' : 'outbound'), legIndex, scheduleId: schedule.id, routeId: schedule.routeId, passengerId: passenger.id, passengerName: passenger.fullName, seatNumber, originStopId, destinationStopId, status: ticket.status, checkInStatus: ticket.checkInStatus });
        for (const segment of selectedSegments) {
          const holdItem = {
            id: deterministicId('hold-item', holdId, seatNumber, segment.id),
            holdId,
            resourceType: 'bus_seat_segment',
            resourceKey: `bus:${schedule.id}:${seatNumber}:${segment.id}`,
            serviceType: 'bus',
            companyId: booking.companyId,
            listingId: booking.listingId,
            scheduleId: schedule.id,
            seatNumber,
            routeId: schedule.routeId,
            segmentId: segment.id,
            segmentOrder: segment.segmentOrder,
            originStopId,
            destinationStopId,
            selectedLabel: `${seatNumber} / segment ${segment.segmentOrder + 1}`,
            status: holdStatus === 'consumed' ? 'consumed' : holdStatus === 'active' ? 'active' : 'expired',
            expiresAt: holdExpiry || now,
            consumedAt: holdStatus === 'consumed' ? hold.consumedAt : null,
            consumedBy: holdStatus === 'consumed' ? 'canonical-bus-migration' : '',
            bookingId: booking.id,
            bookingRef: booking.bookingRef,
          };
          await upsert(InventoryHoldItem, { id: holdItem.id }, holdItem);
          if (apply) {
            const inventoryPatch = ['confirmed', 'in_progress', 'completed'].includes(itemStatus)
              ? { status: ticket.checkInStatus === 'checked_in' ? 'checked_in' : ticket.checkInStatus === 'no_show' ? 'no_show' : 'booked', bookingId: booking.id, bookingItemId, reservationId, ticketId: ticket.id, passengerId: passenger.id, holdId: '', lockedUntil: null }
              : itemStatus === 'awaiting_payment'
                ? { status: 'held', holdId, lockedUntil: holdExpiry, bookingId: booking.id, bookingItemId, reservationId, passengerId: passenger.id }
                : { status: 'available', holdId: '', lockedUntil: null, bookingId: '', bookingItemId: '', reservationId: '', ticketId: '', passengerId: '' };
            await BusSeatSegmentInventory.updateOne({ scheduleId: schedule.id, seatNumber, segmentId: segment.id }, { $set: { ...inventoryPatch, updatedAt: now } });
          }
        }
      }
      itemSummaries.push({ id: item.id, serviceType: 'bus', domainReservationId: reservation.id, scheduleId: schedule.id, status: item.status, pricing: item.pricing });
      legSummaries.push({ legType: leg.legType || (legIndex ? 'return' : 'outbound'), legIndex, bookingItemId: item.id, reservationId: reservation.id, scheduleId: schedule.id, routeId: schedule.routeId, vehicleId: schedule.vehicleId, originStopId, destinationStopId, seatNumbers, status: reservation.status });
      migratedLegs += 1;
    }
    if (migratedLegs) {
      await update(Booking, { id: booking.id }, { bookingItems: itemSummaries, bookingLegs: legSummaries, ticketLegs: ticketSummaries, tripType: migratedLegs > 1 ? 'round_trip' : booking.tripType || 'one_way' });
      report.bookings.migrated += 1;
    }
  }
}

async function verify(listingIds) {
  const future = { $gt: now };
  const activeBookingStatuses = { $nin: ['cancelled', 'refunded', 'failed', 'expired'] };
  return {
    routesMissingStops: await Route.countDocuments({ listingId: { $in: listingIds }, status: 'active', $or: [{ originStopId: { $exists: false } }, { originStopId: '' }, { destinationStopId: { $exists: false } }, { destinationStopId: '' }] }),
    routesMissingSegments: await Route.countDocuments({ listingId: { $in: listingIds }, status: 'active', segmentCount: { $lt: 1 } }),
    vehiclesMissingSeatMap: await Vehicle.countDocuments({ listingId: { $in: listingIds }, status: 'active', $or: [{ activeSeatMapVersionId: { $exists: false } }, { activeSeatMapVersionId: '' }] }),
    routesMissingFare: await Route.countDocuments({ listingId: { $in: listingIds }, status: 'active', $or: [{ activeFareProductId: { $exists: false } }, { activeFareProductId: '' }] }),
    futureDeparturesMissingCanonicalReferences: await TripSchedule.countDocuments({ listingId: { $in: listingIds }, departAt: future, status: { $ne: 'archived' }, $or: [{ seatMapVersionId: { $exists: false } }, { seatMapVersionId: '' }, { fareProductId: { $exists: false } }, { fareProductId: '' }, { originStopId: { $exists: false } }, { originStopId: '' }, { destinationStopId: { $exists: false } }, { destinationStopId: '' }] }),
    activeBookingsMissingCanonicalItem: await Booking.countDocuments({ serviceType: 'bus', listingId: { $in: listingIds }, bookingStatus: activeBookingStatuses, id: { $nin: await BookingItem.distinct('bookingId', { serviceType: 'bus' }) } }),
  };
}

async function run() {
  const connection = await connectDb();
  if (!connection || !mongoose.connection.db) throw new Error('MongoDB connection is required for this migration');
  const listings = await busListings();
  const listingMap = new Map(listings.map((listing) => [listing.id, listing]));
  const listingIds = [...listingMap.keys()];
  const before = await verify(listingIds);
  await migrateRoutes(listingMap);
  await migrateVehicles(listingMap);
  await migrateFares(listingMap);
  await migrateDepartures(listingMap);
  await migrateBookings(listingMap);
  const after = apply ? await verify(listingIds) : before;
  console.log(JSON.stringify({ ...report, busListings: listingIds.length, before, after }, null, 2));
  if (apply) {
    const hardFailures = Object.entries(after).filter(([, count]) => count > 0);
    if (hardFailures.length || report.bookings.unresolved.length) {
      throw new Error(`Canonical bus migration requires manual reconciliation: ${JSON.stringify({ hardFailures, unresolvedBookings: report.bookings.unresolved })}`);
    }
  }
}

run()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect().catch(() => {});
  });
