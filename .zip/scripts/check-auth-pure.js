'use strict';

const assert = require('assert');
const { validatePassword, passwordByteLength, MAX_PASSWORD_BYTES } = require('../src/services/auth/passwordPolicy');
const { employeePermissions, normalizePermissions, roleHasPermission } = require('../src/config/accessControl');

const checks = [];
function check(label, fn) {
  try { fn(); checks.push({ label, ok: true }); }
  catch (error) { checks.push({ label, ok: false, error: error.message }); }
}
function rejects(label, fn, code) {
  check(label, () => {
    let thrown = null;
    try { fn(); } catch (error) { thrown = error; }
    assert(thrown, 'Expected rejection');
    if (code) assert.strictEqual(thrown.code, code);
  });
}

check('valid password accepted', () => assert.strictEqual(validatePassword('SecurePass123'), 'SecurePass123'));
check('UTF-8 byte length is measured', () => assert.strictEqual(passwordByteLength('é'), 2));
rejects('password below minimum rejected', () => validatePassword('A1short'), 'invalid_password_policy');
rejects('password without a number rejected', () => validatePassword('OnlyLettersHere'), 'invalid_password_policy');
rejects('password over bcrypt byte limit rejected', () => validatePassword(`A1${'x'.repeat(MAX_PASSWORD_BYTES)}`), 'invalid_password_policy');
rejects('multi-byte password over bcrypt byte limit rejected', () => validatePassword(`A1${'é'.repeat(36)}`), 'invalid_password_policy');
check('legacy staff permissions canonicalize', () => assert.deepStrictEqual(normalizePermissions(['view_bookings', 'scanner']), ['booking.view', 'checkin.scan']));
check('check-in role defaults are canonical', () => assert(employeePermissions('Check-in agent', []).includes('checkin.scan')));
check('driver defaults are canonical', () => assert.deepStrictEqual(employeePermissions('Driver', []), ['manifest.view', 'checkin.assist', 'trip.status.update', 'incident.create']));
check('company owner wildcard permission matches', () => assert(roleHasPermission('company_admin', 'booking.view')));
check('customer cannot gain company permissions', () => assert.strictEqual(roleHasPermission('customer', 'company.manage'), false));

const failed = checks.filter((row) => !row.ok);
console.log(JSON.stringify({ passed: checks.length - failed.length, failed: failed.length, checks }, null, 2));
if (failed.length) process.exitCode = 1;
