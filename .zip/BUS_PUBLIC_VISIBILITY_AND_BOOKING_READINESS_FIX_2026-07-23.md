# Bus Public Visibility and Booking Readiness Fix

Date: 2026-07-23

## Problem

Changing a bus listing from Draft to Active returned:

> Bus service cannot be activated: Publish at least one dated departure

The platform treated two independent states as one:

1. Whether the bus service profile may be shown publicly.
2. Whether customers may book a specific future departure.

That prevented a complete bus service profile from appearing on the marketplace until a dated departure had already been published.

## Corrected behavior

### Public listing readiness

A bus service can be activated and published publicly when these public-profile requirements are complete:

- Company is active and verified.
- At least one public bus/service image exists.
- Public operations phone exists.
- Operator licence reference exists.
- Baggage policy exists.
- Cancellation/refund policy exists.

The listing is then stored as:

- `status: active`
- `releaseStatus: published`
- `publication.public: true`
- `bookable: false` when no valid future departure exists

### Booking readiness

`bookable` becomes true only when the public profile is ready and the bus has:

- An active route.
- An active vehicle.
- Valid permit, inspection and insurance records.
- An active fare product.
- A future published departure, or a currently boarding/delayed departure that has not ended.

Past departures do not keep a listing bookable.

### Dashboard behavior

- Active bus without a future departure displays `Public · schedule pending`.
- The listing remains visible on the homepage and other public catalog pages.
- `Book now` stays disabled until booking readiness is complete.
- A direct calendar action opens Schedules so the company can create and publish the dated departure.
- Success messages now distinguish “published publicly” from “open for booking.”

## Existing data

No database migration is required. After deploying this version, edit the draft listing, select Active, and save again. The existing listing will be published publicly if its public profile is complete.

To enable booking, create and publish a future departure under Schedules & Fares.

## Verification

- Bus public/booking status checks: 35/35 passed.
- Main-page bus visibility checks: 19/19 passed.
- Public bus and vehicle-template checks: 9/9 passed.
- Smart bus form checks: 30/30 passed.
- Bus form contracts: 45/45 passed.
- Live departure seat-map checks: 47/47 passed.
- Bus architecture checks: 81/81 passed.
- Multipart/browser CSRF checks: 46/46 passed.
- Route security, architecture/security and entity-relationship audits passed.
- All JavaScript files parsed successfully.

The full dependency-loaded test suite was not run because the package registry returned HTTP 503 while installing dependencies. The partial `node_modules` directory was removed before packaging.
