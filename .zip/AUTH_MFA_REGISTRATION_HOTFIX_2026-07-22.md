# Classic Trip Super Admin MFA and Partner Registration Hotfix

## Requested corrections

1. Temporarily disable MFA for Super Admin login.
2. Correct partner signup returning a false or unexplained `409 account exists` response.

## Super Admin MFA

MFA enforcement is controlled by one environment flag:

```env
PLATFORM_MFA_ENABLED=false
```

With the delivered value:

- Super Admin and delegated platform administrators sign in directly.
- Web and API MFA middleware bypass setup and challenge enforcement.
- Direct visits to MFA setup/challenge routes return to normal login/dashboard flow.
- Existing encrypted MFA configuration remains stored for later activation.
- The administration UI displays **Temporarily disabled**.

To activate it later:

```env
PLATFORM_MFA_ENABLED=true
MFA_ENCRYPTION_KEY=<strong independent random secret>
```

Restart the application. Administrators without configured MFA will be sent to setup, and configured administrators will receive the normal login challenge.

## Actual cause of the false partner duplicate

The old registration code treated **every MongoDB duplicate-key error (`11000`) occurring after user creation** as an email collision. Partner signup creates a user and then provisions a company, wallet and verification records. If company provisioning hit a duplicate company ID, slug, stale counter, or another organization key, the code:

1. Rolled the new user back.
2. Returned “email or phone already exists.”
3. Left no new user in the database.

That exactly explains why the UI reported an existing account while the users collection appeared empty.

## Registration correction

The repaired boundary now:

- Preserves exact lowercased email aliases instead of removing Gmail dots or `+alias` suffixes.
- Normalizes phone formatting and compares equivalent international representations.
- Checks email and phone independently and identifies the actual conflicting identity field.
- Classifies MongoDB duplicate keys by `keyPattern`/`keyValue` rather than assuming email.
- Uses insert-only creation for new users and companies; creation can no longer overwrite an existing record through an upsert when a counter is stale.
- Retries user/company ID and company slug collisions safely, with collision-resistant UUID fallback.
- Returns non-identity organization conflicts as `registration_conflict` or `company_registration_conflict`, inside the existing partner UI.
- Redirects real identity conflicts into the existing signup panel instead of returning raw JSON.
- Disables the submit button after valid submission to reduce double-submit races.
- Logs the actual connected MongoDB database and conflict classification without logging submitted contact values.
- Keeps the security rule that one email or phone belongs to one login account. Super Admin contact details therefore cannot also create a second partner login.

For legacy databases, align numeric counters after backup:

```bash
npm run migrate:seed-id-counters
```

The application also retries safely at runtime, so stale counters no longer produce a false email error.

## Verification

- Auth hotfix checks: **16/16 passed**.
- Auth/onboarding checks: **130/130 passed**.
- Dependency-free auth behavior checks: **11/11 passed**.
- Bus blueprint checks: **81/81 passed**.
- Architecture/security, route-security, entity-relationship, dashboard-scope, dashboard static smoke and acceptance mapping gates passed.
- All JavaScript source files parse successfully.

The connected Jest/MongoDB integration suite still requires installed dependencies and a transaction-capable MongoDB test environment.
