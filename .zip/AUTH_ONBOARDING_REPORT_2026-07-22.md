# Classic Trip Authentication and All-Role Onboarding Correction Report

## Result

The earlier bus-stage archive preserved an incomplete authentication implementation. It did **not** provide a complete partner, promoter, staff, driver, and administrator onboarding lifecycle. This release corrects that gap while preserving the existing Classic Trip login cards, signup panels, dashboards, buttons, forms, spacing, colors, and navigation.

## Partner signup blocker corrected

The previous flow created a partner owner in a pending state and then rejected pending users at login. It also contained other disconnected signup paths and missing CSRF fields.

The corrected flow now:

1. Creates a password-protected, active company-owner account.
2. Creates exactly one new pending company; public input cannot attach the owner to an existing company.
3. Regenerates the browser session after registration.
4. Redirects the owner into the existing company profile/onboarding workspace.
5. Allows profile, legal document, payout, support, draft bus setup, email verification, phone OTP, and verification submission.
6. Blocks publication, live bookings, scanner/check-in, payment/refund operations, staff/driver invitations, and payouts until company approval.
7. Uses the same canonical registration service from the direct auth form and pricing onboarding flow.
8. Prevents existing-account takeover and passwordless owner provisioning.
9. Lets an owner add or replace the login email/phone in the existing company profile UI; changed contacts invalidate stale approval and require fresh verification.

## Role lifecycle implemented

### Customer

- Public self-registration or Google sign-in.
- Customer account only; no provider or administrative authority.

### Company owner / partner

- Public self-registration or approved signed invitation.
- Active account with a pending, non-operational company.
- Email, phone, legal documents, payout identity, support contacts, agreement, and service-readiness checklist.
- Rejected applications remain in a correction workspace instead of being permanently locked out.

### Promoter

- Public registration or signed invitation.
- Restricted referral/profile workspace while verification is pending.
- Email, phone, identity, payout, terms, and anti-fraud training checklist.
- Offline sales and withdrawals are blocked at both route and service layers until approval.

### Company staff

- Invitation-only from an active, verified company.
- Signed invitation acceptance creates password credentials and an accepted company membership.
- Branch, listing, schedule, service, and permission scopes are canonical and tenant-filtered.
- Generic role editing cannot activate an unaccepted/passwordless membership.

### Driver

- Administrator-approved signed invitation; normal staff invitation cannot masquerade as a driver.
- Dedicated `driver` account role, accepted credentials, verified email, verified phone, licence document, identity document, approved company, safety clearance, and all required permissions.
- Required permissions are one canonical set: `manifest.view`, `checkin.assist`, `trip.status.update`, and `incident.create`.
- Assignment rechecks the actual driver account, active membership, safety clearance, company verification, and all canonical permissions at the service boundary.
- Contact changes suspend assignments and return the driver to verification.

### Delegated platform administrators

- Invitation-only: `admin`, `content_admin`, `support_admin`, `finance_admin`, and `operations_admin`.
- Real TOTP MFA remains implemented with encrypted secret storage, hashed recovery codes, fresh-session enforcement, and challenge attempt limits. Enforcement is temporarily disabled by `PLATFORM_MFA_ENABLED=false` and can be re-enabled without changing the UI or account model.
- `super_admin` is bootstrap/provisioning-only and is not exposed in normal invitation UI.

## Security and reliability corrections

- CSRF fields added to login, customer signup, promoter signup, partner signup, support, password recovery, invitations, phone verification, and MFA forms.
- Central password policy enforces 8 or more characters, a letter, a number, and the bcrypt-safe maximum of 72 UTF-8 bytes.
- Invitation, email-verification, password-reset, and phone OTP secrets are redacted from durable notification history.
- Invitation tokens are random and stored only as hashes.
- Phone OTP uses cryptographic generation, hashed storage, constant-time comparison, attempt limits, expiry, and resend throttling.
- Account state and business verification are separate so onboarding access does not accidentally grant operational access.
- Company scope is derived from the authenticated identity; submitted company IDs cannot switch tenants.
- Contact changes fail closed and invalidate stale email/phone evidence.
- Legacy passwordless privileged accounts and unsafe driver assignments are handled by the migration.
- Canonical permission aliases migrate old labels without allowing old UI names to become authorization truth.
- Failed public registration compensates created account/company/wallet/review records. Duplicate keys are classified by their real collection field, and new user/company creation is insert-only so stale counters cannot overwrite existing records or masquerade as an email conflict.

## UI preservation

No second authentication design or dashboard was created. Changes were made inside the existing UI:

- Existing role selector and partner form.
- Existing partner onboarding and company profile sections.
- Existing promoter profile and verification section.
- Existing invitation acceptance page.
- Existing staff/driver modals and dashboard tables.
- Existing MFA and phone-verification cards.

Only fields, help text, validation, role options, selectors, and backend behavior were adjusted.

## Existing-data migration

Run after a database backup and first review the dry run:

```bash
npm run migrate:auth-onboarding
npm run migrate:auth-onboarding:apply
```

The migration covers:

- Pending partner/promoter onboarding access.
- Rejected-company correction mode.
- Passwordless staff/driver blocking.
- Signed-invitation acceptance timestamps.
- Canonical employee permission labels.
- Unverified driver assignment suspension.
- Driver phone and verification state.
- Company publication restrictions.
- Administrator MFA repair.
- Legacy plaintext invitation-token hashing/removal.

## Verification completed in this artifact environment

- Authentication/onboarding structural gate: **130/130 passed**.
- Dependency-free auth behavior checks: **11/11 passed**.
- Canonical bus gate: **81/81 passed**.
- JavaScript parsing: **470 files checked, 0 failures**.
- Architecture/security gate: passed.
- Route-security audit: passed.
- Entity/relationship UI audit: passed.
- Dashboard scope validation: passed.
- Static dashboard route smoke validation: passed.
- Package and package-lock root metadata: consistent.
- Cleanup scan: no dependency folders, Git metadata, logs, temporary files, backups, or cache junk.

## Not executed in the offline artifact environment

The following remain mandatory in connected CI/staging because dependencies and the package registry were unavailable here:

- `npm ci`.
- Jest runtime and integration suite.
- Application boot against a transaction-capable MongoDB replica set.
- Live SMTP, SMS, Google OAuth, and payment-provider sandbox certification.
- Current `npm audit --omit=dev` advisory scan.
- Load, concurrency, DAST, and penetration testing.

No software can truthfully be guaranteed permanently vulnerability-proof. This release applies fail-closed authorization, tenant isolation, configurable MFA enforcement, hashed one-time secrets, verified state machines, audit records, transactions/idempotency where supported, and automated release gates.

## Runtime wallet provisioning follow-up

Partner account creation now completes its initial company wallet atomically without conflicting `$setOnInsert`/`$inc` paths. A failed downstream provisioning attempt is still compensated, so no half-created account remains. The supplied phone collision was a genuine match to the Super Admin in database `test`; a safe `npm run admin:sync-contact` command is included when that seeded contact needs to be moved.
