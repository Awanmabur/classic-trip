# Classic Trip — All Bus Forms Save Hotfix

Date: 2026-07-22

## What the message meant

`We could not save this action. Please review the form and try again.` was the global fallback for an unhandled server-side `500` response. It was not proof of another missing CSRF token.

The submit-time CSRF synchronization applies to all dynamically created POST forms, including multipart listing and vehicle forms. The remaining failure came from persistence and relationship defects after the request passed CSRF validation.

## Root causes fixed

1. **Route schema failure:** canonical bus routes were created with `version: 0`, but the MongoDB Route schema requires a minimum version of `1`.
2. **Transaction visibility failure:** route rebuilding queried the new route without the active MongoDB session, so a real Atlas transaction could not see its own uncommitted route.
3. **Outbox schema failure:** publishing listings/departures, changing trip status, confirming bookings, holding inventory, check-in and incident actions omitted the required `OutboxEvent.topic` field.
4. **Hidden database errors:** Mongoose validation, cast and duplicate-key failures were treated as unknown 500 errors and collapsed into the same generic message.

## Bus form coverage corrected

- Bus service/listing creation and image upload
- Routes and endpoint edits
- Additional boarding/drop-off branches and ordered route stops
- Vehicles and compliance/status changes
- Versioned seat-map templates
- Fare products and segment fares
- Dated departures and recurring schedule rules
- Seat-status actions
- Booking, inventory, publication and operational outbox actions
- Passenger check-in/no-show actions that use the shared canonical bus services

## Relationship corrections

- Selected route branches are persisted as actual route-stop entities, not copied text.
- Route segment and boarding/drop-off metadata is rebuilt from active ordered stops.
- Origin/destination edits update the endpoint stops and reject duplicate stop relationships.
- Routes and vehicles cannot be silently moved to another listing after creation.
- Vehicle seat geometry is owned by the versioned Seat Maps workflow, not the basic vehicle-edit form.
- Vehicle archive/maintenance changes cannot bypass active/future departure checks.
- Recurring schedule rules now retain blocked-seat selections.

## Error behavior

Expected database problems now return actionable form messages:

- `422` for invalid field/schema values
- `409` for duplicates or unsafe relationship/status conflicts
- The generic save message remains only for genuinely unexpected server failures, while full details remain in server logs.

## Verification completed

- Bus form contract gate: **45/45 passed**
- Multipart CSRF gate: **42/42 passed**
- Browser CSRF synchronization: **4/4 passed**
- Database error normalization: **3/3 passed**
- Bus blueprint verifier: **81/81 passed**
- JavaScript parsing: **475/475 files passed**
- Route security audit: **passed**
- Architecture/security gate: **passed**
- Entity relationship UI audit: **passed**
- Dashboard route smoke validation: **passed**

The Jest/runtime suite was not executed in the artifact environment because the locked dependency installation did not complete. No `node_modules` or partial installation files are included in the final archive.
