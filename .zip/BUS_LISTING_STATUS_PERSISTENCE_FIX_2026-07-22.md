# Bus Listing Status Persistence Fix

Date: 2026-07-22

## Root cause

The company dashboard correctly submitted `status=active`, but the bus-specific `updateBusListing` service did not read or persist `payload.status`. The controller redirected successfully, so the shared flash middleware displayed a save-success message while MongoDB retained `status: draft`.

A second compatibility issue could route older bus listings through the generic listing service when they were identified by Mongo `_id`, slug, `transport`, `coach`, or `bus_company` metadata rather than the canonical `id + serviceType=bus` shape.

## Corrected behavior

- The bus update service now validates and persists the requested status.
- `active` is a publication transition, not a cosmetic field update.
- Activation checks company verification, media, public contact, operator licence, policies, active route, compliant vehicle, active fare, and a published dated departure.
- Successful activation writes these fields together:
  - `status: active`
  - `releaseStatus: published`
  - `bookable: true`
  - `publication.readiness: ready`
- Draft, paused, and archived transitions synchronize `status`, `releaseStatus`, and `bookable` so the dashboard and public catalog cannot disagree.
- A failed activation is atomic: edited values and status are not partially persisted.
- The dashboard now displays the exact readiness failure instead of a false success message.
- Legacy bus listing identities support canonical IDs, slugs, valid Mongo `_id` values, `Bus`, `Coach`, `bus_company`, and bus-company-owned `transport` records.
- Legacy route-linked or vehicle-linked departures can satisfy readiness only when ownership is compatible; explicit foreign company or listing relationships are rejected.
- Dashboard edit actions now use Mongo `_id` when a legacy record has no persisted `id` field.

## Verification

- Bus listing status persistence: 21/21 passed
- Bus form contracts: 45/45 passed
- Smart bus forms: 30/30 passed
- Public bus visibility and seat templates: 9/9 passed
- Main-page bus visibility: 18/18 passed
- Live departure seat maps: 47/47 passed
- Bus architecture blueprint: 81/81 passed
- Multipart CSRF: 42/42 passed
- Browser CSRF synchronization: 4/4 passed
- Dependency-free JavaScript parsing: 490/490 passed
- Architecture/security, route security, dashboard route smoke, and entity relationship audits: passed

The dependency-loaded runtime suite was not executed because `npm ci` could not complete in the artifact environment. The final archive excludes `node_modules` and partial installation files.
