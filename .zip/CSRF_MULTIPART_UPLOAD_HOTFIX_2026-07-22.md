# Bus Listing Multipart CSRF Fix — 2026-07-22

## Reported failure

Creating a bus listing or the complete bus-service wizard returned:

```text
Invalid or missing CSRF token
```

## Confirmed remaining cause

The route-level Multer/CSRF order was already correct, but the browser helper still trusted the token embedded when the dashboard page first loaded.

That failed in real browser sessions when any of these occurred:

- Login or another security flow regenerated the session.
- Another tab refreshed the active session token.
- The browser restored an old dashboard from back/forward cache.
- A dynamically created multipart modal retained an older hidden `_csrf` value.

The previous helper returned immediately when a hidden `_csrf` input already existed, so it never replaced a stale value. The server then correctly rejected the multipart request.

Some privacy-oriented clients may also omit `Origin` and `Referer`. The old multipart preflight rejected those requests before Multer could parse and cryptographically verify the valid hidden token.

## Implemented fix

### Browser token synchronization

`public/js/csrf.js` now:

- Reads the current `XSRF-TOKEN` cookie first and uses the page meta token only as fallback.
- Replaces an existing hidden `_csrf` value on every POST submission.
- Updates the final native `FormData` payload through the `formdata` event.
- Adds the current token to non-safe `fetch` requests.
- Exposes `window.ClassicTripCsrf.token()` for dynamically generated dashboard forms.

`public/js/dashboard-workspace.js` now prefers the live helper token over stale bootstrap data.

All CSRF script includes use a versioned URL so browsers do not keep the old cached helper after deployment.

### Server multipart verification

`src/middlewares/csrf.js` now:

- Canonicalizes origins, including default ports such as `https://host:443` versus `https://host`.
- Rejects explicit cross-origin multipart requests before upload parsing.
- Allows clients that omit `Origin`/`Referer` to continue only to route-level verification.
- Still requires the parsed hidden token or valid CSRF header after Multer.
- Records an internal rejection reason without exposing token values.

CSRF protection remains enabled. Query-string tokens are not accepted.

## Bus listing request sequence

```text
company dashboard
→ live session token synchronized into the dynamic form
→ POST /company/bus-services or /company/listings
→ global CSRF origin/header preflight
→ Multer parses fields and images
→ requireCsrfToken verifies parsed _csrf
→ company scope/service validation
→ controller and transactional service creation
```

## Changed files

- `public/js/csrf.js`
- `public/js/dashboard-workspace.js`
- `src/middlewares/csrf.js`
- `src/views/dashboards/shared/workspace.ejs`
- `src/views/partials/site-head.ejs`
- Authentication/public views that load `csrf.js`
- `scripts/check-browser-csrf.js`
- `scripts/check-multipart-csrf.js`
- `tests/unit/browserCsrf.test.js`
- `tests/unit/csrfMultipart.test.js`
- `package.json`

## Verification

Executed successfully in the artifact environment:

```text
Multipart CSRF verification: 42/42 passed
Browser CSRF synchronization: 4/4 passed
Route security audit: passed
Architecture/security validation: passed
Entity relationship UI audit: passed
JavaScript syntax checks for changed files: passed
```

The full dependency-backed test suite could not be completed in the artifact environment because the package registry returned HTTP 503 while running `npm ci`. This is an external installation failure, not a project test failure.

After extracting locally:

```bash
npm ci
npm run check:csrf-uploads
npm test -- --runInBand tests/unit/csrfMultipart.test.js tests/unit/browserCsrf.test.js
npm run dev
```

Reload the company dashboard with a hard refresh once after restarting, then create the bus listing again.
