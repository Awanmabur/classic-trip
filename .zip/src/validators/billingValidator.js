const { body } = require('express-validator');

const planIds = ['starter', 'growth', 'scale'];

const planRule = () => body('planId')
  .trim()
  .isIn(planIds)
  .withMessage('Choose a valid Classic Trip plan');

const onboardingRules = [
  planRule(),
  body('name').trim().notEmpty().withMessage('Company name is required'),
  body('companyType').trim().notEmpty().withMessage('Company type is required'),
  body('contactName').trim().notEmpty().withMessage('Contact name is required'),
  body('email').trim().isEmail().withMessage('Valid email is required').normalizeEmail(),
  body('phone').trim().notEmpty().withMessage('Phone number is required'),
  body('password').custom((value, { req }) => {
    const signedInOwner = req.session?.user?.role === 'company_admin';
    if (signedInOwner && !value) return true;
    const password = String(value || '');
    if (password.length < 8 || password.length > 128) throw new Error('Password must be between 8 and 128 characters');
    if (!/[A-Za-z]/.test(password)) throw new Error('Password must contain a letter');
    if (!/[0-9]/.test(password)) throw new Error('Password must contain a number');
    return true;
  }),
  body('confirmPassword').custom((value, { req }) => {
    const signedInOwner = req.session?.user?.role === 'company_admin';
    if (signedInOwner && !req.body.password && !value) return true;
    if (String(value || '') !== String(req.body.password || '')) throw new Error('Passwords do not match');
    return true;
  }),
  body('termsAccepted').custom((value) => {
    if (value === true || value === 'true' || value === 'on' || value === '1') return true;
    throw new Error('You must accept the partner terms and privacy rules');
  }),
  body('country').optional().trim(),
  body('operatingCurrency').optional().trim().isIn(['UGX', 'KES', 'RWF', 'TZS', 'USD']).withMessage('Unsupported operating currency'),
  body('city').optional().trim(),
  body('description').optional().trim(),
];

const upgradeRules = [planRule()];

const checkoutRules = [
  body('provider').optional().trim(),
  body('paymentMethod').optional().trim(),
  body('paymentReference').optional().trim(),
];

module.exports = { onboardingRules, upgradeRules, checkoutRules };
