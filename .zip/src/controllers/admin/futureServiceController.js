const futureServiceArchitecture = require('../../services/release/futureServiceArchitecture');

async function summary(req, res, next) { try { res.json({ status: 'section-k-architecture-ready', checkoutEnabledServices: ['bus', 'hotel'], futureServices: await futureServiceArchitecture.modulesLive() }); } catch (error) { next(error); } }

module.exports = { summary };
