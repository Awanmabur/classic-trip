const store = require('../../services/data/persistentStore');
const billingService = require('../../services/billing/billingService');
const { buildDashboardShell } = require('../../services/dashboard/shellConfig');
const mongoDashboardService = require('../../services/dashboard/mongoDashboardService');
const { SERVICE_DASHBOARDS, ROLE_DASHBOARD_FEATURES } = require('../../config/dashboardFeatures');

function requestedPageFromRequest(req) {
  const raw = req.params?.page || '';
  const path = String(req.path || '');
  const aliases = {
    '/company/dashboard': 'overview',
    '/company/listings': 'listings',
    '/company/routes': 'routes',
    '/company/vehicles': 'vehicles',
    '/company/schedules': 'schedules',
    '/company/rooms': 'hotel-rooms',
    '/company/hotel-rooms': 'hotel-rooms',
    '/company/bookings': 'bookings',
    '/company/checkins': 'checkins',
    '/company/employees': 'staff',
    '/company/staff': 'staff',
    '/company/profile': 'company-profile',
    '/company/payouts': 'settlement',
    '/company/settlement': 'settlement',
    '/company/revenue': 'revenue',
    '/company/analytics': 'reports',
    '/company/reports': 'reports',
    '/company/support': 'support',
    '/company/seat-maps': 'seat-maps',
    '/company/manifests-dashboard': 'manifests',
  };
  return raw || aliases[path] || 'overview';
}

function allowedCompanyPage(page, serviceProfile = {}) {
  const serviceDashboardPages = new Set(SERVICE_DASHBOARDS.map((service) => service.key));
  if (serviceDashboardPages.has(page)) return 'overview';
  const visiblePages = new Set(serviceProfile.visiblePages || []);
  return visiblePages.has(page) ? page : 'overview';
}

function companyServiceDashboards(serviceProfile = {}) {
  const serviceType = serviceProfile.primaryServiceType;
  if (!serviceType || serviceType === 'partner') return [];
  return SERVICE_DASHBOARDS.filter((service) => service.serviceType === serviceType);
}

async function index(req, res, next) {
  try {
    const companyId = req.session?.user?.companyId || 'company-01';
    const baseDashboardData = await mongoDashboardService.roleDashboard('company', { companyId });
    const dashboardData = {
      ...baseDashboardData,
      dashboardFeatures: { services: companyServiceDashboards(baseDashboardData.serviceProfile), roles: ROLE_DASHBOARD_FEATURES },
      billing: billingService.companyBillingSummary(companyId),
    };
    const companies = await mongoDashboardService.listEntity('companies', {}, { limit: 100 });
    const notifications = await mongoDashboardService.listEntity('notifications', { $or: [{ ownerType: 'company' }, { audience: 'partners' }] }, { limit: 250 });
    res.render('dashboards/admin/index', {
      seo: { title: `${dashboardData.serviceProfile?.dashboardLabel || 'Company'} dashboard | Classic Trip` },
      dashboardData,
      dashboardShell: buildDashboardShell('company', {
        user: req.session?.user,
        activePage: allowedCompanyPage(requestedPageFromRequest(req), dashboardData.serviceProfile),
        companyId,
        company: dashboardData.company,
        serviceProfile: dashboardData.serviceProfile,
        companies: companies.length ? companies : store.state.companies,
        notificationCount: notifications.length || store.state.notifications?.filter((note) => note.ownerType === 'company' || note.audience === 'partners').length || 0,
      }),
    });
  } catch (error) {
    next(error);
  }
}
module.exports = { index };
