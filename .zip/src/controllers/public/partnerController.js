const partnerPipelineService = require('../../services/onboarding/partnerPipelineService');
const supportRepository = require('../../repositories/domain/supportRepository');
const { nextId } = require('../../services/data/idService');
function cleanText(value, max = 1000) { return String(value || '').replace(/<[^>]*>/g, '').trim().replace(/\s+/g, ' ').slice(0, max); }
async function create(req, res, next) {
  try {
    const lead = await partnerPipelineService.createLead({ businessName: req.body.name, companyType: req.body.companyType, contactName: req.body.contactName, email: req.body.email, phone: req.body.phone, whatsapp: req.body.whatsapp, city: req.body.city || '', country: req.body.country || 'Uganda', notes: req.body.notes, sourceChannel: 'public_partner_form', sourcePath: req.originalUrl }, cleanText(req.body.email || 'public-partner-request', 254));
    const ticket = { id: await nextId('support'), ownerType: 'partner_lead', ownerId: lead.id, companyId: '', category: 'Partner onboarding', subject: `Partner request: ${lead.businessName}`, message: `Contact ${cleanText(req.body.contactName, 160)} at ${cleanText(req.body.email, 254)} / ${cleanText(req.body.phone, 60)} for verification.`, priority: 'high', status: 'open', assignedTo: 'admin-onboarding', createdBy: cleanText(req.body.email || 'partner-request', 254), createdAt: new Date().toISOString(), meta: { source: 'public_partner_form', leadId: lead.id } };
    await supportRepository.tickets.save(ticket, { id: ticket.id }, { mirrorPosition: 'start' });
    return res.redirect('/login#partner');
  } catch (error) { return next(error); }
}
module.exports = { create };
