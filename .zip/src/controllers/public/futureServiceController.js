const futureServiceArchitecture = require('../../services/release/futureServiceArchitecture');

async function index(req, res, next) { try { res.render('pages/future-services', { seo: { title: 'Future services architecture | Classic Trip' }, modules: await futureServiceArchitecture.modulesLive() }); } catch (error) { next(error); } }
async function show(req, res, next) { try { const module = await futureServiceArchitecture.findModuleLive(req.params.serviceType); if (!module) return next(); return res.status(200).render('pages/future-service-detail', { seo: { title: `${module.label} coming soon | Classic Trip` }, module }); } catch (error) { return next(error); } }
async function json(req, res, next) { try { res.json({ modules: await futureServiceArchitecture.modulesLive() }); } catch (error) { next(error); } }

module.exports = { index, show, json };
