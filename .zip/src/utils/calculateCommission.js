const { env } = require('../config/env');

function roundMoney(value) {
  return Math.round((Number(value) || 0) * 100) / 100;
}

function normalizeRates(overrides = {}) {
  const defaults = {
    platform: Number(env.commission.platform),
    promoter: Number(env.commission.promoter),
    platformWithPromoter: Number(env.commission.platformWithPromoter),
    company: Number(env.commission.company),
  };
  const platform = Number(overrides.platformFeePercent ?? overrides.platform);
  const promoter = Number(overrides.promoterCommissionPercent ?? overrides.promoter);
  const company = Number(overrides.partnerPayoutPercent ?? overrides.company);
  const hasPlatform = Number.isFinite(platform) && platform >= 0;
  const hasPromoter = Number.isFinite(promoter) && promoter >= 0;
  return {
    platform: hasPlatform ? platform : defaults.platform,
    promoter: hasPromoter ? promoter : defaults.promoter,
    platformWithPromoter: Number.isFinite(Number(overrides.platformWithPromoter))
      ? Number(overrides.platformWithPromoter)
      : (hasPlatform && hasPromoter ? Math.max(0, platform - promoter) : defaults.platformWithPromoter),
    company: Number.isFinite(company) && company >= 0 ? company : defaults.company,
  };
}

module.exports = function calculateCommission(total, hasValidReferral = false, rateOverrides = {}) {
  const amount = Number(total) || 0;
  const rates = normalizeRates(rateOverrides);
  const platformRate = hasValidReferral ? rates.platformWithPromoter : rates.platform;
  const promoterRate = hasValidReferral ? rates.promoter : 0;
  const companyRate = rates.company;
  return {
    platformRate,
    promoterRate,
    companyRate,
    platformFee: roundMoney((amount * platformRate) / 100),
    promoterAmount: roundMoney((amount * promoterRate) / 100),
    companyAmount: roundMoney((amount * companyRate) / 100),
  };
};
