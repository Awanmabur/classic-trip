const crypto = require('crypto');
const PDFDocument = require('pdfkit');
const { env } = require('../../config/env');
const generateBookingRef = require('../../utils/generateBookingRef');
const calculateCommission = require('../../utils/calculateCommission');
const hotelRepository = require('../../repositories/domain/hotelRepository');
const timelineService = require('../support/timelineService');
const { normalizeLifecycleStatus } = require('../../domain/statuses');
const releaseService = require('../commission/releaseService');
const paymentService = require('../payment/paymentService');
const notificationService = require('../notification/notificationService');
const hotelInventoryService = require('./hotelInventoryService');

function clean(value, fallback = '') { return String(value ?? fallback).trim(); }
function num(value, fallback = 0) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
function list(value) {
  if (Array.isArray(value)) return value.map((v) => clean(v)).filter(Boolean);
  return String(value || '').split(/[,\n]/).map((v) => clean(v)).filter(Boolean);
}
const PROPERTY_STATUSES = new Set(['active', 'paused', 'archived']);
const ROOM_TYPE_STATUSES = new Set(['active', 'paused', 'archived']);
const ROOM_UNIT_STATUSES = new Set(['available', 'occupied', 'maintenance', 'cleaning', 'reserved', 'archived']);
const HOUSEKEEPING_STATUSES = new Set(['clean', 'dirty', 'cleaning', 'inspected', 'maintenance', 'occupied', 'ready']);
const HOUSEKEEPING_TASK_STATUSES = new Set(['', 'open', 'in_progress', 'closed', 'blocked']);
const BED_TYPES = new Set(['single', 'double', 'twin', 'queen', 'king', 'family', 'suite']);

function enumValue(value, allowed, fallback, label) {
  const normalized = clean(value || fallback).toLowerCase().replace(/[ -]+/g, '_');
  if (!allowed.has(normalized)) {
    const error = new Error(`Invalid ${label}`);
    error.status = 422;
    throw error;
  }
  return normalized;
}

async function propertyForListingOrThrow(companyId, listingId, propertyId) {
  const property = propertyId
    ? await hotelRepository.hotelProperties.findOne({ id: clean(propertyId), companyId, listingId })
    : await hotelRepository.hotelProperties.findOne({ companyId, listingId, status: { $ne: 'archived' } });
  if (!property) {
    const error = new Error('Select an active hotel property that belongs to the selected hotel listing');
    error.status = 422;
    throw error;
  }
  if (property.status === 'archived') {
    const error = new Error('Archived hotel properties cannot receive new room types');
    error.status = 409;
    throw error;
  }
  return property;
}
function isoDate(value) {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) {
    const error = new Error('A valid date is required');
    error.status = 422;
    throw error;
  }
  return parsed.toISOString().slice(0, 10);
}
function dateRange(checkIn, checkOut) {
  const start = new Date(`${isoDate(checkIn)}T00:00:00.000Z`);
  const end = new Date(`${isoDate(checkOut)}T00:00:00.000Z`);
  if (!(end > start)) {
    const error = new Error('Check-out must be after check-in');
    error.status = 422;
    throw error;
  }
  const days = [];
  for (let d = new Date(start); d < end; d.setUTCDate(d.getUTCDate() + 1)) days.push(d.toISOString().slice(0, 10));
  return days;
}

async function createProperty(companyId, payload = {}, actorId = 'company-admin') {
  await hotelRepository.companyOrThrow(companyId);
  const listing = await hotelRepository.listingOrThrow(companyId, payload.listingId || payload.slug);
  const property = {
    id: await hotelRepository.nextId('hotel-property'),
    companyId,
    listingId: listing.id,
    propertyName: clean(payload.propertyName || payload.name || listing.title),
    address: clean(payload.address || listing.address),
    city: clean(payload.city || listing.city),
    country: clean(payload.country || listing.country || 'Uganda'),
    mapLocation: clean(payload.mapLocation || payload.location || ''),
    checkInTime: clean(payload.checkInTime || listing.checkInTime || '14:00'),
    checkOutTime: clean(payload.checkOutTime || listing.checkOutTime || '10:00'),
    amenities: list(payload.amenities || listing.amenities),
    policies: list(payload.policies || listing.policy),
    taxesAndFees: list(payload.taxesAndFees).map((fee) => ({ label: fee, amount: 0 })),
    status: enumValue(payload.status, PROPERTY_STATUSES, 'active', 'hotel property status'),
    createdBy: actorId,
    createdAt: new Date().toISOString(),
  };
  Object.assign(listing, {
    address: property.address || listing.address,
    city: property.city || listing.city,
    country: property.country || listing.country,
    checkInTime: property.checkInTime,
    checkOutTime: property.checkOutTime,
    amenities: property.amenities,
  });
  await hotelRepository.hotelProperties.save(property);
  await hotelRepository.listings.save(listing);
  await hotelRepository.audit({ actorId, action: 'hotel.property.created', targetType: 'hotelProperty', targetId: property.id, meta: { companyId, listingId: listing.id } });
  return property;
}

async function updateProperty(companyId, propertyId, payload = {}, actorId = 'company-admin') {
  const property = await hotelRepository.propertyOrThrow(companyId, propertyId);
  const listing = await hotelRepository.listings.findOne({ id: property.listingId, companyId });
  if (payload.propertyName || payload.name) property.propertyName = clean(payload.propertyName || payload.name);
  if (payload.address) property.address = clean(payload.address);
  if (payload.city) property.city = clean(payload.city);
  if (payload.country) property.country = clean(payload.country);
  if (payload.mapLocation || payload.location) property.mapLocation = clean(payload.mapLocation || payload.location);
  if (payload.checkInTime) property.checkInTime = clean(payload.checkInTime);
  if (payload.checkOutTime) property.checkOutTime = clean(payload.checkOutTime);
  if (payload.amenities) property.amenities = list(payload.amenities);
  if (payload.policies) property.policies = list(payload.policies);
  if (payload.status) property.status = enumValue(payload.status, PROPERTY_STATUSES, property.status || 'active', 'hotel property status');
  property.updatedBy = actorId;
  property.updatedAt = new Date().toISOString();
  if (listing) {
    Object.assign(listing, {
      title: property.propertyName || listing.title,
      address: property.address || listing.address,
      city: property.city || listing.city,
      country: property.country || listing.country,
      checkInTime: property.checkInTime,
      checkOutTime: property.checkOutTime,
      amenities: property.amenities,
    });
    await hotelRepository.listings.save(listing);
  }
  await hotelRepository.hotelProperties.save(property);
  await hotelRepository.audit({ actorId, action: 'hotel.property.updated', targetType: 'hotelProperty', targetId: property.id });
  return property;
}

async function archiveProperty(companyId, propertyId, actorId = 'company-admin') {
  return updateProperty(companyId, propertyId, { status: 'archived' }, actorId);
}

async function createRoomType(companyId, payload = {}, actorId = 'company-admin') {
  const listing = await hotelRepository.listingOrThrow(companyId, payload.listingId || payload.slug);
  if (listing.serviceType !== 'hotel') {
    const error = new Error('Room types can only be attached to hotel listings');
    error.status = 422;
    throw error;
  }
  const property = await propertyForListingOrThrow(companyId, listing.id, payload.propertyId);
  const name = clean(payload.name || payload.roomType || 'Standard Room');
  const existing = await hotelRepository.roomTypes.findOne({ listingId: listing.id, propertyId: property.id, name });
  if (existing) throw Object.assign(new Error(`Room type ${name} already exists for this property`), { status: 409 });
  const roomType = {
    id: await hotelRepository.nextId('room-type'), companyId, listingId: listing.id,
    propertyId: property.id, name,
    capacity: Math.max(1, Math.round(num(payload.capacity, 2))),
    bedType: enumValue(payload.bedType, BED_TYPES, 'double', 'bed type'),
    basePrice: Math.max(0, num(payload.basePrice || payload.nightlyPrice || listing.priceFrom, 0)),
    amenities: list(payload.amenities), policies: list(payload.policies),
    taxesAndFees: list(payload.taxesAndFees).map((fee) => ({ label: fee, amount: 0 })),
    status: enumValue(payload.status, ROOM_TYPE_STATUSES, 'active', 'room type status'), createdBy: actorId, createdAt: new Date().toISOString(),
  };
  const defaultInventory = Math.max(0, Math.round(num(payload.defaultInventory ?? payload.inventory, 0)));
  const unitPrefix = clean(payload.unitPrefix || name).replace(/[^A-Za-z0-9]/g, '').slice(0, 4).toUpperCase() || 'ROOM';
  const units = await Promise.all(Array.from({ length: defaultInventory }, async (_, index) => ({
    id: await hotelRepository.nextId('room-unit'), companyId, listingId: listing.id,
    propertyId: roomType.propertyId, roomTypeId: roomType.id,
    unitNumber: `${unitPrefix}-${String(index + 1).padStart(3, '0')}`,
    floor: clean(payload.floor || ''), wing: clean(payload.wing || ''), status: 'available',
    housekeepingStatus: 'clean', notes: '', createdBy: actorId, createdAt: roomType.createdAt,
  })));
  await hotelRepository.transaction(async (session) => {
    await hotelRepository.roomTypes.save(roomType, { id: roomType.id }, { session });
    if (units.length) await hotelRepository.roomUnits.saveMany(units, (row) => ({ id: row.id }), { session });
    if (!Number(listing.priceFrom || 0) || roomType.basePrice < Number(listing.priceFrom || Infinity)) {
      listing.priceFrom = roomType.basePrice; listing.price = roomType.basePrice; listing.updatedAt = new Date().toISOString();
      await hotelRepository.listings.save(listing, { id: listing.id }, { session });
    }
  });
  await hotelRepository.audit({ actorId, action: 'hotel.room_type.created', targetType: 'roomType', targetId: roomType.id, meta: { listingId: listing.id, units: units.length } });
  return { roomType, units };
}

async function updateRoomType(companyId, roomTypeId, payload = {}, actorId = 'company-admin') {
  const roomType = await hotelRepository.roomTypeOrThrow(companyId, roomTypeId);
  if (payload.name || payload.roomType) {
    const name = clean(payload.name || payload.roomType);
    const duplicate = await hotelRepository.roomTypes.findOne({ listingId: roomType.listingId, name, id: { $ne: roomType.id } });
    if (duplicate) throw Object.assign(new Error(`Room type ${name} already exists for this property`), { status: 409 });
    roomType.name = name;
  }
  if (payload.capacity) roomType.capacity = Math.max(1, Math.round(num(payload.capacity, roomType.capacity || 1)));
  if (payload.basePrice || payload.nightlyPrice) roomType.basePrice = Math.max(0, num(payload.basePrice || payload.nightlyPrice, roomType.basePrice || 0));
  if (payload.bedType) roomType.bedType = enumValue(payload.bedType, BED_TYPES, roomType.bedType || 'double', 'bed type');
  if (payload.amenities) roomType.amenities = list(payload.amenities);
  if (payload.policies) roomType.policies = list(payload.policies);
  if (payload.status) roomType.status = enumValue(payload.status, ROOM_TYPE_STATUSES, roomType.status || 'active', 'room type status');
  roomType.updatedBy = actorId; roomType.updatedAt = new Date().toISOString();
  await hotelRepository.roomTypes.save(roomType);
  await hotelRepository.audit({ actorId, action: 'hotel.room_type.updated', targetType: 'roomType', targetId: roomType.id });
  return roomType;
}

async function archiveRoomType(companyId, roomTypeId, actorId = 'company-admin') {
  return updateRoomType(companyId, roomTypeId, { status: 'archived' }, actorId);
}

async function createRoomUnits(companyId, payload = {}, actorId = 'company-admin') {
  const roomType = await hotelRepository.roomTypeOrThrow(companyId, payload.roomTypeId);
  const unitNumbers = list(payload.unitNumbers || payload.units || payload.roomNumbers);
  if (!unitNumbers.length) {
    const error = new Error('At least one room number is required');
    error.status = 422;
    throw error;
  }
  const existing = await hotelRepository.roomUnits.list({ companyId, roomTypeId: roomType.id });
  const existingNumbers = new Set(existing.map((unit) => clean(unit.unitNumber).toLowerCase()));
  const duplicate = unitNumbers.find((unitNumber) => existingNumbers.has(clean(unitNumber).toLowerCase()));
  if (duplicate) {
    const error = new Error(`Room unit ${duplicate} already exists`);
    error.status = 409;
    throw error;
  }
  const units = await Promise.all(unitNumbers.map(async (unitNumber) => ({
    id: await hotelRepository.nextId('room-unit'),
    companyId,
    listingId: roomType.listingId,
    propertyId: roomType.propertyId,
    roomTypeId: roomType.id,
    unitNumber,
    floor: clean(payload.floor || ''),
    wing: clean(payload.wing || ''),
    status: enumValue(payload.status, ROOM_UNIT_STATUSES, 'available', 'room status'),
    housekeepingStatus: enumValue(payload.housekeepingStatus, HOUSEKEEPING_STATUSES, 'clean', 'housekeeping status'),
    notes: clean(payload.notes || ''),
    createdBy: actorId,
    createdAt: new Date().toISOString(),
  })));
  await hotelRepository.roomUnits.saveMany(units);
  await hotelRepository.audit({ actorId, action: 'hotel.room_units.created', targetType: 'roomType', targetId: roomType.id, meta: { count: units.length } });
  return units;
}

async function updateRoomUnit(companyId, unitId, payload = {}, actorId = 'company-admin') {
  const unit = await hotelRepository.roomUnitOrThrow(companyId, unitId);
  if (payload.unitNumber || payload.roomNumber) unit.unitNumber = clean(payload.unitNumber || payload.roomNumber);
  if (payload.floor) unit.floor = clean(payload.floor);
  if (payload.wing) unit.wing = clean(payload.wing);
  if (payload.housekeepingStatus) unit.housekeepingStatus = enumValue(payload.housekeepingStatus, HOUSEKEEPING_STATUSES, unit.housekeepingStatus || 'clean', 'housekeeping status');
  if (payload.status) unit.status = enumValue(payload.status, ROOM_UNIT_STATUSES, unit.status || 'available', 'room status');
  if (payload.notes) unit.notes = clean(payload.notes);
  unit.updatedBy = actorId;
  unit.updatedAt = new Date().toISOString();
  await hotelRepository.roomUnits.save(unit);
  await hotelRepository.audit({ actorId, action: 'hotel.room_unit.updated', targetType: 'roomUnit', targetId: unit.id });
  return unit;
}

async function archiveRoomUnit(companyId, unitId, actorId = 'company-admin') {
  return updateRoomUnit(companyId, unitId, { status: 'archived' }, actorId);
}

async function createNightInventory(companyId, payload = {}, actorId = 'company-admin') {
  const roomType = await hotelRepository.roomTypeOrThrow(companyId, payload.roomTypeId);
  const nights = dateRange(payload.startDate || payload.checkIn, payload.endDate || payload.checkOut);
  const requestedUnitIds = list(payload.roomUnitIds);
  const units = requestedUnitIds.length
    ? await hotelRepository.roomUnits.list({ companyId, id: { $in: requestedUnitIds }, status: { $ne: 'archived' } })
    : await hotelRepository.roomUnits.list({ companyId, roomTypeId: roomType.id, status: { $ne: 'archived' } });
  if (requestedUnitIds.length && units.some((unit) => unit.roomTypeId !== roomType.id)) {
    const error = new Error('Every selected room unit must belong to the selected room type');
    error.status = 422;
    throw error;
  }
  if (requestedUnitIds.length && units.length !== new Set(requestedUnitIds).size) {
    const error = new Error('One or more selected room units do not exist or are archived');
    error.status = 422;
    throw error;
  }
  if (!units.length) {
    const error = new Error('At least one room unit is required');
    error.status = 422;
    throw error;
  }
  const existing = await hotelRepository.roomNightInventories.list({ companyId, roomUnitId: { $in: units.map((unit) => unit.id) }, date: { $in: nights } });
  const byKey = new Map(existing.map((row) => [`${row.roomUnitId}:${row.date}`, row]));
  const rows = [];
  for (const unit of units) {
    for (const date of nights) {
      const key = `${unit.id}:${date}`;
      const row = byKey.get(key) || {
        id: await hotelRepository.nextId('room-night'),
        companyId,
        listingId: roomType.listingId,
        propertyId: roomType.propertyId,
        roomTypeId: roomType.id,
        roomUnitId: unit.id,
            date,
        createdBy: actorId,
        createdAt: new Date().toISOString(),
      };
      row.price = Math.max(0, num(payload.price || payload.nightlyPrice || row.price || roomType.basePrice, roomType.basePrice));
      row.status = clean(payload.status || row.status || 'available');
      row.updatedAt = new Date().toISOString();
      rows.push(row);
    }
  }
  await hotelRepository.roomNightInventories.saveMany(rows, (row) => ({ roomUnitId: row.roomUnitId, date: row.date }));
  await hotelRepository.audit({ actorId, action: 'hotel.inventory.created', targetType: 'roomType', targetId: roomType.id, meta: { nights: nights.length, units: units.length } });
  return rows;
}

async function updateNightStatus(companyId, inventoryId, payload = {}, actorId = 'company-admin') {
  const allowed = ['available', 'held', 'booked', 'occupied', 'checked_in', 'checked_out', 'maintenance', 'cleaning', 'cancelled', 'refunded', 'reserved'];
  const night = await hotelRepository.nightOrThrow(companyId, inventoryId);
  const status = clean(payload.status || night.status);
  if (!allowed.includes(status)) {
    const error = new Error('Invalid room-night status');
    error.status = 422;
    throw error;
  }
  Object.assign(night, { status, notes: clean(payload.notes || night.notes || ''), updatedBy: actorId, updatedAt: new Date().toISOString() });
  const unit = night.roomUnitId ? await hotelRepository.roomUnits.findOne({ id: night.roomUnitId, companyId }) : null;
  if (unit && ['maintenance', 'cleaning', 'occupied', 'available'].includes(status)) {
    unit.status = status === 'occupied' ? 'occupied' : status;
    if (payload.housekeepingStatus) unit.housekeepingStatus = clean(payload.housekeepingStatus);
    unit.updatedAt = night.updatedAt;
    await hotelRepository.roomUnits.save(unit);
  }
  await hotelRepository.roomNightInventories.save(night);
  await hotelRepository.audit({ actorId, action: 'hotel.room_night.status', targetType: 'roomNightInventory', targetId: night.id, meta: { status } });
  return night;
}

async function archiveNightInventory(companyId, inventoryId, actorId = 'company-admin') {
  return updateNightStatus(companyId, inventoryId, { status: 'cancelled', notes: 'Archived by company admin' }, actorId);
}

async function availableNightGroups(listingId, checkIn, checkOut, roomTypeId = '', selectedUnitIds = []) {
  const nights = dateRange(checkIn, checkOut);
  const selected = new Set((selectedUnitIds || []).map(String).filter(Boolean));
  const filter = { listingId, date: { $in: nights }, status: { $in: ['available', 'reserved'] } };
  if (roomTypeId) filter.roomTypeId = roomTypeId;
  if (selected.size) filter.roomUnitId = { $in: Array.from(selected) };
  const all = await hotelRepository.roomNightInventories.list(filter, { sort: { roomUnitId: 1, date: 1 } });
  const byUnit = new Map();
  all.forEach((night) => {
    if (!byUnit.has(night.roomUnitId)) byUnit.set(night.roomUnitId, []);
    byUnit.get(night.roomUnitId).push(night);
  });
  return Array.from(byUnit.values()).filter((rows) => rows.length === nights.length && rows.every((night) => !night.bookingRef));
}

async function createHotelBooking(payload = {}, req = {}) {
  const listing = await hotelRepository.publicListingOrThrow(payload.listingId || payload.slug);
  const checkIn = isoDate(payload.checkInDate || payload.checkIn || payload.startDate);
  const checkOut = isoDate(payload.checkOutDate || payload.checkOut || payload.endDate);
  const nights = dateRange(checkIn, checkOut);
  const roomCount = Math.max(1, Math.round(num(payload.roomCount || payload.rooms, 1)));
  const roomTypeId = clean(payload.roomTypeId || '');
  const selectedRoomUnitIds = list(payload.roomUnitIds || payload.roomUnitId || payload.selected || '');
  const groups = (await availableNightGroups(listing.id, checkIn, checkOut, roomTypeId, selectedRoomUnitIds)).slice(0, roomCount);
  if (groups.length < roomCount) {
    const error = new Error('Not enough room-night inventory available');
    error.status = 409;
    throw error;
  }
  let guests = [];
  try { guests = typeof payload.guests === 'string' ? JSON.parse(payload.guests || '[]') : (payload.guests || payload.guestDetails || []); } catch (error) { guests = []; }
  if (!Array.isArray(guests) || !guests.length) guests = [{ fullName: payload.fullName || 'Hotel Guest', email: payload.email, phone: payload.phone }];
  const selectedRows = groups.flat();
  const unitIds = groups.map((rows) => rows[0].roomUnitId);
  const typeIds = groups.map((rows) => rows[0].roomTypeId);
  const unitRows = await hotelRepository.roomUnits.list({ id: { $in: unitIds } });
  const typeRows = await hotelRepository.roomTypes.list({ id: { $in: typeIds } });
  const unitsById = new Map(unitRows.map((unit) => [unit.id, unit]));
  const typesById = new Map(typeRows.map((type) => [type.id, type]));
  const roomUnits = groups.map((rows) => unitsById.get(rows[0].roomUnitId) || {});
  const roomTypes = groups.map((rows) => typesById.get(rows[0].roomTypeId) || {});
  const subtotal = selectedRows.reduce((total, night) => total + Number(night.price || listing.priceFrom || 0), 0);
  const fees = Math.round(subtotal * 0.045 + 3500);
  const total = subtotal + fees;
  const split = calculateCommission(total, false);
  const bookingRef = generateBookingRef('hotel');
  const bookingItems = groups.map((rows, index) => ({
    id: `hotel-room-${index + 1}`,
    serviceType: 'hotel',
    listingId: listing.id,
    roomTypeId: rows[0].roomTypeId,
    roomUnitId: rows[0].roomUnitId,
    roomNumber: roomUnits[index]?.unitNumber || '',
    checkIn,
    checkOut,
    nights: rows.map((night) => night.date),
    price: rows.reduce((sum, night) => sum + Number(night.price || 0), 0),
    status: 'confirmed',
  }));
  const ticketLegs = bookingItems.map((item, index) => ({
    id: `${bookingRef}-ROOM-${index + 1}`,
    serviceType: 'hotel',
    legType: 'stay',
    roomUnitId: item.roomUnitId,
    roomNumber: item.roomNumber,
    checkIn,
    checkOut,
    qrCodeValue: `CLASSIC-TRIP:HOTEL:${bookingRef}:${item.roomUnitId}:${Date.now()}`,
    status: 'confirmed',
  }));
  const booking = {
    id: await hotelRepository.nextId('booking'),
    bookingRef,
    guestLookupCode: crypto.randomBytes(6).toString('hex').toUpperCase(),
    serviceType: 'hotel',
    guestSnapshot: {
      fullName: payload.fullName || guests[0]?.fullName || 'Hotel Guest',
      email: payload.email || guests[0]?.email || 'guest@example.com',
      phone: payload.phone || guests[0]?.phone || '+256700000000',
    },
    customerUserId: payload.customerUserId || req?.session?.user?.id || null,
    companyId: listing.companyId,
    tenantId: listing.companyId,
    listingId: listing.id,
    passengers: groups.map((rows, index) => ({
      id: `guest-${index + 1}`,
      fullName: guests[index]?.fullName || guests[0]?.fullName || payload.fullName || 'Hotel Guest',
      email: guests[index]?.email || payload.email,
      phone: guests[index]?.phone || payload.phone,
      seatOrRoom: roomUnits[index]?.unitNumber || roomTypes[index]?.name || 'Room',
      roomNumber: roomUnits[index]?.unitNumber || '',
      roomType: roomTypes[index]?.name || '',
    })),
    bookingItems,
    ticketLegs,
    hotelStay: {
      checkIn,
      checkOut,
      nights,
      roomCount,
      adults: Math.max(1, Math.round(num(payload.adults, guests.length || 1))),
      children: Math.max(0, Math.round(num(payload.children, 0))),
      roomUnitIds: roomUnits.map((unit) => unit.id).filter(Boolean),
      roomTypeIds: roomTypes.map((type) => type.id).filter(Boolean),
      status: 'booked',
      specialRequests: clean(payload.specialRequests || payload.addons || ''),
    },
    pricing: { subtotal, fees, addonTotal: 0, total, currency: listing.currency || 'UGX', split },
    grossAmount: total,
    paymentStatus: 'pending',
    bookingStatus: 'pending_payment',
    qrCodeValue: `CLASSIC-TRIP:${bookingRef}:${listing.id}:${Date.now()}`,
    createdAt: new Date().toISOString(),
  };
  const isManualSettlement = payload.paymentStatus === 'successful' || payload.source === 'company_manual';
  let provider;
  let payment;
  if (isManualSettlement) {
    const requested = clean(payload.paymentProvider || payload.provider || 'cash').toLowerCase().replace(/-/g, '_');
    provider = ['cash', 'bank_transfer', 'card', 'mobile_money'].includes(requested) ? requested : 'cash';
    payment = { provider, providerReference: payload.paymentRef || `MANUAL-${bookingRef}`, status: 'successful', paidAt: new Date().toISOString(), checkoutUrl: '' };
  } else {
    provider = paymentService.resolveProviderName(payload.provider || payload.paymentProvider);
    payment = await paymentService.initiatePayment({
      provider,
      bookingRef,
      amount: total,
      currency: booking.pricing.currency,
      customer: booking.guestSnapshot,
      callbackUrl: `${env.appUrl}/booking/payment/callback?bookingRef=${encodeURIComponent(bookingRef)}`,
      description: `Classic Trip hotel booking ${bookingRef}`,
    });
  }
  booking.paymentStatus = payment.status || 'pending';
  booking.paymentProvider = payment.provider || provider;
  booking.paymentRef = payment.providerReference || '';
  booking.checkoutUrl = payment.checkoutUrl || '';
  booking.bookingStatus = booking.paymentStatus === 'successful' ? (payload.bookingStatus || 'confirmed') : 'pending_payment';
  const paymentRow = {
    id: await hotelRepository.nextId('payment'),
    bookingId: booking.id,
    bookingRef,
    companyId: booking.companyId,
    customerUserId: booking.customerUserId,
    amount: total,
    grossAmount: total,
    currency: booking.pricing.currency,
    status: booking.paymentStatus,
    provider: booking.paymentProvider,
    providerReference: booking.paymentRef,
    paymentRef: booking.paymentRef,
    checkoutUrl: booking.checkoutUrl,
    idempotencyKey: `hotel:${bookingRef}`,
    metadata: { listingId: listing.id, checkIn, checkOut, roomUnitIds: booking.hotelStay.roomUnitIds },
    createdAt: booking.createdAt,
    paidAt: booking.paymentStatus === 'successful' ? (payment.paidAt || new Date().toISOString()) : null,
  };
  await hotelRepository.commitHotelBooking({ selectedRows, booking, paymentRow });
  if (booking.paymentStatus === 'successful') {
    try {
      await hotelRepository.settleSuccessfulBooking({ booking, split });
    } catch (error) {
      booking.settlementStatus = 'reconciliation_required';
      booking.settlementError = clean(error.message || 'Settlement creation failed');
      await hotelRepository.bookings.save(booking);
    }
    await notificationService.bookingConfirmed(booking);
  } else {
    await notificationService.queueNotification({
      userId: booking.customerUserId || null,
      channels: ['email', 'sms'],
      title: `Payment pending ${bookingRef}`,
      message: `${bookingRef} is waiting for payment confirmation for ${checkIn} to ${checkOut}.`,
      recipient: { email: booking.guestSnapshot.email, phone: booking.guestSnapshot.phone, name: booking.guestSnapshot.fullName },
      referenceType: 'booking',
      referenceId: booking.id,
      meta: { bookingRef, checkoutUrl: booking.checkoutUrl },
    });
  }
  const actorId = req?.session?.user?.id || payload.createdByEmployeeId || payload.actorId || 'guest';
  await hotelRepository.audit({ actorId, action: 'hotel.booking.created', targetType: 'booking', targetId: bookingRef });
  await timelineService.recordEvent({ bookingRef, companyId: booking.companyId, customerUserId: booking.customerUserId, entityType: 'hotel_booking', entityId: bookingRef, action: 'hotel.booking.created', title: `Hotel booking ${bookingRef} created`, message: `Stay created for ${checkIn} to ${checkOut}.`, status: booking.bookingStatus, actorType: payload.source === 'company_manual' ? 'company' : 'customer', actorId, metadata: { checkIn, checkOut, roomCount, roomTypeId, roomUnitIds: booking.hotelStay.roomUnitIds } });
  await timelineService.recordEvent({ bookingRef, companyId: booking.companyId, customerUserId: booking.customerUserId, entityType: 'room_night_inventory', entityId: booking.hotelStay.roomUnitIds.join(','), action: 'hotel.inventory.booked', title: `Room-night inventory booked for ${bookingRef}`, message: `${selectedRows.length} room-night(s) were converted to booked.`, status: 'booked', actorType: 'system', actorId, metadata: { nights, selectedRoomUnitIds } });
  await timelineService.recordEvent({ bookingRef, companyId: booking.companyId, customerUserId: booking.customerUserId, entityType: 'payment', entityId: paymentRow.id, action: booking.paymentStatus === 'successful' ? 'payment.succeeded' : 'payment.pending', title: booking.paymentStatus === 'successful' ? `Payment received for ${bookingRef}` : `Payment pending for ${bookingRef}`, message: booking.paymentStatus === 'successful' ? 'Hotel voucher and QR are valid for check-in.' : 'Hotel booking is waiting for payment confirmation.', status: booking.paymentStatus, actorType: 'system', actorId });
  await timelineService.recordEvent({ bookingRef, companyId: booking.companyId, customerUserId: booking.customerUserId, entityType: 'hotel_voucher', entityId: ticketLegs[0]?.id || bookingRef, action: 'hotel.voucher.issued', title: `Hotel voucher issued for ${bookingRef}`, message: `${ticketLegs.length} room voucher(s) were created.`, status: 'issued', actorType: 'system', actorId });
  return booking;
}

async function roomMap(companyId, listingId, startDate, endDate) {
  const listing = await hotelRepository.listingOrThrow(companyId, listingId);
  const dates = startDate && endDate ? dateRange(startDate, endDate) : [];
  const units = await hotelRepository.roomUnits.list({ companyId, listingId: listing.id, status: { $ne: 'archived' } });
  const roomTypes = await hotelRepository.roomTypes.list({ id: { $in: units.map((unit) => unit.roomTypeId) } });
  const typesById = new Map(roomTypes.map((type) => [type.id, type]));
  const nightFilter = { roomUnitId: { $in: units.map((unit) => unit.id) } };
  if (dates.length) nightFilter.date = { $in: dates };
  const allNights = await hotelRepository.roomNightInventories.list(nightFilter, { sort: { date: 1 } });
  const byUnit = new Map();
  allNights.forEach((night) => {
    if (!byUnit.has(night.roomUnitId)) byUnit.set(night.roomUnitId, []);
    byUnit.get(night.roomUnitId).push(night);
  });
  return units.map((unit) => {
    const roomType = typesById.get(unit.roomTypeId) || {};
    const nights = byUnit.get(unit.id) || [];
    const activeNight = nights.find((night) => ['booked', 'occupied', 'checked_in', 'held', 'maintenance', 'cleaning', 'reserved'].includes(night.status)) || nights[0];
    return [roomType.name || 'Room', unit.unitNumber, nights.map((night) => `${night.date}:${night.status}`).join(' | ') || unit.status, activeNight?.bookingRef || '-', activeNight?.guestName || '-', activeNight?.status || unit.status, { entity: 'room_night', id: activeNight?.id || unit.id, label: unit.unitNumber, status: activeNight?.status || unit.status }];
  });
}

async function manifestRows(companyId, listingId, mode = 'arrivals') {
  const listing = await hotelRepository.listingOrThrow(companyId, listingId);
  const bookings = await hotelRepository.bookings.list({ companyId, listingId: listing.id, serviceType: 'hotel' });
  return bookings.filter((booking) => {
    const status = booking.hotelStay?.status || booking.bookingStatus;
    if (mode === 'in-house') return ['checked_in', 'occupied', 'in_house'].includes(status);
    if (mode === 'departures') return ['checked_in', 'occupied', 'confirmed', 'checked_out', 'completed'].includes(status) || booking.bookingStatus === 'completed';
    return ['confirmed', 'booked', 'checked_in', 'completed'].includes(booking.bookingStatus) || ['booked', 'checked_in', 'checked_out', 'completed'].includes(status);
  }).map((booking) => [booking.bookingRef, booking.guestSnapshot?.fullName || '-', (booking.passengers || []).map((guest) => guest.seatOrRoom).join(', '), booking.hotelStay?.checkIn || '-', booking.hotelStay?.checkOut || '-', booking.hotelStay?.status || booking.bookingStatus, { entity: 'hotel_booking', id: booking.bookingRef, label: booking.bookingRef, status: booking.bookingStatus }]);
}

async function markStay(companyId, bookingRef, status, actorId = 'company-admin') {
  const booking = await hotelRepository.bookingOrThrow(companyId, bookingRef);
  const normalized = normalizeLifecycleStatus(status);
  booking.hotelStay = booking.hotelStay || {};
  booking.hotelStay.status = normalized;
  booking.bookingStatus = normalized === 'checked_out' ? 'completed' : normalized;
  const now = new Date().toISOString();
  if (normalized === 'checked_out') {
    booking.completedAt = now;
    booking.checkOutAt = now;
    booking.settlementStatus = booking.settlementStatus || 'eligible';
  }
  if (normalized === 'checked_in') {
    booking.checkedInAt = now;
    booking.checkInStatus = 'checked_in';
  }
  const nightStatus = normalized === 'checked_in' ? 'occupied' : normalized;
  const affectedNights = await hotelRepository.roomNightInventories.list({ bookingRef });
  const unitIds = Array.from(new Set(affectedNights.map((night) => night.roomUnitId).filter(Boolean)));
  const units = await hotelRepository.roomUnits.list({ companyId, id: { $in: unitIds } });
  const unitsById = new Map(units.map((unit) => [unit.id, unit]));
  affectedNights.forEach((night) => {
    night.status = nightStatus;
    night.checkInStatus = normalized;
    night.updatedAt = now;
    const unit = unitsById.get(night.roomUnitId);
    if (unit && normalized === 'checked_in') {
      unit.status = 'occupied';
      unit.housekeepingStatus = 'occupied';
      unit.updatedAt = now;
    }
    if (unit && normalized === 'checked_out') {
      unit.status = 'cleaning';
      unit.housekeepingStatus = 'dirty';
      unit.housekeepingTaskStatus = 'open';
      unit.housekeepingPriority = 'normal';
      unit.housekeepingDueAt = new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString();
      unit.lastGuestBookingRef = bookingRef;
      unit.updatedAt = now;
    }
  });
  await timelineService.recordEvent({ bookingRef, companyId: booking.companyId, customerUserId: booking.customerUserId, entityType: 'hotel_stay', entityId: bookingRef, action: `hotel.stay.${normalized}`, title: normalized === 'checked_in' ? `Guest checked in for ${bookingRef}` : normalized === 'checked_out' ? `Guest checked out for ${bookingRef}` : `Hotel stay updated for ${bookingRef}`, message: normalized === 'checked_in' ? 'Guest arrival was confirmed and room state changed to occupied.' : normalized === 'checked_out' ? 'Guest departure was confirmed and stay was completed.' : `Stay status changed to ${normalized}.`, status: normalized, actorType: 'company', actorId, metadata: { roomUnitIds: booking.hotelStay.roomUnitIds || [], checkIn: booking.hotelStay.checkIn, checkOut: booking.hotelStay.checkOut } });
  let releasedCommissions = [];
  if (normalized === 'checked_out') {
    releasedCommissions = (await releaseService.releaseCompletedBooking(bookingRef)) || [];
    booking.earningsReleasedAt = booking.earningsReleasedAt || (releasedCommissions.length ? now : booking.earningsReleasedAt);
    booking.settlementStatus = releasedCommissions.length ? 'settled' : booking.settlementStatus;
    await timelineService.recordEvent({ bookingRef, companyId: booking.companyId, customerUserId: booking.customerUserId, entityType: 'settlement', entityId: bookingRef, action: 'hotel.settlement.eligible', title: `Hotel stay settlement updated for ${bookingRef}`, message: releasedCommissions.length ? 'Stay completion released eligible company/promoter earnings.' : 'Stay completion marked this booking settlement-eligible.', status: booking.settlementStatus || 'eligible', actorType: 'system', actorId, metadata: { releasedCommissions: releasedCommissions.length } });
  }
  await hotelRepository.bookings.save(booking);
  await hotelRepository.roomNightInventories.saveMany(affectedNights);
  await hotelRepository.roomUnits.saveMany(units);
  await hotelRepository.commissions.saveMany(releasedCommissions);
  await hotelRepository.audit({ actorId, action: `hotel.stay.${normalized}`, targetType: 'booking', targetId: bookingRef, meta: { affectedNights: affectedNights.length } });
  return booking;
}

async function updateHousekeeping(companyId, unitId, payload = {}, actorId = 'company-admin') {
  const unit = await hotelRepository.roomUnitOrThrow(companyId, unitId);
  const status = enumValue(payload.housekeepingStatus, HOUSEKEEPING_STATUSES, unit.housekeepingStatus || 'clean', 'housekeeping status');
  const roomStatus = enumValue(payload.status, ROOM_UNIT_STATUSES, unit.status || 'available', 'room status');
  const taskStatus = enumValue(payload.taskStatus, HOUSEKEEPING_TASK_STATUSES, unit.housekeepingTaskStatus || (['clean', 'inspected'].includes(status) ? 'closed' : 'open'), 'housekeeping task status');
  Object.assign(unit, {
    housekeepingStatus: status,
    status: roomStatus,
    housekeepingTaskStatus: ['clean', 'inspected'].includes(status) ? 'closed' : taskStatus,
    housekeepingPriority: clean(payload.priority || unit.housekeepingPriority || 'normal'),
    housekeepingAssignedTo: clean(payload.assignedTo || unit.housekeepingAssignedTo || ''),
    housekeepingDueAt: payload.dueAt || unit.housekeepingDueAt || null,
    notes: clean(payload.notes || unit.notes || ''),
    updatedBy: actorId,
    updatedAt: new Date().toISOString(),
  });
  const activeNights = await hotelRepository.roomNightInventories.list({ roomUnitId: unit.id, status: { $in: ['cleaning', 'maintenance', 'occupied', 'checked_out'] } });
  if (status === 'clean' || status === 'inspected') {
    unit.status = roomStatus === 'maintenance' ? 'maintenance' : 'available';
    activeNights.filter((night) => ['cleaning', 'checked_out'].includes(clean(night.status))).forEach((night) => { night.status = 'available'; night.housekeepingStatus = status; night.updatedAt = unit.updatedAt; });
  } else if (status === 'cleaning') {
    unit.status = 'cleaning';
    activeNights.forEach((night) => { if (night.status !== 'maintenance') night.status = 'cleaning'; night.housekeepingStatus = status; night.updatedAt = unit.updatedAt; });
  } else if (status === 'maintenance') {
    unit.status = 'maintenance';
    activeNights.forEach((night) => { night.status = 'maintenance'; night.housekeepingStatus = status; night.updatedAt = unit.updatedAt; });
  }
  await hotelRepository.roomUnits.save(unit);
  await hotelRepository.roomNightInventories.saveMany(activeNights);
  await hotelRepository.audit({ actorId, action: 'hotel.housekeeping.updated', targetType: 'roomUnit', targetId: unit.id, meta: { housekeepingStatus: unit.housekeepingStatus, roomStatus: unit.status, taskStatus: unit.housekeepingTaskStatus } });
  return unit;
}



async function roomTypeSummary(roomType) {
  const units = await hotelRepository.roomUnits.list({ roomTypeId: roomType.id, status: { $ne: 'archived' } });
  return { ...roomType, roomType: roomType.name, nightlyPrice: roomType.basePrice, inventory: units.length, availableUnits: units.length };
}

async function createRoom(companyId, payload = {}, actorId = 'company-admin') {
  const listing = await hotelRepository.listingOrThrow(companyId, payload.listingId || payload.slug);
  let property = payload.propertyId
    ? await propertyForListingOrThrow(companyId, listing.id, payload.propertyId)
    : await hotelRepository.hotelProperties.findOne({ companyId, listingId: listing.id, status: { $ne: 'archived' } });
  // Legacy one-screen hotel setup remains supported, but it still creates the canonical
  // property -> room type -> room unit hierarchy instead of writing a duplicate Room model.
  if (!property) {
    property = await createProperty(companyId, {
      listingId: listing.id,
      propertyName: payload.propertyName || listing.title,
      address: payload.address || listing.address,
      city: payload.city || listing.city,
      country: payload.country || listing.country,
      checkInTime: payload.checkInTime || listing.checkInTime,
      checkOutTime: payload.checkOutTime || listing.checkOutTime,
      amenities: payload.propertyAmenities || listing.amenities,
      status: 'active',
    }, actorId);
  }
  const result = await createRoomType(companyId, {
    ...payload,
    propertyId: property.id,
    name: payload.name || payload.roomType,
    basePrice: payload.basePrice || payload.nightlyPrice,
    defaultInventory: payload.defaultInventory ?? payload.inventory ?? 1,
  }, actorId);
  return roomTypeSummary(result.roomType);
}

async function updateRoomInventory(companyId, roomTypeId, payload = {}, actorId = 'company-admin') {
  const roomType = await updateRoomType(companyId, roomTypeId, {
    name: payload.name || payload.roomType,
    basePrice: payload.basePrice ?? payload.nightlyPrice,
    capacity: payload.capacity,
    amenities: payload.amenities,
    status: payload.status,
  }, actorId);
  if (typeof payload.inventory !== 'undefined') {
    const desired = Math.max(0, Math.round(num(payload.inventory, 0)));
    const active = await hotelRepository.roomUnits.list({ roomTypeId: roomType.id, companyId, status: { $ne: 'archived' } }, { sort: { createdAt: 1 } });
    if (active.length < desired) {
      const all = await hotelRepository.roomUnits.list({ roomTypeId: roomType.id, companyId });
      const existingNumbers = new Set(all.map((row) => clean(row.unitNumber).toLowerCase()));
      const names = [];
      let sequence = all.length + 1;
      while (names.length < desired - active.length) {
        const candidate = `${clean(roomType.name).replace(/[^A-Za-z0-9]/g, '').slice(0, 4).toUpperCase() || 'ROOM'}-${String(sequence++).padStart(3, '0')}`;
        if (!existingNumbers.has(candidate.toLowerCase())) { existingNumbers.add(candidate.toLowerCase()); names.push(candidate); }
      }
      await createRoomUnits(companyId, { roomTypeId: roomType.id, unitNumbers: names }, actorId);
    } else if (active.length > desired) {
      const toArchive = active.slice(desired);
      toArchive.forEach((unit) => { unit.status = 'archived'; unit.updatedBy = actorId; unit.updatedAt = new Date().toISOString(); });
      await hotelRepository.roomUnits.saveMany(toArchive, (row) => ({ id: row.id }));
    }
  }
  return roomTypeSummary(roomType);
}

async function archiveRoom(companyId, roomTypeId, actorId = 'company-admin') {
  const roomType = await archiveRoomType(companyId, roomTypeId, actorId);
  const units = await hotelRepository.roomUnits.list({ companyId, roomTypeId: roomType.id, status: { $ne: 'archived' } });
  units.forEach((unit) => { unit.status = 'archived'; unit.updatedBy = actorId; unit.updatedAt = new Date().toISOString(); });
  if (units.length) await hotelRepository.roomUnits.saveMany(units, (row) => ({ id: row.id }));
  return roomTypeSummary(roomType);
}

function toCsv(headers, rows) {
  const esc = (value) => { const text = String(value ?? ''); return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text; };
  return [headers, ...rows.map((row) => row.filter((cell) => typeof cell !== 'object'))].map((row) => row.map(esc).join(',')).join('\n');
}

async function pdfBuffer(title, rows) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 36, info: { Title: title } });
    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    doc.fontSize(16).text(title, { underline: true });
    doc.moveDown();
    rows.forEach((row) => doc.fontSize(9).text(row.filter((cell) => typeof cell !== 'object').join(' | ')));
    doc.end();
  });
}

module.exports = {
  createProperty,
  updateProperty,
  archiveProperty,
  createRoomType,
  updateRoomType,
  archiveRoomType,
  createRoomUnits,
  updateRoomUnit,
  archiveRoomUnit,
  createNightInventory,
  updateNightStatus,
  archiveNightInventory,
  createHotelBooking,
  roomMap,
  manifestRows,
  markStay,
  updateHousekeeping,
  createRoom,
  updateRoomInventory,
  archiveRoom,
  toCsv,
  pdfBuffer,
};
