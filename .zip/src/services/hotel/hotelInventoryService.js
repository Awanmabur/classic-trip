const crypto = require('crypto');
const hotelRepository = require('../../repositories/domain/hotelRepository');
const { mongoReady, sessionOptions } = require('../shared/mongoUnitOfWork');

const OPEN_NIGHT_STATUSES = new Set(['available', 'open']);
const ACTIVE_UNIT_STATUSES = new Set(['available']);

function clean(value) { return String(value || '').trim(); }
function dateOnly(value, label = 'date') {
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) throw Object.assign(new Error(`A valid ${label} is required`), { status: 422 });
  return parsed.toISOString().slice(0, 10);
}
function dateRange(checkInValue, checkOutValue) {
  const checkIn = dateOnly(checkInValue, 'check-in date');
  const checkOut = dateOnly(checkOutValue, 'check-out date');
  const start = new Date(`${checkIn}T00:00:00.000Z`);
  const end = new Date(`${checkOut}T00:00:00.000Z`);
  if (!(end > start)) throw Object.assign(new Error('Check-out must be after check-in'), { status: 422 });
  const nights = [];
  for (let cursor = new Date(start); cursor < end; cursor.setUTCDate(cursor.getUTCDate() + 1)) nights.push(cursor.toISOString().slice(0, 10));
  return { checkIn, checkOut, nights };
}
function nightResourceKey(roomUnitId, date) { return `room-unit-night:${clean(roomUnitId)}:${dateOnly(date, 'night date')}`; }
function nightId(roomUnitId, date) {
  return `room-night-${crypto.createHash('sha256').update(`${clean(roomUnitId)}:${dateOnly(date)}`).digest('hex').slice(0, 24)}`;
}
function nightIsOpen(row = {}) {
  return OPEN_NIGHT_STATUSES.has(clean(row.status || 'available').toLowerCase())
    && Number(row.availableInventory ?? 1) > 0
    && !clean(row.bookingRef);
}

async function resolveRoomTypeAndUnit({ listingId, companyId = '', roomTypeId = '', roomUnitId = '', selectionId = '' } = {}, options = {}) {
  const selected = clean(selectionId);
  let unit = null;
  let roomType = null;
  const unitKey = clean(roomUnitId) || selected;
  if (unitKey) unit = await hotelRepository.roomUnits.findOne({ id: unitKey, ...(listingId ? { listingId } : {}), ...(companyId ? { companyId } : {}), status: { $ne: 'archived' } }, options);
  const typeKey = clean(roomTypeId) || (!unit ? selected : unit.roomTypeId);
  if (typeKey) roomType = await hotelRepository.roomTypes.findOne({ id: typeKey, ...(listingId ? { listingId } : {}), ...(companyId ? { companyId } : {}), status: 'active' }, options);
  if (!roomType && unit?.roomTypeId) roomType = await hotelRepository.roomTypes.findOne({ id: unit.roomTypeId, status: 'active' }, options);
  if (!roomType) throw Object.assign(new Error('Room type not found or unavailable'), { status: 404 });
  if (unit && unit.roomTypeId !== roomType.id) throw Object.assign(new Error('Room unit does not belong to the selected room type'), { status: 422 });
  return { roomType, unit };
}

async function ensureNightInventoryForUnit(roomType, unit, nights, options = {}) {
  const existing = await hotelRepository.roomNightInventories.list({ roomUnitId: unit.id, date: { $in: nights } }, options);
  const byDate = new Map(existing.map((row) => [row.date, row]));
  const missing = nights.filter((date) => !byDate.has(date)).map((date) => ({
    id: nightId(unit.id, date),
    companyId: roomType.companyId,
    listingId: roomType.listingId,
    propertyId: roomType.propertyId || unit.propertyId || '',
    roomTypeId: roomType.id,
    roomUnitId: unit.id,
    date,
    price: Number(roomType.basePrice || 0),
    availableInventory: 1,
    status: 'available',
    createdBy: options.actorId || 'inventory-materializer',
    createdAt: new Date().toISOString(),
  }));
  if (missing.length) {
    await hotelRepository.roomNightInventories.saveMany(missing, (row) => ({ roomUnitId: row.roomUnitId, date: row.date }), options);
    missing.forEach((row) => byDate.set(row.date, row));
  }
  return nights.map((date) => byDate.get(date)).filter(Boolean);
}

async function activeHeldKeys(resourceKeys, holdId = '', now = new Date(), options = {}) {
  if (!resourceKeys.length) return new Set();
  const rows = await hotelRepository.inventoryHoldItems.list({
    resourceType: 'room_unit_night',
    resourceKey: { $in: resourceKeys },
    status: 'active',
    expiresAt: { $gt: now },
    ...(holdId ? { holdId: { $ne: holdId } } : {}),
  }, options);
  return new Set(rows.map((row) => row.resourceKey));
}

async function selectAvailableRoom({ listingId, companyId = '', roomTypeId = '', roomUnitId = '', selectionId = '', checkIn, checkOut, holdId = '' } = {}, options = {}) {
  const range = dateRange(checkIn, checkOut);
  const resolved = await resolveRoomTypeAndUnit({ listingId, companyId, roomTypeId, roomUnitId, selectionId }, options);
  const unitFilter = resolved.unit
    ? { id: resolved.unit.id }
    : { roomTypeId: resolved.roomType.id, status: { $in: [...ACTIVE_UNIT_STATUSES] } };
  const units = resolved.unit ? [resolved.unit] : await hotelRepository.roomUnits.list(unitFilter, { ...options, sort: { unitNumber: 1 }, limit: 500 });
  for (const unit of units) {
    if (!ACTIVE_UNIT_STATUSES.has(clean(unit.status).toLowerCase())) continue;
    const rows = await ensureNightInventoryForUnit(resolved.roomType, unit, range.nights, options);
    if (rows.length !== range.nights.length || !rows.every(nightIsOpen)) continue;
    const keys = rows.map((row) => nightResourceKey(unit.id, row.date));
    if ((await activeHeldKeys(keys, holdId, new Date(), options)).size) continue;
    return {
      roomType: resolved.roomType,
      roomUnit: unit,
      nightRows: rows,
      ...range,
      nightlyTotal: rows.reduce((sum, row) => sum + Number(row.price ?? resolved.roomType.basePrice ?? 0), 0),
    };
  }
  throw Object.assign(new Error('No room unit is available for the selected dates'), { status: 409, code: 'ROOM_UNIT_UNAVAILABLE' });
}

async function claimSelectedRoom(booking, payload = {}, session = null) {
  const item = booking.bookingItems?.[0] || {};
  const selection = await selectAvailableRoom({
    listingId: booking.listingId,
    companyId: booking.companyId,
    roomTypeId: payload.roomTypeId || item.roomTypeId || booking.hotelStay?.roomTypeIds?.[0],
    roomUnitId: payload.roomUnitId || item.roomUnitId || booking.hotelStay?.roomUnitIds?.[0],
    selectionId: payload.roomTypeId || payload.roomUnitId,
    checkIn: payload.checkInDate || payload.checkIn || booking.hotelStay?.checkIn || item.checkIn,
    checkOut: payload.checkOutDate || payload.checkOut || booking.hotelStay?.checkOut || item.checkOut,
    holdId: payload.holdId || booking.holdId || '',
  }, { session });

  const updates = {
    status: 'booked', availableInventory: 0, bookingRef: booking.bookingRef,
    guestName: booking.guestSnapshot?.fullName || 'Guest', checkInStatus: 'not_checked',
    holdId: payload.holdId || '', notes: booking.notes || '', updatedAt: new Date().toISOString(),
  };
  if (mongoReady()) {
    const RoomNightInventory = require('../../models/RoomNightInventory');
    for (const row of selection.nightRows) {
      const updated = await RoomNightInventory.findOneAndUpdate(
        { id: row.id, roomUnitId: selection.roomUnit.id, status: { $in: [...OPEN_NIGHT_STATUSES] }, availableInventory: { $gt: 0 }, $or: [{ bookingRef: '' }, { bookingRef: { $exists: false } }, { bookingRef: null }] },
        { $set: updates },
        sessionOptions(session, { new: true, runValidators: true })
      ).lean();
      if (!updated) throw Object.assign(new Error('Selected room nights are no longer available'), { status: 409, code: 'ROOM_NIGHT_CLAIM_FAILED' });
    }
  } else {
    for (const row of selection.nightRows) {
      if (!nightIsOpen(row)) throw Object.assign(new Error('Selected room nights are no longer available'), { status: 409, code: 'ROOM_NIGHT_CLAIM_FAILED' });
      Object.assign(row, updates);
      await hotelRepository.roomNightInventories.save(row, { id: row.id });
    }
  }

  const nightIds = selection.nightRows.map((row) => row.id);
  booking.hotelStay = {
    ...(booking.hotelStay || {}), checkIn: selection.checkIn, checkOut: selection.checkOut,
    nights: selection.nights, roomCount: 1, roomUnitIds: [selection.roomUnit.id], roomTypeIds: [selection.roomType.id], nightIds, status: 'booked',
  };
  booking.bookingItems = (booking.bookingItems?.length ? booking.bookingItems : [{ id: `${booking.bookingRef}-hotel-room-1`, serviceType: 'hotel' }]).map((row, index) => index === 0 ? {
    ...row, serviceType: 'hotel', roomTypeId: selection.roomType.id, roomUnitId: selection.roomUnit.id,
    roomType: selection.roomType.name, checkIn: selection.checkIn, checkOut: selection.checkOut,
    nights: selection.nights, nightIds, unitPrice: Number(selection.roomType.basePrice || 0), status: 'confirmed',
  } : row);
  return selection;
}

async function releaseBookedNights(bookingRef, options = {}) {
  const rows = await hotelRepository.roomNightInventories.list({ bookingRef }, options);
  for (const row of rows) {
    Object.assign(row, { status: 'available', availableInventory: 1, bookingRef: '', guestName: '', checkInStatus: '', holdId: '', updatedAt: new Date().toISOString() });
    await hotelRepository.roomNightInventories.save(row, { id: row.id }, options);
  }
  return rows;
}

async function inventorySummary(listingId, options = {}) {
  const [types, units] = await Promise.all([
    hotelRepository.roomTypes.list({ listingId, status: 'active' }, options),
    hotelRepository.roomUnits.list({ listingId, status: { $in: [...ACTIVE_UNIT_STATUSES] } }, options),
  ]);
  const unitsByType = new Map();
  units.forEach((unit) => unitsByType.set(unit.roomTypeId, (unitsByType.get(unit.roomTypeId) || 0) + 1));
  return types.map((roomType) => ({
    ...roomType,
    roomType: roomType.name,
    nightlyPrice: Number(roomType.basePrice || 0),
    inventory: unitsByType.get(roomType.id) || 0,
    availableUnits: unitsByType.get(roomType.id) || 0,
  }));
}

module.exports = {
  OPEN_NIGHT_STATUSES, ACTIVE_UNIT_STATUSES, dateRange, nightResourceKey, nightIsOpen,
  resolveRoomTypeAndUnit, ensureNightInventoryForUnit, selectAvailableRoom, claimSelectedRoom,
  releaseBookedNights, inventorySummary,
};
