const commerceRepository = require('../../repositories/domain/commerceRepository');

const futurePlatformFeatures = Object.freeze([
  Object.freeze({
    key: 'loyalty',
    label: 'Loyalty',
    release: 'future',
    bookable: false,
    status: 'planned',
    reason: 'Needs wallet maturity, reward rules, fraud controls, and customer account adoption.',
  }),
  Object.freeze({
    key: 'whatsapp_automation',
    label: 'WhatsApp automation',
    release: 'future',
    bookable: false,
    status: 'planned',
    reason: 'Notification adapter is ready; automated conversational booking flows need provider templates and approval.',
  }),
  Object.freeze({
    key: 'mobile_app',
    label: 'Mobile app',
    release: 'future',
    bookable: false,
    status: 'planned',
    reason: 'Launch after the web booking, ticketing, payouts, and support flows are stable in production.',
  }),
]);

function normalized(value) {
  return String(value || '').trim().toLowerCase();
}

async function categoryRoadmap() {
  const [categories, listings] = await Promise.all([
    commerceRepository.categories.list({}, { sort: { label: 1 }, limit: 500 }),
    commerceRepository.listings.list({}, { limit: 10000 }),
  ]);

  return categories.map((category) => {
    const categoryListings = listings.filter((listing) => normalized(listing.serviceType) === normalized(category.key));
    const bookableListings = categoryListings.filter((listing) => listing.bookable !== false && normalized(listing.status) === 'active');
    const release = category.release || (category.bookable ? 'v1' : 'architecture-ready');

    return {
      key: category.key,
      label: category.label,
      icon: category.icon,
      release,
      status: category.status || 'active',
      bookable: Boolean(category.bookable),
      listingCount: categoryListings.length,
      bookableListingCount: bookableListings.length,
      checkoutEnabled: Boolean(category.bookable && bookableListings.length),
      nextStep: category.bookable
        ? 'Keep production inventory, payment, ticketing, and support stable.'
        : 'Connect a provider, finalize inventory rules, enable checkout, then add scanner/support workflows.',
    };
  });
}

async function roadmap() {
  const categories = await categoryRoadmap();
  return {
    launchNow: categories.filter((item) => item.release === 'v1'),
    teasers: categories.filter((item) => item.release === 'teaser'),
    architectureReady: categories.filter((item) => item.release === 'architecture-ready'),
    plannedPlatformFeatures: futurePlatformFeatures.map((item) => ({ ...item })),
  };
}

module.exports = { roadmap, categoryRoadmap };
