const toSlug = require('../../utils/slugify');
const transportRepository = require('../../repositories/domain/transportRepository');
const timelineService = require('../support/timelineService');
const { normalizePermissions, REQUIRED_DRIVER_PERMISSIONS } = require('../../config/accessControl');

const ROUTED_SERVICE_TYPES = ['bus', 'flight', 'train', 'ferry', 'tour', 'airport_transfer', 'package', 'cargo'];
const VEHICLE_SERVICE_TYPES = ['bus', 'flight', 'train', 'ferry', 'tour', 'airport_transfer', 'car_rental', 'cargo'];
const SERVICE_LABELS = {
  bus: 'Bus', flight: 'Flight', train: 'Train', ferry: 'Ferry', tour: 'Tour',
  airport_transfer: 'Airport transfer', car_rental: 'Car rental', cargo: 'Cargo', package: 'Travel package',
};
const MAX_BATCH_SCHEDULES = 180;
const WEEKDAY_INDEX = { sun: 0, sunday: 0, mon: 1, monday: 1, tue: 2, tues: 2, tuesday: 2, wed: 3, wednesday: 3, thu: 4, thursday: 4, fri: 5, friday: 5, sat: 6, saturday: 6 };

function normalize(value) { return String(value || '').toLowerCase().trim(); }
function cleanText(value) { return String(value || '').replace(/<[^>]*>/g, '').trim(); }
function moneyValue(value, fallback = 0) { const amount = Number(value); return Number.isFinite(amount) ? amount : fallback; }
function boolValue(value) { return value === true || value === 'true' || value === 'on' || value === '1' || value === 1; }
function parseList(value) {
  if (Array.isArray(value)) return value.map(cleanText).filter(Boolean);
  return String(value || '').split(',').map(cleanText).filter(Boolean);
}
function parseStops(value) {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; }
  catch (error) { return parseList(value).map((name, index) => ({ name, stopOrder: index + 1 })); }
}
function parseDate(value, field = 'date') {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    const error = new Error(`A valid ${field} is required`);
    error.status = 422;
    throw error;
  }
  return date.toISOString();
}
function listingType(serviceType) { return SERVICE_LABELS[serviceType] || serviceType; }
function companyCanPublish(company = {}) { return company.verificationStatus === 'verified' && company.settings?.canPublish !== false; }
function validationError(message, status = 422) { const error = new Error(message); error.status = status; return error; }
function seatNumbers(totalSeats) { return Array.from({ length: Math.max(0, Math.round(moneyValue(totalSeats, 0))) }, (_, index) => String(index + 1)); }
function cleanSeatNumber(value, index = 0) { const raw = cleanText(value); const numeric = raw.match(/\d+/); return numeric ? String(Number(numeric[0])) : String(index + 1); }
function layoutSeatCount(layoutName, rows, fallback = 32) {
  const safeRows = Math.max(1, Math.round(moneyValue(rows, 0)));
  if (!safeRows) return Math.max(1, Math.round(moneyValue(fallback, 32)));
  const layout = normalize(layoutName || '2x2');
  if (layout === '2x1' || layout === 'sleeper') return safeRows * 3;
  if (layout === '2x3') return safeRows * 5;
  if (layout === 'flight-3x3') return safeRows * 6;
  return safeRows * 4;
}
function columnsForLayout(layoutName) {
  const layout = normalize(layoutName || '2x2');
  if (layout === '2x1' || layout === 'sleeper') return 3;
  if (layout === '2x3') return 5;
  if (layout === 'flight-3x3') return 6;
  return 4;
}
function generateVehicleSeats(totalSeats, cols = 4) {
  const columnCount = Math.max(1, Math.round(moneyValue(cols, 4)));
  return seatNumbers(totalSeats).map((seatNumber, index) => ({
    id: seatNumber, seatNumber, row: Math.floor(index / columnCount) + 1, col: (index % columnCount) + 1,
    deck: 'main', label: seatNumber, displayLabel: `Seat No ${seatNumber}`,
    seatType: index < 4 ? 'vip' : 'standard', seatClass: index < 4 ? 'VIP' : 'Standard',
    priceDelta: 0, status: 'available', blockedReason: '', isAisle: false, isDisabled: false,
  }));
}
function buildVehicleSeatTemplate({ labels = [], totalSeats = 32, cols = 4, defaultSeatClass = 'Standard', vipSeats = [], disabledSeats = [], blockedSeats = [], vipPriceDelta = 0 } = {}) {
  const rawLabels = parseList(labels);
  const safeLabels = rawLabels.length ? rawLabels.map((label, index) => cleanSeatNumber(label, index)) : seatNumbers(totalSeats);
  const vipSet = new Set(parseList(vipSeats).map(cleanSeatNumber));
  const disabledSet = new Set(parseList(disabledSeats).map(cleanSeatNumber));
  const blockedSet = new Set(parseList(blockedSeats).map(cleanSeatNumber));
  return safeLabels.map((label, index) => {
    const seatNumber = cleanSeatNumber(label, index);
    const isVip = vipSet.has(seatNumber);
    const isDisabled = disabledSet.has(seatNumber);
    const isBlocked = blockedSet.has(seatNumber);
    return {
      id: seatNumber, seatNumber, row: Math.floor(index / cols) + 1, col: (index % cols) + 1,
      deck: 'main', label: seatNumber, displayLabel: `Seat No ${seatNumber}`,
      seatType: isDisabled ? 'disabled' : isVip ? 'vip' : 'standard',
      seatClass: isDisabled ? 'Disabled' : isVip ? 'VIP' : ['VIP', 'Standard', 'Disabled'].includes(defaultSeatClass) ? defaultSeatClass : 'Standard',
      priceDelta: isVip ? moneyValue(vipPriceDelta, 0) : 0,
      status: isDisabled ? 'disabled' : isBlocked ? 'blocked' : 'available',
      blockedReason: isBlocked ? 'Blocked from vehicle template' : '', isAisle: false, isDisabled,
    };
  });
}
function vehicleSeatTemplate(vehicle = {}) {
  return Array.isArray(vehicle.seatTemplate) ? vehicle.seatTemplate : (Array.isArray(vehicle.seats) ? vehicle.seats : []);
}
function vehicleView(vehicle = {}) {
  // `seats` is a response-only compatibility alias. Persistence uses seatTemplate exclusively.
  // Preserve object identity for callers holding the newly created/updated vehicle instance;
  // MongoDB validation still persists only the canonical `seatTemplate` schema field.
  const template = vehicleSeatTemplate(vehicle);
  vehicle.seatTemplate = template;
  vehicle.seats = template;
  return vehicle;
}
function vehicleSeatNumbers(vehicle = {}, fallbackTotalSeats = 32) {
  const values = vehicleSeatTemplate(vehicle)
    .filter((seat) => !seat.isAisle && !seat.isDisabled)
    .map((seat) => cleanText(seat.seatNumber || seat.id || seat.label)).filter(Boolean);
  return values.length ? values : seatNumbers(Math.max(1, Math.round(moneyValue(vehicle.totalSeats, fallbackTotalSeats))));
}
function payloadMedia(payload = {}, label = 'Classic Trip media') {
  const asset = payload.mediaAsset || payload.uploadedMedia || payload.asset;
  if (asset && (asset.url || asset.secureUrl)) {
    const url = cleanText(asset.secureUrl || asset.url);
    return [{ url, secureUrl: url, publicId: cleanText(asset.publicId || asset.public_id || url), resourceType: cleanText(asset.resourceType || asset.resource_type || 'image'), width: asset.width, height: asset.height, format: asset.format, alt: cleanText(asset.alt || label), label: cleanText(asset.label || label) }];
  }
  const url = cleanText(payload.imageUrl || payload.image || payload.mediaUrl || payload.photoUrl || '');
  return url ? [{ url, secureUrl: url, publicId: cleanText(payload.imagePublicId || payload.publicId || url), resourceType: 'image', alt: cleanText(payload.imageAlt || label), label: cleanText(payload.imageLabel || label) }] : [];
}
function normalizeStopType(value) {
  const type = normalize(value || 'intermediate').replace(/-/g, '_');
  const aliases = { pickup_point: 'pickup', dropoff_point: 'dropoff', start: 'origin', end: 'destination' };
  const canonical = aliases[type] || type;
  return ['origin', 'boarding', 'pickup', 'intermediate', 'dropoff', 'destination'].includes(canonical) ? canonical : 'intermediate';
}
async function branchOrThrow(companyId, branchId, label = 'Branch') {
  const id = cleanText(branchId);
  if (!id) return null;
  const branch = await transportRepository.branches.findOne({ id, companyId, status: { $ne: 'archived' } });
  if (!branch) throw validationError(`${label} was not found for this company`);
  return branch;
}
function branchDisplayName(branch = {}) {
  return cleanText(branch.city || branch.name || branch.terminalCode || branch.id);
}
async function resolveBranchSelections(companyId, value) {
  const requested = parseList(value);
  if (!requested.length) return { ids: [], names: [] };
  const rows = await transportRepository.branches.list({ companyId, id: { $in: requested }, status: { $ne: 'archived' } });
  const byId = new Map(rows.map((row) => [String(row.id), row]));
  const missing = requested.filter((id) => !byId.has(String(id)));
  if (missing.length) throw validationError(`One or more selected branches/stops no longer exist: ${missing.join(', ')}`);
  return { ids: requested, names: requested.map((id) => branchDisplayName(byId.get(String(id)))) };
}
async function resolveDriver(companyId, driverId) {
  const id = cleanText(driverId);
  if (!id) return null;
  const employee = await transportRepository.employees.findOne({ companyId, id, status: 'active' });
  if (!employee) throw validationError('Selected driver is not an active employee of this company');
  const user = await transportRepository.users.findOne({ id: employee.userId, status: 'active', role: 'driver', verificationStatus: 'verified' });
  if (!user) throw validationError('Selected driver account is not active and fully verified');
  const granted = new Set(normalizePermissions(employee.permissions || []));
  if (!REQUIRED_DRIVER_PERMISSIONS.every((permission) => granted.has(permission))) throw validationError('Selected driver is missing required operational permissions');
  if (String(employee.safetyStatus || '').toLowerCase() !== 'cleared') throw validationError('Selected driver safety verification is not cleared');
  return { employee, user, name: cleanText(user.fullName || user.email || user.phone || employee.id) };
}
function routeStopSnapshot(stop) {
  return { id: stop.id, branchId: stop.branchId || '', name: stop.name, stopType: stop.stopType, stopOrder: stop.stopOrder, timeOffsetMinutes: stop.timeOffsetMinutes, pickupAllowed: stop.pickupAllowed, dropoffAllowed: stop.dropoffAllowed, publicInstructions: stop.publicInstructions, status: stop.status };
}
async function withRouteStops(route) {
  const stops = await transportRepository.routeStops.list({ routeId: route.id, companyId: route.companyId, status: { $ne: 'archived' } }, { sort: { stopOrder: 1 } });
  return { ...route, stops: stops.map(routeStopSnapshot) };
}
function scheduleDriverIds(schedule = {}) {
  return Array.from(new Set([...parseList(schedule.driverIds), schedule.driverEmployeeId, schedule.driverUserId].filter(Boolean)));
}
function seatSnapshot(seat) {
  return { id: seat.id, seatNumber: seat.seatNumber, seatClass: seat.seatClass, seatType: seat.seatType || normalize(seat.seatClass || 'standard'), status: seat.status, priceDelta: Number(seat.priceDelta || 0), blockedReason: seat.blockedReason || '' };
}
async function seatInventorySnapshot(scheduleId) {
  const seats = await transportRepository.seats.list({ scheduleId }, { sort: { seatNumber: 1 } });
  return seats.map(seatSnapshot);
}
async function recalculateScheduleAvailability(schedule) {
  const seats = await transportRepository.seats.list({ scheduleId: schedule.id });
  schedule.totalSeats = seats.length || Number(schedule.totalSeats || 0);
  schedule.availableSeats = seats.filter((seat) => seat.status === 'available').length;
  schedule.seatInventorySnapshot = seats.map(seatSnapshot);
  schedule.updatedAt = new Date().toISOString();
  return schedule;
}

async function createRoute(companyId, payload = {}) {
  const company = await transportRepository.companyOrThrow(companyId);
  const listing = await transportRepository.listingOrThrow(company.id, payload.listingId || payload.slug);
  if (!ROUTED_SERVICE_TYPES.includes(listing.serviceType)) throw validationError('Routes and departures can only be created for transport-style listings');
  const originBranch = await branchOrThrow(company.id, payload.originBranchId || payload.originTerminalId, 'Origin terminal/branch');
  const destinationBranch = await branchOrThrow(company.id, payload.destinationBranchId || payload.destinationTerminalId, 'Destination terminal/branch');
  const origin = cleanText(payload.origin || payload.from || branchDisplayName(originBranch) || listing.from);
  const destination = cleanText(payload.destination || payload.to || branchDisplayName(destinationBranch) || listing.to);
  if (!origin || !destination) throw validationError('Select origin and destination branches or provide their public names');
  if (originBranch && destinationBranch && originBranch.id === destinationBranch.id) throw validationError('Origin and destination must be different');
  const boarding = typeof payload.boardingBranchIds !== 'undefined'
    ? await resolveBranchSelections(company.id, payload.boardingBranchIds)
    : { ids: [], names: parseList(payload.boardingPoints) };
  const dropoffs = typeof payload.dropoffBranchIds !== 'undefined'
    ? await resolveBranchSelections(company.id, payload.dropoffBranchIds)
    : { ids: [], names: parseList(payload.dropoffPoints) };
  const now = new Date().toISOString();
  const route = {
    id: await transportRepository.nextId('route'), listingId: listing.id, companyId: company.id,
    routeName: cleanText(payload.routeName || payload.name || `${origin} to ${destination}`), origin, destination,
    originTerminalId: originBranch?.id || '', destinationTerminalId: destinationBranch?.id || '',
    distanceKm: moneyValue(payload.distanceKm, 0), estimatedDuration: cleanText(payload.estimatedDuration),
    estimatedDurationMinutes: Math.round(moneyValue(payload.estimatedDurationMinutes, 0)), operatingDays: parseList(payload.operatingDays),
    corridor: cleanText(payload.corridor || `${toSlug(origin)}-${toSlug(destination)}`),
    boardingBranchIds: boarding.ids, dropoffBranchIds: dropoffs.ids,
    boardingPoints: boarding.names, dropoffPoints: dropoffs.names,
    baggageRules: cleanText(payload.baggageRules || listing.baggageRules),
    cancellationRules: cleanText(payload.cancellationRules || listing.cancellationRules), publicInstructions: cleanText(payload.publicInstructions),
    policies: parseList(payload.policies || payload.policyIds), status: normalize(payload.status || 'active') === 'archived' ? 'archived' : 'active', createdAt: now,
  };
  const stops = [];
  const addStop = async (item, index) => {
    const branch = item.branchId ? await branchOrThrow(company.id, item.branchId, 'Route stop branch') : null;
    const name = cleanText(item.name || item.stopName || item.label || branchDisplayName(branch));
    if (!name) return;
    stops.push({
      id: await transportRepository.nextId('route-stop'), routeId: route.id, listingId: listing.id, companyId: company.id, branchId: branch?.id || '',
      name, stopType: normalizeStopType(item.stopType || item.type), stopOrder: Math.round(moneyValue(item.stopOrder || item.order, index + 1)),
      timeOffsetMinutes: Math.round(moneyValue(item.timeOffsetMinutes || item.offsetMinutes, 0)), pickupAllowed: item.pickupAllowed !== false,
      dropoffAllowed: item.dropoffAllowed !== false, publicInstructions: cleanText(item.publicInstructions || item.instructions), status: 'active', createdAt: now,
    });
  };
  const explicitStops = parseStops(payload.stops);
  if (originBranch) await addStop({ branchId: originBranch.id, name: origin, stopType: 'origin', pickupAllowed: true, dropoffAllowed: false, stopOrder: 1 }, 0);
  for (const [index, item] of explicitStops.entries()) await addStop(item, stops.length + index);
  if (destinationBranch) await addStop({ branchId: destinationBranch.id, name: destination, stopType: 'destination', pickupAllowed: false, dropoffAllowed: true, stopOrder: stops.length + 1 }, stops.length);
  listing.from = origin; listing.to = destination; listing.corridor = route.corridor; listing.updatedAt = now;
  await transportRepository.transaction(async (session) => {
    await transportRepository.routes.save(route, { id: route.id }, { session });
    await transportRepository.routeStops.saveMany(stops, null, { session });
    await transportRepository.listings.save(listing, { id: listing.id }, { session });
  });
  return { ...route, stops: stops.map(routeStopSnapshot) };
}

async function updateRoute(companyId, routeId, payload = {}) {
  const company = await transportRepository.companyOrThrow(companyId);
  const route = await transportRepository.routeOrThrow(company.id, routeId);
  const listing = await transportRepository.listingOrThrow(company.id, route.listingId);
  if (payload.routeName || payload.name) route.routeName = cleanText(payload.routeName || payload.name);
  const originBranchKey = typeof payload.originBranchId !== 'undefined' ? payload.originBranchId : payload.originTerminalId;
  const destinationBranchKey = typeof payload.destinationBranchId !== 'undefined' ? payload.destinationBranchId : payload.destinationTerminalId;
  const originBranch = typeof originBranchKey !== 'undefined' ? await branchOrThrow(company.id, originBranchKey, 'Origin terminal/branch') : null;
  const destinationBranch = typeof destinationBranchKey !== 'undefined' ? await branchOrThrow(company.id, destinationBranchKey, 'Destination terminal/branch') : null;
  if (typeof originBranchKey !== 'undefined') route.originTerminalId = originBranch?.id || '';
  if (typeof destinationBranchKey !== 'undefined') route.destinationTerminalId = destinationBranch?.id || '';
  if (payload.origin || payload.from || originBranch) route.origin = cleanText(payload.origin || payload.from || branchDisplayName(originBranch));
  if (payload.destination || payload.to || destinationBranch) route.destination = cleanText(payload.destination || payload.to || branchDisplayName(destinationBranch));
  if (!route.origin || !route.destination) throw validationError('Route origin and destination are required');
  if (route.originTerminalId && route.destinationTerminalId && route.originTerminalId === route.destinationTerminalId) throw validationError('Origin and destination must be different');
  if (typeof payload.distanceKm !== 'undefined') route.distanceKm = moneyValue(payload.distanceKm, route.distanceKm);
  if (typeof payload.estimatedDuration !== 'undefined') route.estimatedDuration = cleanText(payload.estimatedDuration);
  if (typeof payload.estimatedDurationMinutes !== 'undefined') route.estimatedDurationMinutes = Math.round(moneyValue(payload.estimatedDurationMinutes, route.estimatedDurationMinutes));
  if (typeof payload.operatingDays !== 'undefined') route.operatingDays = parseList(payload.operatingDays);
  route.corridor = cleanText(payload.corridor || `${toSlug(route.origin)}-${toSlug(route.destination)}`);
  if (typeof payload.boardingBranchIds !== 'undefined') {
    const selected = await resolveBranchSelections(company.id, payload.boardingBranchIds);
    route.boardingBranchIds = selected.ids; route.boardingPoints = selected.names;
  } else if (typeof payload.boardingPoints !== 'undefined') {
    route.boardingBranchIds = []; route.boardingPoints = parseList(payload.boardingPoints);
  }
  if (typeof payload.dropoffBranchIds !== 'undefined') {
    const selected = await resolveBranchSelections(company.id, payload.dropoffBranchIds);
    route.dropoffBranchIds = selected.ids; route.dropoffPoints = selected.names;
  } else if (typeof payload.dropoffPoints !== 'undefined') {
    route.dropoffBranchIds = []; route.dropoffPoints = parseList(payload.dropoffPoints);
  }
  if (typeof payload.baggageRules !== 'undefined') route.baggageRules = cleanText(payload.baggageRules);
  if (typeof payload.cancellationRules !== 'undefined') route.cancellationRules = cleanText(payload.cancellationRules);
  if (typeof payload.publicInstructions !== 'undefined') route.publicInstructions = cleanText(payload.publicInstructions);
  if (payload.status) route.status = normalize(payload.status) === 'archived' ? 'archived' : 'active';
  const now = new Date().toISOString(); route.updatedAt = now;
  listing.from = route.origin; listing.to = route.destination; listing.corridor = route.corridor; listing.updatedAt = now;
  let routeStopRows = [];
  if (typeof payload.stops !== 'undefined') {
    const existing = await transportRepository.routeStops.list({ routeId: route.id, companyId: company.id });
    existing.forEach((stop) => { stop.status = 'archived'; stop.updatedAt = now; });
    const replacements = [];
    for (const [index, item] of parseStops(payload.stops).entries()) {
      const branch = item.branchId ? await branchOrThrow(company.id, item.branchId, 'Route stop branch') : null;
      const name = cleanText(item.name || item.stopName || item.label || branchDisplayName(branch));
      if (!name) continue;
      replacements.push({ id: await transportRepository.nextId('route-stop'), routeId: route.id, listingId: listing.id, companyId: company.id, branchId: branch?.id || '', name, stopType: normalizeStopType(item.stopType || item.type), stopOrder: Math.round(moneyValue(item.stopOrder || item.order, index + 1)), timeOffsetMinutes: Math.round(moneyValue(item.timeOffsetMinutes || item.offsetMinutes, 0)), pickupAllowed: item.pickupAllowed !== false, dropoffAllowed: item.dropoffAllowed !== false, publicInstructions: cleanText(item.publicInstructions || item.instructions), status: 'active', createdAt: now });
    }
    routeStopRows = [...existing, ...replacements];
  }
  await transportRepository.transaction(async (session) => {
    await transportRepository.routes.save(route, { id: route.id }, { session });
    await transportRepository.listings.save(listing, { id: listing.id }, { session });
    if (routeStopRows.length) await transportRepository.routeStops.saveMany(routeStopRows, null, { session });
  });
  return withRouteStops(route);
}

async function createRouteStop(companyId, routeId, payload = {}, actorId = 'company-admin') {
  const company = await transportRepository.companyOrThrow(companyId);
  const route = await transportRepository.routeOrThrow(company.id, routeId);
  const listing = await transportRepository.listingOrThrow(company.id, route.listingId);
  const branch = await branchOrThrow(company.id, payload.branchId, 'Route stop branch');
  const stopType = normalizeStopType(payload.stopType || payload.type);
  const name = cleanText(payload.name || payload.stopName || payload.label || branchDisplayName(branch));
  if (!name) throw validationError('Select a branch or provide the public stop name');

  const activeStops = await transportRepository.routeStops.list(
    { routeId: route.id, companyId: company.id, status: { $ne: 'archived' } },
    { sort: { stopOrder: 1 } }
  );
  if (['origin', 'destination'].includes(stopType)
    && activeStops.some((item) => item.stopType === stopType)) {
    throw validationError(`This route already has an active ${stopType} stop. Update the existing stop instead.`);
  }
  if (branch && activeStops.some((item) => item.branchId === branch.id)) {
    throw validationError('The selected branch is already used as an active stop on this route');
  }

  const maxOrder = activeStops.reduce((maximum, item) => Math.max(maximum, Number(item.stopOrder || 0)), 0);
  const requestedOrder = Math.round(moneyValue(payload.stopOrder || payload.order, maxOrder + 1));
  const now = new Date().toISOString();
  const stop = {
    id: await transportRepository.nextId('route-stop'),
    routeId: route.id,
    listingId: listing.id,
    companyId: company.id,
    branchId: branch?.id || '',
    name,
    stopType,
    stopOrder: Math.max(1, requestedOrder),
    timeOffsetMinutes: Math.max(0, Math.round(moneyValue(payload.timeOffsetMinutes || payload.offsetMinutes, 0))),
    pickupAllowed: typeof payload.pickupAllowed === 'undefined'
      ? !['dropoff', 'destination'].includes(stopType)
      : boolValue(payload.pickupAllowed),
    dropoffAllowed: typeof payload.dropoffAllowed === 'undefined'
      ? !['origin', 'boarding', 'pickup'].includes(stopType)
      : boolValue(payload.dropoffAllowed),
    publicInstructions: cleanText(payload.publicInstructions || payload.instructions),
    status: normalize(payload.status) === 'archived' ? 'archived' : 'active',
    createdBy: actorId,
    createdAt: now,
  };

  if (stop.stopType === 'origin') {
    if (route.destinationTerminalId && stop.branchId && route.destinationTerminalId === stop.branchId) {
      throw validationError('Origin and destination must be different');
    }
    route.origin = stop.name;
    route.originTerminalId = stop.branchId;
    listing.from = stop.name;
  }
  if (stop.stopType === 'destination') {
    if (route.originTerminalId && stop.branchId && route.originTerminalId === stop.branchId) {
      throw validationError('Origin and destination must be different');
    }
    route.destination = stop.name;
    route.destinationTerminalId = stop.branchId;
    listing.to = stop.name;
  }
  route.corridor = cleanText(route.corridor || `${toSlug(route.origin)}-${toSlug(route.destination)}`);
  listing.corridor = route.corridor;
  route.updatedAt = now;
  listing.updatedAt = now;

  await transportRepository.transaction(async (session) => {
    await transportRepository.routeStops.save(stop, { id: stop.id }, { session });
    await transportRepository.routes.save(route, { id: route.id }, { session });
    await transportRepository.listings.save(listing, { id: listing.id }, { session });
  });
  await transportRepository.audit({
    actorId,
    action: 'company.route_stop.created',
    targetId: stop.id,
    meta: { companyId: company.id, routeId: route.id, branchId: stop.branchId, stopType: stop.stopType },
  });
  return stop;
}

async function updateRouteStop(companyId, stopId, payload = {}, actorId = 'company-admin') {
  const company = await transportRepository.companyOrThrow(companyId);
  const stop = await transportRepository.routeStopOrThrow(company.id, stopId);
  const route = await transportRepository.routeOrThrow(company.id, stop.routeId);
  const listing = await transportRepository.listingOrThrow(company.id, route.listingId);
  const branch = typeof payload.branchId !== 'undefined'
    ? await branchOrThrow(company.id, payload.branchId, 'Route stop branch')
    : null;
  const siblings = await transportRepository.routeStops.list(
    { routeId: route.id, companyId: company.id, status: { $ne: 'archived' } },
    { sort: { stopOrder: 1 } }
  );
  const nextType = typeof payload.stopType !== 'undefined' || typeof payload.type !== 'undefined'
    ? normalizeStopType(payload.stopType || payload.type)
    : stop.stopType;
  if (['origin', 'destination'].includes(nextType)
    && siblings.some((item) => item.id !== stop.id && item.stopType === nextType)) {
    throw validationError(`This route already has an active ${nextType} stop`);
  }
  if (branch && siblings.some((item) => item.id !== stop.id && item.branchId === branch.id)) {
    throw validationError('The selected branch is already used as an active stop on this route');
  }

  if (typeof payload.branchId !== 'undefined') stop.branchId = branch?.id || '';
  if (typeof payload.name !== 'undefined' || typeof payload.stopName !== 'undefined' || typeof payload.label !== 'undefined' || branch) {
    stop.name = cleanText(payload.name || payload.stopName || payload.label || branchDisplayName(branch));
  }
  if (!stop.name) throw validationError('Route stop name is required');
  stop.stopType = nextType;
  if (typeof payload.stopOrder !== 'undefined' || typeof payload.order !== 'undefined') {
    stop.stopOrder = Math.max(1, Math.round(moneyValue(payload.stopOrder || payload.order, stop.stopOrder)));
  }
  if (typeof payload.timeOffsetMinutes !== 'undefined' || typeof payload.offsetMinutes !== 'undefined') {
    stop.timeOffsetMinutes = Math.max(0, Math.round(moneyValue(payload.timeOffsetMinutes || payload.offsetMinutes, stop.timeOffsetMinutes)));
  }
  if (typeof payload.pickupAllowed !== 'undefined') stop.pickupAllowed = boolValue(payload.pickupAllowed);
  if (typeof payload.dropoffAllowed !== 'undefined') stop.dropoffAllowed = boolValue(payload.dropoffAllowed);
  if (typeof payload.publicInstructions !== 'undefined' || typeof payload.instructions !== 'undefined') {
    stop.publicInstructions = cleanText(payload.publicInstructions || payload.instructions);
  }
  if (typeof payload.status !== 'undefined') stop.status = normalize(payload.status) === 'archived' ? 'archived' : 'active';

  const now = new Date().toISOString();
  stop.updatedBy = actorId;
  stop.updatedAt = now;
  if (stop.status !== 'archived' && stop.stopType === 'origin') {
    if (route.destinationTerminalId && stop.branchId && route.destinationTerminalId === stop.branchId) {
      throw validationError('Origin and destination must be different');
    }
    route.origin = stop.name;
    route.originTerminalId = stop.branchId;
    listing.from = stop.name;
  }
  if (stop.status !== 'archived' && stop.stopType === 'destination') {
    if (route.originTerminalId && stop.branchId && route.originTerminalId === stop.branchId) {
      throw validationError('Origin and destination must be different');
    }
    route.destination = stop.name;
    route.destinationTerminalId = stop.branchId;
    listing.to = stop.name;
  }
  route.corridor = `${toSlug(route.origin)}-${toSlug(route.destination)}`;
  listing.corridor = route.corridor;
  route.updatedAt = now;
  listing.updatedAt = now;

  await transportRepository.transaction(async (session) => {
    await transportRepository.routeStops.save(stop, { id: stop.id }, { session });
    await transportRepository.routes.save(route, { id: route.id }, { session });
    await transportRepository.listings.save(listing, { id: listing.id }, { session });
  });
  await transportRepository.audit({
    actorId,
    action: 'company.route_stop.updated',
    targetId: stop.id,
    meta: { companyId: company.id, routeId: route.id, branchId: stop.branchId, stopType: stop.stopType, status: stop.status },
  });
  return stop;
}

async function archiveRouteStop(companyId, stopId, actorId = 'company-admin') {
  return updateRouteStop(companyId, stopId, { status: 'archived' }, actorId);
}

async function moveRouteStop(companyId, stopId, direction = 'up', actorId = 'company-admin') {
  const stop = await transportRepository.routeStopOrThrow(companyId, stopId);
  const route = await transportRepository.routeOrThrow(companyId, stop.routeId);
  const siblings = await transportRepository.routeStops.list({ routeId: route.id, companyId, status: { $ne: 'archived' } }, { sort: { stopOrder: 1 } });
  const currentIndex = siblings.findIndex((item) => item.id === stop.id);
  const targetIndex = direction === 'down' ? currentIndex + 1 : currentIndex - 1;
  if (currentIndex < 0 || targetIndex < 0 || targetIndex >= siblings.length) return stop;
  const target = siblings[targetIndex]; const order = stop.stopOrder; stop.stopOrder = target.stopOrder; target.stopOrder = order;
  stop.updatedBy = actorId; target.updatedBy = actorId; stop.updatedAt = target.updatedAt = new Date().toISOString();
  await transportRepository.routeStops.saveMany([stop, target]); route.updatedAt = stop.updatedAt; await transportRepository.routes.save(route);
  await transportRepository.audit({ actorId, action: 'company.route_stop.reordered', targetId: stop.id, meta: { companyId, routeId: route.id, direction, swappedWith: target.id } });
  return stop;
}

async function archiveRoute(companyId, routeId) {
  const route = await transportRepository.routeOrThrow(companyId, routeId); route.status = 'archived'; route.updatedAt = new Date().toISOString();
  const schedules = await transportRepository.schedules.list({ routeId: route.id, companyId });
  schedules.forEach((schedule) => { schedule.status = 'archived'; schedule.updatedAt = route.updatedAt; });
  await transportRepository.routes.save(route); await transportRepository.schedules.saveMany(schedules); return route;
}

async function createVehicle(companyId, payload = {}) {
  const company = await transportRepository.companyOrThrow(companyId);
  const listing = payload.listingId ? await transportRepository.listingOrThrow(company.id, payload.listingId) : null;
  const serviceType = normalize(payload.serviceType || listing?.serviceType || 'bus').replace('-', '_');
  if (!VEHICLE_SERVICE_TYPES.includes(serviceType)) throw validationError('Vehicles cannot be created for hotel listings. Use rooms for hotel inventory.');
  const layoutName = cleanText(payload.layoutName || payload.layout || listing?.layout || (serviceType === 'flight' ? 'flight-3x3' : '2x2'));
  const rows = Math.max(1, Math.round(moneyValue(payload.rows, serviceType === 'flight' ? 10 : 12)));
  const cols = columnsForLayout(layoutName);
  const totalSeats = Math.max(1, Math.round(moneyValue(payload.totalSeats, layoutSeatCount(layoutName, rows, 32))));
  const count = await transportRepository.vehicles.count({ companyId: company.id });
  const vehicle = { id: await transportRepository.nextId('vehicle'), companyId: company.id, listingId: listing?.id || '', serviceType, name: cleanText(payload.name || `${company.name} ${listingType(serviceType)} ${count + 1}`), plateOrCode: cleanText(payload.plateOrCode || payload.code), layoutName, rows, cols, totalSeats, seatTemplate: generateVehicleSeats(totalSeats, cols), amenities: parseList(payload.amenities || 'Ticket scanner'), media: payloadMedia(payload, cleanText(payload.name || `${company.name} vehicle`)), status: ['active', 'maintenance', 'paused', 'archived'].includes(normalize(payload.status)) ? normalize(payload.status) : 'active', createdAt: new Date().toISOString() };
  await transportRepository.vehicles.save(vehicle); return vehicleView(vehicle);
}

async function updateVehicle(companyId, vehicleId, payload = {}) {
  const company = await transportRepository.companyOrThrow(companyId); const vehicle = await transportRepository.vehicleOrThrow(company.id, vehicleId);
  if (payload.listingId) { const listing = await transportRepository.listingOrThrow(company.id, payload.listingId); if (!VEHICLE_SERVICE_TYPES.includes(listing.serviceType)) throw validationError('Vehicles cannot be linked to this listing type'); vehicle.listingId = listing.id; vehicle.serviceType = listing.serviceType; }
  if (payload.serviceType) { const type = normalize(payload.serviceType).replace('-', '_'); if (!VEHICLE_SERVICE_TYPES.includes(type)) throw validationError('Invalid vehicle service type'); vehicle.serviceType = type; }
  if (payload.name) vehicle.name = cleanText(payload.name);
  if (typeof payload.plateOrCode !== 'undefined' || typeof payload.code !== 'undefined') vehicle.plateOrCode = cleanText(payload.plateOrCode || payload.code);
  if (payload.layoutName || payload.layout) { vehicle.layoutName = cleanText(payload.layoutName || payload.layout); vehicle.cols = columnsForLayout(vehicle.layoutName); }
  if (typeof payload.rows !== 'undefined') vehicle.rows = Math.max(1, Math.round(moneyValue(payload.rows, vehicle.rows)));
  if (typeof payload.totalSeats !== 'undefined') { vehicle.totalSeats = Math.max(1, Math.round(moneyValue(payload.totalSeats, vehicle.totalSeats))); vehicle.seatTemplate = generateVehicleSeats(vehicle.totalSeats, vehicle.cols || 4); }
  const media = payloadMedia(payload, vehicle.name); if (media.length) vehicle.media = [...(vehicle.media || []), media[0]];
  if (typeof payload.amenities !== 'undefined') vehicle.amenities = parseList(payload.amenities);
  if (payload.status && ['active', 'maintenance', 'paused', 'archived'].includes(normalize(payload.status))) vehicle.status = normalize(payload.status);
  vehicle.updatedAt = new Date().toISOString(); await transportRepository.vehicles.save(vehicle); return vehicleView(vehicle);
}

async function archiveVehicle(companyId, vehicleId) {
  const vehicle = await transportRepository.vehicleOrThrow(companyId, vehicleId);
  const activeCount = await transportRepository.schedules.count({ vehicleId: vehicle.id, companyId, status: { $in: ['active', 'published', 'boarding', 'departed'] } });
  vehicle.status = activeCount ? 'maintenance' : 'archived'; vehicle.updatedAt = new Date().toISOString(); await transportRepository.vehicles.save(vehicle); return vehicleView(vehicle);
}

async function updateVehicleSeatTemplate(companyId, vehicleId, payload = {}, actorId = 'company-admin') {
  const vehicle = await transportRepository.vehicleOrThrow(companyId, vehicleId || payload.vehicleId);
  const layoutName = cleanText(payload.layoutName || payload.layout || vehicle.layoutName || '2x2');
  const rows = Math.max(1, Math.round(moneyValue(payload.rows, vehicle.rows || 12))); const cols = columnsForLayout(layoutName);
  const labels = parseList(payload.seatLabels || payload.labels); const totalSeats = labels.length || Math.max(1, Math.round(moneyValue(payload.totalSeats, layoutSeatCount(layoutName, rows, vehicle.totalSeats || 32))));
  const preserve = typeof payload.preserveExistingSchedules === 'undefined' ? true : boolValue(payload.preserveExistingSchedules);
  const defaultSeatClass = ['VIP', 'Standard', 'Disabled'].includes(cleanText(payload.defaultSeatClass || vehicle.defaultSeatClass)) ? cleanText(payload.defaultSeatClass || vehicle.defaultSeatClass) : 'Standard';
  const vipPriceDelta = moneyValue(payload.vipPriceDelta, vehicle.vipPriceDelta || 0);
  Object.assign(vehicle, { layoutName, rows, cols, totalSeats, defaultSeatClass, vipPriceDelta, seatTemplate: buildVehicleSeatTemplate({ labels, totalSeats, cols, defaultSeatClass, vipSeats: payload.vipSeats, disabledSeats: payload.disabledSeats, blockedSeats: payload.blockedSeats, vipPriceDelta }), updatedAt: new Date().toISOString() });
  await transportRepository.vehicles.save(vehicle);
  if (!preserve) {
    const schedules = await transportRepository.schedules.list({ companyId, vehicleId: vehicle.id, status: { $in: ['draft', 'active', 'published'] } });
    for (const schedule of schedules) {
      const seats = vehicleSeatTemplate(vehicle).filter((seat) => !seat.isDisabled).map((templateSeat) => ({ id: `seat-${schedule.id}-${templateSeat.seatNumber}`, scheduleId: schedule.id, seatNumber: templateSeat.seatNumber, seatClass: templateSeat.seatClass || defaultSeatClass, seatType: templateSeat.seatType || normalize(defaultSeatClass), priceDelta: moneyValue(templateSeat.priceDelta, 0), status: templateSeat.status === 'blocked' ? 'blocked' : 'available', blockedReason: templateSeat.blockedReason || '', lockedUntil: null, lockId: null, createdAt: vehicle.updatedAt }));
      schedule.totalSeats = seats.length; schedule.availableSeats = seats.filter((seat) => seat.status === 'available').length; schedule.seatInventorySnapshot = seats.map(seatSnapshot); schedule.updatedAt = vehicle.updatedAt;
      // eslint-disable-next-line no-await-in-loop
      await transportRepository.replaceScheduleSeats({ schedule, seats });
    }
  }
  await transportRepository.audit({ actorId, action: 'company.vehicle.seat_template_updated', targetId: vehicle.id, meta: { companyId, layoutName, totalSeats } });
  return vehicleView(vehicle);
}

async function updateVehicleStatus(companyId, vehicleId, payload = {}, actorId = 'company-admin') {
  const vehicle = await transportRepository.vehicleOrThrow(companyId, vehicleId);
  const status = normalize(payload.status || 'active'); if (!['active', 'maintenance', 'paused', 'archived'].includes(status)) throw validationError('Invalid vehicle status');
  vehicle.status = status; vehicle.maintenanceReason = cleanText(payload.maintenanceReason || payload.reason); vehicle.updatedBy = actorId; vehicle.updatedAt = new Date().toISOString();
  await transportRepository.vehicles.save(vehicle); await transportRepository.audit({ actorId, action: 'company.vehicle.status_updated', targetId: vehicle.id, meta: { companyId, status } }); return vehicleView(vehicle);
}

async function validateSchedulePublish(companyId, schedule = {}) {
  const [company, route, vehicle, seats, assignments, activeSchedules, routeStops] = await Promise.all([
    transportRepository.companies.findOne({ id: companyId }),
    transportRepository.routes.findOne({ id: schedule.routeId, companyId }),
    transportRepository.vehicles.findOne({ id: schedule.vehicleId, companyId }),
    transportRepository.seats.list({ scheduleId: schedule.id }),
    transportRepository.driverAssignments.list({ companyId, scheduleId: schedule.id, status: { $nin: ['archived', 'cancelled'] } }),
    transportRepository.schedules.list({ companyId, vehicleId: schedule.vehicleId, id: { $ne: schedule.id }, status: { $in: ['active', 'published', 'boarding', 'departed'] } }),
    transportRepository.routeStops.list({ companyId, routeId: schedule.routeId, status: { $ne: 'archived' } }),
  ]);
  const listing = route ? await transportRepository.listings.findOne({ id: route.listingId, companyId }) : null;
  const failures = []; const warnings = []; const departAt = schedule.departAt ? new Date(schedule.departAt) : null;
  const conflicts = activeSchedules.filter((item) => item.departAt && schedule.departAt && Math.abs(new Date(item.departAt).getTime() - new Date(schedule.departAt).getTime()) < 4 * 60 * 60 * 1000);
  if (!companyCanPublish(company)) failures.push('company_not_verified');
  if (!listing || normalize(listing.status) === 'archived') failures.push('listing_missing_or_archived');
  if (!route || ['archived', 'paused', 'inactive'].includes(normalize(route?.status))) failures.push('route_not_active');
  if (!route?.origin || !route?.destination) failures.push('route_origin_destination_missing');
  if (!route?.cancellationRules && !listing?.cancellationRules) failures.push('cancellation_policy_missing');
  if (!vehicle || ['archived', 'maintenance', 'paused', 'inactive'].includes(normalize(vehicle?.status))) failures.push('vehicle_not_active');
  if (vehicle?.listingId && listing && vehicle.listingId !== listing.id) failures.push('vehicle_listing_mismatch');
  if (!seats.length) failures.push('seat_map_missing');
  if (seats.length && !seats.some((seat) => ['available', 'held', 'booked', 'locked', 'taken'].includes(normalize(seat.status)))) failures.push('seat_inventory_invalid');
  if (!Number(schedule.basePrice || 0)) failures.push('fare_missing');
  if (!schedule.currency) failures.push('currency_missing');
  if (!departAt || Number.isNaN(departAt.getTime())) failures.push('departure_time_missing'); else if (departAt.getTime() <= Date.now()) failures.push('departure_must_be_future');
  if (schedule.arriveAt && departAt && new Date(schedule.arriveAt).getTime() <= departAt.getTime()) failures.push('arrival_must_be_after_departure');
  if (!assignments.length && !scheduleDriverIds(schedule).length) failures.push('driver_assignment_missing');
  if (conflicts.length) failures.push('vehicle_time_conflict');
  if (!route?.boardingPoints?.length && !routeStops.some((stop) => stop.pickupAllowed)) warnings.push('no_pickup_points_configured');
  if (!route?.dropoffPoints?.length && !routeStops.some((stop) => stop.dropoffAllowed)) warnings.push('no_dropoff_points_configured');
  return { ok: failures.length === 0, failures, warnings, checkedAt: new Date().toISOString(), summary: { companyVerified: companyCanPublish(company), routeActive: !!route && !['archived', 'paused', 'inactive'].includes(normalize(route.status)), vehicleActive: !!vehicle && !['archived', 'maintenance', 'paused', 'inactive'].includes(normalize(vehicle.status)), seatCount: seats.length, driverAssigned: !!assignments.length || !!scheduleDriverIds(schedule).length, hasFare: Number(schedule.basePrice || 0) > 0, hasCancellationPolicy: !!(route?.cancellationRules || listing?.cancellationRules) } };
}

async function createSchedule(companyId, payload = {}) {
  const company = await transportRepository.companyOrThrow(companyId); const route = await transportRepository.routeOrThrow(company.id, payload.routeId); const listing = await transportRepository.listingOrThrow(company.id, route.listingId);
  if (!ROUTED_SERVICE_TYPES.includes(listing.serviceType)) throw validationError('Departures cannot be created for this listing type');
  let vehicle = null;
  if (payload.vehicleId) vehicle = await transportRepository.vehicleOrThrow(company.id, payload.vehicleId);
  else vehicle = await transportRepository.vehicles.findOne({ companyId: company.id, listingId: listing.id, status: { $ne: 'archived' } });
  if (!vehicle) throw validationError('Select a vehicle before creating a departure');
  if (vehicle.listingId && vehicle.listingId !== listing.id) throw validationError('Selected vehicle is linked to a different listing');
  const seatList = vehicleSeatNumbers(vehicle, moneyValue(payload.totalSeats, 32)); const totalSeats = Math.max(1, Math.round(moneyValue(payload.totalSeats, vehicle.totalSeats || seatList.length || 32)));
  const blockedSeats = new Set(parseList(payload.blockedSeats)); const now = new Date().toISOString();
  const driver = await resolveDriver(company.id, payload.driverId || parseList(payload.driverIds)[0]);
  const fareClass = normalize(payload.fareClass || 'standard');
  const requestedStatus = ['draft', 'active', 'published'].includes(normalize(payload.status)) ? normalize(payload.status) : 'active';
  const schedule = { id: await transportRepository.nextId('schedule'), routeId: route.id, listingId: listing.id, companyId: company.id, vehicleId: vehicle.id, vehicleName: vehicle.name, driverName: driver?.name || cleanText(payload.driverName), driverIds: driver ? [driver.employee.id, driver.user.id] : parseList(payload.driverIds), driverEmployeeId: driver?.employee.id || '', driverUserId: driver?.user.id || '', assignmentStatus: driver ? 'assigned' : '', departAt: parseDate(payload.departAt || new Date(Date.now() + 86400000), 'departure time'), arriveAt: payload.arriveAt ? parseDate(payload.arriveAt, 'arrival time') : null, boardingStartAt: payload.boardingStartAt ? parseDate(payload.boardingStartAt, 'boarding time') : null, basePrice: moneyValue(payload.basePrice || payload.priceFrom, listing.priceFrom), currency: cleanText(listing.currency || company.operatingCurrency || 'UGX'), fareClass, gate: cleanText(payload.gate), platform: cleanText(payload.platform), notes: cleanText(payload.notes), totalSeats, availableSeats: 0, status: requestedStatus === 'published' ? 'draft' : requestedStatus, scheduleRuleId: cleanText(payload.scheduleRuleId), createdAt: now };
  const seats = seatList.slice(0, totalSeats).map((seatNumber, index) => { const template = vehicleSeatTemplate(vehicle).find((seat) => String(seat.seatNumber) === String(seatNumber)) || {}; const blocked = blockedSeats.has(seatNumber) || template.status === 'blocked'; return { id: `seat-${schedule.id}-${seatNumber}`, scheduleId: schedule.id, seatNumber, seatClass: template.seatClass || (index < 4 ? 'VIP' : 'Standard'), seatType: template.seatType || (index < 4 ? 'vip' : 'standard'), priceDelta: moneyValue(template.priceDelta, index < 4 ? moneyValue(payload.vipPriceDelta, 12000) : 0), status: blocked ? 'blocked' : 'available', blockedReason: blocked ? cleanText(payload.blockedReason || template.blockedReason || 'Blocked during schedule setup') : '', lockedUntil: null, lockId: null, createdAt: now }; });
  schedule.availableSeats = seats.filter((seat) => seat.status === 'available').length; schedule.seatInventorySnapshot = seats.map(seatSnapshot);
  // Save first so repository-backed validation can read the canonical schedule and seat inventory.
  await transportRepository.commitSchedule({ schedule, seats });
  schedule.publishValidation = await validateSchedulePublish(company.id, schedule);
  if (requestedStatus === 'published' && schedule.publishValidation.ok) { schedule.status = 'published'; schedule.publishedAt = new Date().toISOString(); }
  else if (requestedStatus === 'published') schedule.status = 'draft';
  await transportRepository.schedules.save(schedule);
  return { schedule, seats };
}

function allowedWeekdaySet(days) { const indexes = new Set(); parseList(days).forEach((day) => { const index = WEEKDAY_INDEX[normalize(day)]; if (index !== undefined) indexes.add(index); else if (/^[0-6]$/.test(String(day))) indexes.add(Number(day)); }); return indexes; }
async function createScheduleBatch(companyId, payload = {}) {
  const start = new Date(payload.departAt || Date.now() + 86400000); if (Number.isNaN(start.getTime())) throw validationError('A valid departure time is required');
  const until = payload.repeatUntil ? new Date(`${String(payload.repeatUntil).slice(0, 10)}T23:59:59`) : null; const duration = payload.arriveAt ? new Date(payload.arriveAt).getTime() - start.getTime() : null; const days = allowedWeekdaySet(payload.repeatDays); const dates = [];
  if (!until || Number.isNaN(until.getTime()) || until <= start) dates.push(start); else { let cursor = new Date(start); let guard = 0; while (cursor <= until && guard < MAX_BATCH_SCHEDULES) { if (!days.size || days.has(cursor.getDay())) dates.push(new Date(cursor)); cursor = new Date(cursor.getTime() + 86400000); guard += 1; } }
  if (!dates.length) throw validationError('No departure dates matched the selected repeat range and days');
  const schedules = []; for (const departAt of dates) { const arriveAt = Number.isFinite(duration) ? new Date(departAt.getTime() + duration).toISOString() : undefined; const result = await createSchedule(companyId, { ...payload, departAt: departAt.toISOString(), arriveAt }); schedules.push(result.schedule); }
  return { schedules, count: schedules.length };
}

async function createScheduleRule(companyId, payload = {}, actorId = 'company-admin') {
  const company = await transportRepository.companyOrThrow(companyId); const route = await transportRepository.routeOrThrow(company.id, payload.routeId); const listing = await transportRepository.listingOrThrow(company.id, route.listingId);
  if (!ROUTED_SERVICE_TYPES.includes(listing.serviceType)) throw validationError('Recurring departures can only be created for transport-style listings');
  const vehicle = await transportRepository.vehicleOrThrow(company.id, payload.vehicleId); if (vehicle.listingId && vehicle.listingId !== listing.id) throw validationError('Selected vehicle is linked to a different listing');
  const departureTime = cleanText(payload.departureTime); if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(departureTime)) throw validationError('Departure time must be in HH:MM 24-hour format');
  const startDate = payload.startDate ? new Date(`${String(payload.startDate).slice(0, 10)}T00:00:00`) : new Date(); if (Number.isNaN(startDate.getTime())) throw validationError('A valid start date is required');
  const endDate = payload.endDate ? new Date(`${String(payload.endDate).slice(0, 10)}T23:59:59`) : null; if (endDate && Number.isNaN(endDate.getTime())) throw validationError('End date is invalid');
  const rule = { id: await transportRepository.nextId('schedule-rule'), companyId: company.id, listingId: listing.id, routeId: route.id, vehicleId: vehicle.id, departureTime, daysOfWeek: Array.from(allowedWeekdaySet(payload.daysOfWeek)), startDate: startDate.toISOString(), endDate: endDate ? endDate.toISOString() : null, durationMinutes: Math.round(moneyValue(payload.durationMinutes, 0)) || null, basePrice: moneyValue(payload.basePrice || payload.priceFrom, listing.priceFrom), fareClass: normalize(payload.fareClass || 'standard'), notes: cleanText(payload.notes), blockedSeats: parseList(payload.blockedSeats), driverIds: parseList(payload.driverIds), vipPriceDelta: moneyValue(payload.vipPriceDelta, 0), status: 'active', materializedThrough: null, createdBy: actorId, createdAt: new Date().toISOString() };
  await transportRepository.scheduleRules.save(rule); return rule;
}
async function setScheduleRuleStatus(companyId, ruleId, status, actorId = 'company-admin') { const rule = await transportRepository.scheduleRuleOrThrow(companyId, ruleId); rule.status = status; rule.updatedBy = actorId; rule.updatedAt = new Date().toISOString(); await transportRepository.scheduleRules.save(rule); return rule; }
function pauseScheduleRule(companyId, ruleId, actorId = 'company-admin') { return setScheduleRuleStatus(companyId, ruleId, 'paused', actorId); }
function resumeScheduleRule(companyId, ruleId, actorId = 'company-admin') { return setScheduleRuleStatus(companyId, ruleId, 'active', actorId); }
function cancelScheduleRule(companyId, ruleId, actorId = 'company-admin') { return setScheduleRuleStatus(companyId, ruleId, 'cancelled', actorId); }
async function recordScheduleRuleMaterialization(ruleId, materializedThrough) { const rule = await transportRepository.scheduleRules.findOne({ id: ruleId }); if (!rule) return null; rule.materializedThrough = materializedThrough; rule.updatedAt = new Date().toISOString(); await transportRepository.scheduleRules.save(rule); return rule; }

async function updateSchedule(companyId, scheduleId, payload = {}) {
  const company = await transportRepository.companyOrThrow(companyId); const schedule = await transportRepository.scheduleOrThrow(company.id, scheduleId);
  if (payload.routeId) { const route = await transportRepository.routeOrThrow(company.id, payload.routeId); schedule.routeId = route.id; schedule.listingId = route.listingId; }
  if (payload.vehicleId) { const vehicle = await transportRepository.vehicleOrThrow(company.id, payload.vehicleId); if (vehicle.listingId && schedule.listingId && vehicle.listingId !== schedule.listingId) throw validationError('Selected vehicle belongs to a different listing than the route'); schedule.vehicleId = vehicle.id; schedule.vehicleName = vehicle.name; }
  if (typeof payload.driverId !== 'undefined' || typeof payload.driverIds !== 'undefined') {
    const driver = await resolveDriver(company.id, payload.driverId || parseList(payload.driverIds)[0]);
    schedule.driverName = driver?.name || '';
    schedule.driverIds = driver ? [driver.employee.id, driver.user.id] : [];
    schedule.driverEmployeeId = driver?.employee.id || '';
    schedule.driverUserId = driver?.user.id || '';
    schedule.assignmentStatus = driver ? 'assigned' : '';
  } else if (typeof payload.driverName !== 'undefined') schedule.driverName = cleanText(payload.driverName);
  if (payload.departAt) schedule.departAt = parseDate(payload.departAt, 'departure time'); if (payload.arriveAt) schedule.arriveAt = parseDate(payload.arriveAt, 'arrival time'); if (payload.boardingStartAt) schedule.boardingStartAt = parseDate(payload.boardingStartAt, 'boarding time');
  if (typeof payload.basePrice !== 'undefined') schedule.basePrice = moneyValue(payload.basePrice, schedule.basePrice);
  if (payload.fareClass) schedule.fareClass = normalize(payload.fareClass); if (typeof payload.gate !== 'undefined') schedule.gate = cleanText(payload.gate); if (typeof payload.platform !== 'undefined') schedule.platform = cleanText(payload.platform); if (typeof payload.notes !== 'undefined') schedule.notes = cleanText(payload.notes);
  if (payload.status) schedule.status = normalize(payload.status); schedule.publishValidation = await validateSchedulePublish(company.id, schedule); schedule.updatedAt = new Date().toISOString(); await transportRepository.schedules.save(schedule); return schedule;
}
async function publishSchedule(companyId, scheduleId) { const company = await transportRepository.companyOrThrow(companyId); const schedule = await transportRepository.scheduleOrThrow(company.id, scheduleId); schedule.publishValidation = await validateSchedulePublish(company.id, schedule); if (!schedule.publishValidation.ok) { const error = validationError(`Schedule cannot be published: ${schedule.publishValidation.failures.join(', ')}`); error.validation = schedule.publishValidation; throw error; } schedule.status = 'published'; schedule.seatInventorySnapshot = await seatInventorySnapshot(schedule.id); schedule.publishedAt = new Date().toISOString(); schedule.updatedAt = schedule.publishedAt; await transportRepository.schedules.save(schedule); return schedule; }
async function archiveSchedule(companyId, scheduleId) { const schedule = await transportRepository.scheduleOrThrow(companyId, scheduleId); schedule.status = 'archived'; schedule.updatedAt = new Date().toISOString(); await transportRepository.schedules.save(schedule); return schedule; }
async function transitionSchedule(companyId, scheduleId, payload = {}, actorId = 'company-admin') { const allowed = ['draft', 'active', 'published', 'boarding', 'departed', 'arrived', 'completed', 'cancelled', 'delayed', 'archived']; const status = normalize(payload.status || payload.nextStatus); if (!allowed.includes(status)) throw validationError('Invalid schedule status'); if (status === 'published') return publishSchedule(companyId, scheduleId); const schedule = await transportRepository.scheduleOrThrow(companyId, scheduleId); schedule.status = status; schedule.statusReason = cleanText(payload.reason || payload.note); schedule.updatedBy = actorId; schedule.updatedAt = new Date().toISOString(); schedule.seatInventorySnapshot = await seatInventorySnapshot(schedule.id); await transportRepository.schedules.save(schedule); await transportRepository.audit({ actorId, action: 'company.schedule.status_updated', targetId: schedule.id, meta: { companyId, status } }); return schedule; }
function bookingMatchesSchedule(booking = {}, scheduleId = '') { return booking.scheduleId === scheduleId || (booking.bookingItems || []).some((item) => item.scheduleId === scheduleId) || (booking.bookingLegs || []).some((item) => item.scheduleId === scheduleId) || (booking.ticketLegs || []).some((item) => item.scheduleId === scheduleId); }
async function completeSchedule(companyId, scheduleId, payload = {}, actorId = 'company-admin') {
  const schedule = await transportRepository.scheduleOrThrow(companyId, scheduleId); const now = new Date().toISOString(); const releaseService = require('../commission/releaseService');
  Object.assign(schedule, { status: 'completed', completedAt: now, statusReason: cleanText(payload.reason || payload.note || 'Completed from company dashboard'), updatedBy: actorId, updatedAt: now, seatInventorySnapshot: await seatInventorySnapshot(schedule.id) });
  const bookings = await transportRepository.bookings.list({ companyId }); const eligible = bookings.filter((booking) => bookingMatchesSchedule(booking, schedule.id) && ['successful', 'paid', 'completed'].includes(normalize(booking.paymentStatus)) && ['checked_in', 'completed'].includes(normalize(booking.bookingStatus)));
  const releasedCommissions = [];
  for (const booking of eligible) { booking.bookingStatus = 'completed'; booking.completedAt = booking.completedAt || now; booking.completedBy = actorId; const released = (await releaseService.releaseCompletedBooking(booking.bookingRef)) || []; releasedCommissions.push(...released); await timelineService.recordEvent({ bookingRef: booking.bookingRef, bookingId: booking.id, companyId: booking.companyId, customerUserId: booking.customerUserId || '', entityType: 'trip_schedule', entityId: schedule.id, action: 'trip.completed', title: `Trip completed for ${booking.bookingRef}`, message: schedule.statusReason, status: 'completed', actorType: 'company_admin', actorId, visibility: 'shared', metadata: { scheduleId: schedule.id, releasedCommissions: released.length } }); }
  const update = { id: await transportRepository.nextId('trip-status'), companyId, scheduleId: schedule.id, vehicleId: schedule.vehicleId || '', status: 'completed', location: cleanText(payload.location), note: schedule.statusReason, createdBy: actorId, createdAt: now };
  await transportRepository.schedules.save(schedule); await transportRepository.tripStatusUpdates.save(update); await transportRepository.bookings.saveMany(eligible); await transportRepository.commissions.saveMany(releasedCommissions); await transportRepository.audit({ actorId, action: 'company.schedule.completed', targetId: schedule.id, meta: { companyId, releasedBookings: eligible.length, releasedCommissions: releasedCommissions.length } });
  return { schedule, releasedBookings: eligible, releasedCommissions };
}
async function duplicateSchedule(companyId, scheduleId, payload = {}, actorId = 'company-admin') { const original = await transportRepository.scheduleOrThrow(companyId, scheduleId); const result = await createSchedule(companyId, { routeId: original.routeId, vehicleId: payload.vehicleId || original.vehicleId, driverName: payload.driverName || original.driverName, driverIds: payload.driverIds || original.driverIds, departAt: payload.departAt || new Date(Date.now() + 86400000).toISOString(), arriveAt: payload.arriveAt || '', boardingStartAt: payload.boardingStartAt || '', basePrice: payload.basePrice || original.basePrice, fareClass: payload.fareClass || original.fareClass, gate: payload.gate || original.gate, platform: payload.platform || original.platform, notes: payload.notes || `Duplicated from ${original.id}`, totalSeats: payload.totalSeats || original.totalSeats, status: payload.status || 'draft' }); await transportRepository.audit({ actorId, action: 'company.schedule.duplicated', targetId: result.schedule.id, meta: { companyId, sourceScheduleId: original.id } }); return result.schedule; }
async function updateSeatStatus(companyId, payload = {}) {
  await transportRepository.companyOrThrow(companyId); const schedule = await transportRepository.scheduleOrThrow(companyId, payload.scheduleId); const seat = await transportRepository.seats.findOne({ scheduleId: schedule.id, $or: [{ seatNumber: String(payload.seatNumber || '') }, { id: payload.seatId }] }); if (!seat) { const error = new Error('Seat not found for this schedule'); error.status = 404; throw error; }
  const aliases = { held: 'locked', hold: 'locked', booked: 'taken', 'checked-in': 'checked_in', 'no-show': 'no_show' }; const status = payload.status ? aliases[normalize(payload.status)] || normalize(payload.status) : ''; const allowed = ['available', 'selected', 'locked', 'held', 'taken', 'booked', 'checked_in', 'no_show', 'cancelled', 'refunded', 'blocked', 'maintenance', 'reserved', 'disabled']; if (status && !allowed.includes(status)) throw validationError('Invalid seat status');
  if (status) seat.status = status; if (payload.seatClass || payload.seatType) { const type = normalize(payload.seatType || payload.seatClass); seat.seatType = ['vip', 'standard', 'disabled'].includes(type) ? type : 'standard'; seat.seatClass = seat.seatType === 'vip' ? 'VIP' : seat.seatType === 'disabled' ? 'Disabled' : 'Standard'; }
  if (typeof payload.blockedReason !== 'undefined') seat.blockedReason = cleanText(payload.blockedReason); if (typeof payload.priceDelta !== 'undefined') seat.priceDelta = moneyValue(payload.priceDelta, seat.priceDelta); if (seat.status !== 'locked') { seat.lockedUntil = null; seat.lockId = null; } seat.updatedAt = new Date().toISOString();
  await transportRepository.seats.save(seat); await recalculateScheduleAvailability(schedule); await transportRepository.schedules.save(schedule); return { seat, schedule };
}

module.exports = {
  createRoute, updateRoute, archiveRoute, createRouteStop, updateRouteStop, archiveRouteStop, moveRouteStop,
  createVehicle, updateVehicle, archiveVehicle, updateVehicleSeatTemplate, updateVehicleStatus,
  createSchedule, createScheduleBatch, createScheduleRule, pauseScheduleRule, resumeScheduleRule, cancelScheduleRule,
  recordScheduleRuleMaterialization, updateSchedule, publishSchedule, archiveSchedule, transitionSchedule,
  completeSchedule, duplicateSchedule, updateSeatStatus, validateSchedulePublish,
};
