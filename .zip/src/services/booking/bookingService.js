const commerceRepository = require('../../repositories/domain/commerceRepository');
const { buildBooking } = require('./bookingBuilderService');
const paymentSettlementService = require('./paymentSettlementService');
const { env } = require('../../config/env');
const inventoryHoldService = require('./inventoryHoldService');
const ticketAccessService = require('./ticketAccessService');
const ticketScanService = require('../qr/ticketScanService');
const timelineService = require('../support/timelineService');
const { mongoReady, runMongoUnitOfWork, sessionOptions } = require('../shared/mongoUnitOfWork');
const hotelInventoryService = require('../hotel/hotelInventoryService');

async function persistPaymentIntent(intent = {}) {
  if (!mongoReady()) return;
  const PaymentIntent = require('../../models/PaymentIntent');
  await PaymentIntent.updateOne(
    { idempotencyKey: intent.idempotencyKey || intent.id },
    { $set: intent },
    { upsert: true, runValidators: true }
  );
}

async function recordBookingTimeline(booking = {}, action, title, message = '', meta = {}) {
  if (!booking || !booking.bookingRef) return null;
  try {
    return await timelineService.recordEvent({
      bookingRef: booking.bookingRef,
      bookingId: booking.id,
      companyId: booking.companyId,
      customerUserId: booking.customerUserId || '',
      entityType: meta.entityType || 'booking',
      entityId: meta.entityId || booking.id || booking.bookingRef,
      action,
      title,
      message,
      status: meta.status || booking.bookingStatus || booking.paymentStatus || 'open',
      actorType: meta.actorType || 'system',
      actorId: meta.actorId || 'booking-service',
      actorName: meta.actorName || 'Classic Trip',
      visibility: meta.visibility || 'shared',
      metadata: { serviceType: booking.serviceType, scheduleId: booking.scheduleId || '', ...(meta.metadata || {}) },
    });
  } catch (error) {
    return null;
  }
}

function isoDate(value, fallback = new Date()) {
  const date = value ? new Date(value) : new Date(fallback);
  if (Number.isNaN(date.getTime())) {
    const error = new Error('Invalid hotel date');
    error.status = 422;
    throw error;
  }
  return date.toISOString().slice(0, 10);
}

function hotelNightRange(payload = {}, booking = {}) {
  const checkIn = isoDate(payload.checkInDate || payload.checkIn || payload.startDate || booking.hotelStay?.checkIn || booking.bookingItems?.[0]?.checkIn);
  const checkOutSeed = payload.checkOutDate || payload.checkOut || payload.endDate || booking.hotelStay?.checkOut || booking.bookingItems?.[0]?.checkOut;
  const fallbackOut = new Date(`${checkIn}T00:00:00.000Z`);
  fallbackOut.setUTCDate(fallbackOut.getUTCDate() + Math.max(1, Number(payload.nights || 1)));
  const checkOut = isoDate(checkOutSeed || fallbackOut);
  const start = new Date(`${checkIn}T00:00:00.000Z`);
  const end = new Date(`${checkOut}T00:00:00.000Z`);
  if (!(end > start)) {
    const error = new Error('Hotel check-out must be after check-in');
    error.status = 422;
    throw error;
  }
  const nights = [];
  for (let d = new Date(start); d < end; d.setUTCDate(d.getUTCDate() + 1)) nights.push(d.toISOString().slice(0, 10));
  return { checkIn, checkOut, nights };
}

function reusableSeatFilter(scheduleId, seatNumber, holdId = '', now = new Date()) {
  const reusable = [
    { status: 'available' },
    { status: 'locked', lockedUntil: { $lte: now } },
    // Older local builds did not persist bookingRef on Seat, so failed or test checkouts
    // could leave seats stuck as taken forever. Reclaim only unowned taken seats.
    { status: 'taken', $or: [{ bookingRef: { $exists: false } }, { bookingRef: '' }, { bookingRef: null }] },
  ];
  if (holdId) reusable.push({ status: 'locked', lockId: holdId, lockedUntil: { $gt: now } });
  return { scheduleId, seatNumber, $or: reusable };
}

async function refreshScheduleAvailability(scheduleId, session = null) {
  if (!scheduleId || !mongoReady()) return;
  const Seat = require('../../models/Seat');
  const TripSchedule = require('../../models/TripSchedule');
  const availableSeats = await Seat.countDocuments({ scheduleId, status: 'available' }).session(session || null);
  await TripSchedule.updateOne({ id: scheduleId }, { $set: { availableSeats } }, sessionOptions(session));
}

async function claimBusSeatsAtomically(booking = {}, payload = {}, session = null) {
  const seatClaims = (booking.bookingItems || [])
    .filter((item) => item.scheduleId && item.seatNumber)
    .map((item) => ({ scheduleId: item.scheduleId, seatNumber: item.seatNumber, legType: item.legType, passenger: item.passenger || item }));
  if (!seatClaims.length) return;
  if (!mongoReady()) {
    const touched = new Set();
    for (const claim of seatClaims) {
      const seat = await commerceRepository.seats.findOne({ scheduleId: claim.scheduleId, seatNumber: claim.seatNumber });
      if (!seat || !['available', 'locked', 'taken'].includes(seat.status) || (seat.status === 'taken' && seat.bookingRef)) {
        const error = new Error(`Selected seat is no longer available: ${claim.scheduleId}:${claim.seatNumber}`); error.status = 409; throw error;
      }
      Object.assign(seat, { status: 'taken', bookingRef: booking.bookingRef, bookingId: booking.id || '', passengerName: claim.passenger?.fullName || booking.guestSnapshot?.fullName || '', passengerPhone: claim.passenger?.phone || booking.guestSnapshot?.phone || '', passengerEmail: claim.passenger?.email || booking.guestSnapshot?.email || '' });
      delete seat.lockedUntil; delete seat.lockId;
      await commerceRepository.seats.save(seat, { id: seat.id });
      touched.add(claim.scheduleId);
    }
    for (const scheduleId of touched) {
      const schedule = await commerceRepository.schedules.findOne({ id: scheduleId });
      if (schedule) { schedule.availableSeats = Math.max(0, Number(schedule.availableSeats || 0) - seatClaims.filter((row) => row.scheduleId === scheduleId).length); await commerceRepository.schedules.save(schedule, { id: schedule.id }); }
    }
    return;
  }
  const Seat = require('../../models/Seat');
  const now = new Date();
  const holdId = payload.holdId || booking.holdId || '';
  const failures = [];
  for (const claim of seatClaims) {
    const passenger = claim.passenger || {};
    const updated = await Seat.findOneAndUpdate(
      reusableSeatFilter(claim.scheduleId, claim.seatNumber, holdId, now),
      {
        $set: {
          status: 'taken',
          bookingRef: booking.bookingRef,
          bookingId: booking.id || '',
          passengerName: passenger.fullName || passenger.name || booking.guestSnapshot?.fullName || '',
          passengerPhone: passenger.phone || booking.guestSnapshot?.phone || '',
          passengerEmail: passenger.email || booking.guestSnapshot?.email || '',
        },
        $unset: { lockedUntil: '', lockId: '' },
      },
      sessionOptions(session, { new: true })
    ).lean();
    if (!updated) failures.push(`${claim.scheduleId}:${claim.seatNumber}`);
  }
  // In local/demo mode, avoid blocking checkout when a stale selected seat is already
  // taken from a previous manual/test booking. Substitute the next open seat for the
  // same schedule. Production still returns a conflict for genuinely unavailable seats.
  if (failures.length && !env.isProduction) {
    const unresolved = [];
    for (const failed of failures) {
      const [scheduleId, seatNumber] = String(failed).split(':');
      const replacement = await Seat.findOneAndUpdate(
        { scheduleId, status: 'available' },
        {
          $set: {
            status: 'taken',
            bookingRef: booking.bookingRef,
            bookingId: booking.id || '',
            passengerName: booking.guestSnapshot?.fullName || '',
            passengerPhone: booking.guestSnapshot?.phone || '',
            passengerEmail: booking.guestSnapshot?.email || '',
          },
          $unset: { lockedUntil: '', lockId: '' },
        },
        sessionOptions(session, { new: true, sort: { seatNumber: 1 } })
      ).lean();
      if (!replacement) {
        unresolved.push(failed);
        continue;
      }
      (booking.bookingItems || []).forEach((item) => {
        if (item.scheduleId === scheduleId && item.seatNumber === seatNumber) {
          item.originalSeatNumber = seatNumber;
          item.seatNumber = replacement.seatNumber;
          item.seatOrRoom = replacement.seatNumber;
          item.autoReassigned = true;
        }
      });
      (booking.passengers || []).forEach((passenger) => {
        if (passenger.scheduleId === scheduleId && (passenger.seatNumber === seatNumber || passenger.seatOrRoom === seatNumber)) {
          passenger.originalSeatNumber = seatNumber;
          passenger.seatNumber = replacement.seatNumber;
          passenger.seatOrRoom = replacement.seatNumber;
          passenger.autoReassigned = true;
        }
      });
    }
    failures.splice(0, failures.length, ...unresolved);
  }

  const touchedSchedules = [...new Set(seatClaims.map((claim) => claim.scheduleId).filter(Boolean))];
  for (const id of touchedSchedules) await refreshScheduleAvailability(id, session);
  if (failures.length) {
    const error = new Error(`Selected seat is no longer available: ${failures.join(', ')}`);
    error.status = 409;
    error.code = 'SEAT_CLAIM_FAILED';
    throw error;
  }
}

async function claimHotelRoomAtomically(booking = {}, payload = {}, session = null) {
  if (booking.serviceType !== 'hotel') return;
  await hotelInventoryService.claimSelectedRoom(booking, payload, session);
}

async function releaseFailedBookingInventory(booking = {}, payload = {}) {
  if (!booking) return;
  booking.cancelledAt = booking.cancelledAt || new Date().toISOString();
  booking.cancelReason = booking.cancelReason || 'Payment initiation failed';
  if (booking.serviceType === 'bus') {
    const claims = (booking.bookingItems || []).filter((item) => item.scheduleId && item.seatNumber);
    for (const claim of claims) {
      const seat = await commerceRepository.seats.findOne({ scheduleId: claim.scheduleId, seatNumber: claim.seatNumber });
      if (seat && seat.bookingRef === booking.bookingRef) {
        Object.assign(seat, { status: 'available', bookingRef: '', bookingId: '', passengerName: '', passengerPhone: '', passengerEmail: '' });
        delete seat.lockedUntil; delete seat.lockId;
        await commerceRepository.seats.save(seat, { id: seat.id });
      }
    }
    for (const scheduleId of [...new Set(claims.map((row) => row.scheduleId))]) {
      if (mongoReady()) await refreshScheduleAvailability(scheduleId);
      else {
        const schedule = await commerceRepository.schedules.findOne({ id: scheduleId });
        if (schedule) {
          schedule.availableSeats = (await commerceRepository.seats.list({ scheduleId, status: 'available' })).length;
          await commerceRepository.schedules.save(schedule, { id: schedule.id });
        }
      }
    }
  }
  if (booking.serviceType === 'hotel') await hotelInventoryService.releaseBookedNights(booking.bookingRef);
  if (payload.holdId) await inventoryHoldService.releaseHold(payload.holdId, 'payment_failed');
}

async function consumeInventoryHoldInSession(holdId, booking, session) {
  if (!holdId) return;
  const InventoryHold = require('../../models/InventoryHold');
  const InventoryHoldItem = require('../../models/InventoryHoldItem');
  const update = {
    status: 'consumed',
    consumedAt: new Date(),
    consumedBy: booking.customerUserId || 'guest-checkout',
    bookingId: booking.id || '',
    bookingRef: booking.bookingRef || '',
  };
  const parentResult = await InventoryHold.updateOne(
    { id: holdId, status: 'active', expiresAt: { $gt: new Date() } },
    { $set: update },
    sessionOptions(session)
  );
  const itemResult = await InventoryHoldItem.updateMany(
    { holdId, status: 'active', expiresAt: { $gt: new Date() } },
    { $set: update },
    sessionOptions(session)
  );
  if (parentResult.matchedCount !== 1 || itemResult.matchedCount < 1) {
    throw Object.assign(new Error('Inventory hold is missing or expired'), { status: 409 });
  }
}

async function persistBooking(booking, payload, _transactionStartIndex, options = {}) {
  const shouldConsumeHold = Boolean(payload.holdId && !options.skipHoldConsume);
  const execute = async (session = null) => {
    if (options.claimInventory) {
      if (booking.serviceType === 'bus') await claimBusSeatsAtomically(booking, payload, session);
      if (booking.serviceType === 'hotel') await claimHotelRoomAtomically(booking, payload, session);
    }
    if (shouldConsumeHold && mongoReady()) await consumeInventoryHoldInSession(payload.holdId, booking, session);
    await persistBookingRows(booking, payload, session);
  };
  if (mongoReady()) await runMongoUnitOfWork(execute);
  else {
    await execute(null);
    if (shouldConsumeHold) await inventoryHoldService.consumeHold(payload.holdId, booking, { userId: booking.customerUserId || 'guest-checkout' });
  }
  commerceRepository.bookings.mirrorSave(booking, { bookingRef: booking.bookingRef }, 'start');
  commerceRepository.passengers.mirrorMany((booking.passengers || []).map((passenger, index) => ({ ...passenger, bookingId: booking.id, bookingRef: booking.bookingRef, companyId: booking.companyId, listingId: booking.listingId, scheduleId: passenger.scheduleId || booking.scheduleId, passengerIndex: index })), (row) => ({ id: row.id }));
  if (shouldConsumeHold && mongoReady()) await inventoryHoldService.consumeHold(payload.holdId, booking, { userId: booking.customerUserId || 'guest-checkout', skipPersistence: true });
}

async function persistBookingRows(booking, payload, session = null) {
  await commerceRepository.bookings.save(booking, { bookingRef: booking.bookingRef }, { session: session || undefined, mirror: false, mirrorPosition: 'start' });
  const passengers = (booking.passengers || []).map((passenger, index) => ({
    ...passenger,
    id: passenger.id || `${booking.id}-passenger-${index + 1}`,
    bookingId: booking.id,
    bookingRef: booking.bookingRef,
    companyId: booking.companyId,
    listingId: booking.listingId,
    scheduleId: passenger.scheduleId || booking.scheduleId,
    passengerIndex: index,
  }));
  if (passengers.length) await commerceRepository.passengers.saveMany(passengers, (row) => ({ id: row.id }), { session: session || undefined, mirror: false });
  if (booking.paymentRef || booking.paymentProvider) {
    const provider = booking.paymentProvider || payload.provider || 'mock';
    const providerReference = booking.paymentRef || `${booking.bookingRef}:pending`;
    const payment = {
      id: `payment-${booking.bookingRef}`,
      bookingId: booking.id,
      bookingRef: booking.bookingRef,
      companyId: booking.companyId,
      customerUserId: booking.customerUserId || '',
      provider,
      providerReference,
      paymentRef: booking.paymentRef || '',
      amount: booking.pricing?.total || 0,
      grossAmount: booking.pricing?.total || 0,
      currency: booking.pricing?.currency || 'UGX',
      status: booking.paymentStatus || 'pending',
      settlementStatus: booking.settlementStatus === 'settled' ? 'settled' : 'pending',
      paidAt: booking.paymentStatus === 'successful' ? new Date().toISOString() : null,
      checkoutUrl: booking.checkoutUrl || '',
      idempotencyKey: `${provider}:${booking.bookingRef}:${providerReference}`,
      metadata: { source: 'bookingService.persistBooking' },
    };
    await commerceRepository.payments.save(payment, { idempotencyKey: payment.idempotencyKey }, { session: session || undefined, mirror: false });
    if (!session) commerceRepository.payments.mirrorSave(payment, { idempotencyKey: payment.idempotencyKey });
  }
}


async function createGuestBooking(payload, req) {
  const paymentService = require('../payment/paymentService');
  const provider = paymentService.resolveProviderName(payload.provider || payload.paymentProvider || env.paymentProvider);
  const { booking } = await buildBooking({ ...payload, deferPayment: provider !== 'mock' }, req);
  try {
    const intentBase = {
      id: `payment-intent-${booking.bookingRef}`,
      intentRef: `PI-${booking.bookingRef}`,
      bookingId: booking.id,
      bookingRef: booking.bookingRef,
      companyId: booking.companyId,
      customerUserId: booking.customerUserId || '',
      provider,
      idempotencyKey: `${provider}:${booking.bookingRef}:initiate`,
      amount: booking.pricing?.total,
      currency: booking.pricing?.currency,
      status: 'created',
      expiresAt: booking.lockedUntil,
      attempts: [{ at: new Date().toISOString(), provider, status: 'created' }],
      metadata: { source: 'bookingService.createGuestBooking' },
    };
    await persistPaymentIntent(intentBase);
    await persistBooking(booking, payload, 0, { claimInventory: true });
    await recordBookingTimeline(booking, 'booking.created', `Booking ${booking.bookingRef} created`, 'Inventory was selected and booking record was created.', { metadata: { source: payload.source || 'checkout', holdId: payload.holdId || '' } });
    await recordBookingTimeline(booking, 'inventory.claimed', `Inventory claimed for ${booking.bookingRef}`, booking.serviceType === 'bus' ? 'Selected seat inventory was connected to this booking.' : 'Selected room inventory was connected to this booking.', { entityType: 'inventory', entityId: payload.holdId || booking.scheduleId || booking.listingId });
    const payment = await paymentService.initiatePayment({
      ...payload,
      provider,
      bookingRef: booking.bookingRef,
      amount: booking.pricing?.total,
      currency: booking.pricing?.currency,
      customer: booking.guestSnapshot,
      idempotencyKey: intentBase.idempotencyKey,
      callbackUrl: `${env.appUrl}/booking/payment/callback?bookingRef=${encodeURIComponent(booking.bookingRef)}`,
      description: `Classic Trip booking ${booking.bookingRef}`,
    });
    await persistPaymentIntent({
      ...intentBase,
      providerReference: payment.providerReference || '',
      checkoutUrl: payment.checkoutUrl || '',
      status: payment.status || 'pending',
      paidAt: payment.status === 'successful' ? new Date().toISOString() : null,
      attempts: [...intentBase.attempts, { at: new Date().toISOString(), provider, status: payment.status || 'pending', providerReference: payment.providerReference || '' }],
    });
    booking.paymentProvider = payment.provider;
    booking.paymentRef = payment.providerReference;
    booking.checkoutUrl = payment.checkoutUrl || '';
    booking.paymentStatus = payment.status || booking.paymentStatus;
    if (booking.paymentStatus === 'successful') {
      booking.bookingStatus = 'confirmed';
      Object.assign(booking, await paymentSettlementService.settleBookingPayment(booking) || {});
      await recordBookingTimeline(booking, 'payment.succeeded', `Payment received for ${booking.bookingRef}`, 'Payment was confirmed and tickets are valid for operation.', { entityType: 'payment', entityId: payment.providerReference || booking.paymentRef || '', status: 'successful', metadata: { provider: payment.provider } });
      await recordBookingTimeline(booking, 'ticket.issued', `Ticket issued for ${booking.bookingRef}`, `${(booking.ticketLegs || []).length || 1} ticket leg(s) are available for QR validation.`, { entityType: 'ticket', entityId: booking.ticketLegs?.[0]?.id || booking.bookingRef, status: 'issued' });
    } else {
      await recordBookingTimeline(booking, 'payment.pending', `Payment pending for ${booking.bookingRef}`, 'Booking is waiting for payment confirmation before operation.', { entityType: 'payment', entityId: payment.providerReference || booking.paymentRef || '', status: booking.paymentStatus || 'pending', metadata: { provider: payment.provider, checkoutUrl: payment.checkoutUrl || '' } });
    }
  } catch (error) {
    booking.paymentStatus = 'failed';
    booking.bookingStatus = 'cancelled';
    await releaseFailedBookingInventory(booking, payload);
    await persistPaymentIntent({
      id: `payment-intent-${booking.bookingRef}`,
      intentRef: `PI-${booking.bookingRef}`,
      bookingId: booking.id,
      bookingRef: booking.bookingRef,
      companyId: booking.companyId,
      customerUserId: booking.customerUserId || '',
      provider,
      idempotencyKey: `${provider}:${booking.bookingRef}:initiate`,
      amount: booking.pricing?.total,
      currency: booking.pricing?.currency,
      status: 'failed',
      failedAt: new Date().toISOString(),
      failureReason: error.message,
      metadata: { source: 'bookingService.createGuestBooking' },
    });
    await persistBooking(booking, payload, 0, { skipHoldConsume: true });
    await recordBookingTimeline(booking, 'payment.failed', `Payment failed for ${booking.bookingRef}`, error.message || 'Payment failed and inventory was released.', { entityType: 'payment', status: 'failed', visibility: 'shared' });
    throw error;
  }
  await persistBooking(booking, payload, 0, { skipHoldConsume: true });
  const notificationService = require('../notification/notificationService');
  if (booking.bookingStatus === 'confirmed') {
    await notificationService.bookingConfirmed(booking);
  } else {
    await notificationService.queueNotification({
      userId: booking.customerUserId || null,
      channels: ['email', 'sms'],
      title: `Payment pending ${booking.bookingRef}`,
      message: `Your Classic Trip booking ${booking.bookingRef} is waiting for payment confirmation.`,
      recipient: {
        email: booking.guestSnapshot?.email,
        phone: booking.guestSnapshot?.phone,
        name: booking.guestSnapshot?.fullName,
      },
      referenceType: 'booking',
      referenceId: booking.id,
      meta: { bookingRef: booking.bookingRef, checkoutUrl: booking.checkoutUrl },
    });
  }
  const ticketPdfService = require('../pdf/ticketPdfService');
  const listing = await commerceRepository.listings.findOne({ id: booking.listingId });
  booking.ticketPdf = await ticketPdfService.uploadTicketPdf(booking, listing);
  await persistBooking(booking, payload, 0, { skipHoldConsume: true });
  return booking;
}



async function createManualBooking(payload = {}, context = {}) {
  const actorId = String(context.actorId || payload.createdByEmployeeId || payload.actorId || 'employee-system').trim();
  const { booking } = await buildBooking({
    ...payload,
    deferPayment: true,
    paymentStatus: 'pending',
    bookingChannel: 'company_manual',
    source: 'employee_manual',
  }, null);
  booking.source = 'employee_manual';
  booking.bookingChannel = 'company_manual';
  booking.createdByEmployeeId = actorId;
  booking.createdAtDesk = new Date().toISOString();
  booking.paymentStatus = 'pending';
  booking.bookingStatus = 'pending_payment';
  booking.settlementStatus = 'pending';
  const intent = {
    id: `payment-intent-${booking.bookingRef}`,
    intentRef: `PI-${booking.bookingRef}`,
    bookingId: booking.id,
    bookingRef: booking.bookingRef,
    companyId: booking.companyId,
    customerUserId: booking.customerUserId || '',
    provider: 'cash',
    idempotencyKey: `manual:${booking.bookingRef}:awaiting-payment`,
    amount: booking.pricing?.total || 0,
    currency: booking.pricing?.currency || 'UGX',
    status: 'pending',
    expiresAt: null,
    attempts: [{ at: new Date().toISOString(), provider: 'cash', status: 'pending', actorId }],
    metadata: { source: 'bookingService.createManualBooking', actorId },
  };
  await persistPaymentIntent(intent);
  await persistBooking(booking, payload, 0, { claimInventory: true });
  await recordBookingTimeline(booking, 'booking.created', `Manual booking ${booking.bookingRef} created`, 'Company staff created the booking and reserved inventory. Payment is still required.', {
    actorType: 'employee', actorId, status: 'pending_payment', metadata: { source: 'employee_manual' },
  });
  await recordBookingTimeline(booking, 'payment.pending', `Payment pending for ${booking.bookingRef}`, 'The booking is waiting for an authorized payment record.', {
    entityType: 'payment', actorType: 'employee', actorId, status: 'pending', metadata: { provider: 'cash' },
  });
  return booking;
}

async function createOfflineBooking(payload = {}, context = {}) {
  const { nextId } = require('../data/idService');
  const financeRepository = require('../../repositories/domain/financeRepository');
  const paymentReference = String(payload.paymentReference || '').trim();
  const agentId = String(context.agentId || payload.agentId || '').trim();
  const idempotencyKey = String(payload.idempotencyKey || `offline:${agentId}:${paymentReference || payload.listingId || payload.slug || 'sale'}:${payload.scheduleId || payload.roomTypeId || payload.roomUnitId || payload.seatNumber || ''}`).trim();

  const existingPayment = await financeRepository.paymentIntents.findOne({ idempotencyKey });
  if (existingPayment?.bookingRef) {
    const existingBooking = await financeRepository.bookings.findOne({ bookingRef: existingPayment.bookingRef });
    const payment = await require('../../repositories/domain/promoterRepository').payments.findOne({ idempotencyKey: `cash:${existingPayment.bookingRef}` });
    if (existingBooking && payment) return { booking: existingBooking, payment, replayed: true };
  }

  const { booking } = await buildBooking({ ...payload, paymentStatus: 'pending', deferPayment: true, offlineSale: true, agentSale: true, agentId, promoterAttribution: payload.promoterAttribution || null }, null);

  const intent = {
    id: await nextId('payment-intent'),
    intentRef: `PI-${booking.bookingRef}`,
    bookingId: booking.id,
    bookingRef: booking.bookingRef,
    companyId: booking.companyId,
    customerUserId: booking.customerUserId || '',
    provider: 'cash',
    idempotencyKey,
    amount: Number(booking.pricing?.total || payload.amountCollected || payload.total || 0),
    currency: booking.pricing?.currency || payload.currency || 'UGX',
    status: 'created',
    attempts: [{ at: new Date().toISOString(), provider: 'cash', status: 'created', actorId: agentId }],
    metadata: { source: 'bookingService.createOfflineBooking', agentId },
  };

  try {
    const amountCollected = Number(payload.amountCollected || payload.total || 0);
    const computedTotal = Number(booking.pricing?.total || 0);
    if (amountCollected + 0.0001 < computedTotal) {
      const error = new Error(`Collected amount is below the computed booking total of ${booking.pricing?.currency || 'UGX'} ${computedTotal}`);
      error.status = 422;
      throw error;
    }
    await persistPaymentIntent(intent);
    await persistBooking(booking, payload, 0, { claimInventory: true });

    const payment = {
      id: await nextId('payment'),
      bookingId: booking.id,
      bookingRef: booking.bookingRef,
      companyId: booking.companyId,
      customerUserId: booking.customerUserId || '',
      provider: 'cash',
      providerReference: paymentReference || `CASH-${booking.bookingRef}`,
      paymentRef: paymentReference || `CASH-${booking.bookingRef}`,
      methodNote: `Cash collected by approved agent ${agentId || 'unknown'}`,
      amount: Number(booking.pricing?.total || payload.amountCollected || payload.total || 0),
      grossAmount: Number(booking.pricing?.total || payload.amountCollected || payload.total || 0),
      currency: booking.pricing?.currency || payload.currency || 'UGX',
      status: 'successful',
      settlementStatus: 'pending',
      idempotencyKey: `cash:${booking.bookingRef}`,
      paidAt: new Date().toISOString(),
      metadata: { source: 'agent_offline_sale', agentId, externalReference: paymentReference },
    };

    booking.paymentStatus = 'successful';
    booking.paymentProvider = 'cash';
    booking.paymentRef = payment.providerReference;
    booking.paymentMethodNote = payment.methodNote;
    booking.bookingStatus = 'confirmed';
    booking.bookingChannel = 'agent_offline';
    booking.createdByAgentId = agentId;
    booking.agentSale = {
      agentId,
      agentName: String(context.agentName || payload.agentName || '').trim(),
      location: String(payload.agentLocation || '').trim(),
    };

    await runMongoUnitOfWork(async (session) => {
      await financeRepository.bookings.save(booking, { bookingRef: booking.bookingRef }, { session });
      await require('../../repositories/domain/promoterRepository').payments.save(payment, { idempotencyKey: payment.idempotencyKey }, { session });
      await financeRepository.paymentIntents.save({
        ...intent,
        status: 'successful',
        providerReference: payment.providerReference,
        paidAt: payment.paidAt,
        attempts: [...intent.attempts, { at: payment.paidAt, provider: 'cash', status: 'successful', providerReference: payment.providerReference, actorId: agentId }],
      }, { idempotencyKey }, { session });
    });

    try {
      Object.assign(booking, await paymentSettlementService.settleBookingPayment(booking, { source: 'agent_offline' }) || {});
    } catch (settlementError) {
      booking.settlementStatus = 'reconciliation_required';
      booking.settlementError = settlementError.message;
    }
    await persistBooking(booking, payload, 0, { skipHoldConsume: true });
    await recordBookingTimeline(booking, 'booking.created', `Offline booking ${booking.bookingRef} created`, 'An approved promoter recorded an offline booking and cash payment.', { actorType: 'promoter', actorId: agentId, actorName: context.agentName || payload.agentName || 'Promoter', metadata: { source: 'agent_offline_sale' } });
    await recordBookingTimeline(booking, 'payment.succeeded', `Cash payment received for ${booking.bookingRef}`, 'Cash collection was recorded and the ticket was confirmed.', { entityType: 'payment', entityId: payment.id, actorType: 'promoter', actorId: agentId, actorName: context.agentName || payload.agentName || 'Promoter', status: 'successful', metadata: { provider: 'cash', paymentReference: payment.providerReference } });
    return { booking, payment, replayed: false };
  } catch (error) {
    booking.paymentStatus = 'failed';
    booking.bookingStatus = 'cancelled';
    booking.settlementStatus = 'reconciliation_required';
    booking.settlementError = error.message;
    await releaseFailedBookingInventory(booking, payload);
    await persistPaymentIntent({ ...intent, status: 'failed', failedAt: new Date().toISOString(), failureReason: error.message });
    await persistBooking(booking, payload, 0, { skipHoldConsume: true });
    await recordBookingTimeline(booking, 'payment.failed', `Offline booking failed for ${booking.bookingRef}`, error.message, { actorType: 'promoter', actorId: agentId, actorName: context.agentName || payload.agentName || 'Promoter', status: 'failed', metadata: { source: 'agent_offline_sale' } });
    throw error;
  }
}

async function persistCheckIn(booking) {
  if (!mongoReady() || !booking) return;
  const Booking = require('../../models/Booking');
  await Booking.updateOne(
    { bookingRef: booking.bookingRef },
    {
      $set: {
        bookingStatus: booking.bookingStatus,
        checkedInAt: booking.checkedInAt,
        checkedInBy: booking.checkedInBy,
        checkedInByUserId: booking.checkedInByUserId,
        checkInStatus: booking.checkInStatus,
        checkInNote: booking.checkInNote,
        noShowAt: booking.noShowAt,
        noShowBy: booking.noShowBy,
        noShowByUserId: booking.noShowByUserId,
        cancelledAt: booking.cancelledAt,
        cancelReason: booking.cancelReason,
        completedAt: booking.completedAt,
        settlementStatus: booking.settlementStatus,
        passengers: booking.passengers || [],
        ticketLegs: booking.ticketLegs || [],
        scanHistory: booking.scanHistory || [],
      },
    }
  );
}

async function persistFinancialRelease(booking, commissions = []) {
  if (!booking) return;
  await commerceRepository.bookings.save(booking, { bookingRef: booking.bookingRef });
  for (const commission of commissions || []) await commerceRepository.commissions.save(commission, { id: commission.id });
  const rows = await commerceRepository.transactions.list({ referenceType: 'booking', referenceId: booking.id });
  commerceRepository.transactions.mirrorMany(rows, (row) => ({ id: row.id }));
}

async function validateTicket(value, employeeId = 'employee-system', companyId = '', context = {}) {
  const releaseService = require('../commission/releaseService');
  const busOperationsService = require('../../modules/bus/services/busOperationsService');
  const canonicalTicket = companyId ? await busOperationsService.findTicketForScan(companyId, value) : null;
  if (canonicalTicket) {
    const result = await busOperationsService.validateTicket({
      companyId,
      employeeId,
      scannedToken: value,
      scheduleId: context.scheduleId || canonicalTicket.scheduleId,
      note: context.note || '',
      location: context.location || '',
      req: { ip: context.ip || '', headers: { 'user-agent': context.userAgent || '' } },
    });
    if (result.booking?.bookingStatus === 'checked_in') {
      const released = (await releaseService.releaseCompletedBooking(result.booking.bookingRef)) || [];
      result.releasedCommissions = released;
      await persistFinancialRelease(result.booking, released);
    }
    await recordBookingTimeline(result.booking, 'ticket.checked_in', `Ticket checked in for ${result.booking.bookingRef}`, result.message, { entityType: 'bus_ticket', entityId: result.ticket.id, actorType: context.actorRole || 'employee', actorId: employeeId, actorName: context.actorName || '', status: result.booking.bookingStatus, metadata: { location: context.location || '', scheduleId: result.ticket.scheduleId } });
    return result;
  }
  const ticketOperationsService = require('./ticketOperationsService');
  const result = await ticketOperationsService.validate(value, employeeId, companyId, context);
  await ticketScanService.recordScan('validate', value, result, { ...context, userId: employeeId, companyId });
  if (result.ok && result.booking?.bookingStatus === 'checked_in') {
    const released = (await releaseService.releaseCompletedBooking(result.booking.bookingRef)) || [];
    result.releasedCommissions = released;
    await recordBookingTimeline(result.booking, 'ticket.checked_in', `Ticket checked in for ${result.booking.bookingRef}`, result.message || 'Passenger check-in was accepted.', { entityType: 'ticket_scan', entityId: result.ticket?.id || result.ticket?.ticketNumber || result.booking.bookingRef, actorType: context.actorRole || 'employee', actorId: employeeId, actorName: context.actorName || '', status: 'checked_in', metadata: { location: context.location || '', scheduleId: context.scheduleId || result.ticket?.scheduleId || '' } });
    await persistFinancialRelease(result.booking, released);
  } else if (result.booking) {
    await recordBookingTimeline(result.booking, result.ok ? 'ticket.scan.updated' : 'ticket.scan.failed', result.ok ? `Ticket scan updated for ${result.booking.bookingRef}` : `Ticket scan failed for ${result.booking.bookingRef}`, result.message || 'Ticket scan was recorded.', { entityType: 'ticket_scan', entityId: result.ticket?.id || result.ticket?.ticketNumber || result.booking.bookingRef, actorType: context.actorRole || 'employee', actorId: employeeId, actorName: context.actorName || '', status: result.ok ? 'accepted' : 'failed', visibility: result.ok ? 'shared' : 'internal', metadata: { result: result.result || '', location: context.location || '', scheduleId: context.scheduleId || result.ticket?.scheduleId || '' } });
  }
  return result;
}

async function lookupTicket(value, companyId = '', context = {}) {
  const busOperationsService = require('../../modules/bus/services/busOperationsService');
  const canonicalTicket = companyId ? await busOperationsService.findTicketForScan(companyId, value) : null;
  if (canonicalTicket) return busOperationsService.lookupTicket({ companyId, scannedToken: value, scheduleId: context.scheduleId || '' });
  const ticketOperationsService = require('./ticketOperationsService');
  const result = await ticketOperationsService.lookup(value, companyId, context);
  await ticketScanService.recordScan('lookup', value, result, { ...context, companyId });
  return result;
}

async function markNoShow(value, employeeId = 'employee-system', companyId = '', note = '', context = {}) {
  const busOperationsService = require('../../modules/bus/services/busOperationsService');
  const canonicalTicket = companyId ? await busOperationsService.findTicketForScan(companyId, value) : null;
  if (canonicalTicket) {
    const result = await busOperationsService.markNoShow({
      companyId,
      employeeId,
      ticketId: canonicalTicket.id,
      scheduleId: context.scheduleId || canonicalTicket.scheduleId,
      note,
      req: { ip: context.ip || '', headers: { 'user-agent': context.userAgent || '' } },
    });
    await recordBookingTimeline(result.booking, 'ticket.no_show', `No-show marked for ${result.booking.bookingRef}`, note || result.message, { entityType: 'bus_ticket', entityId: result.ticket.id, actorType: context.actorRole || 'employee', actorId: employeeId, actorName: context.actorName || '', status: 'no_show', metadata: { location: context.location || '', scheduleId: result.ticket.scheduleId } });
    return result;
  }
  const ticketOperationsService = require('./ticketOperationsService');
  const result = await ticketOperationsService.markNoShow(value, employeeId, companyId, note, context);
  await ticketScanService.recordScan('no_show', value, result, { ...context, userId: employeeId, companyId, note });
  if (result.ok) await recordBookingTimeline(result.booking, 'ticket.no_show', `No-show marked for ${result.booking.bookingRef}`, note || result.message || 'Passenger was marked as no-show.', { entityType: 'ticket_scan', entityId: result.ticket?.id || result.ticket?.ticketNumber || result.booking.bookingRef, actorType: context.actorRole || 'employee', actorId: employeeId, actorName: context.actorName || '', status: 'no_show', metadata: { location: context.location || '', scheduleId: context.scheduleId || result.ticket?.scheduleId || '' } });
  return result;
}

async function lookupBooking(bookingRef, contact = '', accessCode = '') {
  const booking = await commerceRepository.bookings.findOne({ bookingRef });
  if (!booking) return null;
  if (ticketAccessService.accessCodeMatches(booking, accessCode)) return booking;
  if (!contact) return null;
  return ticketAccessService.contactMatches(booking, contact) ? booking : null;
}

async function cancelBooking(bookingRef, reason = 'Customer requested cancellation', context = {}) {
  const customerRepository = require('../../repositories/domain/customerRepository');
  const transportRepository = require('../../repositories/domain/transportRepository');
  const hotelRepository = require('../../repositories/domain/hotelRepository');
  const booking = await customerRepository.bookings.findOne({ bookingRef });
  if (!booking) return null;
  if (String(booking.serviceType || '').toLowerCase() === 'bus') {
    const busBookingService = require('../../modules/bus/services/busBookingService');
    return busBookingService.cancelBooking(bookingRef, reason, context);
  }
  if (['cancelled', 'refunded', 'voided'].includes(booking.bookingStatus)) return booking;
  if (['completed', 'checked_in', 'checked-in', 'checked-out'].includes(booking.bookingStatus)) {
    const error = new Error('This booking can no longer be cancelled online');
    error.status = 409;
    throw error;
  }

  const cancelledAt = new Date().toISOString();
  booking.bookingStatus = 'cancelled';
  booking.cancelReason = String(reason || 'Customer requested cancellation').trim().slice(0, 1000);
  booking.cancelledAt = cancelledAt;
  booking.ticketLegs = (booking.ticketLegs || []).map((leg) => ({ ...leg, status: 'cancelled', checkInStatus: 'cancelled', cancelledAt }));

  await runMongoUnitOfWork(async (session) => {
    if (booking.serviceType === 'bus') {
      const claims = (booking.bookingItems || []).filter((item) => item.scheduleId && item.seatNumber);
      for (const claim of claims) {
        await transportRepository.seats.updateOne(
          { scheduleId: claim.scheduleId, seatNumber: claim.seatNumber, bookingRef: booking.bookingRef },
          { $set: { status: 'available' }, $unset: { lockedUntil: '', lockId: '', bookingRef: '', bookingId: '', passengerName: '', passengerPhone: '', passengerEmail: '' } },
          { session }
        );
      }
      for (const scheduleId of [...new Set(claims.map((item) => item.scheduleId))]) await refreshScheduleAvailability(scheduleId, session);
    }
    if (booking.serviceType === 'hotel') {
      const nightIds = booking.hotelStay?.nightIds || (booking.bookingItems || []).flatMap((item) => item.nightIds || []);
      const nights = nightIds.length
        ? await hotelRepository.roomNightInventories.list({ id: { $in: nightIds }, bookingRef: booking.bookingRef }, { session })
        : await hotelRepository.roomNightInventories.list({ bookingRef: booking.bookingRef }, { session });
      for (const night of nights) {
        const nextAvailable = Math.max(1, Number(night.availableInventory || 0) + 1);
        await hotelRepository.roomNightInventories.updateOne(
          { id: night.id, bookingRef: booking.bookingRef },
          { $set: { status: 'open', bookingRef: '', guestName: '', checkInStatus: '', availableInventory: nextAvailable }, $unset: { holdId: '' } },
          { session }
        );
      }
    }
    await customerRepository.bookings.save(booking, { bookingRef: booking.bookingRef }, { session });
  });

  customerRepository.bookings.mirrorSave(booking, { bookingRef: booking.bookingRef });
  await recordBookingTimeline(booking, 'booking.cancelled', `Booking ${booking.bookingRef} cancelled`, booking.cancelReason, {
    actorType: context.actorRole || 'customer', actorId: context.actorId || booking.customerUserId || 'customer',
    actorName: context.actorName || '', status: 'cancelled', metadata: { source: 'customer_cancellation' },
  });

  if (booking.paymentStatus === 'successful') {
    try {
      const workflowService = require('../support/workflowService');
      const supportRepository = require('../../repositories/domain/supportRepository');
      supportRepository.bookings.mirrorSave(booking, { bookingRef: booking.bookingRef });
      await Promise.resolve(workflowService.requestRefund({
        bookingRef: booking.bookingRef,
        requesterId: context.actorId || booking.customerUserId || 'customer',
        amount: Number(booking.pricing?.total || 0),
        reason: `Cancellation: ${booking.cancelReason}`,
      }));
    } catch (error) {
      booking.settlementStatus = 'reconciliation_required';
      booking.settlementError = `Cancellation refund request failed: ${error.message}`;
      await customerRepository.bookings.save(booking, { bookingRef: booking.bookingRef });
    }
  }
  return booking;
}

module.exports = { createGuestBooking, createManualBooking, createOfflineBooking, lookupTicket, validateTicket, markNoShow, lookupBooking, cancelBooking };
