const crypto = require('crypto');
const { ENABLED_BOOKING_TYPES } = require('../../config/constants');
const commerceRepository = require('../../repositories/domain/commerceRepository');
const promoterRepository = require('../../repositories/domain/promoterRepository');
const hotelInventoryService = require('../hotel/hotelInventoryService');
const calculateCommission = require('../../utils/calculateCommission');
const fraudService = require('../fraud/fraudService');
const { nextId } = require('../data/idService');

function clean(value) { return String(value || '').trim(); }
function normalize(value) { return clean(value).toLowerCase(); }
function addMinutes(date, minutes) { return new Date(new Date(date).getTime() + Number(minutes || 0) * 60000); }
function toSlug(value) { return clean(value).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }

function parsePayloadArray(value, fallback = []) {
  if (Array.isArray(value)) return value;
  if (!value) return fallback;
  try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : fallback; } catch (_) { return fallback; }
}
function listPayloadValues(value) {
  if (Array.isArray(value)) return value.flatMap((item) => listPayloadValues(item));
  return clean(value).split(/[\n,]+/).map((item) => item.trim()).filter(Boolean);
}
function passengerInputFromPayload(payload = {}) {
  const explicit = parsePayloadArray(payload.passengers, []);
  if (explicit.length) return explicit;
  const names = listPayloadValues(payload.passengerNames || payload.passengerFullName || []);
  const phones = listPayloadValues(payload.passengerPhones || payload.passengerPhone || []);
  const emails = listPayloadValues(payload.passengerEmails || payload.passengerEmail || []);
  const pickups = listPayloadValues(payload.pickupPoints || payload.pickupPoint || []);
  const dropoffs = listPayloadValues(payload.dropoffPoints || payload.dropoffPoint || []);
  const notes = listPayloadValues(payload.passengerNotes || payload.passengerNote || []);
  const count = Math.max(names.length, phones.length, emails.length, pickups.length, dropoffs.length, notes.length);
  return Array.from({ length: count }, (_, index) => ({
    fullName: names[index] || '', phone: phones[index] || '', email: emails[index] || '',
    pickupPoint: pickups[index] || '', dropoffPoint: dropoffs[index] || '', notes: notes[index] || '', specialNotes: notes[index] || '',
  }));
}
function cleanSeatToken(value) {
  const raw = clean(value);
  const withoutPrefix = raw.replace(/^seat\s*(no\.?|number)?\s*/i, '').trim();
  const legacy = withoutPrefix.match(/^[A-Za-z](\d+)$/);
  return legacy ? legacy[1] : withoutPrefix;
}
function seatListFrom(value) {
  if (Array.isArray(value)) return value.flatMap((seat) => seatListFrom(seat));
  return clean(value).split(',').map(cleanSeatToken).filter(Boolean);
}
function addonCatalogFor(serviceType) {
  const options = serviceType === 'hotel'
    ? [{ name: 'Breakfast package', price: 18000 }, { name: 'Airport pickup', price: 45000 }, { name: 'Late checkout', price: 25000 }]
    : [{ name: 'Extra luggage', price: 12000 }, { name: 'Priority boarding', price: 8000 }, { name: 'SMS and WhatsApp ticket', price: 2500 }];
  return options.map((option) => ({ ...option, id: toSlug(option.name) }));
}
function selectedAddonsFor(serviceType, payload = {}) {
  const raw = payload.addons || payload.addonIds || payload.addon || [];
  const ids = new Set((Array.isArray(raw) ? raw : [raw]).flatMap((value) => clean(value).split(',')).map(toSlug).filter(Boolean));
  return addonCatalogFor(serviceType).filter((addon) => ids.has(addon.id));
}
function qrNonceFor(bookingRef, scheduleId, seatNumber, index) {
  return crypto.createHash('sha1').update(`${bookingRef}:${scheduleId}:${seatNumber}:${index}:${Date.now()}:${crypto.randomBytes(12).toString('hex')}`).digest('hex').slice(0, 16).toUpperCase();
}
function qrHash(token) { return crypto.createHash('sha256').update(clean(token)).digest('hex'); }
function qrPreview(token) { const value = clean(token); return value.length > 14 ? `${value.slice(0, 8)}...${value.slice(-4)}` : value; }
function isoDate(value, fallback = new Date()) {
  const parsed = value ? new Date(value) : new Date(fallback);
  if (Number.isNaN(parsed.getTime())) { const error = new Error('Invalid hotel date'); error.status = 422; throw error; }
  return parsed.toISOString().slice(0, 10);
}
function hotelNightRange(payload = {}) {
  const checkIn = isoDate(payload.checkInDate || payload.checkIn || payload.startDate);
  const fallback = new Date(`${checkIn}T00:00:00.000Z`);
  fallback.setUTCDate(fallback.getUTCDate() + Math.max(1, Number(payload.nights || 1)));
  const checkOut = isoDate(payload.checkOutDate || payload.checkOut || payload.endDate || fallback);
  const start = new Date(`${checkIn}T00:00:00.000Z`);
  const end = new Date(`${checkOut}T00:00:00.000Z`);
  if (!(end > start)) { const error = new Error('Hotel check-out must be after check-in'); error.status = 422; throw error; }
  const nights = [];
  for (let cursor = new Date(start); cursor < end; cursor.setUTCDate(cursor.getUTCDate() + 1)) nights.push(cursor.toISOString().slice(0, 10));
  return { checkIn, checkOut, nights };
}
function isActiveLink(link = {}) {
  if (['archived', 'disabled', 'rejected', 'suspended'].includes(link.status)) return false;
  return !link.expiresAt || new Date(link.expiresAt) > new Date();
}
async function resolveReferral(payload, req, listingId) {
  const refCode = clean(payload.ref || req?.cookies?.ct_ref || req?.session?.referralCode || '');
  if (!refCode && payload.promoterAttribution && !req) return payload.promoterAttribution;
  if (!refCode) return null;
  const links = await promoterRepository.links.list({ status: { $nin: ['archived', 'disabled', 'rejected', 'suspended'] } });
  const link = links.find((row) => isActiveLink(row) && (!row.listingId || row.listingId === listingId) && [row.code, row.referralCode, clean(row.code).split('-').slice(0, -1).join('-')].some((value) => normalize(value) === normalize(refCode)));
  if (!link || req?.session?.user?.id === link.promoterId) return null;
  return { promoterId: link.promoterId, linkId: link.id, code: link.code || link.referralCode || refCode };
}
function usableSeat(seat, holdId) {
  if (!seat) return false;
  if (seat.status === 'available') return true;
  if (seat.status === 'locked') return Boolean(holdId && seat.lockId === holdId && (!seat.lockedUntil || new Date(seat.lockedUntil) > new Date()));
  return seat.status === 'taken' && !seat.bookingRef;
}
async function scheduleForListing(listingId, scheduleId) {
  if (scheduleId) return commerceRepository.schedules.findOne({ id: scheduleId, listingId });
  return (await commerceRepository.schedules.list({ listingId, status: { $nin: ['cancelled', 'archived'] } }, { sort: { departAt: 1 }, limit: 1 }))[0] || null;
}
async function selectBusLeg(listing, schedule, requestedSeats, passengerCount, legType, holdId) {
  if (!schedule || ['cancelled', 'archived'].includes(schedule.status)) { const error = new Error('Selected schedule is no longer available'); error.status = 409; throw error; }
  if (schedule.departAt && new Date(schedule.departAt) <= new Date()) { const error = new Error('Selected trip has already departed and can no longer be booked'); error.status = 409; throw error; }
  const seats = await commerceRepository.seats.list({ scheduleId: schedule.id }, { sort: { seatNumber: 1 } });
  const requested = seatListFrom(requestedSeats);
  const used = new Set();
  const selections = [];
  for (let index = 0; index < passengerCount; index += 1) {
    const requestedSeat = requested[index];
    let seat = requestedSeat ? seats.find((row) => row.seatNumber === requestedSeat && usableSeat(row, holdId)) : null;
    if (!seat) seat = seats.find((row) => usableSeat(row, holdId) && !used.has(row.seatNumber));
    if (!seat || used.has(seat.seatNumber)) { const error = new Error('Selected seat is no longer available'); error.status = 409; throw error; }
    used.add(seat.seatNumber);
    selections.push({ legType, schedule, seat, passengerIndex: index, price: Number(schedule.basePrice || listing.priceFrom || 0) + Number(seat.priceDelta || 0) });
  }
  return selections;
}

async function buildBooking(payload = {}, req = null) {
  const listingKey = clean(payload.listingId || payload.slug);
  const listing = await commerceRepository.listings.findOne({ $or: [{ id: listingKey }, { slug: listingKey }] });
  if (!listing) { const error = new Error('Listing not found'); error.status = 404; throw error; }
  const company = await commerceRepository.companies.findOne({ $or: [{ id: listing.companyId }, { slug: listing.companySlug || listing.companyId }] });
  if (listing.status !== 'active' || listing.bookable === false) { const error = new Error('This listing is not currently open for booking'); error.status = 409; throw error; }
  if (!ENABLED_BOOKING_TYPES.includes(listing.serviceType)) { const error = new Error('This service is not currently bookable'); error.status = 409; throw error; }
  if (company && (company.verificationStatus !== 'verified' || company.status === 'suspended' || company.settings?.canPublish === false)) { const error = new Error('Company must be verified before it can receive bookings'); error.status = 403; throw error; }

  const passengerInput = passengerInputFromPayload(payload);
  const promoterAttribution = await resolveReferral(payload, req, listing.id);
  let scheduleId = clean(payload.scheduleId);
  let selected = '';
  let subtotal = Number(listing.priceFrom || 0);
  let tripType = 'one_way';
  let busSelections = [];
  let hotelSelection = null;

  if (listing.serviceType === 'bus') {
    const outbound = await scheduleForListing(listing.id, scheduleId);
    scheduleId = outbound?.id || '';
    const passengerCount = Math.max(1, passengerInput.length, seatListFrom(payload.selectedSeats || payload.selected || payload.seatNumber).length, seatListFrom(payload.returnSeats).length);
    busSelections = await selectBusLeg(listing, outbound, payload.selectedSeats || payload.selected || payload.seatNumber, passengerCount, 'outbound', payload.holdId);
    if (payload.returnScheduleId) {
      const returning = await scheduleForListing(listing.id, payload.returnScheduleId);
      if (!returning || returning.id !== payload.returnScheduleId || new Date(returning.departAt) <= new Date(outbound.departAt)) { const error = new Error('Return trip must depart after the outbound trip'); error.status = 409; throw error; }
      busSelections.push(...await selectBusLeg(listing, returning, payload.returnSeats, passengerCount, 'return', payload.holdId));
      tripType = 'round_trip';
    }
    selected = busSelections.filter((row) => row.legType === 'outbound').map((row) => row.seat.seatNumber).join(',');
    subtotal = busSelections.reduce((sum, row) => sum + row.price, 0);
  } else {
    const range = hotelNightRange(payload);
    hotelSelection = await hotelInventoryService.selectAvailableRoom({
      listingId: listing.id,
      companyId: listing.companyId,
      roomTypeId: payload.roomTypeId,
      roomUnitId: payload.roomUnitId,
      selectionId: payload.roomTypeId || payload.roomUnitId,
      checkIn: range.checkIn,
      checkOut: range.checkOut,
      holdId: payload.holdId || '',
    });
    selected = hotelSelection.roomType.name;
    subtotal = hotelSelection.nightlyTotal;
  }

  const addons = selectedAddonsFor(listing.serviceType, payload);
  const addonTotal = addons.reduce((sum, row) => sum + Number(row.price || 0), 0);
  const fees = Math.round(subtotal * 0.045 + 3500);
  const computedTotal = subtotal + fees + addonTotal;
  const clientTotal = Number(payload.total || 0);
  const total = clientTotal > computedTotal ? clientTotal : computedTotal;
  const split = calculateCommission(total, Boolean(promoterAttribution));
  const bookingId = await nextId('booking');
  const bookingRef = `CT-${String(listing.serviceType || 'TRIP').toUpperCase()}-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
  const initialPaymentStatus = payload.paymentStatus || (payload.deferPayment ? 'pending' : 'successful');
  const outboundSelections = busSelections.filter((row) => row.legType === 'outbound');
  const passengerRows = listing.serviceType === 'bus'
    ? await Promise.all(Array.from({ length: Math.max(1, passengerInput.length, outboundSelections.length) }, async (_, index) => {
      const input = passengerInput[index] || {}; const seat = outboundSelections[index]?.seat;
      return { id: await nextId('passenger'), fullName: input.fullName || input.name || (index === 0 ? payload.passengerName || payload.fullName : `${payload.fullName || 'Guest Customer'} ${index + 1}`), email: input.email || payload.email || '', phone: input.phone || payload.phone || '', seatOrRoom: seat?.seatNumber || selected, seatNumber: seat?.seatNumber || selected, pickupPoint: input.pickupPoint || payload.pickupPoint || '', dropoffPoint: input.dropoffPoint || payload.dropoffPoint || '', specialNotes: input.specialNotes || input.travelNotes || input.notes || '' };
    }))
    : [{ id: await nextId('passenger'), fullName: payload.passengerName || payload.fullName || 'Guest Customer', email: payload.email || '', phone: payload.phone || '', seatOrRoom: selected }];
  const bookingItems = listing.serviceType === 'bus'
    ? await Promise.all(busSelections.map(async (row) => ({ id: await nextId('booking-item'), bookingRef, serviceType: 'bus', legType: row.legType, listingId: listing.id, scheduleId: row.schedule.id, seatNumber: row.seat.seatNumber, passengerIndex: row.passengerIndex, passengerName: passengerRows[row.passengerIndex]?.fullName || 'Passenger', unitPrice: row.price, currency: listing.currency || row.schedule.currency || 'UGX', status: 'confirmed' })))
    : [{ id: await nextId('booking-item'), bookingRef, serviceType: 'hotel', listingId: listing.id, roomType: hotelSelection.roomType.name, roomTypeId: hotelSelection.roomType.id, roomUnitId: hotelSelection.roomUnit.id, checkIn: hotelSelection.checkIn, checkOut: hotelSelection.checkOut, nights: hotelSelection.nights, nightIds: hotelSelection.nightRows.map((row) => row.id), passengerName: passengerRows[0].fullName, unitPrice: Number(hotelSelection.roomType.basePrice || listing.priceFrom || 0), currency: listing.currency || 'UGX', status: 'confirmed' }];
  const ticketLegs = listing.serviceType === 'bus'
    ? await Promise.all(busSelections.map(async (row, index) => {
      const id = await nextId('ticket-leg'); const nonce = qrNonceFor(bookingRef, row.schedule.id, row.seat.seatNumber, index + 1); const token = `CTQR-${bookingRef}-${id}-${nonce}`;
      return { id, bookingRef, ticketNumber: `${bookingRef}-${row.schedule.id}-${row.seat.seatNumber}`, legType: row.legType, serviceType: 'bus', listingId: listing.id, scheduleId: row.schedule.id, seatNumber: row.seat.seatNumber, passengerIndex: row.passengerIndex, passengerName: passengerRows[row.passengerIndex]?.fullName || 'Passenger', qrNonce: nonce, qrToken: token, qrTokenHash: qrHash(token), qrTokenPreview: qrPreview(token), checkInStatus: 'boarding', status: 'valid', createdAt: new Date().toISOString() };
    }))
    : [];
  const booking = {
    id: bookingId, bookingRef, guestLookupCode: crypto.randomBytes(6).toString('hex').toUpperCase(), serviceType: listing.serviceType,
    guestSnapshot: { fullName: payload.fullName || payload.customerName || 'Guest Customer', email: payload.email || 'guest@example.com', phone: payload.phone || '+256700000000' },
    buyerSnapshot: { fullName: payload.fullName || payload.customerName || 'Guest Customer', email: payload.email || 'guest@example.com', phone: payload.phone || '+256700000000', idType: payload.idType || '', documentNumber: payload.documentNumber || '', notes: payload.notes || payload.customerNote || '' },
    customerUserId: payload.customerUserId || payload.userId || req?.session?.user?.id || null, companyId: listing.companyId, listingId: listing.id, scheduleId,
    passengers: passengerRows, bookingItems, bookingLegs: listing.serviceType === 'bus' ? [...new Map(busSelections.map((row) => [row.legType, row])).values()].map((row) => ({ legType: row.legType, scheduleId: row.schedule.id, listingId: listing.id, companyId: listing.companyId, departAt: row.schedule.departAt, arriveAt: row.schedule.arriveAt, status: 'confirmed' })) : [], ticketLegs,
    hotelStay: hotelSelection ? { checkIn: hotelSelection.checkIn, checkOut: hotelSelection.checkOut, nights: hotelSelection.nights, roomCount: 1, roomUnitIds: [hotelSelection.roomUnit.id], roomTypeIds: [hotelSelection.roomType.id], nightIds: hotelSelection.nightRows.map((row) => row.id), status: 'pending_payment' } : undefined,
    tripType, addons, notes: payload.notes || payload.customerNote || '', pricing: { subtotal, fees, addonTotal, total, currency: listing.currency || 'UGX', split, addons }, promoterAttribution,
    referralCode: promoterAttribution?.code || '', paymentStatus: initialPaymentStatus, bookingStatus: initialPaymentStatus === 'successful' ? 'confirmed' : 'pending', settlementStatus: 'pending',
    qrCodeValue: `CLASSIC-TRIP:${bookingRef}:${listing.id}:${Date.now()}`, lockedUntil: addMinutes(new Date(), 10).toISOString(), bookingChannel: payload.offlineSale ? 'agent_offline' : (payload.bookingChannel || 'web'), createdByAgentId: payload.agentId || '', createdAt: new Date().toISOString(),
  };
  booking.risk = fraudService.scoreBookingRisk(booking);
  return { booking, listing, company };
}

module.exports = { buildBooking, qrHash };
