const { addMinutes } = require('../../utils/dates');
const inventoryHoldService = require('./inventoryHoldService');
const hotelInventoryService = require('../hotel/hotelInventoryService');
const hotelRepository = require('../../repositories/domain/hotelRepository');

const reservations = [];

function nowDate(value = new Date()) { return value instanceof Date ? value : new Date(value); }
function isTest() { return process.env.NODE_ENV === 'test'; }

async function findActiveReservation(reservationId, roomUnitId = '') {
  const now = new Date();
  const local = reservations.find((item) => item.id === reservationId && (!roomUnitId || item.roomUnitId === roomUnitId) && new Date(item.expiresAt) > now);
  if (local) return local;
  return hotelRepository.inventoryHolds.findOne({ id: reservationId, holdType: 'room', status: 'active', expiresAt: { $gt: now }, ...(roomUnitId ? { roomUnitIds: roomUnitId } : {}) });
}

async function roomActiveHoldCount(selectionId, now = new Date()) {
  const at = nowDate(now);
  const unit = await hotelRepository.roomUnits.findOne({ id: selectionId });
  const roomTypeId = unit?.roomTypeId || selectionId;
  const units = unit ? [unit] : await hotelRepository.roomUnits.list({ roomTypeId, status: { $ne: 'archived' } });
  if (!units.length) return 0;
  const keys = new Set(units.map((row) => row.id));
  const items = await hotelRepository.inventoryHoldItems.list({ resourceType: 'room_unit_night', roomUnitId: { $in: [...keys] }, status: 'active', expiresAt: { $gt: at } });
  return new Set(items.map((row) => row.holdId)).size;
}

function createReservation(selection, guest, minutes) {
  const reservation = {
    id: `room-res-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    roomTypeId: selection.roomType.id,
    roomUnitId: selection.roomUnit.id,
    roomType: selection.roomType.name,
    nightDates: selection.nights,
    nightIds: selection.nightRows.map((row) => row.id),
    guest,
    expiresAt: addMinutes(new Date(), minutes).toISOString(),
    createdAt: new Date().toISOString(),
  };
  if (isTest()) reservations.push(reservation);
  return reservation;
}

async function reserveRoom(selectionId, guest = {}, minutes = 10, context = {}) {
  return reserveRoomPersistent(selectionId, guest, minutes, context);
}

async function reserveRoomPersistent(selectionId, guest = {}, minutes = 10, context = {}) {
  const checkIn = context.checkIn || context.checkInDate;
  const checkOut = context.checkOut || context.checkOutDate;
  if (!checkIn || !checkOut) throw Object.assign(new Error('Check-in and check-out dates are required to hold a room'), { status: 422 });
  const selection = await hotelInventoryService.selectAvailableRoom({
    listingId: context.listingId,
    companyId: context.companyId,
    roomTypeId: context.roomTypeId,
    roomUnitId: context.roomUnitId,
    selectionId,
    checkIn,
    checkOut,
  });
  const reservation = createReservation(selection, guest, minutes);
  try {
    await inventoryHoldService.recordRoomHold(reservation, {
      ...context,
      listingId: context.listingId || selection.roomType.listingId,
      companyId: context.companyId || selection.roomType.companyId,
      roomTypeId: selection.roomType.id,
      roomUnitId: selection.roomUnit.id,
      nightDates: selection.nights,
      selectedLabel: `${selection.roomType.name} · ${selection.roomUnit.unitNumber}`,
    });
    return reservation;
  } catch (error) {
    const index = reservations.indexOf(reservation);
    if (index >= 0) reservations.splice(index, 1);
    throw error;
  }
}

function releaseExpiredReservations(now = new Date()) {
  const current = nowDate(now);
  const before = reservations.length;
  for (let index = reservations.length - 1; index >= 0; index -= 1) if (new Date(reservations[index].expiresAt) <= current) reservations.splice(index, 1);
  void inventoryHoldService.expireActiveHolds(current);
  return before - reservations.length;
}

async function consumeReservation(reservationId, roomUnitId = '') {
  const reservation = await findActiveReservation(reservationId, roomUnitId);
  if (!reservation) return null;
  const index = reservations.findIndex((row) => row.id === reservationId);
  if (index >= 0) reservations.splice(index, 1);
  await inventoryHoldService.consumeHold(reservationId, {}, { userId: 'room-reservation' });
  return { ...reservation, status: 'consumed', consumedAt: new Date().toISOString() };
}

module.exports = { reserveRoom, reserveRoomPersistent, releaseExpiredReservations, findActiveReservation, consumeReservation, roomActiveHoldCount, reservations };
