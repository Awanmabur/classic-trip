const { addMinutes } = require('../../utils/dates');
const repositories = require('../../repositories');
const transportRepository = require('../../repositories/domain/transportRepository');
const inventoryHoldService = require('./inventoryHoldService');

function holdId() {
  return `seat-hold-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function fallbackSeats() {
  return transportRepository.seats.fallbackRows();
}

function fallbackBookings() {
  return transportRepository.bookings.fallbackRows();
}

async function assertSeatCanBeHeldFallback(scheduleId, seatNumber, now = new Date()) {
  const resourceKey = inventoryHoldService.seatResourceKey(scheduleId, seatNumber);
  const existingActiveHold = await inventoryHoldService.activeResourceItem(resourceKey, now);
  if (existingActiveHold) throw Object.assign(new Error('Seat is temporarily held by another checkout'), { status: 409 });
  const paidBooking = fallbackBookings().find((booking) => booking.scheduleId === scheduleId
    && String(booking.seatNumber || booking.selectedSeat || booking.seat) === String(seatNumber)
    && !['cancelled', 'refunded', 'failed'].includes(String(booking.bookingStatus || booking.status || '').toLowerCase())
    && !['failed', 'cancelled', 'refunded'].includes(String(booking.paymentStatus || '').toLowerCase()));
  if (paidBooking) throw Object.assign(new Error('Seat is already booked'), { status: 409 });
}

async function lockSeat(scheduleId, seatNumber, minutes = 10) {
  const now = new Date();
  const seat = fallbackSeats().find((item) => item.scheduleId === scheduleId && item.seatNumber === seatNumber);
  if (!seat) throw Object.assign(new Error('Seat not found'), { status: 404 });
  await assertSeatCanBeHeldFallback(scheduleId, seatNumber, now);
  if (['taken', 'booked', 'checked_in', 'no_show', 'checked-in', 'no-show', 'cancelled', 'refunded', 'disabled', 'maintenance', 'blocked'].includes(String(seat.status || '').toLowerCase())) {
    throw Object.assign(new Error('Seat is not available'), { status: 409 });
  }
  if (seat.lockedUntil && new Date(seat.lockedUntil) > now) throw Object.assign(new Error('Seat is temporarily locked'), { status: 409 });
  const nextHoldId = holdId();
  seat.status = 'locked';
  seat.lockedUntil = addMinutes(now, minutes).toISOString();
  seat.lockId = nextHoldId;
  return { id: nextHoldId, type: 'seat', scheduleId, seatNumber, lockedUntil: seat.lockedUntil, seat };
}

function releaseSeatHold(hold = {}) {
  const seat = fallbackSeats().find((item) => item.scheduleId === hold.scheduleId && item.seatNumber === hold.seatNumber);
  if (seat && seat.status === 'locked' && (!hold.id || seat.lockId === hold.id || seat.lockId === hold.groupId)) {
    seat.status = 'available';
    seat.lockedUntil = null;
    seat.lockId = null;
    return true;
  }
  return false;
}

async function lockSeatPersistent(scheduleId, seatNumber, minutes = 10, context = {}) {
  if (!transportRepository.seats.isMongoReady()) {
    const hold = await lockSeat(scheduleId, seatNumber, minutes);
    if (!context.deferHoldPersistence) await inventoryHoldService.recordSeatHold(hold, context);
    return hold;
  }

  const now = new Date();
  const resourceKey = inventoryHoldService.seatResourceKey(scheduleId, seatNumber);
  await Promise.all([
    repositories.inventoryHolds.updateMany(
      { scheduleId, seatNumber, holdType: 'seat', status: 'active', expiresAt: { $lte: now } },
      { $set: { status: 'expired', releasedAt: now, releaseReason: 'expired' } }
    ),
    repositories.inventoryHoldItems.updateMany(
      { resourceKey, status: 'active', expiresAt: { $lte: now } },
      { $set: { status: 'expired', releasedAt: now, releaseReason: 'expired' } }
    ),
    repositories.seats.updateMany(
      { scheduleId, seatNumber, status: 'locked', lockedUntil: { $lte: now } },
      { $set: { status: 'available' }, $unset: { lockedUntil: '', lockId: '' } }
    ),
  ]);

  const lockedUntil = addMinutes(now, minutes);
  const nextHoldId = holdId();
  const activeHoldCount = await repositories.inventoryHoldItems.count({ resourceKey, status: 'active', expiresAt: { $gt: now } });
  if (activeHoldCount) throw Object.assign(new Error('Seat is temporarily held by another checkout'), { status: 409 });

  const seat = await repositories.seats.findOneAndUpdate(
    {
      scheduleId,
      seatNumber,
      status: { $nin: ['taken', 'booked', 'checked_in', 'no_show', 'checked-in', 'no-show', 'cancelled', 'refunded', 'disabled', 'maintenance', 'blocked'] },
      $or: [{ status: 'available' }, { lockedUntil: null }, { lockedUntil: { $exists: false } }, { lockedUntil: { $lte: now } }],
    },
    { $set: { status: 'locked', lockedUntil, lockId: nextHoldId } },
    { new: true, runValidators: true }
  );

  if (!seat) throw Object.assign(new Error('Seat is temporarily locked or unavailable'), { status: 409 });
  const hold = { id: nextHoldId, type: 'seat', scheduleId, seatNumber, lockedUntil: lockedUntil.toISOString(), seat };
  if (!context.deferHoldPersistence) await inventoryHoldService.recordSeatHold(hold, context);
  return hold;
}

async function releaseSeatHoldPersistent(hold = {}) {
  if (!transportRepository.seats.isMongoReady()) return releaseSeatHold(hold);
  if (!hold.scheduleId || !hold.seatNumber) return false;
  const result = await repositories.seats.updateMany(
    { scheduleId: hold.scheduleId, seatNumber: hold.seatNumber, lockId: { $in: [hold.id, hold.groupId].filter(Boolean) } },
    { $set: { status: 'available' }, $unset: { lockedUntil: '', lockId: '' } }
  );
  return Boolean(result.modifiedCount || 0);
}

async function lockSeatsPersistent(scheduleId, seatNumbers = [], minutes = 10, context = {}) {
  const requestedSeats = [...new Set([].concat(seatNumbers).map((seat) => String(seat || '').trim()).filter(Boolean))];
  if (!requestedSeats.length) throw Object.assign(new Error('At least one seat is required'), { status: 422 });
  if (requestedSeats.length <= 1) {
    const hold = await lockSeatPersistent(scheduleId, requestedSeats[0], minutes, context);
    return { ...hold, seatNumbers: [hold.seatNumber], holds: [hold] };
  }

  const groupId = holdId().replace('seat-hold-', 'seat-hold-group-');
  const holds = [];
  try {
    for (const seatNumber of requestedSeats) {
      const hold = await lockSeatPersistent(scheduleId, seatNumber, minutes, { ...context, groupedHoldId: groupId, deferHoldPersistence: true });
      holds.push({ ...hold, groupId });
    }
    holds.forEach((hold) => { if (hold.seat) hold.seat.lockId = groupId; });
    if (transportRepository.seats.isMongoReady()) {
      await repositories.seats.updateMany(
        { scheduleId, seatNumber: { $in: requestedSeats }, status: 'locked' },
        { $set: { lockId: groupId } }
      );
    }
    const groupedHold = { id: groupId, type: 'seats', scheduleId, seatNumber: requestedSeats[0], seatNumbers: requestedSeats, lockedUntil: holds[0]?.lockedUntil, holds, seat: holds[0]?.seat };
    await inventoryHoldService.recordGroupedSeatHold(groupedHold, context);
    return groupedHold;
  } catch (error) {
    await Promise.allSettled([...holds.map((hold) => releaseSeatHoldPersistent(hold)), inventoryHoldService.releaseHold(groupId, 'group_lock_failed')]);
    throw error;
  }
}

function releaseExpiredLocks(now = new Date()) {
  let released = 0;
  for (const seat of fallbackSeats()) {
    if (seat.status === 'locked' && seat.lockedUntil && new Date(seat.lockedUntil) <= now) {
      seat.status = 'available';
      seat.lockedUntil = null;
      seat.lockId = null;
      released += 1;
    }
  }
  return released;
}

async function releaseExpiredLocksPersistent(now = new Date()) {
  if (!transportRepository.seats.isMongoReady()) return releaseExpiredLocks(now);
  const result = await repositories.seats.updateMany(
    { status: 'locked', lockedUntil: { $lte: now } },
    { $set: { status: 'available' }, $unset: { lockedUntil: '', lockId: '' } }
  );
  return result.modifiedCount || 0;
}

module.exports = { lockSeat, lockSeatPersistent, lockSeatsPersistent, releaseSeatHoldPersistent, releaseExpiredLocks, releaseExpiredLocksPersistent };
