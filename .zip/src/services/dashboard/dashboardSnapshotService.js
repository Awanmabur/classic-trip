const repositories = require('../../repositories');
const memoryDatabase = require('../../repositories/memoryDatabase');

const ALL_ENTITIES = [
  ...memoryDatabase.BASE_KEYS.filter((key) => !['notificationTemplates'].includes(key)),
  'platformSettings',
];

const COMPANY_SCOPED = new Set([
  'companyEmployees','companyBranches','companyPolicies','listings','routes','routeStops','routeSegments','vehicles','seatMapTemplates','seatMapVersions','fareProducts','busSegmentFares','schedules','seats','busSeatSegmentInventories',
  'driverAssignments','driverIncidents','tripStatusUpdates','hotelProperties','roomTypes','roomUnits','roomNightInventories',
  'stayRules','bookings','bookingItems','busReservations','busSeatAssignments','busTickets','bookingGroups','payments','supportTickets','refundRequests','promotionCampaigns','reviews','notifications',
  'shiftHandovers','ticketScans','financeStatements','financeRiskReviews','settlementBatches','reconciliationReports','offlineSales',
]);

function clone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function emptySnapshot() {
  const snapshot = {};
  for (const key of memoryDatabase.BASE_KEYS) snapshot[key] = [];
  snapshot.platformSettings = {};
  return snapshot;
}

function memorySnapshot() {
  const snapshot = emptySnapshot();
  for (const key of memoryDatabase.BASE_KEYS) snapshot[key] = clone(memoryDatabase.collection(key));
  snapshot.platformSettings = clone(memoryDatabase.state.platformSettings || {});
  return snapshot;
}

async function list(entity, filter = {}, limit = 2500) {
  const repository = repositories[entity];
  if (!repository?.isReady?.()) return [];
  return repository.list(filter, { sort: { createdAt: -1 }, limit });
}

async function one(entity, filter = {}) {
  const repository = repositories[entity];
  if (!repository?.isReady?.()) return null;
  return repository.findOne(filter);
}

function ids(rows = [], key = 'id') {
  return [...new Set(rows.map((row) => {
    if (!row) return null;
    return key === 'id' ? (row.id || row._id) : row[key];
  }).filter(Boolean).map(String))];
}

function mergeRowsById(current = [], extra = []) {
  const merged = new Map();
  [...(Array.isArray(current) ? current : []), ...(Array.isArray(extra) ? extra : [])].forEach((row) => {
    if (!row) return;
    const rowId = row.id || row._id;
    if (!rowId) return;
    merged.set(String(rowId), row);
  });
  return [...merged.values()];
}

async function adminSnapshot() {
  const snapshot = emptySnapshot();
  await Promise.all(ALL_ENTITIES.map(async (entity) => {
    if (entity === 'platformSettings') {
      snapshot.platformSettings = await one('platformSettings', {}) || {};
      return;
    }
    if (!repositories[entity]) return;
    snapshot[entity] = await list(entity);
  }));
  return snapshot;
}

async function companySnapshot(companyId) {
  const snapshot = emptySnapshot();
  snapshot.companies = [await one('companies', { id: companyId })].filter(Boolean);
  snapshot.users = await list('users', { companyId }, 500);

  const directEntities = [...COMPANY_SCOPED].filter((entity) => repositories[entity]);
  await Promise.all(directEntities.map(async (entity) => {
    if (entity === 'seats') return;
    snapshot[entity] = await list(entity, { companyId });
  }));

  let listingIds = ids(snapshot.listings);

  // Compatibility recovery for older records that were correctly linked to a
  // company-owned listing but did not persist companyId on every transport row.
  // The ownership chain is listing -> route/vehicle/schedule, so this remains
  // company scoped and prevents valid live departure seat maps disappearing.
  if (listingIds.length) {
    const [relatedRoutes, relatedVehicles] = await Promise.all([
      repositories.routes ? list('routes', { listingId: { $in: listingIds } }, 3000) : [],
      repositories.vehicles ? list('vehicles', { listingId: { $in: listingIds } }, 3000) : [],
    ]);
    snapshot.routes = mergeRowsById(snapshot.routes, relatedRoutes);
    snapshot.vehicles = mergeRowsById(snapshot.vehicles, relatedVehicles);

    const routeIds = ids(snapshot.routes);
    const vehicleIdsForSchedules = ids(snapshot.vehicles);
    const scheduleOwnership = [
      { listingId: { $in: listingIds } },
      ...(routeIds.length ? [{ routeId: { $in: routeIds } }] : []),
      ...(vehicleIdsForSchedules.length ? [{ vehicleId: { $in: vehicleIdsForSchedules } }] : []),
    ];
    const [relatedSchedules, relatedStops, relatedSegments] = await Promise.all([
      repositories.schedules ? list('schedules', { $or: scheduleOwnership }, 5000) : [],
      repositories.routeStops && routeIds.length ? list('routeStops', { routeId: { $in: routeIds } }, 5000) : [],
      repositories.routeSegments && routeIds.length ? list('routeSegments', { routeId: { $in: routeIds } }, 5000) : [],
    ]);
    snapshot.schedules = mergeRowsById(snapshot.schedules, relatedSchedules);
    snapshot.routeStops = mergeRowsById(snapshot.routeStops, relatedStops);
    snapshot.routeSegments = mergeRowsById(snapshot.routeSegments, relatedSegments);
  }

  const scheduleIds = ids(snapshot.schedules);
  const vehicleIds = ids(snapshot.vehicles);
  const referencedVersionIds = [...new Set([
    ...snapshot.schedules.map((row) => row?.seatMapVersionId),
    ...snapshot.vehicles.map((row) => row?.activeSeatMapVersionId),
  ].filter(Boolean))];
  const referencedTemplateIds = [...new Set([
    ...snapshot.schedules.map((row) => row?.seatMapTemplateId),
    ...snapshot.vehicles.map((row) => row?.activeSeatMapTemplateId),
  ].filter(Boolean))];

  const [relatedVersions, relatedTemplates] = await Promise.all([
    repositories.seatMapVersions && (referencedVersionIds.length || vehicleIds.length)
      ? list('seatMapVersions', {
          $or: [
            ...(referencedVersionIds.length ? [{ id: { $in: referencedVersionIds } }] : []),
            ...(vehicleIds.length ? [{ vehicleId: { $in: vehicleIds } }] : []),
          ],
        }, 5000)
      : [],
    repositories.seatMapTemplates && (referencedTemplateIds.length || vehicleIds.length)
      ? list('seatMapTemplates', {
          $or: [
            ...(referencedTemplateIds.length ? [{ id: { $in: referencedTemplateIds } }] : []),
            ...(vehicleIds.length ? [{ vehicleId: { $in: vehicleIds } }] : []),
          ],
        }, 3000)
      : [],
  ]);
  snapshot.seatMapVersions = mergeRowsById(snapshot.seatMapVersions, relatedVersions)
    .filter((row) => vehicleIds.includes(String(row.vehicleId || '')) || listingIds.includes(String(row.listingId || '')) || referencedVersionIds.includes(String(row.id || row._id || '')));
  snapshot.seatMapTemplates = mergeRowsById(snapshot.seatMapTemplates, relatedTemplates)
    .filter((row) => vehicleIds.includes(String(row.vehicleId || '')) || listingIds.includes(String(row.listingId || '')) || referencedTemplateIds.includes(String(row.id || row._id || '')));

  const bookingRefs = ids(snapshot.bookings, 'bookingRef');
  const bookingIds = ids(snapshot.bookings);
  const propertyIds = ids(snapshot.hotelProperties);
  const roomTypeIds = ids(snapshot.roomTypes);

  const relatedTasks = [
    ['categories', {}, 500],
    ['seats', scheduleIds.length ? { $or: [
      { scheduleId: { $in: scheduleIds } },
      { departureId: { $in: scheduleIds } },
      { tripScheduleId: { $in: scheduleIds } },
    ] } : { scheduleId: '__none__' }, 5000],
    ['passengers', bookingIds.length ? { bookingId: { $in: bookingIds } } : { bookingId: '__none__' }, 5000],
    ['wallets', { ownerType: 'company', ownerId: companyId }, 50],
    ['walletTransactions', { ownerType: 'company', ownerId: companyId }, 5000],
    ['commissions', { companyId }, 5000],
    ['cartCheckoutAttempts', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['paymentIntents', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['receiptInvoices', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['taxFeeRecords', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['bookingTimelineEvents', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 5000],
    ['correspondenceMessages', { companyId }, 5000],
    ['notificationDeliveryAttempts', { companyId }, 5000],
    ['promoterLinks', listingIds.length ? { listingId: { $in: listingIds } } : { listingId: '__none__' }, 2000],
    ['roomUnits', propertyIds.length ? { propertyId: { $in: propertyIds } } : { propertyId: '__none__' }, 3000],
    ['roomNightInventories', roomTypeIds.length ? { roomTypeId: { $in: roomTypeIds } } : { roomTypeId: '__none__' }, 5000],
  ];
  await Promise.all(relatedTasks.map(async ([entity, filter, limit]) => {
    if (repositories[entity]) snapshot[entity] = await list(entity, filter, limit);
  }));
  snapshot.platformSettings = await one('platformSettings', {}) || {};
  return snapshot;
}

async function customerSnapshot(context = {}) {
  const snapshot = emptySnapshot();
  const user = await one('users', { id: context.customerId });
  snapshot.users = [user].filter(Boolean);
  const ownership = [{ customerUserId: context.customerId }];
  if (user?.email) ownership.push({ 'guestSnapshot.email': String(user.email).toLowerCase() });
  if (user?.phone) ownership.push({ 'guestSnapshot.phone': user.phone });
  snapshot.bookings = await list('bookings', { $or: ownership }, 2000);
  const bookingRefs = ids(snapshot.bookings, 'bookingRef');
  const bookingIds = ids(snapshot.bookings);
  const listingIds = ids(snapshot.bookings, 'listingId');
  const companyIds = ids(snapshot.bookings, 'companyId');
  const tasks = [
    ['listings', listingIds.length ? { id: { $in: listingIds } } : { id: '__none__' }, 1000],
    ['companies', companyIds.length ? { id: { $in: companyIds } } : { id: '__none__' }, 1000],
    ['passengers', bookingIds.length ? { bookingId: { $in: bookingIds } } : { bookingId: '__none__' }, 5000],
    ['payments', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['refundRequests', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['rescheduleRequests', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['reviews', { customerUserId: context.customerId }, 2000],
    ['savedListings', { userId: context.customerId }, 2000],
    ['supportTickets', { $or: [{ ownerId: context.customerId }, { customerUserId: context.customerId }, ...(bookingRefs.length ? [{ bookingRef: { $in: bookingRefs } }] : [])] }, 2000],
    ['notifications', { $or: [{ customerId: context.customerId }, { userId: context.customerId }, { audience: 'customer' }] }, 2000],
    ['wallets', { ownerType: 'customer', ownerId: context.customerId }, 20],
    ['receiptInvoices', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 2000],
    ['bookingTimelineEvents', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 5000],
    ['correspondenceMessages', bookingRefs.length ? { bookingRef: { $in: bookingRefs } } : { bookingRef: '__none__' }, 5000],
    ['deviceSessions', { userId: context.customerId }, 200],
    ['securityEvents', { actorId: context.customerId }, 200],
  ];
  await Promise.all(tasks.map(async ([entity, filter, limit]) => { if (repositories[entity]) snapshot[entity] = await list(entity, filter, limit); }));
  return snapshot;
}

async function promoterSnapshot(context = {}) {
  const snapshot = emptySnapshot();
  const promoterId = context.promoterId;
  snapshot.users = [await one('users', { id: promoterId })].filter(Boolean);
  const tasks = [
    ['promoterLinks', { promoterId }, 3000], ['referralClicks', { promoterId }, 5000], ['attributionSessions', { promoterId }, 5000],
    ['campaignConversions', { promoterId }, 5000], ['agentProfiles', { $or: [{ userId: promoterId }, { promoterId }] }, 50],
    ['offlineSales', { $or: [{ promoterId }, { agentId: promoterId }] }, 5000], ['fraudSignals', { $or: [{ promoterId }, { agentId: promoterId }] }, 5000],
    ['commissions', { promoterId }, 5000], ['wallets', { ownerType: 'promoter', ownerId: promoterId }, 50],
    ['walletTransactions', { ownerType: 'promoter', ownerId: promoterId }, 5000], ['payoutRequests', { ownerType: 'promoter', ownerId: promoterId }, 2000],
    ['supportTickets', { $or: [{ ownerId: promoterId }, { promoterId }] }, 2000], ['notifications', { $or: [{ promoterId }, { userId: promoterId }, { audience: 'promoter' }] }, 2000],
  ];
  await Promise.all(tasks.map(async ([entity, filter, limit]) => { if (repositories[entity]) snapshot[entity] = await list(entity, filter, limit); }));
  const listingIds = ids(snapshot.promoterLinks, 'listingId');
  const bookingRefs = ids(snapshot.campaignConversions, 'bookingRef');
  snapshot.listings = listingIds.length ? await list('listings', { id: { $in: listingIds } }, 3000) : [];
  snapshot.companies = snapshot.listings.length ? await list('companies', { id: { $in: ids(snapshot.listings, 'companyId') } }, 1000) : [];
  snapshot.bookings = bookingRefs.length ? await list('bookings', { bookingRef: { $in: bookingRefs } }, 5000) : await list('bookings', { 'promoterAttribution.promoterId': promoterId }, 5000);
  snapshot.promotionCampaigns = listingIds.length ? await list('promotionCampaigns', { listingId: { $in: listingIds } }, 2000) : [];
  return snapshot;
}

async function load(role, context = {}) {
  if (!repositories.mongoReady()) {
    if (process.env.NODE_ENV === 'test') return memorySnapshot();
    throw new Error('MongoDB is required to build dashboard projections');
  }
  if (role === 'admin' || ['support','finance','operations','content'].includes(role)) return adminSnapshot();
  if (role === 'company' || role === 'employee') return companySnapshot(context.companyId);
  if (role === 'customer') return customerSnapshot(context);
  if (role === 'promoter') return promoterSnapshot(context);
  return emptySnapshot();
}

module.exports = { load, memorySnapshot, emptySnapshot };
