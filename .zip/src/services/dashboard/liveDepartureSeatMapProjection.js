'use strict';

function key(value) {
  return String(value == null ? '' : value).trim();
}

function normalize(value) {
  return key(value).toLowerCase().replace(/[-\s]+/g, '_');
}

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

function rowId(row = {}) {
  const value = row && typeof row === 'object' ? row : {};
  return key(value.id || value._id);
}

function firstById(rows = []) {
  const map = new Map();
  asArray(rows).filter(Boolean).forEach((row) => {
    const ids = [row.id, row._id].map(key).filter(Boolean);
    ids.forEach((id) => map.set(id, row));
  });
  return map;
}

function seatNumberOf(seat = {}, index = 0) {
  return key(
    seat.seatNumber
    || seat.displayLabel
    || seat.label
    || seat.code
    || seat.number
    || seat.name
    || seat.id
    || (index + 1)
  ).toUpperCase();
}

function canonicalSeatStatus(value) {
  const status = normalize(value || 'available');
  if (['taken', 'booked', 'sold', 'confirmed', 'checked_in'].includes(status)) return 'booked';
  if (['locked', 'held', 'selected', 'pending_payment', 'reserved'].includes(status)) return 'held';
  if (['blocked', 'maintenance', 'disabled', 'unavailable', 'non_sellable'].includes(status)) return 'blocked';
  if (['cancelled', 'refunded', 'no_show'].includes(status)) return status;
  return 'available';
}

function seatArrayFrom(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== 'object') return [];
  const candidates = [
    value.seats,
    value.seatTemplate,
    value.seatDefinitions,
    value.inventory,
    value.items,
    value.layout?.seats,
    value.snapshot?.seats,
  ];
  return candidates.find(Array.isArray) || [];
}

function scheduleIdOf(schedule = {}) {
  return rowId(schedule);
}

function scheduleRefOfSeat(seat = {}) {
  return key(seat.scheduleId || seat.departureId || seat.tripScheduleId || seat.tripId);
}

function scheduleRefOfLeg(row = {}) {
  return key(row.scheduleId || row.departureId || row.tripScheduleId || row.tripId);
}

function isBusDepartureSchedule(schedule = {}, context = {}) {
  const listing = context.listingById?.get(key(schedule.listingId)) || {};
  const route = context.routeById?.get(key(schedule.routeId)) || {};
  const routeListing = context.listingById?.get(key(route.listingId)) || {};
  const vehicle = context.vehicleById?.get(key(schedule.vehicleId)) || {};
  const values = [
    schedule.serviceType,
    schedule.transportType,
    schedule.type,
    schedule.group,
    schedule.inventoryType,
    listing.serviceType,
    listing.type,
    listing.group,
    route.serviceType,
    routeListing.serviceType,
    vehicle.serviceType,
  ].map(normalize);
  if (values.includes('bus') || values.includes('coach')) return true;
  return Boolean(
    schedule.seatMapVersionId
    || schedule.seatMapTemplateId
    || schedule.seatMapSnapshot
    || seatArrayFrom(schedule.seatInventorySnapshot).length
    || normalize(schedule.inventoryType) === 'seats'
  );
}

function bookingForSeat(bookings = [], scheduleId, seatNumber) {
  return asArray(bookings).find((booking) => {
    if (asArray(booking.ticketLegs).some((leg) => scheduleRefOfLeg(leg) === scheduleId && seatNumberOf(leg) === seatNumber)) return true;
    if (asArray(booking.bookingItems).some((item) => scheduleRefOfLeg(item) === scheduleId && seatNumberOf(item) === seatNumber)) return true;
    if (scheduleRefOfLeg(booking) !== scheduleId) return false;
    return asArray(booking.passengers).some((passenger) => seatNumberOf({ seatNumber: passenger.seatNumber || passenger.seatOrRoom || passenger.seatLabel }) === seatNumber);
  }) || null;
}

function versionSeatRows(version = {}) {
  return seatArrayFrom(version);
}

function resolveSourceSeats(schedule = {}, context = {}) {
  const scheduleId = scheduleIdOf(schedule);
  const persisted = asArray(context.seats).filter((seat) => scheduleRefOfSeat(seat) === scheduleId);
  if (persisted.length) return { source: 'persisted_inventory', seats: persisted, needsRepair: false };

  const scheduleInventorySnapshot = seatArrayFrom(schedule.seatInventorySnapshot);
  if (scheduleInventorySnapshot.length) return { source: 'schedule_inventory_snapshot', seats: scheduleInventorySnapshot, needsRepair: true };

  const snapshotSeats = seatArrayFrom(schedule.seatMapSnapshot);
  if (snapshotSeats.length) return { source: 'schedule_seat_map_snapshot', seats: snapshotSeats, needsRepair: true };

  const vehicle = context.vehicleById.get(key(schedule.vehicleId)) || {};
  const requestedVersionId = key(
    schedule.seatMapVersionId
    || schedule.seatMapSnapshot?.versionId
    || schedule.seatMapSnapshot?.seatMapVersionId
    || schedule.seatMapSnapshot?.id
    || vehicle.activeSeatMapVersionId
  );
  const version = context.versionById.get(requestedVersionId)
    || asArray(context.seatMapVersions)
      .filter((item) => key(item.vehicleId) === key(schedule.vehicleId) && normalize(item.status) === 'published')
      .sort((a, b) => Number(b.version || 0) - Number(a.version || 0))[0]
    || null;
  const versionSeats = versionSeatRows(version);
  if (versionSeats.length) return { source: 'published_seat_map_version', seats: versionSeats, version, needsRepair: true };

  const vehicleSeats = seatArrayFrom(vehicle.seatTemplate || vehicle.seatMap || vehicle.layout);
  if (vehicleSeats.length) return { source: 'vehicle_seat_template', seats: vehicleSeats, version, needsRepair: true };

  const total = Number(
    schedule.totalSeats
    || schedule.capacity
    || schedule.seatCapacity
    || schedule.seatMapSnapshot?.totalSeats
    || schedule.seatMapSnapshot?.capacity
    || version?.totalSeats
    || version?.capacity
    || vehicle.totalSeats
    || vehicle.capacity
    || 0
  );
  if (Number.isFinite(total) && total > 0 && total <= 300) {
    return {
      source: 'capacity_fallback',
      seats: Array.from({ length: Math.floor(total) }, (_, index) => ({ seatNumber: String(index + 1), status: 'available' })),
      version,
      needsRepair: true,
    };
  }
  return { source: 'missing_inventory', seats: [], version, needsRepair: true };
}

function normalizedSeat(seat = {}, index, schedule, mapContext) {
  const scheduleId = scheduleIdOf(schedule);
  const seatNumber = seatNumberOf(seat, index);
  const booking = bookingForSeat(mapContext.bookings, scheduleId, seatNumber);
  const ticket = asArray(booking?.ticketLegs).find((leg) => scheduleRefOfLeg(leg) === scheduleId && seatNumberOf(leg) === seatNumber) || {};
  const passenger = asArray(booking?.passengers)[Number(ticket.passengerIndex || 0)]
    || asArray(booking?.passengers).find((row) => seatNumberOf({ seatNumber: row.seatNumber || row.seatOrRoom || row.seatLabel }) === seatNumber)
    || {};
  const status = booking ? 'booked' : canonicalSeatStatus(seat.status || (seat.enabled === false || seat.isDisabled ? 'disabled' : 'available'));
  return {
    id: rowId(seat) || `seat-${scheduleId}-${seatNumber}`,
    scheduleId,
    seatNumber,
    displayLabel: key(seat.displayLabel || seat.label || seatNumber),
    row: Number(seat.row || seat.rowNumber || 0),
    col: Number(seat.col || seat.column || seat.columnNumber || 0),
    deck: key(seat.deck || 'main'),
    seatClass: key(seat.seatClass || seat.seatType || 'Standard'),
    seatType: key(seat.seatType || normalize(seat.seatClass || 'standard')),
    status,
    priceDelta: Number(seat.priceDelta || 0),
    lockedUntil: seat.lockedUntil || '',
    lockId: key(seat.lockId),
    blockedReason: key(seat.blockedReason),
    bookingRef: key(booking?.bookingRef),
    passengerName: key(passenger.fullName || ticket.passengerName),
    passengerPhone: key(passenger.phone || booking?.guestSnapshot?.phone),
    passengerEmail: key(passenger.email || booking?.guestSnapshot?.email),
    ticketNumber: key(ticket.ticketNumber),
    checkInStatus: key(ticket.checkInStatus || booking?.checkInStatus),
    paymentStatus: key(booking?.paymentStatus),
  };
}

function sortSchedules(rows = []) {
  return [...rows].sort((a, b) => {
    const aTime = new Date(a.departAt || a.travelDate || a.departureAt || a.createdAt || 0).getTime();
    const bTime = new Date(b.departAt || b.travelDate || b.departureAt || b.createdAt || 0).getTime();
    const aFuture = Number.isFinite(aTime) && aTime >= Date.now();
    const bFuture = Number.isFinite(bTime) && bTime >= Date.now();
    if (aFuture !== bFuture) return aFuture ? -1 : 1;
    return aFuture ? aTime - bTime : bTime - aTime;
  });
}

function buildLiveDepartureSeatMaps(input = {}) {
  const listingById = firstById(input.listings);
  const routeById = firstById(input.routes);
  const vehicleById = firstById(input.vehicles);
  const versionById = firstById(input.seatMapVersions);
  const context = {
    ...input,
    listingById,
    routeById,
    vehicleById,
    versionById,
    seats: asArray(input.seats),
    bookings: asArray(input.bookings),
    seatMapVersions: asArray(input.seatMapVersions),
  };

  const schedules = sortSchedules(asArray(input.schedules).filter((schedule) => {
    if (!schedule || normalize(schedule.status) === 'archived') return false;
    return isBusDepartureSchedule(schedule, context);
  }));

  return schedules.map((schedule) => {
    const scheduleId = scheduleIdOf(schedule);
    const listing = listingById.get(key(schedule.listingId)) || {};
    const route = routeById.get(key(schedule.routeId)) || {};
    const vehicle = vehicleById.get(key(schedule.vehicleId)) || {};
    const source = resolveSourceSeats(schedule, context);
    const seats = source.seats.map((seat, index) => normalizedSeat(seat, index, schedule, context));
    const bookedSeats = seats.filter((seat) => seat.status === 'booked').length;
    const heldSeats = seats.filter((seat) => seat.status === 'held').length;
    const blockedSeats = seats.filter((seat) => seat.status === 'blocked').length;
    const availableSeats = seats.filter((seat) => seat.status === 'available').length;
    const totalSeats = seats.length || Number(schedule.totalSeats || schedule.capacity || source.version?.totalSeats || vehicle.totalSeats || vehicle.capacity || 0);
    const routeSnapshot = schedule.routeSnapshot || {};
    const origin = routeSnapshot.origin?.name || routeSnapshot.origin || route.origin || listing.from;
    const destination = routeSnapshot.destination?.name || routeSnapshot.destination || route.destination || listing.to;
    return {
      id: scheduleId,
      scheduleId,
      listingId: rowId(listing) || key(schedule.listingId),
      listingTitle: key(listing.title || schedule.listingTitle || schedule.listingId || 'Bus service'),
      routeId: rowId(route) || key(schedule.routeId),
      routeLabel: key(route.routeName || routeSnapshot.routeName || [origin, destination].filter(Boolean).join(' to ') || 'Route pending'),
      vehicleId: rowId(vehicle) || key(schedule.vehicleId),
      vehicleName: key(vehicle.name || schedule.vehicleName || vehicle.plateOrCode || 'Vehicle pending'),
      seatMapVersionId: rowId(source.version) || key(schedule.seatMapVersionId || schedule.seatMapSnapshot?.versionId),
      seatMapVersion: Number(source.version?.version || schedule.seatMapSnapshot?.version || 0) || '',
      departAt: schedule.departAt || schedule.travelDate || schedule.departureAt || '',
      travelDate: schedule.travelDate || schedule.departAt || schedule.departureAt || '',
      status: key(schedule.status || 'draft'),
      inventorySource: source.source,
      inventoryNeedsRepair: Boolean(source.needsRepair),
      totalSeats,
      bookedSeats,
      soldSeats: bookedSeats,
      heldSeats,
      blockedSeats,
      availableSeats,
      totals: { total: totalSeats, booked: bookedSeats, held: heldSeats, available: availableSeats, blocked: blockedSeats },
      seats,
    };
  });
}

module.exports = {
  buildLiveDepartureSeatMaps,
  isBusDepartureSchedule,
  canonicalSeatStatus,
  seatArrayFrom,
  rowId,
};
