'use strict';

function key(value) {
  return String(value == null ? '' : value).trim();
}

function rowId(row = {}) {
  const value = row && typeof row === 'object' ? row : {};
  return key(value.id || value._id);
}

function asArray(value) {
  return Array.isArray(value) ? value : [];
}

function explicitOwnerAllows(row = {}, companyId) {
  const owner = key(row.companyId);
  return !owner || owner === key(companyId);
}

function linkedTo(set, value) {
  const id = key(value);
  return Boolean(id && set.has(id));
}

function uniqueRows(rows = []) {
  const seen = new Set();
  return asArray(rows).filter((row) => {
    if (!row) return false;
    const id = rowId(row);
    if (!id) return true;
    if (seen.has(id)) return false;
    seen.add(id);
    return true;
  });
}

/**
 * Resolve company-owned transport records through canonical relationships.
 *
 * Security rule: an explicit companyId always wins. A row carrying another
 * company's id is never adopted merely because it references this company's
 * listing. Ownership inference is used only for legacy rows where companyId
 * was omitted.
 */
function buildCompanyTransportScope(state = {}, companyId, companyListings = []) {
  const companyKey = key(companyId);
  const listings = uniqueRows(companyListings).filter((row) => key(row.companyId) === companyKey);
  const listingIds = new Set(listings.map(rowId).filter(Boolean));

  const routes = uniqueRows(state.routes).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(listingIds, row.listingId)));
  const routeIds = new Set(routes.map(rowId).filter(Boolean));

  const vehicles = uniqueRows(state.vehicles).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(listingIds, row.listingId)));
  const vehicleIds = new Set(vehicles.map(rowId).filter(Boolean));

  const schedules = uniqueRows(state.schedules).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey
      || linkedTo(listingIds, row.listingId)
      || linkedTo(routeIds, row.routeId)
      || linkedTo(vehicleIds, row.vehicleId)));
  const scheduleIds = new Set(schedules.map(rowId).filter(Boolean));

  const referencedVersionIds = new Set([
    ...schedules.map((row) => key(row.seatMapVersionId || row.seatMapSnapshot?.versionId || row.seatMapSnapshot?.id)),
    ...vehicles.map((row) => key(row.activeSeatMapVersionId)),
  ].filter(Boolean));
  const referencedTemplateIds = new Set([
    ...schedules.map((row) => key(row.seatMapTemplateId || row.seatMapSnapshot?.templateId)),
    ...vehicles.map((row) => key(row.activeSeatMapTemplateId)),
  ].filter(Boolean));

  const seatMapVersions = uniqueRows(state.seatMapVersions).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey
      || linkedTo(listingIds, row.listingId)
      || linkedTo(vehicleIds, row.vehicleId)
      || linkedTo(referencedVersionIds, rowId(row))));

  const seatMapTemplates = uniqueRows(state.seatMapTemplates).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey
      || linkedTo(listingIds, row.listingId)
      || linkedTo(vehicleIds, row.vehicleId)
      || linkedTo(referencedTemplateIds, rowId(row))));

  const routeStops = uniqueRows(state.routeStops).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(routeIds, row.routeId)));
  const routeSegments = uniqueRows(state.routeSegments).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(routeIds, row.routeId)));

  const fareProducts = uniqueRows(state.fareProducts).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(routeIds, row.routeId) || linkedTo(listingIds, row.listingId)));
  const fareProductIds = new Set(fareProducts.map(rowId).filter(Boolean));
  const segmentFares = uniqueRows(state.busSegmentFares).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(fareProductIds, row.fareProductId) || linkedTo(routeIds, row.routeId)));

  const seats = uniqueRows(state.seats).filter((row) => explicitOwnerAllows(row, companyKey)
    && (key(row.companyId) === companyKey || linkedTo(scheduleIds, row.scheduleId || row.departureId || row.tripScheduleId)));

  return {
    listings,
    listingIds,
    routes,
    routeIds,
    routeStops,
    routeSegments,
    vehicles,
    vehicleIds,
    schedules,
    scheduleIds,
    seatMapTemplates,
    seatMapVersions,
    fareProducts,
    segmentFares,
    seats,
    inferredCounts: {
      routes: routes.filter((row) => !key(row.companyId)).length,
      vehicles: vehicles.filter((row) => !key(row.companyId)).length,
      schedules: schedules.filter((row) => !key(row.companyId)).length,
      seatMapTemplates: seatMapTemplates.filter((row) => !key(row.companyId)).length,
      seatMapVersions: seatMapVersions.filter((row) => !key(row.companyId)).length,
      seats: seats.filter((row) => !key(row.companyId)).length,
    },
  };
}

module.exports = {
  buildCompanyTransportScope,
  explicitOwnerAllows,
  rowId,
  key,
};
