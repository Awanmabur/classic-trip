const walletService = require('../wallet/walletService');
const ledgerService = require('../wallet/ledgerService');
const commissionService = require('./commissionService');
const financeRepository = require('../../repositories/domain/financeRepository');

async function releaseCompletedBooking(bookingRef) {
  const booking = await financeRepository.bookings.findOne({ bookingRef });
  if (!booking || !['checked_in', 'completed'].includes(booking.bookingStatus)) return null;
  if (!(await financeRepository.commissions.count({ bookingId: booking.id }))) {
    await commissionService.createCommission(booking, Boolean(booking.promoterAttribution), booking.pricing?.split);
  }
  const currency = booking.pricing?.currency || 'UGX';
  const commissions = await financeRepository.commissions.list({ bookingId: booking.id, status: 'pending' });
  for (const commission of commissions) {
    await walletService.movePendingToAvailable('company', commission.companyId, currency, commission.companyAmount, {
      transactionType: 'company_earning_released', referenceType: 'booking', referenceId: booking.id,
    });
    if (commission.promoterId && commission.promoterAmount > 0) {
      await walletService.movePendingToAvailable('promoter', commission.promoterId, currency, commission.promoterAmount, {
        transactionType: 'promoter_commission_released', referenceType: 'booking', referenceId: booking.id,
      });
    }
    await ledgerService.updateTransactions({ referenceType: 'booking', referenceId: booking.id, status: 'pending' }, { status: 'completed' });
    Object.assign(commission, { status: 'released', releasedAt: new Date().toISOString() });
    await financeRepository.commissions.save(commission, { id: commission.id });
  }
  if (commissions.length) {
    booking.earningsReleasedAt = new Date().toISOString();
    await financeRepository.bookings.save(booking, { bookingRef: booking.bookingRef });
  }
  return commissions;
}

module.exports = { releaseCompletedBooking };
