'use strict';

function normalize(value) {
  return String(value == null ? '' : value).trim().toLowerCase().replace(/[\s-]+/g, '_');
}

function entityId(row = {}) {
  const value = row.id ?? row._id ?? row.uuid ?? '';
  return String(value == null ? '' : value).trim();
}

function sameId(left, right) {
  const a = typeof left === 'object' && left ? entityId(left) : String(left == null ? '' : left).trim();
  const b = typeof right === 'object' && right ? entityId(right) : String(right == null ? '' : right).trim();
  return Boolean(a && b && a === b);
}

const SERVICE_ALIASES = Object.freeze({
  bus: 'bus', buses: 'bus', coach: 'bus', coaches: 'bus', bus_company: 'bus', bus_service: 'bus',
  road_transport: 'bus', passenger_bus: 'bus', public_bus: 'bus',
  hotel: 'hotel', hotels: 'hotel', accommodation: 'hotel', stay: 'hotel', stays: 'hotel', property: 'hotel',
  flight: 'flight', flights: 'flight', airline: 'flight', air: 'flight',
  train: 'train', trains: 'train', rail: 'train', railway: 'train',
  ferry: 'ferry', ferries: 'ferry', boat: 'ferry',
  car_rental: 'car_rental', rental_car: 'car_rental', car: 'car_rental',
  tour: 'tour', tours: 'tour', event: 'event', events: 'event', cargo: 'cargo',
  insurance: 'insurance', airport_transfer: 'airport_transfer', visa: 'visa', package: 'package',
});

function containsBusMarker(value) {
  return /(^|[^a-z])(bus|coach|shuttle)([^a-z]|$)/i.test(String(value || ''));
}

function canonicalServiceType(listing = {}, context = {}) {
  const candidates = [
    listing.serviceType,
    listing.catalogType,
    listing.categoryKey,
    listing.type,
    listing.listingType,
  ].map(normalize).filter(Boolean);

  for (const candidate of candidates) {
    if (SERVICE_ALIASES[candidate]) return SERVICE_ALIASES[candidate];
  }

  const rawGroup = normalize(listing.group);
  if (SERVICE_ALIASES[rawGroup] && rawGroup !== 'transport') return SERVICE_ALIASES[rawGroup];

  const listingKey = entityId(listing);
  const relatedVehicles = Array.isArray(context.vehicles)
    ? context.vehicles.filter((row) => ownerCompatible(listing, row) && sameId(row.listingId, listingKey))
    : [];
  const relatedSchedules = relatedSchedulesForListing(listing, context);

  const relatedBus = relatedVehicles.some((row) => ['bus', 'coach', 'bus_company'].includes(normalize(row.serviceType || row.transportType || row.type)))
    || relatedSchedules.some((row) => ['bus', 'coach', 'bus_company'].includes(normalize(row.serviceType || row.transportType || row.type)));

  if (relatedBus || containsBusMarker(listing.type) || containsBusMarker(listing.title) || containsBusMarker(listing.listingKind)) return 'bus';
  if (rawGroup === 'transport') return 'more';
  return SERVICE_ALIASES[rawGroup] || candidates[0] || 'more';
}


function ownerCompatible(listing = {}, row = {}) {
  return !listing.companyId || !row.companyId || sameId(listing.companyId, row.companyId);
}

function relatedSchedulesForListing(listing = {}, context = {}) {
  const listingKey = entityId(listing);
  if (!listingKey || !Array.isArray(context.schedules)) return [];

  const routeIds = new Set((Array.isArray(context.routes) ? context.routes : [])
    .filter((row) => ownerCompatible(listing, row) && sameId(row.listingId, listingKey))
    .map((row) => entityId(row))
    .filter(Boolean));
  const vehicleIds = new Set((Array.isArray(context.vehicles) ? context.vehicles : [])
    .filter((row) => ownerCompatible(listing, row) && sameId(row.listingId, listingKey))
    .map((row) => entityId(row))
    .filter(Boolean));

  return context.schedules.filter((row) => {
    if (!ownerCompatible(listing, row)) return false;
    if (row.listingId) return sameId(row.listingId, listingKey);
    const routeMatch = row.routeId && routeIds.has(String(row.routeId));
    const vehicleMatch = row.vehicleId && vehicleIds.has(String(row.vehicleId));
    return Boolean(routeMatch || vehicleMatch);
  });
}

const HIDDEN_STATES = new Set(['archived', 'deleted', 'removed', 'rejected', 'suspended', 'blocked']);
const PUBLIC_STATES = new Set(['active', 'published', 'live', 'public', 'approved', 'verified']);
const DEPARTURE_PUBLIC_STATES = new Set(['published', 'boarding', 'delayed', 'departed', 'arrived']);

function publicationState(listing = {}) {
  return [
    listing.releaseStatus,
    listing.publicationStatus,
    listing.publication?.status,
    listing.publication?.releaseStatus,
    listing.status,
  ].map(normalize).filter(Boolean);
}

function hasPublishedDeparture(listing = {}, context = {}) {
  return relatedSchedulesForListing(listing, context)
    .some((row) => DEPARTURE_PUBLIC_STATES.has(normalize(row.status)));
}

function isPublicListing(listing, context = {}) {
  if (!listing) return false;
  const states = publicationState(listing);
  if (states.some((state) => HIDDEN_STATES.has(state))) return false;

  const explicitReleaseStates = [
    listing.releaseStatus,
    listing.publicationStatus,
    listing.publication?.status,
    listing.publication?.releaseStatus,
  ].map(normalize).filter(Boolean);
  if (explicitReleaseStates.some((state) => PUBLIC_STATES.has(state))) return true;
  if (listing.publishedAt || listing.publication?.publishedAt) return true;

  const publishedBusDeparture = canonicalServiceType(listing, context) === 'bus' && hasPublishedDeparture(listing, context);
  if (publishedBusDeparture) return true;

  // An explicit draft/review release state takes precedence over a generic operational
  // status such as `active`. Legacy listings without release metadata may still use
  // the operational status as their public-state source.
  if (explicitReleaseStates.length) return false;
  return [listing.status].map(normalize).some((state) => PUBLIC_STATES.has(state));
}

module.exports = {
  normalize,
  entityId,
  sameId,
  canonicalServiceType,
  publicationState,
  hasPublishedDeparture,
  relatedSchedulesForListing,
  isPublicListing,
};
