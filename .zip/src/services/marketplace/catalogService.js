const commerceRepository = require('../../repositories/domain/commerceRepository');
const contentRepository = require('../../repositories/domain/contentRepository');
const promoterRepository = require('../../repositories/domain/promoterRepository');
const { publicCatalogGroup } = require('./catalogGrouping');
const { entityId, sameId, canonicalServiceType, relatedSchedulesForListing, isPublicListing: publicListingVisible } = require('./catalogVisibility');

const SERVICE_LABELS = {
  bus: 'Bus', hotel: 'Hotel', flight: 'Flight', train: 'Train', ferry: 'Ferry',
  car_rental: 'Car rental', tour: 'Tour', event: 'Event', cargo: 'Cargo', insurance: 'Insurance',
};
const TYPE_ORDER = ['bus', 'hotel', 'flight', 'train', 'ferry', 'car_rental', 'tour', 'event', 'cargo', 'insurance'];

function normalize(value) { return String(value || '').trim().toLowerCase().replace(/[\s-]+/g, '_'); }
function text(value) { return String(value || '').trim(); }
function number(value) { const parsed = Number(value); return Number.isFinite(parsed) ? parsed : 0; }
function unique(values) { return [...new Set(values.filter(Boolean))]; }
function asDate(value) { const date = value ? new Date(value) : null; return date && !Number.isNaN(date.getTime()) ? date : null; }
function active(row) { return !row?.status || ['active', 'published', 'verified', 'approved', 'boarding', 'delayed', 'departed', 'arrived'].includes(normalize(row.status)); }
function isPublicListing(row, data = {}) { return publicListingVisible(row, data && typeof data === 'object' && !Array.isArray(data) ? data : {}); }

async function snapshot() {
  const [categories, listings, companies, routes, schedules, seats, vehicles, roomTypes, roomUnits, roomNights, bookings, links, campaigns, blogs, wallets, users] = await Promise.all([
    commerceRepository.categories.list({}, { sort: { order: 1, name: 1 }, limit: 500 }),
    commerceRepository.listings.list({}, { sort: { createdAt: -1 }, limit: 5000 }),
    commerceRepository.companies.list({}, { sort: { name: 1 }, limit: 2000 }),
    commerceRepository.routes.list({}, { sort: { createdAt: -1 }, limit: 5000 }),
    commerceRepository.schedules.list({}, { sort: { departAt: 1 }, limit: 10000 }),
    commerceRepository.seats.list({}, { limit: 50000 }),
    commerceRepository.vehicles.list({}, { limit: 10000 }),
    commerceRepository.roomTypes.list({}, { limit: 10000 }),
    commerceRepository.roomUnits.list({}, { limit: 20000 }),
    commerceRepository.roomNights.list({}, { limit: 50000 }),
    commerceRepository.bookings.list({}, { sort: { createdAt: -1 }, limit: 5000 }),
    promoterRepository.links.list({ status: { $ne: 'archived' } }, { sort: { createdAt: -1 }, limit: 5000 }),
    contentRepository.promotionCampaigns.list({}, { sort: { createdAt: -1 }, limit: 5000 }),
    contentRepository.blogs.list({}, { sort: { publishedAt: -1, createdAt: -1 }, limit: 500 }),
    commerceRepository.wallets.list({}, { limit: 5000 }),
    commerceRepository.users.list({}, { limit: 5000 }),
  ]);
  return { categories, listings, companies, routes, schedules, seats, vehicles, roomTypes, roomUnits, roomNights, bookings, links, campaigns, blogs, wallets, users };
}

function companyFor(data, identifier) {
  const key = normalize(identifier);
  return data.companies.find((row) => [entityId(row), row.slug, row.name].some((value) => normalize(value) === key)) || null;
}

function listingFor(data, identifier, serviceType = '') {
  const key = normalize(identifier);
  const type = normalize(serviceType);
  return data.listings.find((row) => (!type || canonicalServiceType(row, data) === type)
    && [entityId(row), row.slug, row.title].some((value) => normalize(value) === key)) || null;
}

function listingSchedules(data, listingId) {
  const listing = data.listings.find((row) => sameId(row, listingId)) || { id: listingId };
  return relatedSchedulesForListing(listing, data);
}
function listingRoutes(data, listingId) { return data.routes.filter((row) => sameId(row.listingId, listingId)); }
function scheduleSeats(data, scheduleId) { return data.seats.filter((row) => sameId(row.scheduleId, scheduleId)); }
function listingRooms(data, listingId) {
  const types = data.roomTypes.filter((row) => sameId(row.listingId, listingId) && active(row));
  return types.map((roomType) => {
    const roomTypeId = entityId(roomType);
    const units = data.roomUnits.filter((unit) => sameId(unit.roomTypeId, roomTypeId) && !['archived', 'maintenance'].includes(normalize(unit.status)));
    const unitIds = new Set(units.map((unit) => entityId(unit)));
    const nights = data.roomNights.filter((night) => unitIds.has(String(night.roomUnitId || '')));
    const availableNights = nights.filter((night) => ['available', 'open', 'reserved'].includes(normalize(night.status)) && !night.bookingRef && number(night.availableInventory ?? 1) > 0).length;
    return {
      ...roomType,
      roomTypeId,
      roomType: roomType.name || roomType.title,
      inventory: units.length,
      availableUnits: units.length,
      availableNights,
      nightlyPrice: number(roomType.basePrice),
      price: number(roomType.basePrice),
    };
  });
}

function liveCampaignFor(data, listingId, now = new Date()) {
  return data.campaigns.find((campaign) => sameId(campaign.listingId, listingId) && normalize(campaign.status) === 'active'
    && (!campaign.startsAt || new Date(campaign.startsAt) <= now)
    && (!campaign.endsAt || new Date(campaign.endsAt) >= now));
}

function catalogItem(data, listing) {
  const stableId = entityId(listing);
  const company = companyFor(data, listing.companyId || listing.companySlug);
  const schedules = listingSchedules(data, stableId).filter((row) => active(row));
  const nextSchedule = schedules.filter((row) => !asDate(row.departAt) || asDate(row.departAt) >= new Date()).sort((a, b) => (asDate(a.departAt)?.getTime() || 0) - (asDate(b.departAt)?.getTime() || 0))[0] || schedules[0];
  const seats = nextSchedule ? scheduleSeats(data, entityId(nextSchedule)) : [];
  const rooms = listingRooms(data, stableId);
  const availableSeats = seats.filter((row) => normalize(row.status) === 'available').length;
  const roomInventory = rooms.reduce((sum, row) => sum + Math.max(0, number(row.inventory || row.availableUnits || row.available)), 0);
  const serviceType = canonicalServiceType(listing, data);
  const remainingInventory = serviceType === 'bus'
    ? (seats.length ? availableSeats : number(nextSchedule?.availableSeats || listing.availableSeats || listing.inventory))
    : serviceType === 'hotel'
      ? (roomInventory || number(listing.availableRooms || listing.inventory))
      : number(listing.remainingInventory || listing.inventory || listing.availability);
  const route = listingRoutes(data, stableId)[0] || {};
  const from = listing.from || route.origin || route.from || listing.city || '';
  const to = listing.to || route.destination || route.to || listing.location || '';
  const priceFrom = number(listing.priceFrom || listing.price || nextSchedule?.price || rooms[0]?.price);
  const bookable = listing.bookable !== false && active(listing) && (remainingInventory > 0 || !['bus', 'hotel'].includes(serviceType));
  const policy = text(listing.policy || listing.cancellationPolicy || listing.refundPolicy);
  const enriched = {
    ...listing,
    id: stableId,
    serviceType,
    type: listing.type || serviceType,
    internalGroup: listing.group || '',
    group: publicCatalogGroup(serviceType, listing.group),
    typeLabel: SERVICE_LABELS[serviceType] || serviceType,
    companyName: company?.name || listing.companyName || listing.partner || '',
    companySlug: company?.slug || listing.companySlug || entityId(company || {}),
    partner: listing.partner || company?.name || '',
    isVerified: listing.isVerified !== false && ['verified', 'approved', 'active'].includes(normalize(company?.verificationStatus || company?.status || 'verified')),
    isSponsored: Boolean(liveCampaignFor(data, stableId)),
    from, to,
    city: listing.city || from || to,
    country: listing.country || company?.country || '',
    corridor: listing.corridor || route.corridor || normalize(`${from}-${to}`),
    routeLabel: listing.routeLabel || [from, to].filter(Boolean).join(' → ') || listing.title,
    nextDepartAt: nextSchedule?.departAt || listing.nextDepartAt || null,
    scheduleId: entityId(nextSchedule || {}),
    remainingInventory,
    availableSeats,
    priceFrom,
    price: priceFrom,
    currency: String(listing.currency || nextSchedule?.currency || rooms[0]?.currency || 'UGX').toUpperCase(),
    ratingAverage: number(listing.ratingAverage || listing.rating || 4.5),
    rating: String(listing.ratingAverage || listing.rating || 4.5),
    reviewCount: number(listing.reviewCount || listing.reviewsCount),
    img: listing.img || listing.image || listing.coverImage || listing.media?.[0]?.url || '',
    bookable,
    instantConfirmation: listing.instantConfirmation !== false && bookable,
    refundable: /refund|cancellation/.test(normalize(policy)),
    slug: listing.slug || stableId,
    url: `/listings/${serviceType}/${listing.slug || stableId}`,
    bookingUrl: bookable ? `/book/${serviceType}/${listing.slug || stableId}` : '',
    companyUrl: `/companies/${company?.slug || entityId(company || {})}`,
    searchText: normalize([listing.title, listing.description, from, to, listing.city, listing.country, company?.name, serviceType].join(' ')),
  };
  return enriched;
}

function score(item) {
  return (item.isSponsored ? 15 : 0) + (item.isVerified ? 10 : 0) + (item.bookable ? 8 : 0)
    + number(item.ratingAverage) * 10 + Math.min(number(item.reviewCount), 500) / 20
    + Math.min(number(item.remainingInventory), 60) / 6;
}

function applySearch(items, query = {}) {
  const q = normalize(query.q || query.search);
  const serviceType = normalize(query.serviceType || query.type || '');
  const city = normalize(query.city);
  const country = normalize(query.country);
  const origin = normalize(query.origin || query.from);
  const destination = normalize(query.destination || query.to);
  const partner = normalize(query.partner || query.company);
  const min = number(query.minPrice || query.min);
  const max = number(query.maxPrice || query.max);
  const minRating = number(query.minRating || query.rating);
  let rows = items.filter((item) => {
    if (q && !item.searchText.includes(q)) return false;
    if (serviceType && serviceType !== 'all' && normalize(item.serviceType) !== serviceType && normalize(item.group) !== serviceType) return false;
    if (city && !normalize(`${item.city} ${item.from} ${item.to}`).includes(city)) return false;
    if (country && !normalize(item.country).includes(country)) return false;
    if (origin && !normalize(item.from).includes(origin)) return false;
    if (destination && !normalize(item.to).includes(destination)) return false;
    if (partner && !normalize(`${item.partner} ${item.companyName}`).includes(partner)) return false;
    if (min && item.priceFrom < min) return false;
    if (max && item.priceFrom > max) return false;
    if (minRating && item.ratingAverage < minRating) return false;
    if ((query.verified === 'true' || query.verified === true) && !item.isVerified) return false;
    if ((query.bookable === 'true' || query.bookable === true) && !item.bookable) return false;
    if ((query.sponsored === 'true' || query.sponsored === true) && !item.isSponsored) return false;
    if ((query.available === 'true' || query.availableOnly === 'true' || query.availableOnly === true) && item.remainingInventory <= 0) return false;
    return true;
  });
  const sort = normalize(query.sort || 'recommended');
  rows = rows.sort((a, b) => {
    if (sort === 'cheapest') return a.priceFrom - b.priceFrom;
    if (sort === 'top_rated') return b.ratingAverage - a.ratingAverage;
    if (sort === 'availability') return b.remainingInventory - a.remainingInventory;
    if (sort === 'soonest') return (asDate(a.nextDepartAt)?.getTime() || Number.MAX_SAFE_INTEGER) - (asDate(b.nextDepartAt)?.getTime() || Number.MAX_SAFE_INTEGER);
    return score(b) - score(a);
  });
  return rows;
}

function routeHighlights(items) {
  const groups = new Map();
  for (const item of items) {
    const key = item.corridor || item.routeLabel || item.id;
    const row = groups.get(key) || { key, corridor: key, type: item.serviceType, label: item.routeLabel, count: 0, remainingSeats: 0, minPrice: null, currency: item.currency, nextDeparture: '' };
    row.count += 1;
    row.remainingSeats += number(item.remainingInventory);
    row.minPrice = row.minPrice == null ? item.priceFrom : Math.min(row.minPrice, item.priceFrom);
    const next = asDate(item.nextDepartAt);
    if (next && (!row.nextDeparture || next < new Date(row.nextDeparture))) row.nextDeparture = next.toISOString();
    groups.set(key, row);
  }
  return [...groups.values()].sort((a, b) => b.count - a.count || b.remainingSeats - a.remainingSeats).slice(0, 12);
}

function marketplaceInfo(items) {
  const stats = {
    liveListings: items.length,
    availableNow: items.reduce((sum, item) => sum + number(item.remainingInventory), 0),
    countries: unique(items.map((item) => item.country)).length,
    types: unique(items.map((item) => item.serviceType)).length,
    partners: unique(items.map((item) => item.partner || item.companyName)).length,
    departuresNext24h: items.filter((item) => { const d = asDate(item.nextDepartAt); const diff = d ? d - new Date() : -1; return diff >= 0 && diff <= 86400000; }).length,
  };
  const typeStats = TYPE_ORDER.map((type) => {
    const rows = items.filter((item) => item.serviceType === type);
    return { type, label: SERVICE_LABELS[type] || type, count: rows.length, partners: unique(rows.map((item) => item.partner)).length, remainingSeats: rows.reduce((sum, item) => sum + number(item.remainingInventory), 0) };
  });
  return {
    generatedAt: new Date().toISOString(), stats, typeStats, routeHighlights: routeHighlights(items),
    hero: { badges: [{ icon: 'fa-solid fa-shield-halved', label: 'Secure checkout' }, { icon: 'fa-solid fa-headset', label: 'Booking support ready' }], stats: [{ value: String(stats.liveListings), label: 'Live listings' }, { value: String(stats.availableNow), label: 'Seats / rooms open' }, { value: String(stats.countries), label: 'Countries covered' }, { value: String(stats.types), label: 'Active categories' }] },
    guides: items.slice().sort((a, b) => score(b) - score(a)).slice(0, 4).map((item) => ({ id: `guide-${item.id}`, listingId: item.id, title: `${item.routeLabel}: what to know before you book`, tag: item.serviceType === 'hotel' ? 'Stay guide' : 'Route guide', image: item.img, excerpt: item.description || item.policy || `${item.partner}`, location: item.routeLabel, partner: item.partner, price: { amount: item.priceFrom, currency: item.currency }, url: item.url })),
    featured: Object.fromEntries(TYPE_ORDER.map((type) => [type, items.filter((item) => item.serviceType === type).slice(0, 12)])),
  };
}

function publicCompany(data, company) {
  const companyId = entityId(company);
  const listings = data.listings.filter((row) => sameId(row.companyId, companyId) && isPublicListing(row, data));
  const campaigns = data.campaigns.filter((row) => sameId(row.companyId, companyId));
  return { ...company, listingsCount: listings.length, activeListingsCount: listings.length, bookableListingsCount: listings.filter((row) => row.bookable !== false).length, sponsoredListingsCount: listings.filter((row) => liveCampaignFor(data, entityId(row))).length, campaignCount: campaigns.length };
}

function publicRoute(data, route) {
  const listing = listingFor(data, route.listingId);
  const schedules = listing ? listingSchedules(data, entityId(listing)) : [];
  const nextSchedule = schedules.find(active) || schedules[0];
  const item = listing ? catalogItem(data, listing) : null;
  return { ...route, id: entityId(route), listing: item, scheduleCount: schedules.length, availableSeats: schedules.reduce((sum, row) => sum + number(row.availableSeats), 0), nextDepartAt: nextSchedule?.departAt || null, bookingUrl: item?.bookingUrl || '', listingUrl: item?.url || '' };
}

function availability(data, listing) {
  if (!listing) return null;
  const listingId = entityId(listing);
  const serviceType = canonicalServiceType(listing, data);
  const schedules = listingSchedules(data, listingId).filter(active).sort((a, b) => (asDate(a.departAt)?.getTime() || 0) - (asDate(b.departAt)?.getTime() || 0));
  const selected = schedules[0];
  if (serviceType === 'bus') return { listing, schedules, scheduleId: entityId(selected), seats: selected ? scheduleSeats(data, entityId(selected)) : [] };
  if (serviceType === 'hotel') return { listing, rooms: listingRooms(data, listingId) };
  return { listing, message: 'Provider integration planned; read-only listing for now.' };
}

function listingPreview(data, listing, currentAvailability, company) {
  const current = currentAvailability || availability(data, listing) || {};
  const rooms = current.rooms || [];
  const seats = current.seats || [];
  const subtotal = number(listing.priceFrom || listing.price);
  const serviceFee = Math.round(subtotal * 0.045 + 3500);
  return {
    currency: listing.currency || 'UGX', subtotal, serviceFee, totalEstimate: subtotal + serviceFee,
    serviceIcon: ({ hotel: 'fa-hotel', bus: 'fa-bus', flight: 'fa-plane', train: 'fa-train', ferry: 'fa-ship', car_rental: 'fa-car' })[listing.serviceType] || 'fa-ticket',
    previewSeats: seats.slice(0, 32), previewRooms: rooms.slice(0, 12),
    firstSeat: seats.find((row) => normalize(row.status) === 'available')?.seatNumber || seats[0]?.seatNumber || '',
    firstRoom: entityId(rooms.find((row) => number(row.inventory) > 0) || rooms[0] || {}),
    selectedPreview: listing.serviceType === 'hotel' ? (rooms[0]?.roomType || rooms[0]?.name || 'Room pending') : (seats[0]?.seatNumber || 'Slot S1'),
    addons: [], partnerName: listing.partner || company?.name || 'Classic Trip partner', supportPhone: company?.supportPhone || company?.phone || '+256 700 000 000',
    scheduleLabel: current.schedules?.[0]?.departureTime || listing.time || 'Flexible schedule', ticketAccess: 'Email, SMS, WhatsApp', policy: listing.bookable ? 'Instant checkout' : 'Provider teaser', paymentMethods: ['Mobile Money', 'Card', 'Wallet', 'Pay at office'],
  };
}

async function search(query = {}) {
  const data = await snapshot();
  const items = data.listings.filter((row) => isPublicListing(row, data)).map((row) => catalogItem(data, row));
  return { data, results: applySearch(items, query) };
}

async function searchWithMeta(query = {}) {
  const { data, results } = await search(query);
  const marketplace = marketplaceInfo(results);
  return { data, results, meta: { total: results.length, marketplace, typeStats: marketplace.typeStats, routeHighlights: marketplace.routeHighlights, query } };
}

async function homeBootstrap() {
  const data = await snapshot();
  const listings = data.listings.filter((row) => isPublicListing(row, data)).map((row) => catalogItem(data, row));
  const marketplace = marketplaceInfo(listings);
  const campaigns = data.campaigns.map((campaign) => ({ ...campaign, listing: listings.find((row) => sameId(row.id, campaign.listingId)), company: companyFor(data, campaign.companyId) }));
  const links = data.links.slice(0, 12).map((link) => ({ ...link, listing: listings.find((row) => sameId(row.id, link.listingId)), shareUrl: link.url, conversionRate: number(link.clicks) ? Math.round(number(link.conversions) / number(link.clicks) * 1000) / 10 : 0 }));
  return {
    generatedAt: new Date().toISOString(), listings, categories: data.categories, companies: data.companies.map((row) => publicCompany(data, row)), routes: data.routes.filter((row) => active(row) && listings.some((listing) => sameId(listing.id, row.listingId))).map((row) => publicRoute(data, row)),
    bookings: data.bookings.slice(0, 8).map((booking) => ({ code: booking.bookingRef, title: listings.find((row) => sameId(row.id, booking.listingId))?.title || booking.serviceType, type: booking.serviceType, selected: booking.passengers?.[0]?.seatOrRoom || 'Selected inventory', total: `${booking.pricing?.currency || 'UGX'} ${Math.round(number(booking.pricing?.total)).toLocaleString()}`, customer: booking.guestSnapshot?.fullName || 'Guest customer', status: booking.bookingStatus, ticketUrl: `/tickets/${booking.bookingRef}` })),
    promoterLinks: links, campaigns,
    blogs: data.blogs.filter((row) => normalize(row.status) === 'published').slice(0, 4).map((row) => ({ ...row, url: `/blogs/${row.slug}` })),
    serviceStats: data.categories.map((category) => { const rows = listings.filter((item) => item.serviceType === category.key); return { ...category, count: rows.length, available: rows.reduce((sum, row) => sum + row.remainingInventory, 0) }; }),
    corridorStats: routeHighlights(listings), marketplace,
    heroStats: { liveRoutes: marketplace.routeHighlights.length || data.routes.length, verifiedPartners: marketplace.stats.partners, bookableInventory: listings.filter((row) => row.bookable).length, totalServices: marketplace.stats.liveListings, availableNow: marketplace.stats.availableNow, departuresNext24h: marketplace.stats.departuresNext24h },
  };
}

async function recordReferralClick(code, listingId, request = {}) {
  const key = normalize(code);
  const link = await promoterRepository.links.findOne({ status: { $ne: 'archived' }, $or: [{ code }, { code: key }] });
  const click = { id: `ref-click-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, linkId: link?.id || null, promoterId: link?.promoterId || null, listingId: listingId || link?.listingId || null, code: text(code), ip: request.ip || '', userAgent: request.headers?.['user-agent'] || '', createdAt: new Date().toISOString() };
  await promoterRepository.clicks.save(click, { id: click.id });
  if (link) { link.clicks = number(link.clicks) + 1; link.updatedAt = new Date().toISOString(); await promoterRepository.links.save(link, { id: link.id }); }
  return click;
}

module.exports = { snapshot, companyFor, listingFor, isPublicListing, catalogItem, publicCompany, publicRoute, availability, listingPreview, marketplaceInfo, routeHighlights, applySearch, search, searchWithMeta, homeBootstrap, recordReferralClick, entityId, sameId, canonicalServiceType, relatedSchedulesForListing };
