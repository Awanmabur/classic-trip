const { buildSeedData } = require('../seeds/seedAll');

const BASE_KEYS = [
  'categories','users','companies','listings','partnerLeads','discoverySessions','agreements','invitations','verificationReviews',
  'routes','routeSegments','seatMapTemplates','seatMapVersions','fareProducts','busSegmentFares','vehicles','schedules','seats','busSeatSegmentInventories','hotelProperties','roomTypes','roomUnits','roomNightInventories','stayRules',
  'companyEmployees','companyBranches','companyPolicies','driverAssignments','driverIncidents','tripStatusUpdates','routeStops',
  'carts','cartCheckoutAttempts','bookingGroups','bookings','bookingItems','busReservations','busSeatAssignments','busTickets','passengers','payments','correspondenceMessages','bookingTimelineEvents',
  'notificationDeliveryAttempts','pushSubscriptions','rescheduleRequests','wallets','walletTransactions','paymentIntents',
  'paymentWebhookEvents','receiptInvoices','taxFeeRecords','financeStatements','financeRiskReviews','settlementBatches','payoutRequests',
  'payoutBatches','reconciliationReports','promoterLinks','referralClicks','attributionSessions','campaignConversions','agentProfiles',
  'offlineSales','fraudSignals','commissions','blogs','reviews','notifications','supportTickets','refundRequests','promotionCampaigns',
  'auditLogs','securityEvents','loginAudits','deviceSessions','idempotencyKeyRecords','savedListings','shiftHandovers','subscriptionOrders',
  'subscriptions','inventoryHolds','inventoryHoldItems','outboxEvents','ticketScans','futureServiceModules','scheduleRules','flightOffers',
  'trainInventories','tourPackageInventories','carRentalUnits','eventTicketInventories','cargoShipments','insurancePolicyRecords',
  'corporateTravelAccounts','loyaltyAccounts','notificationTemplates'
];

const ALIASES = {
  serviceCategories: 'categories',
  tripSchedules: 'schedules',
  holds: 'inventoryHolds',
  campaigns: 'promotionCampaigns',
  refunds: 'refundRequests',
  blogPosts: 'blogs',
  walletLedgerEntries: 'walletTransactions',
};

const state = Object.create(null);

function clone(value) {
  if (typeof structuredClone === 'function') return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function empty() {
  for (const key of BASE_KEYS) state[key] = [];
  state.platformSettings = {};
  for (const [alias, target] of Object.entries(ALIASES)) state[alias] = state[target];
  return state;
}

function loadSeed({ force = false } = {}) {
  if (!force && Array.isArray(state.users) && state.users.length) return { loaded: false, reason: 'already_loaded' };
  const data = buildSeedData();
  empty();
  for (const key of BASE_KEYS) {
    if (Array.isArray(data[key])) state[key] = clone(data[key]);
  }
  if (data.platformSettings) {
    const raw = Array.isArray(data.platformSettings) ? data.platformSettings[0] : data.platformSettings;
    state.platformSettings = clone(raw || {});
  }
  if (Array.isArray(data.notificationTemplates)) state.notificationTemplates = clone(data.notificationTemplates);
  for (const [alias, target] of Object.entries(ALIASES)) state[alias] = state[target];
  return {
    loaded: true,
    records: Object.values(data).reduce((sum, value) => sum + (Array.isArray(value) ? value.length : 0), 0),
  };
}

function reset({ seed = process.env.NODE_ENV === 'test' } = {}) {
  empty();
  return seed ? loadSeed({ force: true }) : { loaded: false, reason: 'empty' };
}

function collection(entity) {
  const key = ALIASES[entity] || entity;
  if (!Array.isArray(state[key])) state[key] = [];
  if (ALIASES[entity]) state[entity] = state[key];
  return state[key];
}

function replace(entity, rows = []) {
  const key = ALIASES[entity] || entity;
  state[key] = rows;
  for (const [alias, target] of Object.entries(ALIASES)) if (target === key) state[alias] = state[key];
  return state[key];
}

empty();
if (process.env.NODE_ENV === 'test') loadSeed({ force: true });

function projection() {
  if (process.env.NODE_ENV !== 'test') throw new Error('The memory database projection is test-only');
  const { createDashboardProjection } = require('../services/dashboard/dashboardProjectionEngine');
  return createDashboardProjection(state);
}

function findCompany(idOrSlug) { return projection().findCompany(idOrSlug); }
function findListing(idOrSlug, serviceType) { return projection().findListing(idOrSlug, serviceType); }
function findBooking(ref) { return projection().findBooking(ref); }
function schedulesForListing(listingId) { return projection().schedulesForListing(listingId); }
function seatsForSchedule(scheduleId) { return projection().seatsForSchedule(scheduleId); }
function roomsForListing(listingId) { return projection().roomsForListing(listingId); }
function getAvailability(listingId, scheduleId) { return projection().getAvailability(listingId, scheduleId); }
function buildListingCatalog() { return projection().buildListingCatalog(); }
function searchListings(query = {}) { return projection().searchListings(query); }
function marketplaceInfo(rows = []) { return projection().marketplaceInfo(rows); }
function dashboardData(role = 'admin', context = {}) { return projection().dashboardData(role, context); }
function findUserByIdentity(identity) { return projection().findUserByIdentity(identity); }
function upsertUser(user = {}) {
  if (process.env.NODE_ENV !== 'test') throw new Error('The memory database is test-only');
  const existing = state.users.find((row) => row.id === user.id || (user.email && row.email === user.email) || (user.phone && row.phone === user.phone));
  if (existing) { Object.assign(existing, user); return existing; }
  state.users.push(user); return user;
}
async function createBooking(payload = {}, req = null) {
  const bookingService = require('../services/booking/bookingService');
  return bookingService.createGuestBooking(payload, req);
}
async function settleBookingPayment(ref, options = {}) {
  return require('../services/booking/paymentSettlementService').settleBookingPayment(ref, options);
}
async function recordReferralClick(code, listingId, req = {}) {
  return require('../services/marketplace/catalogService').recordReferralClick(code, listingId, req);
}
async function markNoShow(value, employeeId, companyId, note, context = {}) {
  return require('../services/booking/bookingService').markNoShow(value, employeeId, companyId, note, context);
}

module.exports = {
  state,
  collection,
  replace,
  reset,
  loadSeed,
  invalidateReadModelCaches() {},
  BASE_KEYS: [...BASE_KEYS],
  ALIASES: { ...ALIASES },
  findCompany, findListing, findBooking, schedulesForListing, seatsForSchedule, roomsForListing, getAvailability,
  buildListingCatalog, searchListings, marketplaceInfo, dashboardData, findUserByIdentity, upsertUser,
  createBooking, settleBookingPayment, recordReferralClick, markNoShow,
};
