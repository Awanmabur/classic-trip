const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = {
  withTransaction,
  tickets: new HybridCollection('supportTickets'),
  refunds: new HybridCollection('refundRequests'),
  reviews: new HybridCollection('reviews'),
  timelineEvents: new HybridCollection('bookingTimelineEvents'),
  rescheduleRequests: new HybridCollection('rescheduleRequests'),
  messages: new HybridCollection('correspondenceMessages'),
  deliveryAttempts: new HybridCollection('notificationDeliveryAttempts'),
  notifications: new HybridCollection('notifications'),
  auditLogs: new HybridCollection('auditLogs'),
  agreements: new HybridCollection('agreements'),
  verificationReviews: new HybridCollection('verificationReviews'),
  companyEmployees: new HybridCollection('companyEmployees'),
  users: new HybridCollection('users'),
  bookings: new HybridCollection('bookings'),
  payments: new HybridCollection('payments'),
  listings: new HybridCollection('listings'),
  schedules: new HybridCollection('schedules'),
  commissions: new HybridCollection('commissions'),
  seats: new HybridCollection('seats'),
  roomNights: new HybridCollection('roomNightInventories'),
};
