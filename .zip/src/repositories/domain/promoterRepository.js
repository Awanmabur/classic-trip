const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const repository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  profiles: new HybridCollection('agentProfiles'),
  links: new HybridCollection('promoterLinks'),
  clicks: new HybridCollection('referralClicks'),
  attributionSessions: new HybridCollection('attributionSessions'),
  conversions: new HybridCollection('campaignConversions'),
  fraudSignals: new HybridCollection('fraudSignals'),
  offlineSales: new HybridCollection('offlineSales'),
  bookings: new HybridCollection('bookings'),
  listings: new HybridCollection('listings'),
  schedules: new HybridCollection('schedules'),
  seats: new HybridCollection('seats'),
  payments: new HybridCollection('payments'),
  wallets: new HybridCollection('wallets'),
  transactions: new HybridCollection('walletTransactions'),
  commissions: new HybridCollection('commissions'),
  campaigns: new HybridCollection('promotionCampaigns'),
  auditLogs: new HybridCollection('auditLogs'),

};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = { ...repository, withTransaction };
