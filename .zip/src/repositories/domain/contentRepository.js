const { HybridCollection } = require('./hybridCollection');

module.exports = {
  blogs: new HybridCollection('blogPosts'),
  listings: new HybridCollection('listings'),
  categories: new HybridCollection('categories'),
  companies: new HybridCollection('companies'),
  reviews: new HybridCollection('reviews'),
  promotionCampaigns: new HybridCollection('promotionCampaigns'),
  platformSettings: new HybridCollection('platformSettings'),
  futureServiceModules: new HybridCollection('futureServiceModules'),
  auditLogs: new HybridCollection('auditLogs'),
};
