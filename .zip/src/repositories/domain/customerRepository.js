const { HybridCollection } = require('./hybridCollection');

module.exports = {
  users: new HybridCollection('users'),
  verificationReviews: new HybridCollection('verificationReviews'),
  agentProfiles: new HybridCollection('agentProfiles'),
  savedListings: new HybridCollection('savedListings'),
  listings: new HybridCollection('listings'),
  bookings: new HybridCollection('bookings'),
  wallets: new HybridCollection('wallets'),
  transactions: new HybridCollection('walletTransactions'),
  reviews: new HybridCollection('reviews'),
  refunds: new HybridCollection('refundRequests'),
  reschedules: new HybridCollection('rescheduleRequests'),
  supportTickets: new HybridCollection('supportTickets'),
  auditLogs: new HybridCollection('auditLogs'),
};
