const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const commerceRepository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  categories: new HybridCollection('categories'),
  listings: new HybridCollection('listings'),
  routes: new HybridCollection('routes'),
  routeStops: new HybridCollection('routeStops'),
  vehicles: new HybridCollection('vehicles'),
  schedules: new HybridCollection('schedules'),
  seats: new HybridCollection('seats'),
  hotelProperties: new HybridCollection('hotelProperties'),
  roomTypes: new HybridCollection('roomTypes'),
  roomUnits: new HybridCollection('roomUnits'),
  roomNights: new HybridCollection('roomNightInventories'),
  carts: new HybridCollection('carts'),
  holds: new HybridCollection('inventoryHolds'),
  holdItems: new HybridCollection('inventoryHoldItems'),
  bookings: new HybridCollection('bookings'),
  bookingGroups: new HybridCollection('bookingGroups'),
  passengers: new HybridCollection('passengers'),
  payments: new HybridCollection('payments'),
  paymentIntents: new HybridCollection('paymentIntents'),
  webhookEvents: new HybridCollection('paymentWebhookEvents'),
  checkoutAttempts: new HybridCollection('cartCheckoutAttempts'),
  refunds: new HybridCollection('refundRequests'),
  reschedules: new HybridCollection('rescheduleRequests'),
  commissions: new HybridCollection('commissions'),
  wallets: new HybridCollection('wallets'),
  transactions: new HybridCollection('walletTransactions'),
  promoterLinks: new HybridCollection('promoterLinks'),
  attributionSessions: new HybridCollection('attributionSessions'),
  conversions: new HybridCollection('campaignConversions'),
  timelineEvents: new HybridCollection('bookingTimelineEvents'),
  correspondence: new HybridCollection('correspondenceMessages'),
  notifications: new HybridCollection('notifications'),
  outboxEvents: new HybridCollection('outboxEvents'),
  auditLogs: new HybridCollection('auditLogs'),
};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = { ...commerceRepository, withTransaction };
