const repositories = require('..');
const memoryDatabase = require('../memoryDatabase');

function isTest() {
  return process.env.NODE_ENV === 'test';
}

function testFallback() {
  if (!isTest()) throw new Error('Platform settings require an available MongoDB repository');
  if (!memoryDatabase.state.platformSettings || Array.isArray(memoryDatabase.state.platformSettings)) memoryDatabase.state.platformSettings = {};
  return memoryDatabase.state.platformSettings;
}

async function get() {
  if (repositories.mongoReady()) {
    const row = await repositories.platformSettings.findOne({});
    if (!row) return {};
    const plain = { ...row };
    delete plain._id;
    delete plain.__v;
    return plain;
  }
  return testFallback();
}

async function save(settings, options = {}) {
  const row = { ...settings, updatedAt: settings.updatedAt || new Date().toISOString() };
  if (repositories.mongoReady()) {
    await repositories.platformSettings.upsert(row, {}, { session: options.session || undefined });
    return row;
  }
  Object.assign(testFallback(), row);
  if (Array.isArray(row.notificationTemplates)) memoryDatabase.state.notificationTemplates = row.notificationTemplates;
  memoryDatabase.invalidateReadModelCaches();
  return row;
}

module.exports = { get, save };
