const { mongoose } = require('../../config/db');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');
const { clean } = require('../mongoRepository');
const { nextId } = require('../../services/data/idService');
const { HybridCollection } = require('./hybridCollection');

const collections = {
  companies: new HybridCollection('companies'),
  listings: new HybridCollection('listings'),
  hotelProperties: new HybridCollection('hotelProperties'),
  roomTypes: new HybridCollection('roomTypes'),
  roomUnits: new HybridCollection('roomUnits'),
  roomNightInventories: new HybridCollection('roomNightInventories'),
  bookings: new HybridCollection('bookings'),
  payments: new HybridCollection('payments'),
  auditLogs: new HybridCollection('auditLogs'),
  commissions: new HybridCollection('commissions'),
  wallets: new HybridCollection('wallets'),
  walletTransactions: new HybridCollection('walletTransactions'),
  inventoryHolds: new HybridCollection('inventoryHolds'),
  inventoryHoldItems: new HybridCollection('inventoryHoldItems'),
};

function notFound(message) {
  const error = new Error(message);
  error.status = 404;
  throw error;
}

async function companyOrThrow(companyId) {
  return (await collections.companies.findOne({ id: companyId })) || notFound('Company not found');
}

async function listingOrThrow(companyId, identifier) {
  const listing = await collections.listings.findOne({ companyId, $or: [{ id: identifier }, { slug: identifier }] });
  if (!listing || listing.serviceType !== 'hotel') notFound('Hotel listing not found');
  return listing;
}

async function publicListingOrThrow(identifier) {
  const listing = await collections.listings.findOne({ serviceType: 'hotel', $or: [{ id: identifier }, { slug: identifier }] });
  return listing || notFound('Hotel listing not found');
}

async function propertyOrThrow(companyId, propertyId) {
  return (await collections.hotelProperties.findOne({ id: propertyId, companyId })) || notFound('Hotel property not found');
}

async function roomTypeOrThrow(companyId, roomTypeId) {
  return (await collections.roomTypes.findOne({ id: roomTypeId, companyId })) || notFound('Room type not found');
}

async function roomUnitOrThrow(companyId, unitId) {
  return (await collections.roomUnits.findOne({ id: unitId, companyId })) || notFound('Room unit not found');
}

async function nightOrThrow(companyId, inventoryId) {
  return (await collections.roomNightInventories.findOne({ id: inventoryId, companyId })) || notFound('Room-night inventory not found');
}

async function bookingOrThrow(companyId, bookingRef) {
  return (await collections.bookings.findOne({ bookingRef, companyId, serviceType: 'hotel' })) || notFound('Hotel booking not found');
}

async function audit({ actorId, action, targetType, targetId, meta = {} }) {
  const row = {
    id: await nextId('audit'),
    actorId,
    action,
    targetType,
    targetId,
    meta,
    status: 'success',
    createdAt: new Date().toISOString(),
  };
  await collections.auditLogs.save(row);
  return row;
}


function model(name) {
  require(`../../models/${name}`);
  return mongoose.model(name);
}

async function commitHotelBooking({ selectedRows, booking, paymentRow }) {
  const mongoBacked = collections.bookings.isMongoReady();
  const result = await transaction(async (session) => {
    if (!collections.bookings.isMongoReady()) {
      const currentRows = [];
      for (const selected of selectedRows) {
        const current = await collections.roomNightInventories.findOne({ id: selected.id, companyId: selected.companyId });
        if (!current || !['available', 'reserved'].includes(current.status) || current.bookingRef) {
          const error = new Error('One or more room nights are no longer available');
          error.status = 409;
          throw error;
        }
        currentRows.push(current);
      }
      for (const current of currentRows) {
        current.status = 'booked';
        current.bookingRef = booking.bookingRef;
        current.guestName = booking.guestSnapshot?.fullName || 'Hotel Guest';
        current.checkInStatus = 'not_checked';
        current.updatedAt = new Date().toISOString();
        await collections.roomNightInventories.save(current);
      }
      await collections.bookings.save(booking);
      await collections.payments.save(paymentRow);
      return { booking, paymentRow, nights: currentRows };
    }

    const RoomNightInventory = model('RoomNightInventory');
    const Booking = model('Booking');
    const Payment = model('Payment');
    const claimed = [];
    for (const selected of selectedRows) {
      const row = await RoomNightInventory.findOneAndUpdate(
        {
          id: selected.id,
          companyId: selected.companyId,
          status: { $in: ['available', 'reserved'] },
          $or: [{ bookingRef: { $exists: false } }, { bookingRef: '' }, { bookingRef: null }],
        },
        {
          $set: {
            status: 'booked',
            bookingRef: booking.bookingRef,
            guestName: booking.guestSnapshot?.fullName || 'Hotel Guest',
            checkInStatus: 'not_checked',
            updatedAt: new Date(),
          },
        },
        { new: true, session, runValidators: true }
      ).lean();
      if (!row) {
        const error = new Error('One or more room nights are no longer available');
        error.status = 409;
        throw error;
      }
      claimed.push(clean(row));
    }
    await Booking.updateOne(
      { bookingRef: booking.bookingRef },
      { $set: booking },
      { upsert: true, runValidators: true, session }
    );
    await Payment.updateOne(
      { idempotencyKey: paymentRow.idempotencyKey },
      { $set: paymentRow },
      { upsert: true, runValidators: true, session }
    );
    return { booking, paymentRow, nights: claimed };
  });
  if (mongoBacked) {
    result.nights.forEach((row) => collections.roomNightInventories.mirrorSave(row));
    collections.bookings.mirrorSave(result.booking);
    collections.payments.mirrorSave(result.paymentRow);
  }
  return result;
}


function settlementRows(booking, split) {
  const currency = booking.pricing?.currency || 'UGX';
  const rows = [
    { ownerType: 'platform', ownerId: 'platform', amount: Number(split.platformFee || 0), balanceField: 'availableBalance', transactionType: 'platform_fee', status: 'completed' },
    { ownerType: 'company', ownerId: booking.companyId, amount: Number(split.companyAmount || 0), balanceField: 'pendingBalance', transactionType: 'company_earning_pending', status: 'pending' },
  ];
  if (booking.promoterAttribution?.promoterId && Number(split.promoterAmount || 0) > 0) {
    rows.push({ ownerType: 'promoter', ownerId: booking.promoterAttribution.promoterId, amount: Number(split.promoterAmount || 0), balanceField: 'pendingBalance', transactionType: 'promoter_commission_pending', status: 'pending' });
  }
  return rows.map((row) => ({ ...row, currency }));
}

function safeId(value) {
  return String(value || '').replace(/[^a-zA-Z0-9_-]+/g, '-').slice(0, 100);
}

async function settleSuccessfulBooking({ booking, split }) {
  if (!booking || booking.paymentStatus !== 'successful') return booking;
  const existing = await collections.commissions.findOne({ bookingId: booking.id });
  if (existing) {
    if (booking.settlementStatus !== 'settled') {
      booking.settlementStatus = 'settled';
      booking.settledAt = booking.settledAt || existing.createdAt || new Date().toISOString();
      await collections.bookings.save(booking);
    }
    return booking;
  }
  const now = new Date().toISOString();
  const commission = {
    id: `commission-${safeId(booking.id)}`,
    bookingId: booking.id,
    bookingRef: booking.bookingRef,
    promoterId: booking.promoterAttribution?.promoterId || null,
    companyId: booking.companyId,
    platformFee: Number(split.platformFee || 0),
    promoterAmount: Number(split.promoterAmount || 0),
    companyAmount: Number(split.companyAmount || 0),
    status: 'pending',
    releasedAt: null,
    createdAt: now,
  };
  const entries = settlementRows(booking, split);

  if (!collections.bookings.isMongoReady()) {
    const wallets = [];
    const transactions = [];
    for (const entry of entries) {
      let wallet = await collections.wallets.findOne({ ownerType: entry.ownerType, ownerId: entry.ownerId, currency: entry.currency });
      if (!wallet) {
        wallet = { id: `wallet-${safeId(entry.ownerType)}-${safeId(entry.ownerId)}-${safeId(entry.currency)}`, ownerType: entry.ownerType, ownerId: entry.ownerId, currency: entry.currency, availableBalance: 0, pendingBalance: 0, createdAt: now };
      }
      const transactionId = `wallet-txn-${safeId(booking.id)}-${safeId(entry.transactionType)}`;
      const prior = await collections.walletTransactions.findOne({ id: transactionId });
      if (!prior) {
        wallet[entry.balanceField] = Number(wallet[entry.balanceField] || 0) + entry.amount;
        transactions.push({ id: transactionId, walletId: wallet.id, ownerType: entry.ownerType, ownerId: entry.ownerId, transactionType: entry.transactionType, direction: 'credit', amount: entry.amount, currency: entry.currency, status: entry.status, referenceType: 'booking', referenceId: booking.id, createdAt: now });
      }
      wallets.push(wallet);
    }
    booking.settlementStatus = 'settled';
    booking.settledAt = now;
    await collections.commissions.save(commission);
    await collections.wallets.saveMany(wallets);
    await collections.walletTransactions.saveMany(transactions);
    await collections.bookings.save(booking);
    return booking;
  }

  const mirroredWallets = [];
  const mirroredTransactions = [];
  const result = await transaction(async (session) => {
    const Commission = model('Commission');
    const Wallet = model('Wallet');
    const WalletTransaction = model('WalletTransaction');
    const Booking = model('Booking');
    const duplicate = await Commission.findOne({ bookingId: booking.id }).session(session).lean();
    if (duplicate) return booking;
    await Commission.create([commission], { session });
    for (const entry of entries) {
      const walletId = `wallet-${safeId(entry.ownerType)}-${safeId(entry.ownerId)}-${safeId(entry.currency)}`;
      const transactionId = `wallet-txn-${safeId(booking.id)}-${safeId(entry.transactionType)}`;
      const transactionExists = await WalletTransaction.exists({ id: transactionId }).session(session);
      if (transactionExists) continue;
      const wallet = await Wallet.findOneAndUpdate(
        { ownerType: entry.ownerType, ownerId: entry.ownerId, currency: entry.currency },
        { $setOnInsert: { id: walletId, ownerType: entry.ownerType, ownerId: entry.ownerId, currency: entry.currency }, $inc: { [entry.balanceField]: entry.amount } },
        { upsert: true, new: true, runValidators: true, session }
      ).lean();
      const transactionRow = {
        id: transactionId,
        walletId: wallet.id || walletId,
        ownerType: entry.ownerType,
        ownerId: entry.ownerId,
        transactionType: entry.transactionType,
        direction: 'credit',
        amount: entry.amount,
        currency: entry.currency,
        status: entry.status,
        referenceType: 'booking',
        referenceId: booking.id,
        createdAt: now,
      };
      await WalletTransaction.create([transactionRow], { session });
      mirroredWallets.push(clean(wallet));
      mirroredTransactions.push(transactionRow);
    }
    booking.settlementStatus = 'settled';
    booking.settledAt = now;
    await Booking.updateOne({ bookingRef: booking.bookingRef }, { $set: { settlementStatus: 'settled', settledAt: now } }, { session, runValidators: true });
    return booking;
  });
  collections.commissions.mirrorSave(commission);
  mirroredWallets.forEach((row) => collections.wallets.mirrorSave(row));
  mirroredTransactions.forEach((row) => collections.walletTransactions.mirrorSave(row));
  collections.bookings.mirrorSave(booking);
  return result;
}

async function transaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = {
  ...collections,
  nextId,
  companyOrThrow,
  listingOrThrow,
  publicListingOrThrow,
  propertyOrThrow,
  roomTypeOrThrow,
  roomUnitOrThrow,
  nightOrThrow,
  bookingOrThrow,
  audit,
  transaction,
  commitHotelBooking,
  settleSuccessfulBooking,
};
