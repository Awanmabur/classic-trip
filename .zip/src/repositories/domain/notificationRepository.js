const { HybridCollection } = require('./hybridCollection');

module.exports = {
  notifications: new HybridCollection('notifications'),
  deliveryAttempts: new HybridCollection('notificationDeliveryAttempts'),
  pushSubscriptions: new HybridCollection('pushSubscriptions'),
  users: new HybridCollection('users'),
  companyEmployees: new HybridCollection('companyEmployees'),
  auditLogs: new HybridCollection('auditLogs'),
};
