const { HybridCollection } = require('./hybridCollection');

module.exports = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  securityEvents: new HybridCollection('securityEvents'),
  loginAudits: new HybridCollection('loginAudits'),
  deviceSessions: new HybridCollection('deviceSessions'),
  idempotencyKeys: new HybridCollection('idempotencyKeyRecords'),
  auditLogs: new HybridCollection('auditLogs'),
  verificationReviews: new HybridCollection('verificationReviews'),
};
