const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');
const crypto = require('crypto');
const { duplicateKeyFields } = require('../../utils/mongoDuplicate');

const financeRepository = {
  wallets: new HybridCollection('wallets'),
  transactions: new HybridCollection('walletTransactions'),
  payments: new HybridCollection('payments'),
  commissions: new HybridCollection('commissions'),
  paymentIntents: new HybridCollection('paymentIntents'),
  receiptInvoices: new HybridCollection('receiptInvoices'),
  taxFeeRecords: new HybridCollection('taxFeeRecords'),
  statements: new HybridCollection('financeStatements'),
  riskReviews: new HybridCollection('financeRiskReviews'),
  settlementBatches: new HybridCollection('settlementBatches'),
  payoutRequests: new HybridCollection('payoutRequests'),
  payoutBatches: new HybridCollection('payoutBatches'),
  reconciliationReports: new HybridCollection('reconciliationReports'),
  bookings: new HybridCollection('bookings'),
  refunds: new HybridCollection('refundRequests'),
  companies: new HybridCollection('companies'),
  users: new HybridCollection('users'),
  auditLogs: new HybridCollection('auditLogs'),
};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

function walletFilter(ownerType, ownerId, currency) {
  return { ownerType, ownerId, currency };
}

async function atomicWalletDelta({ ownerType, ownerId, currency, availableDelta = 0, pendingDelta = 0, requireAvailable = 0, session = null, walletId }) {
  const filter = walletFilter(ownerType, ownerId, currency);
  if (requireAvailable > 0) filter.availableBalance = { $gte: requireAvailable };

  if (repositories.mongoReady()) {
    const Model = financeRepository.wallets.repository.Model;
    const increments = {
      availableBalance: Number(availableDelta || 0),
      pendingBalance: Number(pendingDelta || 0),
    };
    const options = {
      new: true,
      upsert: requireAvailable <= 0,
      runValidators: true,
      // Mongoose schema defaults must not be copied into $setOnInsert because
      // the balance fields are also incremented in the same atomic operation.
      setDefaultsOnInsert: false,
      session: session || undefined,
      lean: true,
    };

    let wallet = null;
    let candidateWalletId = walletId || `wallet-${crypto.randomUUID()}`;
    for (let attempt = 1; attempt <= 5; attempt += 1) {
      const update = {
        // $inc initializes missing numeric fields. Keeping balance fields out
        // of $setOnInsert avoids MongoDB's "path would create a conflict"
        // error during first-time partner/promoter wallet provisioning.
        $setOnInsert: {
          id: candidateWalletId,
          ownerType,
          ownerId,
          currency,
        },
        $inc: increments,
      };

      try {
        wallet = await Model.findOneAndUpdate(filter, update, options);
        break;
      } catch (error) {
        const duplicateFields = duplicateKeyFields(error);
        const walletIdentityRace = Number(error?.code) === 11000
          && ['ownerType', 'ownerId', 'currency'].some((field) => duplicateFields.includes(field));
        if (walletIdentityRace) {
          // A concurrent request won the unique (ownerType, ownerId, currency)
          // insert. Apply this request's delta to the winner exactly once.
          wallet = await Model.findOneAndUpdate(filter, { $inc: increments }, {
            ...options,
            upsert: false,
            setDefaultsOnInsert: false,
          });
          break;
        }

        const identifierCollision = Number(error?.code) === 11000 && duplicateFields.includes('id');
        if (identifierCollision && options.upsert && attempt < 5) {
          candidateWalletId = `wallet-${crypto.randomUUID()}`;
          continue;
        }
        throw error;
      }
    }

    if (!wallet) return null;
    const plain = { ...wallet, id: wallet.id || String(wallet._id) };
    delete plain._id;
    delete plain.__v;
    financeRepository.wallets.mirrorSave(plain, walletFilter(ownerType, ownerId, currency));
    return plain;
  }

  let wallet = await financeRepository.wallets.findOne(filter);
  if (!wallet) {
    wallet = { id: walletId, ownerType, ownerId, currency, availableBalance: 0, pendingBalance: 0 };
    financeRepository.wallets.mirrorSave(wallet, filter);
  }
  if (requireAvailable > 0 && Number(wallet.availableBalance || 0) < requireAvailable) return null;
  wallet.availableBalance = Number(wallet.availableBalance || 0) + Number(availableDelta || 0);
  wallet.pendingBalance = Number(wallet.pendingBalance || 0) + Number(pendingDelta || 0);
  return wallet;
}

module.exports = { ...financeRepository, withTransaction, walletFilter, atomicWalletDelta };
