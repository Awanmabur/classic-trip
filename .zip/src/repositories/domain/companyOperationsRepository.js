const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const companyOperationsRepository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  branches: new HybridCollection('companyBranches'),
  policies: new HybridCollection('companyPolicies'),
  listings: new HybridCollection('listings'),
  vehicles: new HybridCollection('vehicles'),
  schedules: new HybridCollection('schedules'),
  driverAssignments: new HybridCollection('driverAssignments'),
  driverIncidents: new HybridCollection('driverIncidents'),
  tripStatusUpdates: new HybridCollection('tripStatusUpdates'),
  hotelProperties: new HybridCollection('hotelProperties'),
  roomTypes: new HybridCollection('roomTypes'),
  roomUnits: new HybridCollection('roomUnits'),
  auditLogs: new HybridCollection('auditLogs'),
};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = { ...companyOperationsRepository, withTransaction };
