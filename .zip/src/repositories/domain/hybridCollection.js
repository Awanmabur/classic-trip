const repositories = require('..');
const memoryDatabase = require('../memoryDatabase');

function valueAt(row, path) {
  return String(path).split('.').reduce((value, key) => (value == null ? undefined : value[key]), row);
}

function comparable(value) {
  if (value instanceof Date) return value.getTime();
  const date = typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value) ? Date.parse(value) : NaN;
  return Number.isNaN(date) ? value : date;
}

function matchesCondition(actual, expected) {
  if (expected && typeof expected === 'object' && !Array.isArray(expected) && !(expected instanceof Date)) {
    if ('$in' in expected) return expected.$in.some((value) => String(actual) === String(value));
    if ('$nin' in expected) return !expected.$nin.some((value) => String(actual) === String(value));
    if ('$ne' in expected) return String(actual) !== String(expected.$ne);
    if ('$exists' in expected) return expected.$exists ? actual !== undefined && actual !== null : actual === undefined || actual === null;
    const left = comparable(actual);
    if ('$gte' in expected && !(left >= comparable(expected.$gte))) return false;
    if ('$gt' in expected && !(left > comparable(expected.$gt))) return false;
    if ('$lte' in expected && !(left <= comparable(expected.$lte))) return false;
    if ('$lt' in expected && !(left < comparable(expected.$lt))) return false;
    return true;
  }
  if (Array.isArray(actual)) return actual.some((value) => String(value) === String(expected));
  return String(actual) === String(expected);
}

function matches(row, filter = {}) {
  if (!filter || !Object.keys(filter).length) return true;
  if (Array.isArray(filter.$or) && !filter.$or.some((entry) => matches(row, entry))) return false;
  if (Array.isArray(filter.$and) && !filter.$and.every((entry) => matches(row, entry))) return false;
  return Object.entries(filter)
    .filter(([key]) => !key.startsWith('$'))
    .every(([key, expected]) => matchesCondition(valueAt(row, key), expected));
}

function compareRows(sort = {}) {
  const entries = Object.entries(sort);
  return (a, b) => {
    for (const [key, direction] of entries) {
      const left = comparable(valueAt(a, key));
      const right = comparable(valueAt(b, key));
      if (left === right) continue;
      return (left > right ? 1 : -1) * (Number(direction) < 0 ? -1 : 1);
    }
    return 0;
  };
}

class HybridCollection {
  constructor(entity) {
    this.entity = entity;
    this.repository = repositories.repositoryFor(entity);
  }

  isMongoReady() {
    return repositories.mongoReady();
  }

  fallbackRows() {
    if (process.env.NODE_ENV !== 'test' && this.isMongoReady()) {
      throw new Error(`In-memory access is forbidden for '${this.entity}' while MongoDB is active`);
    }
    if (process.env.NODE_ENV !== 'test' && !this.isMongoReady()) {
      throw new Error(`MongoDB is unavailable; '${this.entity}' cannot use an in-memory production fallback`);
    }
    const rows = memoryDatabase.state[this.entity];
    if (!Array.isArray(rows)) memoryDatabase.state[this.entity] = [];
    return memoryDatabase.state[this.entity];
  }

  mirrorSave(row, filter = null, position = 'end') {
    if (!row) return row;
    if (process.env.NODE_ENV !== 'test' && this.isMongoReady()) return row;
    memoryDatabase.invalidateReadModelCaches();
    const resolvedFilter = filter || this.repository.defaultFilter(row);
    const rows = this.fallbackRows();
    const existing = rows.find((item) => matches(item, resolvedFilter));
    if (existing) {
      Object.assign(existing, row);
      if (position === 'start') {
        const index = rows.indexOf(existing);
        if (index > 0) rows.unshift(...rows.splice(index, 1));
      }
      return existing;
    }
    if (position === 'start') rows.unshift(row);
    else rows.push(row);
    return row;
  }

  async list(filter = {}, options = {}) {
    if (this.isMongoReady()) return this.repository.list(filter, options);
    let rows = this.fallbackRows().filter((row) => matches(row, filter));
    if (options.sort) rows = rows.slice().sort(compareRows(options.sort));
    if (options.skip) rows = rows.slice(options.skip);
    if (options.limit) rows = rows.slice(0, options.limit);
    return rows;
  }

  rows() {
    return this.fallbackRows();
  }

  findOneCached(filter = {}) {
    return this.fallbackRows().find((row) => matches(row, filter)) || null;
  }

  listCached(filter = {}, options = {}) {
    let rows = this.fallbackRows().filter((row) => matches(row, filter));
    if (options.sort) rows = rows.slice().sort(compareRows(options.sort));
    if (options.skip) rows = rows.slice(options.skip);
    if (options.limit) rows = rows.slice(0, options.limit);
    return rows;
  }

  async findOne(filter = {}, options = {}) {
    if (this.isMongoReady()) return this.repository.findOne(filter, options);
    return this.fallbackRows().find((row) => matches(row, filter)) || null;
  }

  async count(filter = {}, options = {}) {
    if (this.isMongoReady()) return this.repository.count(filter, options);
    return this.fallbackRows().filter((row) => matches(row, filter)).length;
  }

  async insert(row, options = {}) {
    if (!row) return row;
    memoryDatabase.invalidateReadModelCaches();
    const { mirrorPosition = 'end', mirror = process.env.NODE_ENV === 'test', ...repositoryOptions } = options || {};
    if (this.isMongoReady()) {
      await this.repository.insert(row, repositoryOptions);
      if (mirror) this.mirrorSave(row, null, mirrorPosition);
      return row;
    }
    const resolvedFilter = this.repository.defaultFilter(row);
    if (this.fallbackRows().some((item) => matches(item, resolvedFilter))) {
      const error = new Error(`Duplicate key for '${this.entity}'`);
      error.code = 11000;
      error.keyValue = resolvedFilter;
      error.keyPattern = Object.fromEntries(Object.keys(resolvedFilter).map((key) => [key, 1]));
      throw error;
    }
    return this.mirrorSave(row, resolvedFilter, mirrorPosition);
  }

  async save(row, filter = null, options = {}) {
    if (!row) return row;
    memoryDatabase.invalidateReadModelCaches();
    const { mirrorPosition = 'end', mirror = process.env.NODE_ENV === 'test', ...repositoryOptions } = options || {};
    if (this.isMongoReady()) {
      await this.repository.upsert(row, filter, repositoryOptions);
      if (mirror) this.mirrorSave(row, filter, mirrorPosition);
      return row;
    }
    return this.mirrorSave(row, filter, mirrorPosition);
  }

  async saveMany(rows = [], filterFor = null, options = {}) {
    if (!rows.length) return rows;
    memoryDatabase.invalidateReadModelCaches();
    const { mirror = process.env.NODE_ENV === 'test', ...repositoryOptions } = options || {};
    if (this.isMongoReady()) {
      await this.repository.upsertMany(rows, filterFor, repositoryOptions);
      if (mirror) rows.forEach((row) => this.mirrorSave(row, filterFor ? filterFor(row) : null));
      return rows;
    }
    for (const row of rows) this.mirrorSave(row, filterFor ? filterFor(row) : null);
    return rows;
  }

  async updateOne(filter, update, options = {}) {
    memoryDatabase.invalidateReadModelCaches();
    if (this.isMongoReady()) return this.repository.updateOne(filter, update, options);
    const row = await this.findOne(filter);
    if (!row) return { matchedCount: 0, modifiedCount: 0 };
    if (update.$set) Object.assign(row, update.$set);
    if (update.$unset) Object.keys(update.$unset).forEach((key) => { delete row[key]; });
    return { matchedCount: 1, modifiedCount: 1 };
  }

  async updateMany(filter, update, options = {}) {
    memoryDatabase.invalidateReadModelCaches();
    if (this.isMongoReady()) return this.repository.updateMany(filter, update, options);
    const matchesRows = this.fallbackRows().filter((item) => matches(item, filter));
    for (const row of matchesRows) {
      if (update.$set) Object.assign(row, update.$set);
      if (update.$unset) Object.keys(update.$unset).forEach((key) => { delete row[key]; });
    }
    return { matchedCount: matchesRows.length, modifiedCount: matchesRows.length };
  }

  async deleteOne(filter = {}, options = {}) {
    memoryDatabase.invalidateReadModelCaches();
    if (this.isMongoReady()) {
      const existing = await this.repository.findOne(filter, options);
      await this.repository.Model.deleteOne(filter, options);
      return existing;
    }
    const rows = this.fallbackRows();
    const index = rows.findIndex((item) => matches(item, filter));
    if (index < 0) return null;
    return rows.splice(index, 1)[0];
  }

  async deleteMany(filter = {}, options = {}) {
    memoryDatabase.invalidateReadModelCaches();
    if (this.isMongoReady()) {
      const existing = await this.repository.list(filter, options);
      await this.repository.deleteMany(filter, options);
      return existing;
    }
    const rows = this.fallbackRows();
    const removed = rows.filter((item) => matches(item, filter));
    memoryDatabase.replace(this.entity, rows.filter((item) => !matches(item, filter)));
    return removed;
  }

  mirrorMany(rows = [], filterFor = null, position = 'end') {
    if (process.env.NODE_ENV !== 'test' && this.isMongoReady()) return rows;
    rows.forEach((row) => this.mirrorSave(row, filterFor ? filterFor(row) : null, position));
    return rows;
  }

  async refresh(filter = {}, options = {}) {
    if (!this.isMongoReady()) return this.listCached(filter, options);
    return this.repository.list(filter, options);
  }
}

module.exports = { HybridCollection, matches };
