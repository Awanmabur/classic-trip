const { HybridCollection } = require('./hybridCollection');

module.exports = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  invitations: new HybridCollection('invitations'),
  verificationReviews: new HybridCollection('verificationReviews'),
  securityEvents: new HybridCollection('securityEvents'),
  loginAudits: new HybridCollection('loginAudits'),
  deviceSessions: new HybridCollection('deviceSessions'),
  idempotencyKeys: new HybridCollection('idempotencyKeyRecords'),
  auditLogs: new HybridCollection('auditLogs'),
};
