const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const repository = {
  orders: new HybridCollection('subscriptionOrders'),
  subscriptions: new HybridCollection('subscriptions'),
  payments: new HybridCollection('payments'),
  companies: new HybridCollection('companies'),
  users: new HybridCollection('users'),
  supportTickets: new HybridCollection('supportTickets'),
  auditLogs: new HybridCollection('auditLogs'),
};
async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}
module.exports = { ...repository, withTransaction };
