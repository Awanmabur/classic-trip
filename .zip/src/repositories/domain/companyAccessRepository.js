const { HybridCollection } = require('./hybridCollection');

module.exports = {
  companies: new HybridCollection('companies'),
  listings: new HybridCollection('listings'),
  routes: new HybridCollection('routes'),
  schedules: new HybridCollection('schedules'),
  vehicles: new HybridCollection('vehicles'),
  bookings: new HybridCollection('bookings'),
  hotelProperties: new HybridCollection('hotelProperties'),
  roomTypes: new HybridCollection('roomTypes'),
  roomUnits: new HybridCollection('roomUnits'),
  roomNightInventories: new HybridCollection('roomNightInventories'),
};
