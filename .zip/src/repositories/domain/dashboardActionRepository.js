const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const dashboardActionRepository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  listings: new HybridCollection('listings'),
  bookings: new HybridCollection('bookings'),
  payments: new HybridCollection('payments'),
  tickets: new HybridCollection('supportTickets'),
  refunds: new HybridCollection('refundRequests'),
  reviews: new HybridCollection('reviews'),
  handovers: new HybridCollection('shiftHandovers'),
  schedules: new HybridCollection('schedules'),
  vehicles: new HybridCollection('vehicles'),
  auditLogs: new HybridCollection('auditLogs'),
  timelineEvents: new HybridCollection('bookingTimelineEvents'),
};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = { ...dashboardActionRepository, withTransaction };
