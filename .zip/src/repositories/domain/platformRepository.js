const { HybridCollection } = require('./hybridCollection');

module.exports = {
  outboxEvents: new HybridCollection('outboxEvents'),
  notifications: new HybridCollection('notifications'),
  deliveryAttempts: new HybridCollection('notificationDeliveryAttempts'),
  auditLogs: new HybridCollection('auditLogs'),
  platformSettings: new HybridCollection('platformSettings'),
  paymentIntents: new HybridCollection('paymentIntents'),
  promotionCampaigns: new HybridCollection('promotionCampaigns'),
  bookings: new HybridCollection('bookings'),
  commissions: new HybridCollection('commissions'),
  futureServiceModules: new HybridCollection('futureServiceModules'),
};
