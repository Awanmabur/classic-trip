const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const onboardingRepository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  driverAssignments: new HybridCollection('driverAssignments'),
  branches: new HybridCollection('companyBranches'),
  policies: new HybridCollection('companyPolicies'),
  invitations: new HybridCollection('invitations'),
  verificationReviews: new HybridCollection('verificationReviews'),
  partnerLeads: new HybridCollection('partnerLeads'),
  discoverySessions: new HybridCollection('discoverySessions'),
  agreements: new HybridCollection('agreements'),
  agentProfiles: new HybridCollection('agentProfiles'),
  listings: new HybridCollection('listings'),
  routes: new HybridCollection('routes'),
  vehicles: new HybridCollection('vehicles'),
  schedules: new HybridCollection('schedules'),
  hotelProperties: new HybridCollection('hotelProperties'),
  roomTypes: new HybridCollection('roomTypes'),
  roomUnits: new HybridCollection('roomUnits'),
  auditLogs: new HybridCollection('auditLogs'),
  notifications: new HybridCollection('notifications'),
};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = { ...onboardingRepository, withTransaction };
