const { HybridCollection } = require('./hybridCollection');
const repositories = require('..');
const { runMongoUnitOfWork } = require('../../services/shared/mongoUnitOfWork');

const adminActionRepository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  listings: new HybridCollection('listings'),
  campaigns: new HybridCollection('promotionCampaigns'),
  bookings: new HybridCollection('bookings'),
  payments: new HybridCollection('payments'),
  walletTransactions: new HybridCollection('walletTransactions'),
  tickets: new HybridCollection('supportTickets'),
  refunds: new HybridCollection('refundRequests'),
  auditLogs: new HybridCollection('auditLogs'),
  driverAssignments: new HybridCollection('driverAssignments'),
  vehicles: new HybridCollection('vehicles'),
  schedules: new HybridCollection('schedules'),
  invitations: new HybridCollection('invitations'),
};

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = { ...adminActionRepository, withTransaction };
