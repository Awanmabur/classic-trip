const reportingRepository = require('../repositories/domain/reportingRepository');
const { nextId } = require('../services/data/idService');
function audit(action) {
  return (req, res, next) => {
    (async () => {
      const row = {
        id: await nextId('audit'), actorId: req.session?.user?.id || 'guest', actorName: req.session?.user?.fullName || '', actorRole: req.session?.user?.role || 'guest',
        action, target: req.originalUrl, ip: req.ip, userAgent: req.headers?.['user-agent'] || '', status: 'success', createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      };
      await reportingRepository.auditLogs.save(row, { id: row.id }, { mirrorPosition: 'start' });
    })().catch(() => {});
    next();
  };
}
module.exports = { audit };
