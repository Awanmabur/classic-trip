'use strict';

const { HybridCollection } = require('../../../repositories/domain/hybridCollection');
const { runMongoUnitOfWork } = require('../../../services/shared/mongoUnitOfWork');
const { nextId } = require('../../../services/data/idService');
const { notFoundError } = require('../domain/busDomain');

const busRepository = {
  users: new HybridCollection('users'),
  companies: new HybridCollection('companies'),
  employees: new HybridCollection('companyEmployees'),
  branches: new HybridCollection('companyBranches'),
  listings: new HybridCollection('listings'),
  routes: new HybridCollection('routes'),
  routeStops: new HybridCollection('routeStops'),
  routeSegments: new HybridCollection('routeSegments'),
  vehicles: new HybridCollection('vehicles'),
  seatMapTemplates: new HybridCollection('seatMapTemplates'),
  seatMapVersions: new HybridCollection('seatMapVersions'),
  fareProducts: new HybridCollection('fareProducts'),
  segmentFares: new HybridCollection('busSegmentFares'),
  scheduleRules: new HybridCollection('scheduleRules'),
  schedules: new HybridCollection('schedules'),
  seats: new HybridCollection('seats'),
  segmentInventory: new HybridCollection('busSeatSegmentInventories'),
  holds: new HybridCollection('inventoryHolds'),
  holdItems: new HybridCollection('inventoryHoldItems'),
  bookings: new HybridCollection('bookings'),
  bookingItems: new HybridCollection('bookingItems'),
  reservations: new HybridCollection('busReservations'),
  passengers: new HybridCollection('passengers'),
  seatAssignments: new HybridCollection('busSeatAssignments'),
  tickets: new HybridCollection('busTickets'),
  paymentIntents: new HybridCollection('paymentIntents'),
  payments: new HybridCollection('payments'),
  idempotencyKeys: new HybridCollection('idempotencyKeyRecords'),
  driverAssignments: new HybridCollection('driverAssignments'),
  incidents: new HybridCollection('driverIncidents'),
  tripStatusUpdates: new HybridCollection('tripStatusUpdates'),
  ticketScans: new HybridCollection('ticketScans'),
  outboxEvents: new HybridCollection('outboxEvents'),
  auditLogs: new HybridCollection('auditLogs'),
};

async function oneOrThrow(collection, filter, message, options = {}) {
  const row = await collection.findOne(filter, options);
  if (!row) throw notFoundError(message);
  return row;
}

async function companyOrThrow(companyId, options = {}) {
  return oneOrThrow(busRepository.companies, { id: companyId }, 'Company not found', options);
}

async function listingOrThrow(companyId, listingId, options = {}) {
  const key = String(listingId || '').trim();
  const identities = [{ id: key }, { slug: key }];
  if (/^[a-f0-9]{24}$/i.test(key)) identities.push({ _id: key });
  const listing = await oneOrThrow(busRepository.listings, { companyId, $or: identities }, 'Bus service listing not found for this company', options);
  const serviceType = String(listing.serviceType || '').toLowerCase().trim().replace(/[\s-]+/g, '_');
  const type = String(listing.type || '').toLowerCase().trim().replace(/[\s-]+/g, '_');
  const group = String(listing.group || '').toLowerCase().trim().replace(/[\s-]+/g, '_');
  if (!['bus', 'coach', 'bus_company', 'transport'].includes(serviceType)
    && !['bus', 'coach'].includes(type)
    && !['bus', 'transport'].includes(group)) {
    throw notFoundError('Bus service listing not found for this company');
  }
  return listing;
}

async function routeOrThrow(companyId, routeId, options = {}) {
  return oneOrThrow(busRepository.routes, { id: routeId, companyId }, 'Bus route not found for this company', options);
}

async function vehicleOrThrow(companyId, vehicleId, options = {}) {
  return oneOrThrow(busRepository.vehicles, { id: vehicleId, companyId, serviceType: 'bus' }, 'Bus vehicle not found for this company', options);
}

async function scheduleOrThrow(companyId, scheduleId, options = {}) {
  return oneOrThrow(busRepository.schedules, { id: scheduleId, companyId }, 'Bus departure not found for this company', options);
}

async function fareProductOrThrow(companyId, fareProductId, options = {}) {
  return oneOrThrow(busRepository.fareProducts, { id: fareProductId, companyId }, 'Bus fare product not found for this company', options);
}

async function seatMapVersionOrThrow(companyId, versionId, options = {}) {
  return oneOrThrow(busRepository.seatMapVersions, { id: versionId, companyId }, 'Seat-map version not found for this company', options);
}

async function audit({ actorId = 'system', action, targetType = 'bus', targetId, companyId = '', metadata = {}, session = null }) {
  const row = {
    id: await nextId('audit'),
    actorId,
    actorRole: metadata.actorRole || '',
    action,
    targetType,
    targetId,
    target: targetId,
    companyId,
    meta: metadata,
    status: 'success',
    createdAt: new Date().toISOString(),
  };
  await busRepository.auditLogs.save(row, { id: row.id }, session ? { session } : {});
  return row;
}

async function outbox({ eventType, aggregateType, aggregateId, companyId = '', payload = {}, dedupeKey, session = null }) {
  const row = {
    id: await nextId('outbox'),
    dedupeKey: dedupeKey || `${eventType}:${aggregateId}`,
    topic: eventType,
    type: eventType,
    eventType,
    aggregateType,
    aggregateId,
    companyId,
    payload,
    status: 'pending',
    attempts: 0,
    createdAt: new Date().toISOString(),
  };
  await busRepository.outboxEvents.save(row, { dedupeKey: row.dedupeKey }, session ? { session } : {});
  return row;
}

async function withTransaction(work) {
  return runMongoUnitOfWork(work);
}

module.exports = {
  ...busRepository,
  nextId,
  oneOrThrow,
  companyOrThrow,
  listingOrThrow,
  routeOrThrow,
  vehicleOrThrow,
  scheduleOrThrow,
  fareProductOrThrow,
  seatMapVersionOrThrow,
  audit,
  outbox,
  withTransaction,
};
