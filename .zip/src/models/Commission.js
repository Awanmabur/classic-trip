const { Schema, model } = require('./_helpers');

const commissionSchema = new Schema({
  id: { type: String, unique: true, sparse: true, index: true },
  bookingId: { type: String, required: true, index: true },
  bookingRef: { type: String, index: true },
  promoterId: { type: String, index: true },
  companyId: { type: String, index: true },
  platformFee: Number,
  promoterAmount: Number,
  companyAmount: Number,
  status: { type: String, default: 'pending', index: true, enum: ['pending', 'released', 'cancelled', 'partially_refunded'] },
  releasedAt: Date,
}, { timestamps: true });

module.exports = model('Commission', commissionSchema);
