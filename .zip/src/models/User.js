const { Schema, model } = require('./_helpers');

const userSchema = new Schema({
  id: { type: String, index: true, unique: true, sparse: true },
  role: { type: String, enum: ['super_admin', 'admin', 'finance_admin', 'support_admin', 'operations_admin', 'content_admin', 'company_admin', 'company_employee', 'driver', 'customer', 'promoter'], default: 'customer', index: true },
  fullName: { type: String, required: true, trim: true },
  email: { type: String, lowercase: true, trim: true, index: true, unique: true, sparse: true },
  phone: { type: String, trim: true, index: true },
  passwordHash: String,
  googleId: { type: String, index: true },
  authProviders: { type: Schema.Types.Mixed, default: {} },
  status: { type: String, enum: ['active', 'pending', 'suspended', 'blocked'], default: 'active', index: true },
  isVerified: { type: Boolean, default: false },
  companyId: { type: String, index: true },
  referralCode: { type: String, index: true },
  city: String,
  preferredSeat: String,
  passengerNote: String,
  savedPassengerDetails: String,
  permissionsLabel: String,
  twoFactorEnabled: { type: Boolean, default: false },
  mfa: { type: Schema.Types.Mixed, default: {} },
  mfaSetup: { type: Schema.Types.Mixed, default: {} },
  loginAlertsEnabled: { type: Boolean, default: true },
  recoveryEmail: String,
  passwordChangedAt: Date,
  authVersion: { type: Number, min: 0, default: 0 },
  // Live-verified 2026-07: only 'pending'/'verified' (plus null/unset) ever observed or written
  // for User.verificationStatus - unlike Company.verificationStatus, this model's flow never
  // rejects a user directly, so 'rejected' isn't included here.
  verificationStatus: { type: String, enum: ['pending', 'verified'], index: true },
  onboardingStatus: { type: String, trim: true, index: true },
  requestedRole: { type: String, enum: ['promoter'], index: true },
  roleChangeStatus: { type: String, enum: ['pending', 'approved', 'rejected'], index: true },
  verificationDocumentType: String,
  verificationReference: String,
  promoterProfile: Schema.Types.Mixed,
  payoutAccount: Schema.Types.Mixed,
  emailVerifiedAt: Date,
  phoneVerifiedAt: Date,
  phoneVerificationStatus: String,
  phoneVerification: Schema.Types.Mixed,
  profileCompletion: Schema.Types.Mixed,
  emailVerifyToken: String,
  emailVerifyTokenExpiresAt: Date,
  lastLoginAt: Date,
}, { timestamps: true });

userSchema.index({ email: 1, role: 1 });
module.exports = model('User', userSchema);
