const { Schema, model } = require('./_helpers');

const tripScheduleSchema = new Schema({
  id: { type: String, unique: true, sparse: true, index: true },
  routeId: { type: String, required: true, index: true },
  listingId: { type: String, index: true },
  companyId: { type: String, index: true },
  vehicleId: { type: String, index: true },
  vehicleName: String,
  routeVersion: { type: Number, default: 1 },
  originStopId: { type: String, index: true },
  destinationStopId: { type: String, index: true },
  seatMapTemplateId: { type: String, index: true },
  seatMapVersionId: { type: String, index: true },
  fareProductId: { type: String, index: true },
  routeSnapshot: Schema.Types.Mixed,
  seatMapSnapshot: Schema.Types.Mixed,
  fareSnapshot: Schema.Types.Mixed,
  inventoryReadyAt: Date,
  driverName: String,
  departAt: { type: Date, required: true, index: true },
  arriveAt: Date,
  basePrice: Number,
  currency: { type: String, default: 'UGX' },
  totalSeats: Number,
  availableSeats: Number,
  // Matches transitionSchedule's own allowed-status list (companyService.js) - live-verified
  // 2026-07 (active/archived observed).
  status: { type: String, default: 'active', index: true, enum: ['draft', 'active', 'published', 'boarding', 'departed', 'arrived', 'completed', 'delayed', 'cancelled', 'archived'] },
  driverIds: [String],
  boardingStartAt: Date,
  // 'premium' is live data with no corresponding literal anywhere in current code/dashboard
  // forms - included because it's real, not invented; the dashboard select should offer it too
  // (see Phase D).
  fareClass: { type: String, enum: ['standard', 'economy', 'business', 'executive', 'vip', 'premium', 'express'] },
  gate: String,
  platform: String,
  notes: String,
  seatInventorySnapshot: [Schema.Types.Mixed],
  publishValidation: Schema.Types.Mixed,
  statusReason: String,
  driverEmployeeId: String,
  driverUserId: String,
  assignmentStatus: String,
  publishedAt: Date,
  completedAt: Date,
  tripStatus: String,
  tripStatusLocation: String,
  tripStatusNote: String,
  tripStatusUpdatedAt: Date,
  scheduleRuleId: { type: String, index: true },
}, { timestamps: true });

module.exports = model('TripSchedule', tripScheduleSchema);
