const { Schema, model } = require('./_helpers');

const financeRulesSchema = new Schema({
  platformFeePercent: { type: Number, min: 0, max: 100, default: 7 },
  promoterCommissionPercent: { type: Number, min: 0, max: 100, default: 3 },
  partnerPayoutPercent: { type: Number, min: 0, max: 100, default: 90 },
  holdMinutes: { type: Number, min: 1, max: 180, default: 10 },
  defaultCurrency: { type: String, default: 'UGX' },
  supportMessage: String,
  updatedBy: String,
  updatedAt: Date,
}, { _id: false });

const priceRuleSchema = new Schema({
  id: { type: String, required: true },
  listingId: String,
  ruleName: { type: String, required: true },
  percent: { type: Number, min: -100, max: 500, default: 0 },
  startsAt: Date,
  endsAt: Date,
  note: String,
  status: { type: String, enum: ['active', 'disabled', 'expired'], default: 'active' },
  createdBy: String,
  createdAt: Date,
}, { _id: false });

const notificationTemplateSchema = new Schema({
  id: { type: String, required: true },
  key: { type: String, required: true },
  subject: { type: String, required: true },
  body: { type: String, required: true },
  status: { type: String, enum: ['active', 'disabled'], default: 'active' },
  updatedBy: String,
  updatedAt: Date,
}, { _id: false });

const platformSettingSchema = new Schema({
  platformName: { type: String, default: 'Classic Trip' },
  defaultCurrency: { type: String, default: 'UGX', index: true },
  platformFeePercent: { type: Number, default: 7, min: 0, max: 100 },
  promoterDefaultPercent: { type: Number, default: 3, min: 0, max: 100 },
  supportEmail: String,
  supportMessage: String,
  maintenanceMode: { type: Boolean, default: false, index: true },
  termsUrl: String,
  privacyUrl: String,
  financeRules: { type: financeRulesSchema, default: () => ({}) },
  priceRules: { type: [priceRuleSchema], default: [] },
  notificationTemplates: { type: [notificationTemplateSchema], default: [] },
  updatedBy: String,
}, { timestamps: true });

module.exports = model('PlatformSetting', platformSettingSchema);
