const { Schema, mediaSchema, model } = require('./_helpers');

const companyEmployeeSchema = new Schema({
  id: { type: String, unique: true, sparse: true, index: true },
  companyId: { type: String, required: true, index: true },
  userId: { type: String, required: true, index: true },
  roleTitle: String,
  branchId: { type: String, index: true },
  branchName: String,
  branch: String, // compatibility display snapshot; branchId is authoritative
  listingIds: [{ type: String, index: true }],
  scheduleIds: [{ type: String, index: true }],
  serviceCategories: [String],
  permissions: [String],
  documents: [mediaSchema],
  licenseNumber: String,
  licenseClass: String,
  licenseExpiresAt: Date,
  assignedFleetId: { type: String, index: true },
  shift: String,
  notes: String,
  safetyStatus: { type: String, enum: ['not_submitted', 'pending_review', 'cleared', 'rejected'], default: 'not_submitted' },
  verifiedBy: String,
  verifiedAt: Date,
  status: { type: String, default: 'requested', index: true, enum: ['requested', 'invited', 'pending_verification', 'active', 'suspended', 'rejected', 'revoked'] },
  invitedAt: Date,
  acceptedAt: Date,
  approvedAt: Date,
  approvedBy: String,
  suspendedAt: Date,
  rejectedAt: Date,
}, { timestamps: true });

module.exports = model('CompanyEmployee', companyEmployeeSchema);
