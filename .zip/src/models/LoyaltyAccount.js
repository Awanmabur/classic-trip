const { Schema, model } = require('./_helpers');

const loyaltyAccountSchema = new Schema({
  id: { type: String, index: true }, userId: { type: String, index: true }, tier: String, pointsBalance: Number, walletCreditBalance: Number,
  coupons: [{ code: String, value: Number, expiresAt: Date, status: { type: String, enum: ['active'] } }], referralRewards: [{ referralCode: String, points: Number, status: { type: String, enum: ['earned'] } }],
  status: { type: String, default: 'planned', enum: ['planned', 'active'] },
}, { timestamps: true });
module.exports = model('LoyaltyAccount', loyaltyAccountSchema);
