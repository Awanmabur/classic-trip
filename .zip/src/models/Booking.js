const { Schema, moneySchema, model } = require('./_helpers');
const { BOOKING_STATUSES } = require('../domain/statuses');

const passengerSnapshotSchema = new Schema({
  id: String,
  fullName: String,
  name: String,
  phone: String,
  email: String,
  identityNumber: String,
  seatOrRoom: String,
  seatNumber: String,
  roomNumber: String,
  roomType: String,
  roomTypeId: String,
  roomUnitId: String,
  scheduleId: String,
  legType: String,
  pickupPoint: String,
  dropoffPoint: String,
  specialNotes: String,
  travelNotes: String,
  checkInStatus: String,
  refundId: String,
}, { _id: false });

const bookingSchema = new Schema({
  id: { type: String, unique: true, sparse: true, index: true },
  bookingRef: { type: String, unique: true, required: true, index: true },
  guestLookupCode: { type: String, index: true },
  cartRef: { type: String, index: true },
  bookingGroupId: { type: String, index: true },
  bookingGroupRef: { type: String, index: true },
  // Union of dashboardFeatures.js's dashboard-having types, companyService.js's
  // ROUTED_SERVICE_TYPES/VEHICLE_SERVICE_TYPES, and live-observed values (2026-07: bus, hotel).
  serviceType: { type: String, required: true, index: true, enum: ['bus', 'hotel', 'flight', 'train', 'ferry', 'tour', 'car_rental', 'airport_transfer', 'event', 'cargo', 'insurance', 'corporate', 'loyalty', 'package'] },
  guestSnapshot: Schema.Types.Mixed,
  buyerSnapshot: Schema.Types.Mixed,
  customerUserId: { type: String, index: true },
  companyId: { type: String, index: true },
  tenantId: { type: String, index: true },
  tenantSlug: { type: String, index: true },
  listingId: { type: String, index: true },
  catalogId: { type: String, index: true },
  scheduleId: { type: String, index: true },
  tripId: { type: String, index: true },
  vehicleId: { type: String, index: true },
  // Immutable traveler snapshots captured at checkout; Passenger is the operational projection.
  passengers: [passengerSnapshotSchema],
  bookingItems: [Schema.Types.Mixed],
  bookingLegs: [Schema.Types.Mixed],
  ticketLegs: [Schema.Types.Mixed],
  hotelStay: Schema.Types.Mixed,
  checkoutUrl: String,
  checkOutAt: Date,
  completedBy: String,
  tripType: { type: String, default: 'one_way', index: true, enum: ['one_way', 'round_trip', 'multi_service', 'single_service_cart'] },
  addons: [Schema.Types.Mixed],
  quantity: { type: Number, default: 1 },
  pricing: moneySchema,
  grossAmount: Number,
  walletUsed: { type: Number, default: 0 },
  promoterAttribution: Schema.Types.Mixed,
  referralCode: { type: String, index: true },
  risk: Schema.Types.Mixed,
  paymentStatus: { type: String, default: 'pending', index: true, enum: ['pending', 'successful', 'failed', 'expired', 'refunded'] },
  paymentProvider: { type: String, enum: ['mock', 'pesapal', 'mtn_momo', 'airtel_money', 'flutterwave', 'paystack', 'dpo', 'cash', 'bank_transfer', 'card', 'mobile_money'] },
  paymentRef: { type: String, index: true },
  paymentMethodNote: String,
  bookingChannel: { type: String, index: true, enum: ['web', 'mobile', 'agent_offline', 'admin_manual', 'company_manual'] },
  createdByAgentId: { type: String, index: true },
  agentSale: Schema.Types.Mixed,
  bookingStatus: { type: String, default: 'draft', index: true, enum: BOOKING_STATUSES },
  settlementStatus: { type: String, default: 'pending', index: true, enum: ['pending', 'settled', 'eligible', 'reconciliation_required'] },
  settlementError: String,
  settledAt: Date,
  qrCodeValue: { type: String, index: true },
  ticketPdf: Schema.Types.Mixed,
  lockedUntil: Date,
  checkInStatus: { type: String, default: 'not_checked', index: true, enum: ['not_checked', 'pending', 'boarding', 'checked_in', 'partial', 'no_show', 'cancelled', 'refunded'] },
  checkedInAt: Date,
  checkedInBy: String,
  checkedInByUserId: { type: String, index: true },
  checkInNote: String,
  noShowAt: Date,
  noShowBy: String,
  noShowByUserId: { type: String, index: true },
  cancelReason: String,
  cancellationReason: String,
  cancelledAt: Date,
  completedAt: Date,
  earningsReleasedAt: Date,
  customerNote: String,
  notes: String,
  auditTrail: [Schema.Types.Mixed],
}, { timestamps: true });

bookingSchema.index({ bookingRef: 1, 'guestSnapshot.phone': 1 });
bookingSchema.index({ companyId: 1, bookingStatus: 1, paymentStatus: 1 });
bookingSchema.index({ companyId: 1, guestLookupCode: 1 });
bookingSchema.index({ companyId: 1, paymentRef: 1 });
bookingSchema.index({ customerUserId: 1, createdAt: -1 });
bookingSchema.index({ referralCode: 1, createdAt: -1 });
bookingSchema.index({ 'ticketLegs.qrTokenHash': 1 }, { sparse: true });
bookingSchema.index({ companyId: 1, scheduleId: 1, 'bookingItems.seatNumber': 1, bookingStatus: 1 });
module.exports = model('Booking', bookingSchema);
