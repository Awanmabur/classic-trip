const { Schema, model } = require('./_helpers');
const { ROOM_NIGHT_STATUSES, ROOM_CHECK_IN_STATUSES } = require('../domain/statuses');

const roomNightInventorySchema = new Schema({
  id: { type: String, index: true },
  companyId: { type: String, required: true, index: true },
  listingId: { type: String, required: true, index: true },
  propertyId: { type: String, index: true },
  roomTypeId: { type: String, index: true },
  roomUnitId: { type: String, index: true },
  date: { type: String, required: true, index: true },
  price: Number,
  availableInventory: { type: Number, default: 1, min: 0 },
  status: { type: String, default: 'available', index: true, enum: ROOM_NIGHT_STATUSES },
  holdId: String,
  bookingRef: { type: String, index: true },
  guestName: String,
  checkInStatus: { type: String, enum: ROOM_CHECK_IN_STATUSES },
  notes: String,
  housekeepingStatus: String,
  createdBy: String,
}, { timestamps: true });

roomNightInventorySchema.index({ roomUnitId: 1, date: 1 }, { unique: true, sparse: true });
module.exports = model('RoomNightInventory', roomNightInventorySchema);
