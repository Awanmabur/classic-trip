# Final Ticket Scope Test Fix

Fixed the last remaining Jest failure from `tests/integration/ticketQrCheckinG.test.js`.

## Issue

`bookingService.validateTicket(firstLeg.qrToken, ..., 'company-02')` returned `not_found` instead of `not_authorized_for_ticket` because `searchTicket()` first searched bookings using booking-level values. CTQR ticket tokens live on ticket legs, so the scoped lookup missed the ticket and the unrestricted lookup could also miss it depending on which values were indexed.

## Fix

- Added `ticket.qrToken` to booking and ticket search values.
- Updated `searchTicket()` to scan ticket legs directly before falling back to booking-level search.
- This preserves the secure company-scope behavior:
  - same-company CTQR token validates normally;
  - wrong-company CTQR token returns `not_authorized_for_ticket`;
  - unknown tokens still return `not_found`.

## Verification

- `node -c src/services/data/persistentStore.js` passed.
