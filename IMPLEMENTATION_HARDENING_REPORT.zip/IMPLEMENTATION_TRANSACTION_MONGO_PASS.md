# Classic Trip - Mongo Transaction and Production Completion Pass

## Summary

This pass continues after demoStore removal by making the checkout/payment/ticket path more MongoDB-first and safer under real traffic.

## Implemented in this pass

### 1. Transaction-style MongoDB checkout persistence
- Added a MongoDB unit-of-work wrapper using `mongoose.startSession()` and `session.withTransaction()`.
- Booking persistence now writes booking, passengers, payments, wallets, wallet transactions, and commissions inside the same MongoDB transaction block when MongoDB is connected.
- The checkout flow now persists/reserves the booking before payment initiation instead of initiating payment first and only writing after.

### 2. Atomic bus seat claiming
- Added `claimBusSeatsAtomically()` in `src/services/booking/bookingService.js`.
- Each selected seat is claimed with `findOneAndUpdate()` using an availability filter.
- Seats are accepted only when they are `available`, or when they are locked by the same valid hold ID.
- If any requested seat cannot be claimed, checkout fails with `SEAT_CLAIM_FAILED` and no payment attempt is started.
- Schedule available-seat counts are decremented in the same MongoDB transaction block.

### 3. Atomic hotel room claiming
- Added `claimHotelRoomAtomically()`.
- Room inventory is claimed using `findOneAndUpdate({ inventory: { $gt: 0 } })`.
- If the room is no longer available, checkout fails with `ROOM_CLAIM_FAILED`.

### 4. Removed non-atomic pre-writes for seats and schedules
- `persistentStore.createBooking()` no longer directly persists selected seats and schedules while building the booking object.
- Seat/schedule writes are now handled by the transaction-aware booking service.

### 5. Fresh Mongo read model refresh
- Added `refreshFromDatabase()` to `persistentStore`.
- Added a throttled request middleware that refreshes the shared read model from MongoDB for public, ticket, API, and dashboard GET pages.
- This keeps dashboard/ticket/listing pages closer to MongoDB state instead of relying only on startup hydration.

### 6. Mongo-backed booking API lookup
- `/api/bookings/:bookingRef` now checks MongoDB if the booking is not already in the read model.
- Matching bookings are merged back into the read model cache for subsequent dashboard/ticket use.

### 7. Safer payment webhook completion
- Payment webhook processing now tries MongoDB if a booking is not in the read model.
- Failed payment webhooks now cancel the booking and release bus seat inventory.
- Persisted webhook updates now include cancellation fields and ticket-leg status updates.

### 8. Seed/dev script cleanup
- Updated `dev:seeded` from `AUTO_SEED_DEMO=true` to `AUTO_SEED_MONGO=true`.
- Documentation references were updated to use the Mongo seed flag.

## Verification

The syntax check passed:

```bash
npm run check
```

Full Jest/acceptance tests were not run in this container because dependencies are not installed here. Run locally after `npm install`.

## Remaining important production work

1. Run the full test suite against local MongoDB.
2. Convert remaining dashboard-heavy read paths from cache reads to direct repository pagination/filtering.
3. Add provider-specific payment clients for MTN, Airtel, Flutterwave/Paystack/DPO.
4. Add Playwright browser E2E tests for search -> preview -> checkout -> payment -> ticket -> scan -> refund.
5. Finish full room-night locking using `RoomNightInventory` for multi-night hotel stays.
6. Add background jobs for expired holds/payment-intent cleanup.
7. Review all protected routes for permission-level company scoping.
