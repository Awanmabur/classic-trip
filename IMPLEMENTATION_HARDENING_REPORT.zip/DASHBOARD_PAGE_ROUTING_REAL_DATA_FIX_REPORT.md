# Dashboard Page Routing and Real Data Fix Report

## Issue traced
Several dashboard sidebar items were wired to the wrong existing page IDs instead of their own pages.

### Super Admin
- Routes pointed to `listings`.
- Vehicles pointed to `listings`.
- Schedules pointed to `bookings`.

This made different sidebar pages open the same content, so Super Admin looked like pages were duplicated and vehicles/routes/schedules were missing.

### Employee / Driver
- Driver Ops pointed to `schedule`.
- Driver Manifest pointed to `inventory`.
- Incidents pointed to `support`.

The real sections existed, but the sidebar never opened them.

## Fixes
- Added real Super Admin sections for:
  - Routes
  - Vehicles
  - Schedules
- Added formatted admin dashboard rows for:
  - `routes`
  - `vehicles`
  - `schedules`
- Corrected Super Admin sidebar `data-page` targets.
- Corrected Employee/Driver sidebar `data-page` targets.
- Verified every dashboard sidebar item now maps to a real section.
- Verified there are no duplicate sidebar page targets across Admin, Company, Customer, Employee/Driver, and Promoter dashboard views.

## Validation
- `node --check src/services/data/persistentStore.js` passes.
- Static dashboard routing audit shows no missing sections and no duplicate page targets.
