# Classic Trip - demoStore Removal and MongoDB Continuation Pass

## Summary
This pass removes the operational `demoStore` module and replaces all imports with `src/services/data/persistentStore.js`, a MongoDB-hydrated/write-through state cache used only as an application read model. Local MongoDB is now the required source of truth for normal development via `MONGO_URI=mongodb://127.0.0.1:27017/classic_trip`.

## Implemented

### 1. Removed demoStore module dependency
- Deleted `src/services/data/demoStore.js`.
- Replaced all source/test/script imports with `src/services/data/persistentStore.js`.
- Removed direct `demoStore` references from runtime source files.
- Reworded docs/runtime strings away from in-memory demo-store terminology.

### 2. Mongo-backed persistent store
- `persistentStore` starts from an empty production state, then hydrates from MongoDB on app boot.
- Added write-through helpers:
  - `persistRow(entity, row)`
  - `persistRows(entity, rows)`
  - `persistBookingGraph(booking)`
- Added automatic array write-through persistence for new rows inserted by services/controllers through `store.state.<collection>.push/unshift/splice`.
- Existing services that still use the shared state now write new records back to Mongo repositories instead of remaining memory-only.

### 3. Local seed config cleanup
- Replaced `AUTO_SEED_MONGO` with `AUTO_SEED_MONGO`.
- `.env` now enables local startup seeding with `AUTO_SEED_MONGO=true`.
- `.env.example` documents `AUTO_SEED_MONGO=false` by default.
- Startup logs now describe MongoDB reference data instead of demo-store fallback.

### 4. Stronger MongoDB uniqueness/index hardening
Added or strengthened indexes for production safety:
- Active seat holds: `scheduleId + seatNumber + holdType + status` partial unique index.
- Active room holds: `roomId + holdType + status` partial unique index.
- Payment provider references: unique sparse `provider + providerReference`.
- Payment idempotency keys: unique sparse `idempotencyKey`.
- Payment intent provider references and idempotency keys: unique sparse indexes.
- Passenger rows: unique sparse `bookingRef + passengerIndex`.
- Booking ticket QR hash and seat-claim helper indexes.

### 5. Payment webhook validation improvements
- Webhooks still require HMAC signature validation.
- Added booking amount validation.
- Added booking currency validation.
- Amount/currency mismatch now records a critical security event and rejects the webhook.

### 6. Booking cancellation continuation
- Customer cancellation now marks ticket legs cancelled.
- Bus cancellations release unscanned/taken seats back to available state.
- Schedule available seat counters are restored.
- Booking graph is persisted back to MongoDB.

### 7. Fixed existing persistence bug
- Fixed `seatLockService.lockSeatPersistent()` so it no longer calls `.lean()` on the repository result.

## Verification
- `npm run check` passed.
- `npm test` could not run in this container because `node_modules` is not installed and `jest` is unavailable.

## Remaining work after this pass
1. Install dependencies locally and run the full suite:
   ```bash
   npm install
   npm run seed:local
   npm run seed:counts
   npm run check
   npm test
   npm run test:acceptance
   ```
2. Run the app against local MongoDB and manually verify the full browser flow.
3. Convert the shared state read-model usage into direct repository queries page-by-page, especially for large admin reports.
4. Add full MongoDB transactions around checkout so seat finalization, booking creation, passenger creation, payment intent creation, wallet/commission entries, and notifications commit atomically.
5. Complete provider-specific payment integrations beyond mock/http provider adapters.
6. Add Playwright/Cypress browser E2E tests.
