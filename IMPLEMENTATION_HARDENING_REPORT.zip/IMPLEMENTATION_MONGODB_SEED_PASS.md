# MongoDB seed implementation pass

## Completed

- Changed local `.env` and `.env.example` to use `MONGO_URI=mongodb://127.0.0.1:27017/classic_trip` and `DEMO_MODE=false`.
- Changed database connection behavior so the app no longer silently falls back to memory when `DEMO_MODE=false`.
- Added a full local MongoDB demo seed path using `npm run seed:local`.
- Added `npm run seed:local:upsert` for non-destructive upsert seeding.
- Added `npm run seed:counts` to verify MongoDB collection counts after seeding.
- Added optional startup seeding with `AUTO_SEED_MONGO=true` and `AUTO_SEED_FORCE=false/true`.
- Expanded seed coverage from catalog-only/demo-memory records to real Mongo-backed records for operational workflows.

## Seed coverage now includes

- Users, companies, categories, listings, blogs.
- Partner leads, discovery sessions, agreements, invitations, verification reviews.
- Routes, route stops, vehicles, schedules, seats.
- Hotel properties, room types, room units, room-night inventory, stay rules.
- Company branches, employees, policies, driver assignments, driver incidents, trip status updates.
- Carts and checkout attempts.
- Bookings, passengers, payments, payment intents, receipts, tax/fee records.
- Booking timelines, correspondence, notifications, notification delivery attempts.
- Wallets, wallet transactions, finance statements, risk reviews, settlement batches, payout requests, payout batches, reconciliation reports.
- Promoter links, referral clicks, attribution sessions, campaign conversions, agent profile, offline sales, fraud signals, commissions.
- Support tickets, refund requests, promotion campaigns, audit logs, reviews.
- Subscriptions, subscription orders, saved listings, shift handovers.
- Security events, login audits, device sessions, idempotency records.
- Future-service modules and sample architecture data for flights, trains, tours, car rentals, events, cargo, insurance, corporate travel, and loyalty.

## Verification

- `npm run check` passed in this environment.
- MongoDB itself is not running inside this container, so I could not execute the actual insert into a live local MongoDB here. The project now includes the commands to seed your local MongoDB instance.
