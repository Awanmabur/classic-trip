# Test Import Order Fix Report

## Issue
The Jest run failed before executing most test bodies with:

```txt
ReferenceError: Cannot access 'FALLBACK_MEDIA' before initialization
```

The test read-model loader was executed near the top of `src/services/data/persistentStore.js`. That loader calls `normalizeHydratedState()`, and the normalization step references `FALLBACK_MEDIA`. Because `FALLBACK_MEDIA` was declared later as a `const`, Node hit the temporal dead zone during module import.

## Fix
Moved the automatic test/seed read-model bootstrapping block until after `FALLBACK_MEDIA` and `SERVICE_LABELS` are initialized.

## Files changed
- `src/services/data/persistentStore.js`

## Verification
- `node --check src/services/data/persistentStore.js` passes in this environment.
- Full Jest execution should now proceed past module import on the user's machine with installed dependencies.
