# Classic Trip Production Completion Pass

This pass continues after the Mongo transaction implementation and focuses on the remaining production-hardening items that can be implemented without a running local MongoDB instance in this environment.

## Implemented in this pass

### 1. Hotel room-night inventory locking
- Guest hotel checkout now carries `checkIn`, `checkOut`, `nights`, `roomId`, `roomUnitId`, and hotel stay metadata into the booking object.
- Mongo checkout now claims hotel room nights before payment initiation where room-night inventory exists.
- Room-night claims use Mongo updates against `RoomNightInventory` and reject checkout when all requested nights cannot be claimed.
- Aggregated seeded hotel inventory using `availableInventory` is supported.
- Failed payment / expired payment release now restores room-night inventory and room counters.

### 2. Payment-intent expiry cleanup job
- Added `src/jobs/expirePaymentIntents.js`.
- Job expires stale `PaymentIntent` rows in `created`, `pending`, or `processing` state.
- Job cancels the related booking if payment never completed.
- Job releases claimed bus seats and hotel room nights.
- Job also expires stale active inventory holds.
- Registered the job with the scheduler using `JOB_EXPIRE_PAYMENT_INTENTS`.

### 3. Provider webhook signature scaffolding
- Added provider-level webhook secret support for MTN, Airtel, Flutterwave, Paystack, and DPO in `env.js`.
- Added provider signature verification support in `httpPaymentProvider.js`.
- Webhook processing now accepts a valid provider-specific HMAC signature when configured, otherwise falls back to Classic Trip's internal webhook signature.
- Webhook security still blocks missing or mismatched signatures.

### 4. More direct Mongo-backed dashboard reads
- Added `src/services/dashboard/mongoDashboardService.js`.
- API dashboard data now uses direct Mongo-backed lists for key role data when MongoDB is connected.
- Admin API list controllers for bookings, disputes/support, payments/wallet transactions, promoters, and promotions now read from Mongo repositories instead of memory-first state.

### 5. Continued demoStore removal
- Confirmed there are no remaining `demoStore` imports.
- The app continues to use `persistentStore` as the compatibility read model while more pages are moved to direct repository reads.

## Verified here
- `npm run check` passed.

## Still remaining
- Run the full Jest and acceptance tests locally after `npm install`.
- Run against a live local MongoDB instance and execute `npm run seed:local` and `npm run seed:counts`.
- Add true Playwright/Cypress browser tests for search → seat/room hold → payment → ticket → scan → refund.
- Replace the remaining dashboard render read-model calls with paginated direct repository queries page-by-page.
- Implement each real payment provider's exact production API contract beyond the generic HTTP adapter.
- Add raw-body webhook parsing if a provider requires signing the original raw request body instead of normalized JSON.
- Add production monitoring and alerting for stale bookings, failed webhooks, and cleanup-job releases.
