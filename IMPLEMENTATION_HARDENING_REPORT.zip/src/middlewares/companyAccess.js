function wantsJson(req) {
  return String(req.originalUrl || req.path || '').startsWith('/api/') || req.xhr || String(req.headers.accept || '').includes('application/json');
}

function forbidden(req, res, code, message) {
  if (wantsJson(req)) return res.status(403).json({ ok: false, code, message });
  return res.status(403).send(message);
}

function requireCompanyAccess(req, res, next) {
  const user = req.session?.user;
  if (!user) return res.redirect('/login');
  if (user.role === 'super_admin' || user.companyId || user.role === 'company_admin' || user.role === 'company_employee') return next();
  return forbidden(req, res, 'company_access_required', 'Company access is required.');
}

function enforceCompanyScope(req, res, next) {
  const user = req.session?.user || {};
  if (['super_admin', 'admin'].includes(user.role)) return next();
  const requested = req.body?.companyId || req.query?.companyId || req.params?.companyId;
  const isCompanyRole = ['company_admin', 'company_employee', 'partner'].includes(user.role);
  const scoped = user.companyId;
  if (!isCompanyRole) return next();
  if (!scoped) return forbidden(req, res, 'company_scope_missing', 'Your user is not attached to a company.');
  if (requested && String(requested) !== String(scoped)) {
    return forbidden(req, res, 'company_scope_denied', 'You cannot access another company workspace.');
  }
  req.body = req.body || {};
  req.body.companyId = scoped;
  return next();
}

module.exports = { requireCompanyAccess, enforceCompanyScope };
