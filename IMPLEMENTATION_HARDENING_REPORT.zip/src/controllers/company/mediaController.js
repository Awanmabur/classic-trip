const companyService = require('../../services/company/companyService');
const { withUploadedMedia } = require('./mediaHelpers');
const uploadService = require('../../services/media/uploadService');

function companyId(req) {
  return req.session?.user?.companyId || req.body.companyId || 'company-01';
}

async function upload(req, res, next) {
  try {
    const target = req.body.target || 'companyLogo';
    const allowed = ['companyLogo', 'companyCover', 'companyDocument'];
    if (!allowed.includes(target)) {
      const error = new Error('Unsupported company media target');
      error.status = 422;
      throw error;
    }
    if (!req.file) {
      const error = new Error('Choose a file to upload');
      error.status = 422;
      throw error;
    }
    const payload = await withUploadedMedia(req, {}, target);
    await companyService.attachMedia({
      companyId: companyId(req),
      target,
      asset: payload.mediaAsset,
      metadata: {
        uploadedBy: req.session?.user?.id || '',
        documentType: req.body.documentType,
        documentReference: req.body.documentReference,
        note: req.body.note,
        label: req.body.label,
        alt: req.body.alt,
      },
    });
    res.redirect('/company/settings');
  } catch (error) {
    next(error);
  }
}

async function destroy(req, res, next) {
  try {
    const target = req.body.target || 'companyDocument';
    const allowed = ['companyLogo', 'companyCover', 'companyDocument', 'listingMedia', 'busListing', 'hotelListing'];
    if (!allowed.includes(target)) {
      const error = new Error('Unsupported company media target');
      error.status = 422;
      throw error;
    }
    const removal = await companyService.removeMedia({
      companyId: companyId(req),
      target,
      targetId: req.body.targetId || req.body.listingId,
      publicId: req.body.publicId,
      actorId: req.session?.user?.id || 'company-user',
    });
    if (removal.media) await uploadService.deleteMedia(removal.media);
    res.redirect('/company/settings');
  } catch (error) {
    next(error);
  }
}

module.exports = { upload, destroy };
