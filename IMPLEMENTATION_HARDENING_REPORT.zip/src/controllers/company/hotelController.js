const hotelService = require('../../services/hotel/hotelService');

function companyId(req) { return req.session?.user?.companyId || req.body.companyId || 'company-01'; }
function actorId(req) { return req.session?.user?.id || 'company-admin'; }

async function createProperty(req, res, next) { try { await hotelService.createProperty(companyId(req), req.body, actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
async function createRoomType(req, res, next) { try { await hotelService.createRoomType(companyId(req), req.body, actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
async function createRoomUnits(req, res, next) { try { await hotelService.createRoomUnits(companyId(req), req.body, actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
async function createInventory(req, res, next) { try { await hotelService.createNightInventory(companyId(req), req.body, actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
async function updateInventoryStatus(req, res, next) { try { await hotelService.updateNightStatus(companyId(req), req.params.id, req.body, actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
async function checkIn(req, res, next) { try { await hotelService.markStay(companyId(req), req.params.bookingRef, 'checked-in', actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
async function checkOut(req, res, next) { try { await hotelService.markStay(companyId(req), req.params.bookingRef, 'checked-out', actorId(req)); res.redirect('/company/rooms'); } catch (error) { next(error); } }
function manifest(req, res, next) { try { const rows = hotelService.manifestRows(companyId(req), req.params.listingId, req.query.mode || 'arrivals'); res.render('pages/hotel-manifest-print', { seo: { title: 'Hotel manifest | Classic Trip' }, rows, mode: req.query.mode || 'arrivals', listingId: req.params.listingId }); } catch (error) { next(error); } }
function manifestCsv(req, res, next) { try { const rows = hotelService.manifestRows(companyId(req), req.params.listingId, req.query.mode || 'arrivals'); res.setHeader('Content-Type', 'text/csv; charset=utf-8'); res.setHeader('Content-Disposition', `attachment; filename="hotel-${req.query.mode || 'arrivals'}-${req.params.listingId}.csv"`); res.send(hotelService.toCsv(['Booking','Guest','Room','Check-in','Check-out','Status'], rows)); } catch (error) { next(error); } }
async function manifestPdf(req, res, next) { try { const rows = hotelService.manifestRows(companyId(req), req.params.listingId, req.query.mode || 'arrivals'); const buffer = await hotelService.pdfBuffer(`Hotel ${req.query.mode || 'arrivals'} manifest`, rows); res.setHeader('Content-Type', 'application/pdf'); res.setHeader('Content-Disposition', `attachment; filename="hotel-${req.query.mode || 'arrivals'}-${req.params.listingId}.pdf"`); res.send(buffer); } catch (error) { next(error); } }

module.exports = { createProperty, createRoomType, createRoomUnits, createInventory, updateInventoryStatus, checkIn, checkOut, manifest, manifestCsv, manifestPdf };
