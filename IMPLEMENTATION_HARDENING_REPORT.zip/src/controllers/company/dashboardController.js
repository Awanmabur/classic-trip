const store = require('../../services/data/persistentStore');
const billingService = require('../../services/billing/billingService');
const { buildDashboardShell } = require('../../services/dashboard/shellConfig');
const mongoDashboardService = require('../../services/dashboard/mongoDashboardService');

async function index(req, res, next) {
  try {
    const companyId = req.session?.user?.companyId || 'company-01';
    const baseDashboardData = await mongoDashboardService.roleDashboard('company', { companyId });
    const dashboardData = {
      ...baseDashboardData,
      billing: billingService.companyBillingSummary(companyId),
    };
    const companies = await mongoDashboardService.listEntity('companies', {}, { limit: 100 });
    const notifications = await mongoDashboardService.listEntity('notifications', { $or: [{ ownerType: 'company' }, { audience: 'partners' }] }, { limit: 250 });
    res.render('dashboards/company/index', {
      seo: { title: `${dashboardData.serviceProfile?.dashboardLabel || 'Company'} dashboard | Classic Trip` },
      dashboardData,
      dashboardShell: buildDashboardShell('company', {
        user: req.session?.user,
        companyId,
        company: dashboardData.company,
        serviceProfile: dashboardData.serviceProfile,
        companies: companies.length ? companies : store.state.companies,
        notificationCount: notifications.length || store.state.notifications?.filter((note) => note.ownerType === 'company' || note.audience === 'partners').length || 0,
      }),
    });
  } catch (error) {
    next(error);
  }
}
module.exports = { index };
