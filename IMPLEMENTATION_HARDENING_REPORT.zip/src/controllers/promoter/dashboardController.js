const store = require('../../services/data/persistentStore');
const { buildDashboardShell } = require('../../services/dashboard/shellConfig');
const mongoDashboardService = require('../../services/dashboard/mongoDashboardService');

async function index(req, res, next) {
  try {
    const promoterId = req.session?.user?.id || 'user-promoter-001';
    const dashboardData = await mongoDashboardService.roleDashboard('promoter', { promoterId });
    res.render('dashboards/promoter/index', {
      seo: { title: 'Promoter dashboard | Classic Trip' },
      dashboardData,
      dashboardShell: buildDashboardShell('promoter', {
        user: req.session?.user,
        notificationCount: store.state.notifications?.filter((note) => note.ownerId === promoterId || note.ownerType === 'promoter').length || 0,
      }),
    });
  } catch (error) {
    next(error);
  }
}
module.exports = { index };
