const store = require('../../services/data/persistentStore');
const { buildDashboardShell } = require('../../services/dashboard/shellConfig');
const mongoDashboardService = require('../../services/dashboard/mongoDashboardService');

async function index(req, res, next) {
  try {
    const companyId = req.session?.user?.companyId || 'company-01';
    const dashboardData = await mongoDashboardService.roleDashboard('employee', { companyId });
    res.render('dashboards/employee/index', {
      seo: { title: 'Employee dashboard | Classic Trip' },
      dashboardData,
      dashboardShell: buildDashboardShell('employee', {
        user: req.session?.user,
        companyId,
        companies: store.state.companies,
        notificationCount: store.state.notifications?.length || 0,
      }),
    });
  } catch (error) {
    next(error);
  }
}
module.exports = { index };
