const store = require('../../services/data/persistentStore');
const companyService = require('../../services/company/companyService');
const bookingService = require('../../services/booking/bookingService');
const { buildDashboardShell } = require('../../services/dashboard/shellConfig');
const mongoDashboardService = require('../../services/dashboard/mongoDashboardService');

function companyId(req) {
  return req.session?.user?.companyId || req.body.companyId || 'company-01';
}

function actorId(req) {
  return req.session?.user?.id || 'driver-system';
}

async function driverDashboard(req, res, next) {
  try {
    const dashboardData = await mongoDashboardService.roleDashboard('driver', {
      companyId: companyId(req),
      employeeId: actorId(req),
    });
    res.render('dashboards/employee/index', {
      seo: { title: 'Driver dashboard | Classic Trip' },
      dashboardData,
      dashboardMode: 'driver',
      dashboardShell: buildDashboardShell('driver', {
        user: req.session?.user,
        companyId: companyId(req),
        companies: store.state.companies,
        notificationCount: store.state.notifications?.length || 0,
      }),
    });
  } catch (error) {
    next(error);
  }
}

async function updateTripStatus(req, res, next) {
  try {
    await companyService.updateTripStatus(companyId(req), req.params.scheduleId, req.body, actorId(req));
    res.redirect('/driver/dashboard#driver-ops');
  } catch (error) {
    next(error);
  }
}

async function createIncident(req, res, next) {
  try {
    await companyService.createDriverIncident(companyId(req), req.body, actorId(req));
    res.redirect('/driver/dashboard#driver-incidents');
  } catch (error) {
    next(error);
  }
}

async function bookingAssist(req, res, next) {
  try {
    const action = String(req.body.action || '').toLowerCase();
    if (action === 'check_in') {
      await bookingService.validateTicket(req.params.bookingRef, actorId(req), companyId(req), {
        actorRole: req.session?.user?.role || 'company_employee',
        source: 'driver_assist',
        note: req.body.note || '',
      });
    } else if (action === 'no_show') {
      await bookingService.markNoShow(req.params.bookingRef, actorId(req), companyId(req), req.body.note || '');
    } else {
      store.state.supportTickets.push({
        id: `support-${store.state.supportTickets.length + 1}`,
        companyId: companyId(req),
        bookingRef: req.params.bookingRef,
        ownerType: 'company',
        subject: 'Driver assistance note',
        message: req.body.note || 'Driver assistance note',
        priority: 'normal',
        status: 'open',
        createdBy: actorId(req),
        createdAt: new Date().toISOString(),
      });
    }
    res.redirect(`/driver/tickets/${encodeURIComponent(req.params.bookingRef)}`);
  } catch (error) {
    next(error);
  }
}

module.exports = {
  driverDashboard,
  updateTripStatus,
  createIncident,
  bookingAssist,
};
