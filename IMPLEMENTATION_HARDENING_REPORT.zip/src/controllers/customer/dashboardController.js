const store = require('../../services/data/persistentStore');
const { buildDashboardShell } = require('../../services/dashboard/shellConfig');
const mongoDashboardService = require('../../services/dashboard/mongoDashboardService');

async function index(req, res, next) {
  try {
    const customerId = req.session?.user?.id || 'user-customer-001';
    const dashboardData = await mongoDashboardService.roleDashboard('customer', { customerId });
    res.render('dashboards/customer/index', {
      seo: { title: 'Customer dashboard | Classic Trip' },
      dashboardData,
      dashboardShell: buildDashboardShell('customer', {
        user: req.session?.user,
        notificationCount: store.state.notifications?.filter((note) => note.ownerId === customerId || note.ownerType === 'customer').length || 0,
      }),
    });
  } catch (error) {
    next(error);
  }
}
module.exports = { index };
