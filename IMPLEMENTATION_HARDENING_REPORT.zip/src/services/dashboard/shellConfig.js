const { getDashboardMenu } = require('../../config/dashboardMenus');

const ROLE_SWITCH_TARGETS = [
  { key: 'admin', role: 'super_admin', label: 'Super Admin', href: '/admin' },
  { key: 'company', role: 'company_admin', label: 'Company Workspace', href: '/company/dashboard' },
  { key: 'driver', role: 'driver', label: 'Driver', href: '/driver/dashboard' },
  { key: 'employee', role: 'company_employee', label: 'Company Staff', href: '/employee/dashboard' },
  { key: 'customer', role: 'customer', label: 'Customer', href: '/account' },
  { key: 'promoter', role: 'promoter', label: 'Promoter / Agent', href: '/promoter/dashboard' },
  { key: 'support', role: 'support_agent', label: 'Support', href: '/support/dashboard' },
  { key: 'finance', role: 'finance_agent', label: 'Finance', href: '/finance/dashboard' },
  { key: 'operations', role: 'operations_agent', label: 'Operations', href: '/operations/dashboard' },
];

function initials(name = '') {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return 'CT';
  return parts.slice(0, 2).map((part) => part[0]?.toUpperCase()).join('') || 'CT';
}

function roleSetFor(user = {}, requestedRole) {
  const explicit = Array.isArray(user.roles) ? user.roles : [];
  const base = user.role ? [user.role] : [];
  const combined = Array.from(new Set([...explicit, ...base]));
  if (combined.includes('super_admin')) return ROLE_SWITCH_TARGETS.map((target) => target.role);
  if (!combined.length && requestedRole) combined.push(requestedRole);
  return combined;
}

function cloneMenu(menu = {}) {
  return {
    ...menu,
    groups: (menu.groups || []).map((group) => ({
      ...group,
      items: (group.items || []).map((item) => ({ ...item })),
    })),
  };
}

function applyCompanyServiceProfile(menu, serviceProfile = {}, company = {}) {
  const visiblePages = new Set(serviceProfile.visiblePages || []);
  const pageMeta = serviceProfile.pageMeta || {};
  const itemLabels = {
    listings: serviceProfile.supportsHotel && !serviceProfile.supportsBus ? 'Rooms & Rates' : serviceProfile.supportsBus ? 'Routes & Inventory' : 'Services',
    routes: serviceProfile.supportsFlight && !serviceProfile.supportsBus ? 'Flight Routes' : 'Routes',
    vehicles: serviceProfile.supportsFlight && !serviceProfile.supportsBus ? 'Aircraft & Fleet' : 'Vehicles',
    schedules: serviceProfile.supportsFlight && !serviceProfile.supportsBus ? 'Flight Schedules' : 'Schedules',
    checkins: serviceProfile.supportsHotel && !serviceProfile.supportsBus ? 'Guest Check-ins' : 'Check-ins',
    seatrooms: serviceProfile.inventoryLabel || 'Inventory',
  };
  const groups = (menu.groups || []).map((group) => ({
    ...group,
    items: (group.items || [])
      .filter((item) => !visiblePages.size || visiblePages.has(item.page))
      .map((item) => ({ ...item, label: itemLabels[item.page] || item.label })),
  })).filter((group) => group.items.length);
  const title = pageMeta.overview?.[0] || `${serviceProfile.dashboardLabel || 'Company'} Dashboard`;
  const subtitle = pageMeta.overview?.[1] || menu.subtitle;
  return {
    ...menu,
    groups,
    label: serviceProfile.dashboardLabel || menu.label,
    consoleName: serviceProfile.consoleName || menu.consoleName,
    title,
    subtitle,
    profileName: company.name || menu.profileName,
    profileMeta: serviceProfile.primaryLabel ? `${serviceProfile.primaryLabel} partner` : menu.profileMeta,
    statusLabel: company.verificationStatus === 'verified' ? 'Verified' : company.verificationStatus || menu.statusLabel,
    createLabel: serviceProfile.supportsHotel && !serviceProfile.supportsBus ? 'Add Room' : serviceProfile.supportsBus ? 'Add Trip' : menu.createLabel,
  };
}

function buildDashboardShell(requestedRole, options = {}) {
  const user = options.user || {};
  let menu = cloneMenu(getDashboardMenu(requestedRole));
  if (menu.roleKey === 'company' && options.serviceProfile) {
    menu = applyCompanyServiceProfile(menu, options.serviceProfile, options.company || {});
  }
  const userName = user.fullName || user.name || menu.profileName;
  const roles = roleSetFor(user, requestedRole);
  const roleSwitcher = ROLE_SWITCH_TARGETS
    .filter((target) => roles.includes(target.role) || target.key === menu.roleKey)
    .map((target) => ({ ...target, active: target.key === menu.roleKey }));
  const companies = options.companies || [];
  const notificationCount = Number(options.notificationCount ?? options.notifications?.length ?? 0) || 0;

  return {
    ...menu,
    currentRole: menu.roleKey,
    userName,
    profileName: userName,
    profileMeta: user.email || menu.profileMeta,
    avatar: initials(userName || menu.profileName || menu.label),
    notificationCount,
    roleSwitcher,
    companies,
    currentCompanyId: user.companyId || options.companyId || '',
    breadcrumbs: options.breadcrumbs || [menu.consoleName || menu.label],
    activePage: options.activePage || 'overview',
  };
}

module.exports = { buildDashboardShell };
