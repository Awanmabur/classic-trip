const PDFDocument = require('pdfkit');
const store = require('../data/persistentStore');
const generateBookingRef = require('../../utils/generateBookingRef');
const calculateCommission = require('../../utils/calculateCommission');
const repositories = require('../../repositories');

function ensureCollections() {
  ['hotelProperties', 'roomTypes', 'roomUnits', 'roomNightInventories', 'stayRules', 'bookings', 'payments', 'notifications', 'auditLogs'].forEach((key) => {
    if (!Array.isArray(store.state[key])) store.state[key] = [];
  });
}

function clean(value, fallback = '') { return String(value ?? fallback).trim(); }
function num(value, fallback = 0) { const n = Number(value); return Number.isFinite(n) ? n : fallback; }
function list(value) {
  if (Array.isArray(value)) return value.map((v) => clean(v)).filter(Boolean);
  return String(value || '').split(/[,\n]/).map((v) => clean(v)).filter(Boolean);
}
function nextId(prefix, rows) { return `${prefix}-${String((rows || []).length + 1).padStart(4, '0')}`; }
function isoDate(value) { return new Date(value).toISOString().slice(0, 10); }
function dateRange(checkIn, checkOut) {
  const start = new Date(`${isoDate(checkIn)}T00:00:00.000Z`);
  const end = new Date(`${isoDate(checkOut)}T00:00:00.000Z`);
  if (!(end > start)) {
    const error = new Error('Check-out must be after check-in');
    error.status = 422;
    throw error;
  }
  const days = [];
  for (let d = new Date(start); d < end; d.setUTCDate(d.getUTCDate() + 1)) days.push(d.toISOString().slice(0, 10));
  return days;
}
async function upsert(entity, row) {
  if (repositories.mongoReady && repositories[entity]) await repositories[entity].upsert(row);
}
function companyOrThrow(companyId) {
  const company = store.findCompany(companyId);
  if (!company) { const error = new Error('Company not found'); error.status = 404; throw error; }
  return company;
}
function hotelListingOrThrow(companyId, listingId) {
  const listing = store.state.listings.find((item) => (item.id === listingId || item.slug === listingId) && item.companyId === companyId);
  if (!listing || listing.serviceType !== 'hotel') { const error = new Error('Hotel listing not found'); error.status = 404; throw error; }
  return listing;
}
function inventoryById(id, companyId) {
  const night = store.state.roomNightInventories.find((item) => item.id === id && (!companyId || item.companyId === companyId));
  if (!night) { const error = new Error('Room-night inventory not found'); error.status = 404; throw error; }
  return night;
}

async function createProperty(companyId, payload = {}, actorId = 'company-admin') {
  ensureCollections();
  companyOrThrow(companyId);
  const listing = hotelListingOrThrow(companyId, payload.listingId || payload.slug);
  const property = {
    id: nextId('hotel-property', store.state.hotelProperties),
    companyId,
    listingId: listing.id,
    propertyName: clean(payload.propertyName || payload.name || listing.title),
    address: clean(payload.address || listing.address),
    city: clean(payload.city || listing.city),
    country: clean(payload.country || listing.country || 'Uganda'),
    mapLocation: clean(payload.mapLocation || payload.location || ''),
    checkInTime: clean(payload.checkInTime || listing.checkInTime || '14:00'),
    checkOutTime: clean(payload.checkOutTime || listing.checkOutTime || '10:00'),
    amenities: list(payload.amenities || listing.amenities),
    policies: list(payload.policies || listing.policy),
    taxesAndFees: list(payload.taxesAndFees).map((fee) => ({ label: fee, amount: 0 })),
    status: clean(payload.status || 'active'),
    createdBy: actorId,
    createdAt: new Date().toISOString(),
  };
  listing.address = property.address || listing.address;
  listing.city = property.city || listing.city;
  listing.country = property.country || listing.country;
  listing.checkInTime = property.checkInTime;
  listing.checkOutTime = property.checkOutTime;
  listing.amenities = property.amenities;
  store.state.hotelProperties.push(property);
  await upsert('hotelProperties', property);
  await upsert('listings', listing);
  return property;
}

async function createRoomType(companyId, payload = {}, actorId = 'company-admin') {
  ensureCollections();
  const listing = hotelListingOrThrow(companyId, payload.listingId || payload.slug);
  const property = payload.propertyId ? store.state.hotelProperties.find((item) => item.id === payload.propertyId && item.companyId === companyId) : store.state.hotelProperties.find((item) => item.listingId === listing.id);
  const roomType = {
    id: nextId('room-type', store.state.roomTypes),
    companyId,
    listingId: listing.id,
    propertyId: property?.id || '',
    name: clean(payload.name || payload.roomType || 'Standard Room'),
    capacity: Math.max(1, Math.round(num(payload.capacity, 2))),
    basePrice: Math.max(0, num(payload.basePrice || payload.nightlyPrice || listing.priceFrom, 0)),
    amenities: list(payload.amenities),
    policies: list(payload.policies),
    taxesAndFees: list(payload.taxesAndFees).map((fee) => ({ label: fee, amount: 0 })),
    status: clean(payload.status || 'active'),
    createdBy: actorId,
    createdAt: new Date().toISOString(),
  };
  store.state.roomTypes.push(roomType);
  const legacyRoom = {
    id: nextId('room', store.state.rooms),
    listingId: listing.id,
    companyId,
    roomType: roomType.name,
    roomTypeId: roomType.id,
    propertyId: roomType.propertyId,
    capacity: roomType.capacity,
    nightlyPrice: roomType.basePrice,
    inventory: Math.max(1, Math.round(num(payload.defaultInventory, 1))),
    amenities: roomType.amenities,
    status: roomType.status,
    createdAt: roomType.createdAt,
  };
  store.state.rooms.push(legacyRoom);
  roomType.roomId = legacyRoom.id;
  listing.priceFrom = Math.min(...store.roomsForListing(listing.id).map((room) => Number(room.nightlyPrice || listing.priceFrom)).filter(Boolean));
  listing.price = listing.priceFrom;
  await upsert('roomTypes', roomType);
  await upsert('rooms', legacyRoom);
  await upsert('listings', listing);
  return { roomType, room: legacyRoom };
}

async function createRoomUnits(companyId, payload = {}, actorId = 'company-admin') {
  ensureCollections();
  const roomType = store.state.roomTypes.find((item) => item.id === payload.roomTypeId && item.companyId === companyId);
  if (!roomType) { const error = new Error('Room type not found'); error.status = 404; throw error; }
  const existingUnitCount = store.state.roomUnits.length;
  const units = list(payload.unitNumbers || payload.units || payload.roomNumbers).map((unitNumber, index) => ({
    id: `room-unit-${String(existingUnitCount + index + 1).padStart(4, '0')}`,
    companyId,
    listingId: roomType.listingId,
    propertyId: roomType.propertyId,
    roomTypeId: roomType.id,
    roomId: roomType.roomId,
    unitNumber,
    floor: clean(payload.floor || ''),
    wing: clean(payload.wing || ''),
    status: clean(payload.status || 'available'),
    housekeepingStatus: clean(payload.housekeepingStatus || 'clean'),
    notes: clean(payload.notes || ''),
    createdBy: actorId,
    createdAt: new Date().toISOString(),
  }));
  units.forEach((unit) => store.state.roomUnits.push(unit));
  const legacyRoom = store.state.rooms.find((room) => room.id === roomType.roomId);
  if (legacyRoom) legacyRoom.inventory = store.state.roomUnits.filter((unit) => unit.roomTypeId === roomType.id && unit.status !== 'archived').length;
  await Promise.all(units.map((unit) => upsert('roomUnits', unit)));
  if (legacyRoom) await upsert('rooms', legacyRoom);
  return units;
}

async function createNightInventory(companyId, payload = {}, actorId = 'company-admin') {
  ensureCollections();
  const roomType = store.state.roomTypes.find((item) => item.id === payload.roomTypeId && item.companyId === companyId);
  if (!roomType) { const error = new Error('Room type not found'); error.status = 404; throw error; }
  const nights = dateRange(payload.startDate || payload.checkIn, payload.endDate || payload.checkOut);
  const units = payload.roomUnitIds ? list(payload.roomUnitIds).map((id) => store.state.roomUnits.find((unit) => unit.id === id && unit.companyId === companyId)).filter(Boolean) : store.state.roomUnits.filter((unit) => unit.roomTypeId === roomType.id && unit.status !== 'archived');
  if (!units.length) { const error = new Error('At least one room unit is required'); error.status = 422; throw error; }
  const rows = [];
  units.forEach((unit) => {
    nights.forEach((date) => {
      let row = store.state.roomNightInventories.find((item) => item.roomUnitId === unit.id && item.date === date);
      if (!row) {
        row = {
          id: nextId('room-night', store.state.roomNightInventories),
          companyId,
          listingId: roomType.listingId,
          propertyId: roomType.propertyId,
          roomTypeId: roomType.id,
          roomUnitId: unit.id,
          roomId: roomType.roomId,
          date,
          price: Math.max(0, num(payload.price || payload.nightlyPrice || roomType.basePrice, roomType.basePrice)),
          status: clean(payload.status || 'available'),
          createdBy: actorId,
          createdAt: new Date().toISOString(),
        };
        store.state.roomNightInventories.push(row);
      } else {
        row.price = Math.max(0, num(payload.price || payload.nightlyPrice || row.price, row.price));
        row.status = clean(payload.status || row.status);
        row.updatedAt = new Date().toISOString();
      }
      rows.push(row);
    });
  });
  await Promise.all(rows.map((row) => upsert('roomNightInventories', row)));
  return rows;
}

async function updateNightStatus(companyId, inventoryId, payload = {}, actorId = 'company-admin') {
  ensureCollections();
  const allowed = ['available', 'held', 'booked', 'occupied', 'checked-in', 'checked-out', 'maintenance', 'cleaning', 'cancelled', 'refunded', 'reserved'];
  const night = inventoryById(inventoryId, companyId);
  const status = clean(payload.status || night.status);
  if (!allowed.includes(status)) { const error = new Error('Invalid room-night status'); error.status = 422; throw error; }
  night.status = status;
  night.notes = clean(payload.notes || night.notes || '');
  night.updatedBy = actorId;
  night.updatedAt = new Date().toISOString();
  const unit = store.state.roomUnits.find((item) => item.id === night.roomUnitId);
  if (unit && ['maintenance', 'cleaning', 'occupied', 'available'].includes(status)) {
    unit.status = status === 'occupied' ? 'occupied' : status;
    if (payload.housekeepingStatus) unit.housekeepingStatus = clean(payload.housekeepingStatus);
    unit.updatedAt = night.updatedAt;
    await upsert('roomUnits', unit);
  }
  await upsert('roomNightInventories', night);
  store.state.auditLogs.unshift({ id: nextId('audit', store.state.auditLogs), actorId, action: 'hotel.room_night.status', targetType: 'roomNightInventory', targetId: night.id, createdAt: new Date().toISOString(), meta: { status } });
  return night;
}

function availableNightGroups(listingId, checkIn, checkOut, roomTypeId = '') {
  const nights = dateRange(checkIn, checkOut);
  const all = store.state.roomNightInventories.filter((night) => night.listingId === listingId && (!roomTypeId || night.roomTypeId === roomTypeId) && nights.includes(night.date));
  const byUnit = new Map();
  all.forEach((night) => {
    if (!byUnit.has(night.roomUnitId)) byUnit.set(night.roomUnitId, []);
    byUnit.get(night.roomUnitId).push(night);
  });
  return Array.from(byUnit.values()).filter((rows) => rows.length === nights.length && rows.every((night) => night.status === 'available' || night.status === 'reserved'));
}

async function createHotelBooking(payload = {}, req = {}) {
  ensureCollections();
  const listing = store.findListing(payload.listingId || payload.slug, 'hotel') || store.state.listings.find((item) => item.id === payload.listingId && item.serviceType === 'hotel');
  if (!listing) { const error = new Error('Hotel listing not found'); error.status = 404; throw error; }
  const checkIn = isoDate(payload.checkInDate || payload.checkIn || payload.startDate);
  const checkOut = isoDate(payload.checkOutDate || payload.checkOut || payload.endDate);
  const nights = dateRange(checkIn, checkOut);
  const roomCount = Math.max(1, Math.round(num(payload.roomCount || payload.rooms, 1)));
  const roomTypeId = clean(payload.roomTypeId || '');
  const groups = availableNightGroups(listing.id, checkIn, checkOut, roomTypeId).slice(0, roomCount);
  if (groups.length < roomCount) { const error = new Error('Not enough room-night inventory available'); error.status = 409; throw error; }
  let guests = [];
  try { guests = JSON.parse(payload.guests || payload.guestDetails || '[]'); } catch (error) { guests = []; }
  if (!Array.isArray(guests) || !guests.length) guests = [{ fullName: payload.fullName || 'Hotel Guest', email: payload.email, phone: payload.phone }];
  const selectedRows = groups.flat();
  const subtotal = selectedRows.reduce((total, night) => total + Number(night.price || listing.priceFrom || 0), 0);
  const fees = Math.round(subtotal * 0.045 + 3500);
  const total = subtotal + fees;
  const split = calculateCommission(total, false);
  const bookingRef = generateBookingRef('hotel');
  const roomUnits = groups.map((rows) => store.state.roomUnits.find((unit) => unit.id === rows[0].roomUnitId) || {});
  const roomTypes = groups.map((rows) => store.state.roomTypes.find((type) => type.id === rows[0].roomTypeId) || {});
  selectedRows.forEach((night) => {
    night.status = 'booked';
    night.bookingRef = bookingRef;
    night.guestName = payload.fullName || guests[0]?.fullName || 'Hotel Guest';
    night.checkInStatus = 'not_checked';
    night.updatedAt = new Date().toISOString();
  });
  const bookingItems = groups.map((rows, index) => ({
    id: `hotel-room-${index + 1}`,
    serviceType: 'hotel',
    listingId: listing.id,
    roomTypeId: rows[0].roomTypeId,
    roomUnitId: rows[0].roomUnitId,
    roomNumber: roomUnits[index]?.unitNumber || '',
    checkIn,
    checkOut,
    nights: rows.map((night) => night.date),
    price: rows.reduce((totalRow, night) => totalRow + Number(night.price || 0), 0),
    status: 'confirmed',
  }));
  const ticketLegs = bookingItems.map((item, index) => ({
    id: `${bookingRef}-ROOM-${index + 1}`,
    serviceType: 'hotel',
    legType: 'stay',
    roomUnitId: item.roomUnitId,
    roomNumber: item.roomNumber,
    checkIn,
    checkOut,
    qrCodeValue: `CLASSIC-TRIP:HOTEL:${bookingRef}:${item.roomUnitId}:${Date.now()}`,
    status: 'confirmed',
  }));
  const booking = {
    id: nextId('booking', store.state.bookings),
    bookingRef,
    serviceType: 'hotel',
    guestSnapshot: { fullName: payload.fullName || guests[0]?.fullName || 'Hotel Guest', email: payload.email || guests[0]?.email || 'guest@example.com', phone: payload.phone || guests[0]?.phone || '+256700000000' },
    customerUserId: payload.customerUserId || req?.session?.user?.id || null,
    companyId: listing.companyId,
    listingId: listing.id,
    passengers: groups.map((rows, index) => ({ id: `guest-${index + 1}`, fullName: guests[index]?.fullName || guests[0]?.fullName || payload.fullName || 'Hotel Guest', email: guests[index]?.email || payload.email, phone: guests[index]?.phone || payload.phone, seatOrRoom: roomUnits[index]?.unitNumber || roomTypes[index]?.name || 'Room', roomNumber: roomUnits[index]?.unitNumber || '', roomType: roomTypes[index]?.name || '' })),
    bookingItems,
    ticketLegs,
    hotelStay: { checkIn, checkOut, nights, roomCount, roomUnitIds: roomUnits.map((unit) => unit.id).filter(Boolean), roomTypeIds: roomTypes.map((type) => type.id).filter(Boolean), status: 'booked' },
    pricing: { subtotal, fees, addonTotal: 0, total, currency: listing.currency || 'UGX', split },
    paymentStatus: payload.paymentStatus || 'successful',
    bookingStatus: payload.bookingStatus || 'confirmed',
    qrCodeValue: `CLASSIC-TRIP:${bookingRef}:${listing.id}:${Date.now()}`,
    createdAt: new Date().toISOString(),
  };
  store.state.bookings.unshift(booking);
  store.state.payments.unshift({ id: nextId('payment', store.state.payments), bookingId: booking.id, bookingRef, amount: total, currency: booking.pricing.currency, status: booking.paymentStatus, provider: payload.paymentProvider || 'Classic Trip Payments', createdAt: booking.createdAt });
  store.state.notifications.unshift({ id: nextId('notification', store.state.notifications), userId: booking.customerUserId || 'guest', title: 'Hotel booking confirmed', message: `${bookingRef} is confirmed for ${checkIn} to ${checkOut}.`, status: 'queued', createdAt: booking.createdAt });
  store.state.auditLogs.unshift({ id: nextId('audit', store.state.auditLogs), actorId: req?.session?.user?.id || 'guest', action: 'hotel.booking.created', targetType: 'booking', targetId: bookingRef, createdAt: booking.createdAt });
  await Promise.all(selectedRows.map((night) => upsert('roomNightInventories', night)));
  await upsert('bookings', booking);
  await upsert('payments', store.state.payments[0]);
  return booking;
}

function roomMap(companyId, listingId, startDate, endDate) {
  ensureCollections();
  const listing = hotelListingOrThrow(companyId, listingId);
  const dates = startDate && endDate ? dateRange(startDate, endDate) : [];
  const units = store.state.roomUnits.filter((unit) => unit.companyId === companyId && unit.listingId === listing.id && unit.status !== 'archived');
  return units.map((unit) => {
    const roomType = store.state.roomTypes.find((type) => type.id === unit.roomTypeId) || {};
    const nights = store.state.roomNightInventories.filter((night) => night.roomUnitId === unit.id && (!dates.length || dates.includes(night.date))).sort((a, b) => a.date.localeCompare(b.date));
    const activeNight = nights.find((night) => ['booked', 'occupied', 'checked-in', 'held', 'maintenance', 'cleaning', 'reserved'].includes(night.status)) || nights[0];
    return [roomType.name || 'Room', unit.unitNumber, nights.map((night) => `${night.date}:${night.status}`).join(' | ') || unit.status, activeNight?.bookingRef || '-', activeNight?.guestName || '-', activeNight?.status || unit.status, { entity: 'room_night', id: activeNight?.id || unit.id, label: unit.unitNumber, status: activeNight?.status || unit.status }];
  });
}

function manifestRows(companyId, listingId, mode = 'arrivals') {
  const listing = hotelListingOrThrow(companyId, listingId);
  const bookings = store.state.bookings.filter((booking) => booking.companyId === companyId && booking.listingId === listing.id && booking.serviceType === 'hotel');
  return bookings.filter((booking) => {
    const status = booking.hotelStay?.status || booking.bookingStatus;
    if (mode === 'in-house') return ['checked-in', 'occupied', 'in_house'].includes(status);
    if (mode === 'departures') return ['checked-in', 'occupied', 'confirmed', 'checked-out', 'completed'].includes(status) || booking.bookingStatus === 'completed';
    return ['confirmed', 'booked', 'checked-in', 'completed'].includes(booking.bookingStatus) || ['booked', 'checked-in', 'checked-out', 'completed'].includes(status);
  }).map((booking) => [booking.bookingRef, booking.guestSnapshot?.fullName || '-', (booking.passengers || []).map((guest) => guest.seatOrRoom).join(', '), booking.hotelStay?.checkIn || '-', booking.hotelStay?.checkOut || '-', booking.hotelStay?.status || booking.bookingStatus, { entity: 'hotel_booking', id: booking.bookingRef, label: booking.bookingRef, status: booking.bookingStatus }]);
}

async function markStay(companyId, bookingRef, status, actorId = 'company-admin') {
  ensureCollections();
  const booking = store.state.bookings.find((item) => item.bookingRef === bookingRef && item.companyId === companyId && item.serviceType === 'hotel');
  if (!booking) { const error = new Error('Hotel booking not found'); error.status = 404; throw error; }
  const normalized = status === 'check-in' ? 'checked-in' : status === 'check-out' ? 'checked-out' : status;
  booking.hotelStay = booking.hotelStay || {};
  booking.hotelStay.status = normalized;
  booking.bookingStatus = normalized === 'checked-out' ? 'completed' : normalized;
  const nightStatus = normalized === 'checked-in' ? 'occupied' : normalized;
  store.state.roomNightInventories.filter((night) => night.bookingRef === bookingRef).forEach((night) => { night.status = nightStatus; night.checkInStatus = normalized; night.updatedAt = new Date().toISOString(); });
  store.state.auditLogs.unshift({ id: nextId('audit', store.state.auditLogs), actorId, action: `hotel.stay.${normalized}`, targetType: 'booking', targetId: bookingRef, createdAt: new Date().toISOString() });
  await upsert('bookings', booking);
  return booking;
}

function toCsv(headers, rows) {
  const esc = (value) => { const text = String(value ?? ''); return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text; };
  return [headers, ...rows.map((row) => row.filter((cell) => typeof cell !== 'object'))].map((row) => row.map(esc).join(',')).join('\n');
}
async function pdfBuffer(title, rows) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: 'A4', margin: 36, info: { Title: title } });
    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);
    doc.fontSize(16).text(title, { underline: true });
    doc.moveDown();
    rows.forEach((row) => doc.fontSize(9).text(row.filter((cell) => typeof cell !== 'object').join(' | ')));
    doc.end();
  });
}

module.exports = { createProperty, createRoomType, createRoomUnits, createNightInventory, updateNightStatus, createHotelBooking, roomMap, manifestRows, markStay, toCsv, pdfBuffer };
