# Local Dashboard + Checkout UX Fix Report

## Fixed

### Local MongoDB checkout 500
- Added `MONGO_TRANSACTIONS=false` support for normal local MongoDB.
- Checkout no longer requires MongoDB replica-set transactions by default.
- Atomic single-document seat/room claims still run with `findOneAndUpdate` safeguards.
- Multi-document transactions can still be enabled for Atlas, mongos, or a replica set with `MONGO_TRANSACTIONS=true`.

### Dashboard navigation
- Added clearer marketplace operations navigation for admin/company areas.
- Company dashboard already contains Routes, Vehicles, Schedules, Bookings, Check-ins, and Service Inventory sections; this pass makes them easier to find.
- Admin dashboard now also exposes Routes, Vehicles, and Schedules shortcuts.

### Dashboard nav/search styling
- Added consistent rounded search styling to the shared dashboard topbar.
- Added matching admin dashboard topbar search styling.
- Sidebar dashboard subtitle now uses a simple `Workspace` label instead of repeating console titles.

### Removed duplicate dashboard title noise
- Replaced large default dashboard headings with the active page name.
- Hid repeated long dashboard subtitles from the top nav area.
- Admin sidebar no longer displays `Super Admin Console` as a repeated chrome title.

### Cleaner view/edit modals
- View modals now hide technical/internal fields such as ids, hashes, tokens, raw metadata, QR values, backend payloads, and internal arrays.
- View modals now show a smaller important-field subset.
- Field labels are cleaned up from backend key names into user-friendly labels.
- Edit buttons opened from a View modal now infer the correct entity and reuse the same important record fields instead of falling back to a generic edit form.

## Notes
- Production transaction support remains available with `MONGO_TRANSACTIONS=true`, but local standalone MongoDB should keep it false.
- Jest could not be re-run in this container because `node_modules`/`jest` are not installed here. Syntax check passed.

## Verification

```bash
npm run check
```

Passed.
