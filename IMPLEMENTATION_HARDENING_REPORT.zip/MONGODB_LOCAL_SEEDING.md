# Local MongoDB seeding for Classic Trip

This build now treats MongoDB as the real local data source by default.

## Local setup

1. Start MongoDB locally:

```bash
mongod --dbpath /path/to/your/mongo-data
```

or start MongoDB using your normal local service manager.

2. Confirm `.env` uses local MongoDB and demo memory fallback is off:

```env
DEMO_MODE=false
MONGO_URI=mongodb://127.0.0.1:27017/classic_trip
AUTO_SEED_MONGO=false
```

3. Install dependencies:

```bash
npm install
```

4. Seed the full reference seed dataset into MongoDB:

```bash
npm run seed:local
```

This runs a fresh seed and replaces the local reference seed database collections with Mongo-backed reference seed records.

5. Check seeded collection counts:

```bash
npm run seed:counts
```

6. Start the app:

```bash
npm run dev
```

## Optional startup seeding

To seed automatically only when the database is empty:

```env
AUTO_SEED_MONGO=true
AUTO_SEED_FORCE=false
```

To force reseeding on every startup, only for local development:

```env
AUTO_SEED_MONGO=true
AUTO_SEED_FORCE=true
```

Do not use forced auto-seeding in production because it clears and recreates reference seed data.

## What is seeded

The seed now creates real MongoDB rows for the public catalog, partner/company operations, bus operations, hotel inventory, carts, bookings, passengers, payments, payment intents, receipts, tax/fee records, support/correspondence, notifications, wallets, ledgers, settlement, payouts, reconciliation, promoter attribution, security records, subscriptions, reviews, and future-service architecture placeholders.

Expected generated dataset size from the seed builder is more than 6,000 records across the registered MongoDB models, including thousands of seat and room-night inventory records.
