# Classic Trip end-to-end hardening update

This build implements the first production-hardening pass across the frontend-to-backend booking/payment/ticket path and selected platform security gaps.

## Implemented in this build

### Booking, passenger, and payment persistence
- Booking persistence now stores booking items, booking legs, ticket legs, trip type, passengers, payment records, and payment intent records when MongoDB is connected.
- Passenger records now include booking reference, company/listing/schedule scope, passenger index, seat number, pickup/dropoff, and special notes.
- Payment initiation now creates a PaymentIntent before contacting the provider, then updates it with provider reference, checkout URL, final status, paidAt, or failure details.
- Failed payment initiation now cancels the booking, releases the hold, and returns seats/rooms back to inventory in memory and MongoDB when available.

### Seat and room inventory hardening
- Multi-seat hold flow now creates a real grouped inventory hold record, so the hold id passed from frontend checkout can be consumed by backend booking.
- Persisted booking finalization now marks every booked seat as taken, not only the first passenger seat.
- Schedule available-seat counters now decrement per schedule and per booked item, including multi-seat/round-trip booking items.
- Room holds now count active memory and MongoDB holds before accepting a new room hold.
- Hotel inventory decrement now checks inventory is greater than zero before decrementing in MongoDB.

### QR and scanner security
- Ticket legs no longer need to persist the raw QR token directly.
- Ticket QR values are derived for display/scanning from the booking ref, ticket-leg id, and QR nonce, while persistent lookup uses a SHA-256 hash.
- Scanner logs now store a SHA-256 hash of the scanned token instead of saving the full raw scanned QR value.
- Public ticket page still renders scannable QR codes, but scanner validation compares against hashes.

### Refund reversal workflow
- Refund approval now marks booking, ticket legs, and passengers as refunded for full refunds.
- Full refund approval releases unscanned bus seats back to inventory and increments schedule availability.
- Refund approval now persists refund and booking status updates to MongoDB when connected.
- Refund rejection now persists the rejected refund state to MongoDB when connected.

### Notifications and delivery audit
- Notification delivery attempts are now recorded separately in NotificationDeliveryAttempt records when MongoDB is connected.
- Each email/SMS/WhatsApp send attempt stores channel, recipient, provider, status, response/error, attemptedAt, and completedAt.

### API hardening
- Upload API is now protected by authenticated API access.
- Upload, delete, and signature endpoints now require one of: super_admin, admin, company_admin, company_employee, or promoter.
- Booking API read endpoint now requires a logged-in owner/company/admin user or matching contact query, and returns a safer limited public payload instead of the full booking object.

## Still not fully complete

This build does not claim full production readiness yet. Remaining high-priority items:

1. Install dependencies and run the full Jest/integration/acceptance test suite.
2. Replace remaining persistentStore/Mongo-first services outside the booking/payment/ticket core path.
3. Add true MongoDB transactions around multi-seat booking finalization and payment intent creation.
4. Add provider-specific webhook signature verification for MTN, Airtel, Flutterwave, Paystack, and DPO instead of only the Classic Trip HMAC wrapper.
5. Add full room-night inventory uniqueness for hotel bookings across date ranges.
6. Add browser E2E tests for search -> hold -> preview -> payment -> ticket -> scan -> refund.
7. Review every dashboard action for company-scope authorization at action level.
8. Feature-flag or hide every future-service checkout path that is not fully integrated.

## Verification in this container

- `npm run check` passed.
- Full `npm test` could not run because `node_modules` is not installed in this environment and `jest` is unavailable.
