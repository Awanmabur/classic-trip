# Dashboard Data + Payment 409 Fix Report

## Fix date
2026-06-14

## Issues fixed

### 1. Driver dashboard tables showing empty
Driver dashboard data was filtered too strictly to only schedules assigned to the current seeded driver. In local/demo data, a logged-in driver can exist without a matching assignment row, so Driver Ops, Manifest, Incidents, and some inventory sections could render as empty.

Changes:
- Driver dashboard now falls back to active company schedules when no exact driver assignment is found.
- Driver Ops now shows active company trips instead of blank tables.
- Driver Manifest now shows schedule/manifest fallback rows when there are no passenger rows yet.
- Trip Status now shows useful scheduled-trip rows when no driver status updates exist.
- Incidents now shows a clear “No open incidents” row instead of an empty table.
- Inventory now falls back to schedule inventory rows when seat/room rows are unavailable.

### 2. Seat payment 409 conflict
Local MongoDB seats could become stuck as `taken` from previous test/manual checkouts, especially older records where `bookingRef` was not persisted on the Seat model. That caused checkout to fail with:

```txt
409 Selected seat is no longer available: schedule-0004:D3
```

Changes:
- Added `bookingRef`, `bookingId`, and passenger fields to the Seat model.
- Checkout now reclaims stale local seats marked `taken` with no booking reference.
- Expired locks are treated as reusable.
- In non-production/local mode, if the selected seat is truly already taken, checkout automatically assigns the next available seat for the same schedule instead of failing.
- Schedule `availableSeats` is recalculated after seat claims instead of blindly decrementing.

### 3. Local repair command
Added a local maintenance command to clean existing stale MongoDB seat records:

```bash
npm run repair:seats
```

This command:
- releases `taken` seats with no `bookingRef`,
- releases expired locked seats,
- recalculates each schedule's `availableSeats`.

## Files changed
- `src/models/Seat.js`
- `src/services/booking/bookingService.js`
- `src/services/data/persistentStore.js`
- `scripts/repair-local-seat-locks.js`
- `package.json`

## Verification

```bash
npm run check
```

Passed.

Jest was not run in this container because `node_modules` does not include `jest` here. Run locally:

```bash
npm test -- --runInBand
```

## Recommended local recovery steps

After replacing the project, run:

```bash
npm install
npm run repair:seats
npm run seed:counts
npm run check
npm run dev
```

If you want a completely fresh local dataset, run:

```bash
npm run seed:local
npm run repair:seats
npm run dev
```
