# Test Failure Fix Report

This pass fixes the failures reported from the Jest run in `Pasted text(9).txt`.

## Root cause

After the `demoStore` removal pass, `persistentStore` became MongoDB-first but no longer populated the in-memory compatibility read model when Jest runs without a live Mongo seed. Existing integration tests and several runtime dashboard helpers still expect `store.state.users`, `store.state.companies`, `store.state.listings`, schedules, seats, hotels, promoter links, and future-service teaser records to be available immediately.

That empty read model caused the repeated failures such as:

- `Cannot read properties of undefined (reading 'id')`
- `Company not found`
- dashboard login checks returning `302` instead of `200` or `403`
- future-service roadmap returning empty launch categories

## Fixes applied

1. Added `loadSeedReadModel()` to `src/services/data/persistentStore.js`.
   - Uses the existing Mongo seed builder from `src/seeds/seedAll.js`.
   - Hydrates the compatibility read model only in `NODE_ENV=test` or when `SEED_READ_MODEL=true`.
   - Keeps production MongoDB-first behavior intact.

2. Added test fallback when Mongo hydration returns zero rows.
   - In tests, an empty DB now loads the seeded read model.
   - In production, an empty DB still remains empty unless explicitly seeded.

3. Fixed API test auth behavior.
   - `/api/uploads` now correctly returns `401` for unauthenticated test requests.
   - `/api/scanner/*` keeps the intended test helper identity so company-scope spoofing tests receive `403 company_scope_denied`.

4. Fixed company-scope JSON detection for mounted API routers.
   - Uses `req.originalUrl` as well as `req.path` so mounted `/api/*` routes return JSON errors correctly.

5. Fixed Paystack webhook normalization.
   - `metadata.bookingRef` and `metadata.custom_fields.booking_ref` now take priority over the provider transaction reference when setting `bookingRef`.
   - Provider transaction reference remains in `providerReference`.

## Verification here

Static syntax checks passed for the modified files:

- `src/services/data/persistentStore.js`
- `src/middlewares/apiAuth.js`
- `src/middlewares/companyAccess.js`
- `src/services/payment/webhookService.js`

Full Jest execution still requires local `node_modules` and your local Mongo/runtime setup.

## Run locally

```bash
npm install
npm run seed:local
npm run seed:counts
npm run check
npm test -- --runInBand
npm run dev
```
