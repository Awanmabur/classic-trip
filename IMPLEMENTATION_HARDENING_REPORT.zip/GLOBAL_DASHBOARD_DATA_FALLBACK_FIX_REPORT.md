# Global Dashboard Data Fallback Fix

## Problem
Some dashboard pages showed empty tables even though seeded/demo data existed. The issue was global, not only the driver dashboard: each dashboard view loaded default useful rows, then blindly ran `Object.assign(data, backendDashboardData)`. When a Mongo-backed dashboard query returned an empty array for a section, that empty array replaced the populated fallback rows and left the table blank.

## Fix
Updated all dashboard views to merge backend data safely:

- Admin dashboard
- Company dashboard
- Employee dashboard
- Driver dashboard, through the employee dashboard view
- Customer dashboard
- Promoter dashboard
- Support / Finance / Operations shells, through the admin dashboard view

The new merge behavior:

- Non-empty backend arrays replace fallback rows.
- Empty backend arrays no longer erase existing useful rows.
- Non-empty backend objects are merged or applied.
- Empty/null/undefined scalar values no longer erase visible values.

## Result
Dashboards now keep showing useful seeded/demo/runtime rows while still preferring real MongoDB data whenever it exists. This prevents blank tables across all dashboards after local seeding, partial seeding, or role-specific filtering.

## Verification
- Confirmed all dashboard views now use the safe merge helper.
- Ran syntax check with `npm run check`.
