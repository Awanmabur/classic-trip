# Global Dashboard Real Data Trace Fix

## Problem traced
The dashboard issue was not a missing table in one role. It was a shared data-pipeline problem:

1. Each dashboard page had large hardcoded demo `const data = { ... }` blocks in the browser script.
2. The Mongo dashboard service sometimes returned raw Mongo documents using keys like `bookings`, `listings`, `schedules`, etc.
3. The dashboard renderers expect formatted table rows from `persistentStore.dashboardData()`, not raw objects.
4. Empty Mongo arrays and raw Mongo documents caused sections to look blank, while the hardcoded client fallback caused repeated unrelated content across pages.

## Fixes applied
- Removed the hardcoded client-side demo data blocks from all dashboard EJS files:
  - Admin
  - Company
  - Employee / Driver
  - Customer
  - Promoter
- Changed the dashboard service to return formatted dashboard row data only.
- Stopped raw Mongo rows from overwriting formatted dashboard table rows.
- Mapped Support, Finance, and Operations dashboards to the admin dashboard data model so they receive full platform data.
- Added local development read-model fallback when the dashboard data store is empty, so local dashboards can still show seeded records after startup.
- Updated Employee, Driver, Customer, and Promoter dashboard controllers to use the shared dashboard service instead of bypassing it.

## Expected result
Dashboards now show data from the correct formatted dashboard model. They no longer reuse the same generic static content across unrelated pages, and blank tables caused by raw Mongo object rows are avoided.

## Recommended local reset
After applying this build, run:

```bash
npm install
npm run seed:local
npm run repair:seats
npm run seed:counts
npm run check
npm run dev
```

If MongoDB already contains old broken/partial records, use a fresh seed reset before judging dashboard data.
