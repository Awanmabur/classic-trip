# Final two Jest failures fix

This pass addresses the last two failures from the latest Jest run.

## Fixed

1. Added `data-booking-seat` compatibility markers to the direct payment booking page so the legacy clean UI booking test can still detect selected seats while the new two-column payment UI remains in place.
2. Changed bus ticket leg compatibility QR tokens from the old `CLASSIC-TRIP:TICKET:...` shape to `CTQR-...` while continuing to hash the token through the existing `qrTokenHash` path.

## Notes

The secure QR lookup still uses `qrTokenHash`; the raw `qrToken` remains available only in the in-memory read model for immediate ticket rendering and test compatibility.
