# Final Dashboard Cleanup Report

## Main issues traced

1. Vehicle rows were missing when a local MongoDB database already had schedules from an older seed but did not have matching vehicle documents. The previous inventory helper only created vehicles when schedules were missing, so dashboards could show schedules/routes but no vehicles.
2. Super Admin route, vehicle, and schedule tables existed but the shared renderer did not have dedicated render branches for those row shapes, so they could fall back to the generic booking renderer and look like duplicated or wrong content.
3. Employee/Driver dashboards did not expose vehicle and route pages, even though the data exists and is needed operationally.
4. View modals could show too many technical/backend fields, which made pages noisy and confusing.

## Fixes applied

- Reworked `ensureBookableInventory()` so every bookable bus listing gets a route, a vehicle, schedules, and seat rows even when only some of those collections already exist.
- Backfilled missing vehicle assignments onto existing schedules.
- Added seat rows for schedules that were missing generated seats.
- Added formatted dashboard rows for employee/driver `routes` and `vehicles`.
- Added Employee/Driver dashboard sidebar pages for Routes and Vehicles.
- Added Employee/Driver route and vehicle sections with focused columns.
- Added dedicated Super Admin renderers for Routes, Vehicles, and Schedules so those sections no longer render through the booking fallback.
- Kept Company Vehicles visible and connected to formatted vehicle rows.
- Cleaned dashboard detail modals to hide noisy technical values like tokens, hashes, secrets, raw payloads, signatures, cloudinary/public IDs, cookies, sessions, and long internal IDs.

## Verification performed

- `npm run check` passed.
- Dashboard data smoke check confirms formatted row counts:
  - Admin: vehicles, routes, schedules present.
  - Company: vehicles, routes, schedules present.
  - Employee: vehicles, routes, schedules present.
  - Driver: vehicles, routes, schedules present.
- Dashboard route check confirms sidebar buttons point to real sections, except `overview`, which is handled by the existing top dashboard block.

## Recommended local reset

Run this after replacing your project:

```bash
npm install
npm run seed:local
npm run repair:seats
npm run seed:counts
npm run check
npm run dev
```

Then hard refresh dashboards with `Ctrl + F5`.
