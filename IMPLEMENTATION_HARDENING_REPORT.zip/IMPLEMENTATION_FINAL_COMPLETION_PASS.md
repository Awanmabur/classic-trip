# Classic Trip Final Completion Pass

This pass continues from `classic_trip_production_completion_pass.zip` and focuses on the remaining production-readiness items that can be completed in the current codebase without external provider accounts or a running MongoDB service.

## Completed in this pass

### 1. Raw-body webhook support
- Express JSON and URL-encoded parsers now preserve `req.rawBody`.
- Payment webhooks pass the raw body into the webhook service.
- Provider signature checks can now validate signatures that require the exact original request body.

### 2. Provider-specific webhook contracts
- Added stricter provider signature verification for:
  - Paystack: `x-paystack-signature` using HMAC SHA-512 over the raw body.
  - Flutterwave: `verif-hash` direct secret match, with HMAC SHA-256 fallback for compatible integrations.
  - MTN/Airtel/DPO/generic providers: HMAC SHA-256 over the raw body.
- If a provider-specific webhook secret is configured, Classic Trip no longer accepts the internal fallback signature for that provider. This prevents a configured provider webhook from being bypassed by an internal test signature.

### 3. Webhook payload normalization
- Added `normalizeProviderPayload()` so incoming provider payloads are mapped into the Classic Trip fields:
  - `provider`
  - `bookingRef`
  - `providerReference`
  - `amount`
  - `currency`
  - `status`
  - `idempotencyKey`
- The normalizer supports common payload locations such as `payload.data`, `metadata`, `meta`, `tx_ref`, `reference`, and provider-specific nested values.

### 4. Webhook event audit persistence
- Added `PaymentWebhookEvent` model.
- Webhook events are now recorded with:
  - provider
  - provider reference
  - booking reference
  - idempotency key
  - signature status
  - processing status
  - amount/currency
  - raw payload
  - raw-body hash
  - failure reason when blocked
- Added repository mapping for `paymentWebhookEvents`.

### 5. Dashboard rendering moved further to Mongo-backed data
- Superadmin dashboard rendering now uses `mongoDashboardService.roleDashboard()`.
- Company dashboard rendering now uses `mongoDashboardService.roleDashboard()`.
- Shell notification/company counts now attempt Mongo reads first and fallback to hydrated state only when Mongo is not ready.

### 6. Company-scope route hardening
- Added `enforceCompanyScope` middleware.
- Company and employee/driver routes now reject attempts to submit another company’s `companyId`.
- API scanner and dashboard API routes now enforce company scoping for company roles.
- Superadmin/admin users remain allowed to pass explicit company scope for cross-company operations.

### 7. Final payment/security tests added
- Added unit tests for provider payload normalization and provider signature contracts.
- Added integration test for company scope spoofing rejection on scoped API routes.

### 8. Environment and documentation updates
- `.env.example` now includes provider webhook secrets for MTN, Airtel, Flutterwave, Paystack and DPO.
- `.env.example` now includes `JOB_EXPIRE_PAYMENT_INTENTS`.
- README was updated to remove the old demo-store language and document the MongoDB-first data layer.

## Verification completed in this environment

```bash
npm run check
```

Result: passed.

## Verification that still requires your local machine

The container does not include installed `node_modules`, so Jest could not be executed here. Run this locally after `npm install` and with MongoDB running:

```bash
npm install
npm run seed:local
npm run seed:counts
npm run check
npm test
npm run test:acceptance
npm run dev
```

## External items that still require real credentials/accounts

The code now has provider-specific webhook contracts and generic HTTP initiation support, but real payment completion still requires each provider’s production/sandbox account details:

- MTN Mobile Money API URL/key/secret
- Airtel Money API URL/key/secret
- Flutterwave API URL/key/webhook secret
- Paystack API URL/key/webhook secret
- DPO API URL/key/webhook secret

Final provider certification will require testing against each provider sandbox and adjusting any provider-specific request/response fields that differ from the generic contract.
