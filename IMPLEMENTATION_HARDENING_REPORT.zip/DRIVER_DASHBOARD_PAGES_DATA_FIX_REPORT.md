# Driver Dashboard Pages and Data Fix

## Fixed

- Added real dashboard sections for the config-driven menu pages:
  - `driver-ops`
  - `driver-manifest`
  - `driver-incidents`
- Driver Ops now renders assigned trips and trip status updates.
- Driver Manifest now renders passenger/check-in rows plus seat/inventory rows.
- Incidents now renders driver incident rows and includes a compact incident report form.
- Sidebar/hash navigation now opens those pages directly instead of showing a blank dashboard area.
- Added page metadata for Driver Ops, Driver Manifest, and Incidents so the topbar updates correctly.
- Allowed users with the `driver` role to access `/driver/*` routes.
- Improved driver incident data mapping so seeded/runtime fields such as `incidentType`, `notes`, `updatedAt`, and `updatedBy` display correctly.

## Verification

- `npm run check` passed.

## Notes

- If a dashboard still has no rows after this patch, run `npm run seed:local` and restart the server so the Mongo read model is hydrated before opening the dashboard.
