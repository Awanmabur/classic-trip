const { Schema, moneySchema, model } = require('./_helpers');
const { BOOKING_STATUSES } = require('../domain/statuses');

const passengerSnapshotSchema = new Schema({
  id: String,
  fullName: String,
  name: String,
  phone: String,
  email: String,
  identityType: String,
  identityNumber: String,
  nationality: String,
  sex: String,
  emergencyContactName: String,
  emergencyContactPhone: String,
  guestType: String,
  roomIndex: Number,
  seatOrRoom: String,
  seatNumber: String,
  roomNumber: String,
  roomType: String,
  roomTypeId: String,
  roomUnitId: String,
  scheduleId: String,
  legType: String,
  pickupPoint: String,
  dropoffPoint: String,
  specialNotes: String,
  specialRequests: String,
  travelNotes: String,
  checkInStatus: String,
  refundId: String,
}, { _id: false });

const bookingSchema = new Schema({
  id: { type: String, unique: true, sparse: true, index: true },
  bookingRef: { type: String, unique: true, required: true, index: true },
  guestLookupCode: { type: String, index: true },
  cartRef: { type: String, index: true },
  bookingGroupId: { type: String, index: true },
  bookingGroupRef: { type: String, index: true },
  serviceType: { type: String, required: true, index: true, enum: ['bus', 'hotel', 'flight', 'local_transport', 'tour', 'car_rental', 'cargo'] },
  guestSnapshot: Schema.Types.Mixed,
  buyerSnapshot: Schema.Types.Mixed,
  customerUserId: { type: String, index: true },
  companyId: { type: String, index: true },
  // Marketplace-owned services retain the operating supplier/agent/driver partner
  // separately from the platform tenant. These fields are required for tenant-safe
  // agency dashboards, driver assignment, commissions and settlement.
  supplierId: { type: String, index: true },
  agentCompanyId: { type: String, index: true },
  providerCompanyId: { type: String, index: true },
  tenantId: { type: String, index: true },
  tenantSlug: { type: String, index: true },
  listingId: { type: String, index: true },
  catalogId: { type: String, index: true },
  scheduleId: { type: String, index: true },
  tripId: { type: String, index: true },
  vehicleId: { type: String, index: true },
  // Immutable traveler snapshots captured at checkout; Passenger is the operational projection.
  passengers: [passengerSnapshotSchema],
  bookingItems: [Schema.Types.Mixed],
  bookingLegs: [Schema.Types.Mixed],
  ticketLegs: [Schema.Types.Mixed],
  hotelStay: Schema.Types.Mixed,
  serviceReservation: Schema.Types.Mixed,
  checkoutUrl: String,
  checkOutAt: Date,
  completedBy: String,
  tripType: { type: String, default: 'one_way', index: true, enum: ['one_way', 'round_trip', 'multi_service', 'single_service_cart'] },
  addons: [Schema.Types.Mixed],
  quantity: { type: Number, default: 1 },
  pricing: moneySchema,
  // Immutable partner commission contract used for this booking. Later platform or
  // company percentage changes must never rewrite historical settlement values.
  commercialTermsSnapshot: Schema.Types.Mixed,
  grossAmount: Number,
  walletUsed: { type: Number, default: 0 },
  promoterAttribution: Schema.Types.Mixed,
  referralCode: { type: String, index: true },
  risk: Schema.Types.Mixed,
  paymentStatus: { type: String, default: 'pending', index: true, enum: ['pending', 'successful', 'failed', 'expired', 'refunded'] },
  refundStatus: { type: String, index: true, enum: ['none', 'requested', 'partially_refunded', 'refunded', 'rejected'], default: 'none' },
  refundedAmount: { type: Number, default: 0, min: 0 },
  refundIds: [{ type: String, index: true }],
  paymentProvider: { type: String, enum: ['pesapal', 'mtn_momo', 'airtel_money', 'flutterwave', 'paystack', 'dpo', 'cash', 'bank_transfer', 'card', 'mobile_money'] },
  paymentRef: { type: String, index: true },
  paymentMethodNote: String,
  bookingChannel: { type: String, index: true, enum: ['web', 'mobile', 'agent_offline', 'admin_manual', 'company_manual'] },
  createdByAgentId: { type: String, index: true },
  agentSale: Schema.Types.Mixed,
  bookingStatus: { type: String, default: 'draft', index: true, enum: BOOKING_STATUSES },
  settlementStatus: { type: String, default: 'pending', index: true, enum: ['pending', 'pending_payment', 'pending_fulfillment', 'settled', 'eligible', 'reconciliation_required', 'refunded'] },
  settlementError: String,
  settledAt: Date,
  qrCodeValue: { type: String, index: true },
  ticketPdf: Schema.Types.Mixed,
  lockedUntil: Date,
  checkInStatus: { type: String, default: 'not_checked', index: true, enum: ['not_checked', 'pending', 'boarding', 'checked_in', 'partial', 'no_show', 'cancelled', 'refunded'] },
  checkedInAt: Date,
  checkedInBy: String,
  checkedInByUserId: { type: String, index: true },
  checkInNote: String,
  noShowAt: Date,
  noShowBy: String,
  noShowByUserId: { type: String, index: true },
  cancelReason: String,
  cancellationReason: String,
  cancelledAt: Date,
  completedAt: Date,
  earningsReleasedAt: Date,
  supplierPayableReleasedAt: Date,
  customerNote: String,
  notes: String,
  auditTrail: [Schema.Types.Mixed],
}, { timestamps: true });

bookingSchema.index({ bookingRef: 1, 'guestSnapshot.phone': 1 });
bookingSchema.index({ companyId: 1, bookingStatus: 1, paymentStatus: 1 });
bookingSchema.index({ agentCompanyId: 1, serviceType: 1, createdAt: -1 });
bookingSchema.index({ providerCompanyId: 1, serviceType: 1, createdAt: -1 });
bookingSchema.index({ supplierId: 1, serviceType: 1, createdAt: -1 });
bookingSchema.index({ companyId: 1, guestLookupCode: 1 });
bookingSchema.index({ companyId: 1, paymentRef: 1 });
bookingSchema.index({ customerUserId: 1, createdAt: -1 });
bookingSchema.index({ referralCode: 1, createdAt: -1 });
bookingSchema.index({ 'ticketLegs.qrTokenHash': 1 }, { sparse: true });
bookingSchema.index({ companyId: 1, scheduleId: 1, 'bookingItems.seatNumber': 1, bookingStatus: 1 });
module.exports = model('Booking', bookingSchema);
