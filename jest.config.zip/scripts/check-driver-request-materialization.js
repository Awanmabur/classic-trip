'use strict';

const Module = require('module');
const path = require('path');

let passed = 0;
function check(condition, message) {
  if (!condition) throw new Error(`FAIL: ${message}`);
  passed += 1;
}

function matches(row, filter = {}) {
  return Object.entries(filter).every(([key, expected]) => {
    if (key === '$or') return expected.some((item) => matches(row, item));
    const actual = row[key];
    if (expected && typeof expected === 'object' && !Array.isArray(expected)) {
      if ('$nin' in expected) return !expected.$nin.includes(actual);
      if ('$regex' in expected) return expected.$regex.test(String(actual || ''));
    }
    return String(actual ?? '') === String(expected ?? '');
  });
}

function collection(rows) {
  return {
    async findOne(filter = {}) { return rows.find((row) => matches(row, filter)) || null; },
    async save(row, filter = {}) {
      const index = rows.findIndex((item) => matches(item, filter));
      if (index >= 0) rows[index] = row;
      else rows.push(row);
      return row;
    },
    async list(filter = {}) { return rows.filter((row) => matches(row, filter)); },
    async count(filter = {}) { return rows.filter((row) => matches(row, filter)).length; },
  };
}

async function main() {
  const employees = [{
    id: 'driver-membership-1', companyId: 'company-1', userId: 'driver-user-1',
    roleTitle: 'Driver', serviceCategories: ['driver', 'bus'],
    permissions: ['manifest.view', 'checkin.assist', 'trip.status.update', 'incident.create'],
    licenseNumber: 'DL-1', safetyStatus: 'cleared', status: 'active', acceptedAt: new Date().toISOString(),
  }];
  const users = [{
    id: 'driver-user-1', companyId: 'company-1', role: 'driver', status: 'active',
    verificationStatus: 'company_verified', passwordHash: 'stored-hash', fullName: 'Partner Admin Activated Driver',
  }];
  const repository = {
    employees: collection(employees), users: collection(users),
    async audit() { return null; },
  };

  const originalLoad = Module._load;
  Module._load = function patchedLoad(request, parent, isMain) {
    const parentFile = String(parent?.filename || '');
    if (parentFile.endsWith(path.join('bus', 'services', 'busDepartureService.js'))) {
      if (request === '../repositories/busRepository') return repository;
      if (request === './busSetupService') return {};
    }
    return originalLoad.apply(this, arguments);
  };

  try {
    const servicePath = path.join(process.cwd(), 'src/modules/bus/services/busDepartureService.js');
    delete require.cache[require.resolve(servicePath)];
    const service = require(servicePath);

    let rejectedCandidate = false;
    try { await service.resolveDriver('company-1', 'request:request-1'); } catch (error) {
      rejectedCandidate = /active driver account from this company/i.test(String(error.message || ''));
    }
    check(rejectedCandidate, 'A saved request must not be selectable before it becomes an active company driver membership.');

    const resolved = await service.resolveDriver('company-1', 'driver-membership-1');
    check(resolved.employee.id === 'driver-membership-1', 'The canonical active driver membership must resolve.');
    check(resolved.user.id === 'driver-user-1', 'The linked dedicated driver account must resolve.');
    check(resolved.assignment.assignable === true, 'A Partner Admin activated driver must be selectable for a departure.');
    check(resolved.assignment.operational === true, 'A cleared and verified activated driver must be operational.');

    employees[0].safetyStatus = 'pending_review';
    const pendingSafety = await service.resolveDriver('company-1', 'driver-membership-1');
    check(pendingSafety.assignment.assignable === true, 'An active company driver remains optionally selectable while compliance is pending.');
    check(pendingSafety.assignment.operational === false, 'Pending safety clearance remains visible as an operational warning.');
    check(pendingSafety.assignment.warnings.some((reason) => /safety clearance/i.test(reason)), 'The selector keeps the pending safety warning.');

    employees[0].status = 'suspended';
    let blockedSuspended = false;
    try { await service.resolveDriver('company-1', 'driver-membership-1'); } catch (error) {
      blockedSuspended = /active company membership/i.test(String(error.message || ''));
    }
    check(blockedSuspended, 'A suspended membership must not be selectable.');
  } finally {
    Module._load = originalLoad;
  }

  console.log(`Active-driver assignment source verification passed (${passed}/${passed}).`);
}

main().catch((error) => {
  console.error(error.message || error);
  process.exitCode = 1;
});
